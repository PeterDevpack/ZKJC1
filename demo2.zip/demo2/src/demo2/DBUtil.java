package demo2;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBUtil {
	public final static String DRIVER = "oracle.jdbc.OracleDriver";
	public final static String URL = "jdbc:oracle:thin:@ 172.16.129.137:1521:orcl";
	public final static String USER = "esignhf";
	public final static String PASSWORD = "esignhf";
	static{
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	public static Connection getConnection() throws SQLException{
		return DriverManager.getConnection(URL, USER, PASSWORD);
	}
	
	public static void close(Connection conn) throws Exception{
		if(conn != null){
			conn.close();
		}
	}
	
	public static void close(Statement pst) throws Exception{
		if(pst != null){
			pst.close();
		}
	}
	
	public static void close(ResultSet res) throws Exception{
		if(res != null){
			res.close();
		}
	}
	
/*	public static void main(String[] args) {
		DBUtil db = new DBUtil();
		try {
			System.out.println(db.getConnection());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}*/
}

