package com.uplooking.ibmmq;


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

/**
 * 函数功能： MQjava客户端实现
 */


public class MQClient {

    /**
     * Logger for this class
     */
    private static final Log logger = LogFactory.getLog(MQClient.class);
    private String strExtraSendXmlFileName = "C:\\test\\jndi.properties";
    private static Properties props; // Properties类表示一组持久的属性。 Properties可以保存到流中或从流中加载。 属性列表中的每个键及其对应的值都是一个字符串。



    /**
     *
     * 函数功能：TODO 主测试方法 <br>
     * 相关参数： <br>
     *
     * @param args
     *            修改记录： <br>
     */

    public static void main(String[] args) {

        MQClient test = new MQClient();
        // 发送消息
        test.putMsg();
        // 接收消息
        //test.getMsg();
    }

    public void putMsg() {
        // MQ发送数据
        try {
            // 建立MQ客户端应用上下文环境       getProperty(String key) 使用此属性列表中指定的键搜索属性。
            MQEnvironment.hostname = "192.168.43.230";//IP
            MQEnvironment.port =1414 ;//端口
            MQEnvironment.CCSID = 1381;//字符集
            MQEnvironment.channel = "FUWUQI_LIANJIE";//访问的服务器通道名
           // MQEnvironment.userID = "";//用户名
           // MQEnvironment.password = "";//密码
            // 连接队列管理器
            MQQueueManager qMgr = new MQQueueManager( "192.168.43.230");
            //设置打开选项以便打开用于输出的队列，如果队列管理器正在停止，我们也已设置了选项去应对不成功情况。
            int openOptions = MQC.MQOO_OUTPUT | MQC.MQOO_FAIL_IF_QUIESCING;
            // 打开队列
            MQQueue q = null;
            try {
            	System.out.println("111");
                // 建立通道的连接
                q = qMgr.accessQueue("FUWUQI_LIANJIE",openOptions);
            } catch (MQException me) {
                System.out.println("打开队列出现通讯异常" + me.getMessage() + "\n");
                return;
            }
            InputStream fins = new FileInputStream(new File( strExtraSendXmlFileName));
            byte[] data = new byte[fins.available()];
            fins.read(data);
            fins.close();
            MQMessage msg = new MQMessage();
            msg.write(data);
            // 放入消息
            q.put(msg);
            System.out.println("客户端发送数据包成功..");
            // 关闭队列
            q.close();
            // 断开队列管理器连接
            qMgr.disconnect();
        } catch (MQException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     *
     * 函数功能：TODO 获取数据 <br>
     * 修改记录： <br>
     */
    public void getMsg() {
        // MQ接收数据
        try {
            // 建立用上下文环境
            MQEnvironment.hostname = "192.168.80.1";
            MQEnvironment.port = 1414;
            MQEnvironment.CCSID = 1381;
            MQEnvironment.channel = "CNN_JACK";
          //  MQEnvironment.userID = props.getProperty("mqUserName");
           // MQEnvironment.password = props.getProperty("mqPassword");
            // 建立队列管理器
            MQQueueManager qMgr = new MQQueueManager("192.168.80.1");
            int openOptions = MQC.MQOO_INPUT_AS_Q_DEF| MQC.MQOO_FAIL_IF_QUIESCING;
            // 打开队列
            MQQueue q = qMgr.accessQueue("CNN_JACK",openOptions);
            MQGetMessageOptions mgo = new MQGetMessageOptions();
            mgo.options |= MQC.MQGMO_NO_WAIT;
            // 构造返回消息
            MQMessage msg = new MQMessage();
            if ((msg = fetchOneMsg(q)) != null) {
                byte[] xmlData = new byte[msg.getDataLength()];
                msg.readFully(xmlData);
                logger.info(new String(xmlData));
                System.out.println("接收服务器端返回数据包成功..\n接收数据为:\n"
                        + new String(xmlData));
            }
            // 关闭队列
            q.close();
            // 断开队列管理器
            qMgr.disconnect();
        } catch (MQException e) {
            logger.error(e);
            e.printStackTrace();
        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
        }
    }

    /**
     *
     * 函数功能：TODO 从队列中取出消息 <br>
     * 相关参数： <br>
     *
     * @param q
     * @return
     * @throws Exception
     *             修改记录： <br>
     */
    private static MQMessage fetchOneMsg(MQQueue q) throws Exception {
        MQGetMessageOptions mgo = new MQGetMessageOptions();
        mgo.options |= MQC.MQGMO_NO_WAIT;
        MQMessage msg = new MQMessage();
        try {
            // 获取消息
            q.get(msg, mgo);
        } catch (MQException e) {
            return null;
        }
        return msg;
    }
}
