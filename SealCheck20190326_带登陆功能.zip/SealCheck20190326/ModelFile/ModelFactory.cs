﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using Sinodata.Common;

namespace Sinodata.ModelsLib.ModelFile
{
    public class ModelFactory
    {
        /// <summary>
        /// 根据xml创建实体对象的初始化键值对
        /// xml需要是特定的格式
        /// </summary>
        /// <param name="xml"></param>
        /// <returns></returns>
        public static Dictionary<string, object> CreateModelDic(string xml) 
        {
            string xmlPath = PathHelper.GetAppPath("ModelFile\\"+xml);
            if (!File.Exists(xmlPath))
                throw new Exception("缺少文件" + xml);
            XmlDocument xdoc = new XmlDocument();
            xdoc.Load(xmlPath);
            XmlNodeList nods = xdoc.GetElementsByTagName("Model");
            if (nods == null || nods.Count == 0)
                throw new Exception("文件" + xml + "格式不正确,缺少Model");
            XmlNode xt = nods[0];
            string modelType = xt.Attributes["Type"].Value;
            if (string.IsNullOrEmpty(modelType))
                throw new Exception("文件" + xml + "格式不正确,缺少Type");
            Dictionary<string, object> reDic = new Dictionary<string, object>();
            foreach (XmlNode xnode in xdoc.GetElementsByTagName("MD"))
            {
                if (xnode.Attributes["Type"].Value == modelType)
                {
                    foreach (XmlNode xxnode in xnode.ChildNodes)
                    {
                        if (reDic.ContainsKey(xxnode.Attributes["key"].Value))
                            throw new Exception("文件" + xml + "格式不正确,有重复的项" + xxnode.Attributes["key"].Value);
                        else
                            reDic.Add(xxnode.Attributes["key"].Value, xxnode.Attributes["value"].Value);
                    }
                    break;
                }
            }
            return reDic;
        }

    }
}
