package demo2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class MyTest {
	
	public static Connection connection;
	public static PreparedStatement pstn;
	
	
	public static void main(String[] args) {
		try {
			connection = DBUtil.getConnection();
			String a =  p_truncate(connection);
			System.out.println(a);
			
			/*for (int i = 0; i < 500; i++) {
				System.out.println(i);
				insert(connection);
			}*/
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public static  String  p_truncate(Connection connection) {
		try {
			String sql = "call test_user.p_truncate()";
			pstn = connection.prepareCall(sql);
			pstn.execute();
			 return "11";
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DBUtil.close(pstn);
				//DBUtil.close(connection);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		 return "22";
	}

	public static  void insert(Connection connection) {
		try {
			connection.setAutoCommit(false);  
			
			String sql = "insert into MyTest values( ?)";
			pstn = connection.prepareStatement(sql);

			for (int i = 0; i < 500; i++) {
				pstn.setInt(1, i);
				pstn.addBatch(); 
			}
			pstn.executeBatch();
			connection.commit();
			pstn.clearBatch();
			connection.setAutoCommit(true);  
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				DBUtil.close(pstn);
				//DBUtil.close(connection);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		
	
	}
	
	
}
