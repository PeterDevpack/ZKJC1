package com.unitop.framework.util;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.unitop.bank.CommonUtil;
import com.unitop.bank.FunctionConfiguration;
import com.unitop.config.SystemConfig;
import com.unitop.sysmgr.bo.Clerk;

public class AccessFilter implements Filter {
	protected static Log _log = LogFactory.getLog(AccessFilter.class);

	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) arg0;
		HttpServletResponse response = (HttpServletResponse) arg1;
		HttpSession session = request.getSession();
		String path = request.getServletPath();
		String ipaddress = IPTool.getIpAddr(request);
		Clerk clerk = (Clerk) session.getAttribute("clerk");
		String adminCode = (String) session.getAttribute("admin");
		// ��ӡģ�����طſ����� �����ǿؼ�������ȡģ����Ϣ��ַ ��������Ϊ������Ϊ��session
		if (path.equals("/pingz.do")) 
		{
			String method = request.getParameter("method");
			if ("getPingzmb".equals(method))
			{
				chain.doFilter(request, response);
				return;
			}
		}
		//����ũ�����������ϵͳ��¼��֤����
		//20170512ͨ�ź��Ŀ��ؿ��ƣ�Ĭ��no
		
			if (path.equals("/SSOLogin.do")) 
			{   
				if("yes".equals(SystemConfig.getInstance().getValue("isNotSingle"))){
					chain.doFilter(request, response);
					return;
				}
				return;
			}
		if(path.equals("/login.do")){
			chain.doFilter(request, response);
			return;
		}
		if (path.equals("/syslogin.do")) 
		{
			chain.doFilter(request, response);
			return;
		}
		if (adminCode != null) 
		{
			request.setAttribute("totalRows", 0);
			chain.doFilter(request, response);
			return;
		}
		if(request.getHeader("referer")==null){
			request.getRequestDispatcher("/login.jsp").forward(request,response);
			return;
		}
		if (path.equals("/changepwd.do")) 
		{
			chain.doFilter(request, response);
			return;
		}
		if (clerk == null) 
		{
			if (path.equals("/logout.do")) 
			{
				request.getRequestDispatcher("/login.jsp").forward(request,response);
				return;
			}
			if (!path.equals("/login.do"))
			{
				request.getRequestDispatcher("/timeOutlogin.jsp").forward(request, response);
				return;
			}
		} else {
			if (!ipaddress.equals(clerk.getIp())) 
			{
				request.getRequestDispatcher("/login.jsp").forward(request, response);
				return;
			}
		}
		request.setAttribute("totalRows", 0);
		chain.doFilter(request, response);
	}

	@SuppressWarnings("unused")
	public void init(FilterConfig config) throws ServletException {
		ServletContext servletContext = config.getServletContext();
		SystemConfig systemConfig = SystemConfig.getInstance();
		
		CommonUtil.info("--> ����UFS���׺��ֵ�[Begin]");
		System.out.println("--> load ufs trade[Begin]");
		FunctionConfiguration fcfg = FunctionConfiguration.getInstance();
		System.out.println("--> load ufs trade[End]");
		CommonUtil.info("--> ����UFS���׺��ֵ�[Begin]");
		//EC���ҳ���ҳ������������
		if(servletContext.getAttribute("ec_yemjlts")==null)
		{
			servletContext.setAttribute("ec_yemjlts", systemConfig.getValue("baobys"));
		}
	}

	public void destroy() {
	}
}