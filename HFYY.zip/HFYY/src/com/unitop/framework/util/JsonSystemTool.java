package com.unitop.framework.util;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import com.unitop.sysmgr.bo.Clerk;

/*
 * by ldd 2013��03��26�� 
 */
public class JsonSystemTool {

	/*
	 * String to JSON For Clerk
	 */
	public static String toJsonForClerk(Clerk clerk){
		Map jsonMap = new HashMap();
		jsonMap.put("guiyh",clerk.getCode());
		jsonMap.put("guiyjgh",clerk.getOrgcode());
		jsonMap.put("guiyqx",clerk.getRoleStr());
		JSONObject json = JSONObject.fromObject(jsonMap);
		return json.toString().replace("\"", "\\\\\"");
	}
	
	public static String toJsonForClerkForZhang(Clerk clerk){
		Map jsonMap = new HashMap();
		jsonMap.put("guiyh",clerk.getCode());
		jsonMap.put("guiyjgh",clerk.getOrgcode());
		jsonMap.put("guiyqx",clerk.getRoleStr());
		JSONObject json = JSONObject.fromObject(jsonMap);
		return json.toString().replace("\"", "\\\"");
	}
	
}
