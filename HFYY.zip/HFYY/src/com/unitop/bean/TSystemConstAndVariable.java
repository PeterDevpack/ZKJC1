package com.unitop.bean;

public final class TSystemConstAndVariable { 
	// TZhanghglState
	public final static String Zhangh_Init = "0";

	public final static String Zhangh_Qry = "1";

	public final static String Zhangh_Add = "2";

	public final static String Zhangh_Del = "3";

	public final static String Zhangh_Upd = "4";

	// TUpdTimeStampType
	public final static String ZhanghSc = "0";

	public final static String YinqSc = "1";

	public final static String YinqZhSc = "2";

	public final static String WendSc = "3";

	public final static String PingzSc = "4";

	// TAddYinqFrom
	public final static String From_Gather = "0";

	public final static String From_Image = "1";

	// TYinqCaozType
	public final static String AddYz = "0";

	public final static String ChangeYz = "1";

	public final static String DelYz = "2";

	public final static String ZuofYz = "3";

	public final static String AddQz = "4";

	public final static String ChangeQz = "5";

	public final static String DelQz = "6";

	public final static String ZuofQz = "7";

	public final static String GatherFromImage = "8";

	public final static String CancelDel = "9";

	public final static String LagDelete = "10";

	public final static String GuasYq = "11";

	public final static String JiegYq = "12";

	// TVerifyNetPointInfoType
	public final static String cn_Null = "0";

	public final static String cn_Manage = "1";

	public final static String cn_Audit = "2";

	public final static String cn_Check = "3";

	public final static String cn_Search = "4";

	// TCheckFunctionMode
	public final static String Common_Check = "0";

	public final static String Special_Check = "1";
}
