package com.unitop.bean;

public class Param {
	private String cansbs;//������ʶ
	private String cansmc;//��������
	private String canslx;//��������
	private String cansfl;//��������
	private String cansz;//����ֵ
	private String canssm;//����˵��
	public String getCansbs() {
		return cansbs;
	}
	public void setCansbs(String cansbs) {
		this.cansbs = cansbs;
	}
	public String getCansfl() {
		return cansfl;
	}
	public void setCansfl(String cansfl) {
		this.cansfl = cansfl;
	}
	public String getCanslx() {
		return canslx;
	}
	public void setCanslx(String canslx) {
		this.canslx = canslx;
	}
	public String getCansmc() {
		return cansmc;
	}
	public void setCansmc(String cansmc) {
		this.cansmc = cansmc;
	}
	public String getCanssm() {
		return canssm;
	}
	public void setCanssm(String canssm) {
		this.canssm = canssm;
	}
	public String getCansz() {
		return cansz;
	}
	public void setCansz(String cansz) {
		this.cansz = cansz;
	}

	
}
