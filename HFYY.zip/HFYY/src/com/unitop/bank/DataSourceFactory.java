package com.unitop.bank;

import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.alibaba.druid.pool.DruidDataSource;
import com.mchange.v2.c3p0.ComboPooledDataSource;

public class DataSourceFactory {
	private static DriverManagerDataSource dataSource;
	private static ComboPooledDataSource cpds;
	private static DruidDataSource dds;
	private static BasicDataSource bds;
	private static Context context = null;

	// ���������ļ��е�connectType�ж���ʲô���͵����ӳ�
	public static DataSource getDataSourceByPool() 
	{ 
		DatabaseSet dbSet = DatabaseSet.getInstance();
		int dsType = Integer.parseInt((dbSet.getDbElement("dsType")).getValue());
		try
		{
			// value{0,1,2,3,4} <0-jdbc><1-c3p0><2-dbcp><3-druid><4-was>
			switch(dsType)
			{
				case 0:
					return getDataSourceByJDBC();
				case 1:
					return  getDataSourceByC3p0();
				case 2:
					return getDataSourceByDbcp();
				case 3:
					return getDataSourceByDruid();
				case 4:
					return getDataSourceByWas();
				default:
					return getDataSourceByJDBC();
			}
		}
		catch(NamingException e)
		{
			e.printStackTrace();
			return getDataSourceByJDBC();
		}
	}
	
	// by c3p0
	private static ComboPooledDataSource getDataSourceByC3p0()
	{
		if (cpds == null) {
			cpds = new ComboPooledDataSource();
			DatabaseSet dbSet = DatabaseSet.getInstance();
			try{
				//���ع�������
				cpds.setDriverClass((dbSet.getDbElement("pub_driverClass")).getValue());
				cpds.setJdbcUrl((dbSet.getDbElement("pub_jdbcUrl")).getValue());
				cpds.setUser((dbSet.getDbElement("pub_user")).getValue());
				cpds.setPassword((dbSet.getDbElement("pub_password")).getValue());
				//����c3p0˽������
				cpds.setMinPoolSize(Integer.parseInt((dbSet.getDbElement("c3p0_minPoolSize")).getValue()));
				cpds.setMaxPoolSize(Integer.parseInt((dbSet.getDbElement("c3p0_maxPoolSize")).getValue()));
				cpds.setInitialPoolSize(Integer.parseInt((dbSet.getDbElement("c3p0_initialPoolSize")).getValue()));
				cpds.setMaxIdleTime(Integer.parseInt((dbSet.getDbElement("c3p0_maxIdleTime")).getValue()));
				cpds.setAcquireIncrement(Integer.parseInt((dbSet.getDbElement("c3p0_acquireIncrement")).getValue()));
				cpds.setMaxStatements(Integer.parseInt((dbSet.getDbElement("c3p0_maxStatements")).getValue()));
				cpds.setIdleConnectionTestPeriod(Integer.parseInt((dbSet.getDbElement("c3p0_idleConnectionTestPeriod")).getValue()));
				cpds.setAcquireRetryAttempts(Integer.parseInt((dbSet.getDbElement("c3p0_acquireRetryAttempts")).getValue()));
				cpds.setBreakAfterAcquireFailure(Boolean.valueOf((dbSet.getDbElement("c3p0_breakAfterAcquireFailure")).getValue()));
				cpds.setTestConnectionOnCheckout(Boolean.valueOf((dbSet.getDbElement("c3p0_testConnectionOnCheckout")).getValue()));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return cpds;
	}

	// by dbcp
	private static BasicDataSource getDataSourceByDbcp()
	{
		if (bds == null) {
			bds = new BasicDataSource();
			DatabaseSet dbSet = DatabaseSet.getInstance();
			try{
				//���ع�������
				bds.setDriverClassName((dbSet.getDbElement("pub_driverClass")).getValue());
				bds.setUrl((dbSet.getDbElement("pub_jdbcUrl")).getValue());
				bds.setUsername((dbSet.getDbElement("pub_user")).getValue());
				bds.setPassword((dbSet.getDbElement("pub_password")).getValue());
				//����dbcp˽������
				bds.setInitialSize(Integer.parseInt((dbSet.getDbElement("dbcp_initialSize")).getValue()));
				bds.setMinIdle(Integer.parseInt((dbSet.getDbElement("dbcp_minIdle")).getValue()));
				bds.setMaxIdle(Integer.parseInt((dbSet.getDbElement("dbcp_maxIdle")).getValue()));
				bds.setMaxActive(Integer.parseInt((dbSet.getDbElement("dbcp_maxActive")).getValue()));
				bds.setMaxWait(Integer.parseInt((dbSet.getDbElement("dbcp_maxWait")).getValue()));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return bds;
	}
	
	// by druid
		private static DruidDataSource getDataSourceByDruid()
		{
			if (dds == null) {
				dds = new DruidDataSource();
				DatabaseSet dbSet = DatabaseSet.getInstance();
				try{
					//���ع�������
					dds.setDriverClassName((dbSet.getDbElement("pub_driverClass")).getValue());
					dds.setUrl((dbSet.getDbElement("pub_jdbcUrl")).getValue());
					dds.setUsername((dbSet.getDbElement("pub_user")).getValue());
					dds.setPassword((dbSet.getDbElement("pub_password")).getValue());
					//����druid˽������
					dds.setName((dbSet.getDbElement("druid_name")).getValue());
					dds.setInitialSize(Integer.parseInt((dbSet.getDbElement("druid_InitialSize")).getValue()));
					dds.setMinIdle(Integer.parseInt((dbSet.getDbElement("druid_MinIdle")).getValue()));
					dds.setMaxActive(Integer.parseInt((dbSet.getDbElement("druid_MaxActive")).getValue()));
					dds.setRemoveAbandoned(Boolean.valueOf((dbSet.getDbElement("druid_removeAbandoned")).getValue()));
					dds.setRemoveAbandonedTimeout(Integer.parseInt((dbSet.getDbElement("druid_removeAbandonedTimeout")).getValue()));
					dds.setLogAbandoned(Boolean.valueOf((dbSet.getDbElement("druid_logAbandoned")).getValue()));
					dds.setMaxWait(Integer.parseInt((dbSet.getDbElement("druid_maxWait")).getValue()));
					dds.setTimeBetweenEvictionRunsMillis(Integer.parseInt((dbSet.getDbElement("druid_timeBetweenEvictionRunsMillis")).getValue()));
					dds.setMinEvictableIdleTimeMillis(Integer.parseInt((dbSet.getDbElement("druid_minEvictableIdleTimeMillis")).getValue()));
					dds.setValidationQuery((dbSet.getDbElement("druid_validationQuery")).getValue());
					dds.setTestWhileIdle(Boolean.valueOf((dbSet.getDbElement("druid_testWhileIdle")).getValue()));
					dds.setTestOnBorrow(Boolean.valueOf((dbSet.getDbElement("druid_testOnBorrow")).getValue()));
					dds.setTestOnReturn(Boolean.valueOf((dbSet.getDbElement("druid_testOnReturn")).getValue()));
					dds.setPoolPreparedStatements(Boolean.valueOf((dbSet.getDbElement("druid_poolPreparedStatements")).getValue()));
					dds.setMaxPoolPreparedStatementPerConnectionSize(Integer.parseInt((dbSet.getDbElement("druid_maxPoolPreparedStatementPerConnectionSize")).getValue()));
					if("true".equals((dbSet.getDbElement("druid_filters")).getValue()))
					{
						dds.setFilters((dbSet.getDbElement("druid_filters")).getValue());
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			return dds;
		}
	
	// by jdbc
	private static DriverManagerDataSource getDataSourceByJDBC() {
		if (dataSource == null) {
			dataSource = new DriverManagerDataSource();
			DatabaseSet dbSet = DatabaseSet.getInstance();
			dataSource.setDriverClassName((dbSet.getDbElement("pub_driverClass")).getValue());
			dataSource.setUrl((dbSet.getDbElement("pub_jdbcUrl")).getValue());
			dataSource.setUsername((dbSet.getDbElement("pub_user")).getValue());
			dataSource.setPassword((dbSet.getDbElement("pub_password")).getValue());
		}
		return dataSource;
	}
	
	// by was
	public static DataSource getDataSourceByWas() throws NamingException 
	{  
		try
		{
			Context ctx = GetContext();
			return (DataSource) ctx.lookup(ConnectPoolName());	
		}
		catch (NamingException e)
		{
			throw e;
		}
	}



	private static Context GetContext() {
		try {
			if (context == null) {
				context = new InitialContext();
				/*System.out.println("context.getNameInNamespace()+  :"+context.getNameInNamespace());
				Hashtable env = context.getEnvironment();
				Enumeration keys = env.keys();
				if(keys.hasMoreElements()){
					Object key = keys.nextElement();
					Object value = env.get(key);
					System.out.println("ENV:"+key+"="+value);
				}*/
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return context;
	}


	private static String FConnectPoolName = "JNDI/OracleDataSource";

	private static String ConnectPoolName() {
		if (FConnectPoolName == null) {
			DatabaseSet dbSet = DatabaseSet.getInstance();
			FConnectPoolName = dbSet.getDbElement("ConnectPoolName").getValue();
		}
		return FConnectPoolName;
	}
	
	public static void release(){
		try {
			dataSource.getConnection().close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
