package com.unitop.bank;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import com.unitop.bean.DataSets;
import com.unitop.framework.util.StringUtil;
import com.unitop.util.ExceptionUtil;

public class JsonManage {
	public static String JsonToDBI(JSONObject json) {
		
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
//		UniDBI DBI = new UniDBI();
		DataSets dataSets =  new DataSets();
//		JSONObject jsonObject = JSONObject.fromObject(json);
//		Map<String, String> parameter = new HashMap<String, String>();
		UniDBInterface dbinterface = new UniDBInterface();
		String funcID = "";
		String ret = "";
		try{
 			String trade = (String) json.get("TRADE");
			JSONObject tradeData = json.getJSONObject("TRANSDATA");
			String qianfrq = (String)tradeData.get("qianfrq");
			if(!StringUtil.isEmpty(qianfrq)){
				if(qianfrq.indexOf("-")==-1){
					SimpleDateFormat sm = new SimpleDateFormat("yyyyMMdd");
					Date d = sm.parse(qianfrq);
					sm = new SimpleDateFormat("yyyy-MM-dd");
					qianfrq = sm.format(d);
					System.out.println(qianfrq);
					tradeData.put("qianfrq", qianfrq);
				}
			}
			Map parameterMap = new HashMap();
			
			
//			if("0000".equals(trade)){
//				/**
//				 * 0000Ϊͨ�ô��룬��ʾ�򵥲�ѯ��򵥽���
//				 */
//				SimpleTrades simple = new SimpleTrades();
//				ret = simple.operateSimpleTrades(tradeData);
//				
//			}else{
				/**
				 * ����trade����ָ���ض��ĸ��Ӳ�ѯ���ӽ���
				 */
				if("0001".equals(trade)){
					funcID = "com.unitop.bank.complextrans.impl.JsonGetAccountInfo";
				}
//				else if("0002".equals(trade)){
//					funcID = "com.unitop.bank.complextrans.impl.JsonSubmitAccountInfo";
//				}
				else if("0003".equals(trade)){
					funcID = "com.unitop.bank.complextrans.impl.VerifySubmit";
				}
//				else if("0004".equals(trade)){
//					funcID = "com.unitop.bank.complextrans.impl.JsonSecondCheck";
//				}
//				else if("0005".equals(trade)){
//					funcID = "com.unitop.bank.complextrans.impl.GetOCXParamters";
//				}
//				/**trade="0006"�Ͽ������˻���ϵ*/
//				else if("0006".equals(trade)){
//					funcID="com.unitop.bank.complextrans.impl.CoreExchange";
//				}else if("0007".equals(trade)){
//					funcID="com.unitop.bank.complextrans.impl.ExchangeOrg";
//				}else if("0008".equals(trade)){
//					//��ѯ��ӡӡ������
//					funcID="com.unitop.bank.complextrans.impl.GetSealNumsForCheck";
//				}
				list.add(tradeData);
				parameterMap.put(funcID, list);
				dataSets.setParamMap(parameterMap);
				ret = dbinterface.execSQL(funcID, new HashMap(), dataSets);
				
//			}
			
			json.put("TRANSDATAECHO", ret);
			json.put("TRANSDATA", "");
//			JSONObject jsonRet = JSONObject.fromObject(ret);
//			
//			JSONObject tradeEcho = new JSONObject();
//			tradeEcho.put("RETCODE", jsonRet.get("RETCODE"));
//			jsonRet.remove("RETCODE");
//			tradeEcho.put("RETTEXT", jsonRet.get("RETTEXT"));
//			jsonRet.remove("RETTEXT");
//			json.put("TRADEECHO",tradeEcho);
//			DBI.setFuncID(trade);
//			DBI.setParams(parameterMap);
//			DBI.setDataSets(dataSets);
//			CommonUtil.info("return.info:"+ret);
		} catch (Exception e) {
//			CommonUtil.error("JsonManage exception", e);
			e.printStackTrace();
			JSONObject jsonRet = new JSONObject();
			jsonRet.put("RETCODE", "1000");
			jsonRet.put("RETTEXT", "SINO:"+ExceptionUtil.exceptionTransfer(e));
			json.put("TRANSDATAECHO", jsonRet);

		} finally{
			return json.toString();
		}
	}
	public static void main(String[] args) {
		//yuanͬ�� �첽 
//		String json="{\"TRADE\" : \"0001\" , \"TRADECRC\" : \"\" , \"TRADESERIES\" : \"\" , \"TRANSDATA\" : {\"act\" : \"2\" , \"clerkorg\" : \"12\" , \"jine\" : \"100000\" , \"kehh\" : \"\" ,\"pingzpz\" : \"2\" , \"qianfrq\" : \"2017-04-28\" , \"resource\" : \"\" , \"sealtype\" : \"0\" , \"zhangh\"  : \"201704010001\"}}";
		/**
		 * �첽����
		 */
//		JSONObject common = JSONObject.fromObject("{\"SEALAPPURL\" : \"http://32.114.156.28:8080/JNYY/uniDBInterfaceForJson.jsp\",\"TELLNO\" : \"fzfh\",\"TELLORGNO\" : \"11701\",\"ACCORGNO\" : \"11701\",\"ACCNO\" : \"111111111111111111\",\"BILLDATE\" : \"20170422\",\"AMOUNT\" : \"0.00\",\"BILLNO\" :\"333\",\"BILLTYPE\" : \"00\",\"BUESSID\" : \"0001\",\"TASKID\" : \"0001\",\"SYSCODE\" : \"0001\",\"RESOURCE\" : \"0001\",\"DPI\" : \"200\",\"SEALTYPE\" : \"0\",\"TASKDATE\" : \"20170422\",\"IMAGENAME\" : \"C:/Users/chensq/Desktop/�½��ļ���/20161124113101.jpg\"}");
		/**
		 * ͬ����ȡӡ����Ϣ
		 */
		String json="{\"TRADE\":\"0001\",\"TRADECRC\":\"\",\"TRADESERIES\":\"\",\"TRANSDATA\":{\"act\":\"2\",\"xitlx\":\"1\",\"clerkorg\":\"12\",\"jine\":\"100000\",\"kehh\":\"\",\"pingzpz\":\"2\",\"qianfrq\":\"2017-04-28\",\"resource\":\"\",\"sealtype\":\"1\",\"zhangh\":\"123123123321\"}}";
		/**
		 * ��־����
		 */
//		String  json="{\"SEALGRONO\" : \"0\",\"TRADE\" : \"0003\",\"TRADECRC\" : \"\",\"TRADESERIES\" : \"\",\"TRANSDATA\" : {\"SEALS\" : [{\"checkmode\" : \"1\",\"checkmode_fz\" : \"1\",\"checkmode_mp\" : \"0\",\"checkmode_zk\" : \"1\",\"checkresult\" : \"2\",\"checkresult_fz\" : \"2\",\"checkresult_mp\" : \"2\",\"checkresult_zk\" : \"1\",\"sealinknum\" : \"3\",\"sealinktype\" : \"0\",\"yanybj\" : \"0\"}],\"act\" : \"0\",\"checkmode\" : \"1\",\"checkmode_fz\" : \"1\",\"checkmode_mp\" : \"0\",\"checkmode_zk\" : \"1\",\"checknum\" : \"20170427\",\"checkresult\" : \"2\",\"checkresult_fz\" : \"2\",\"checkresult_mp\" : \"2\",\"checkresult_zk\" : \"1\",\"chuprq\" : \"20170427\",\"clerknum\" : \"0000\",\"credencetype\" : \"20170427\",\"guiyjgh\" : \"00000\",\"money\" : \"55.22\",\"renwbs\" : \"082014042008500013\",\"transorg\" : \"0003\",\"weigyy\" : \"\",\"yanyly\" : \"\",\"yewbs\" : \"\",\"zhangh\" : \"201704010001\",\"zuhgz\" : \"\",\"zuhzh\" : \"201704010001\"}}";
		JSONObject common = JSONObject.fromObject(json);
		String ss=JsonToDBI(common);
		System.out.println(ss);
	}
}
 