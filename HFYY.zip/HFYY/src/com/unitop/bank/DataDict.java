package com.unitop.bank;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.andromda.core.common.XmlObjectFactory;

import com.unitop.bean.FieldAttribute;
import com.unitop.exception.UfSealException;

public class DataDict implements Serializable {

	private static final long serialVersionUID = 1L;

	private Map<String,FieldAttribute> dictMap = new HashMap<String,FieldAttribute>();

	private static DataDict datadict;

	/**
	 * Gets a Configuration instance from the given <code>uri</code>.
	 * 
	 * @deprecated
	 * @param uri
	 *            the URI to the configuration file.
	 * @return the configured instance.
	 */
	public static DataDict getInstance(final URL uri) {
		if (datadict == null)
			datadict = (DataDict) XmlObjectFactory.getInstance(DataDict.class)
					.getObject(uri);
		return datadict;
	}

	public static DataDict getInstance() {
		if (datadict == null) {
			datadict = new DataDict();
			try {
				reload();
			} catch (Exception e) {
				CommonUtil.error("DataDict getInstance exception",e);
			}
		}
		return datadict;
	}
	
	/**
	 * �����ֵ�
	 * @throws UfSealException
	 * @throws IOException
	 * @throws SQLException  
	 */
	@SuppressWarnings("unchecked")
	public static void reload() throws UfSealException, IOException, SQLException  {
		CommonUtil.debug("load DataDict..");
		datadict.removeAllField();
		// ��ѯ���ݿ�YQ_JIAOYZD
		List<Map<String,String>> list = new DBOperation().commondQueryWithMap("select * from YQ_JIAOYZD", new HashMap());
		for (int i = 0; i < list.size(); i++) {
			Map<String,String> row =  list.get(i);
			FieldAttribute field = new FieldAttribute();
			field.setName(row.get("ZIDM").toLowerCase());
			String length = row.get("ZIDCD");
			int endIndex = length.lastIndexOf('.');
			if (endIndex >= 0) {
				length = length.substring(0, endIndex);
			}
			field.setLength(length);
			field.setType((String) row.get("ZIDLX").toLowerCase());
			datadict.addField(field);
		}
		File file = new File("../DataDict.txt");
		CommonUtil.info(file.getAbsolutePath());
		if (!file.exists()) {
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file, false);
		for (Object key : datadict.dictMap.keySet()) {
			FieldAttribute field = datadict.getField(key.toString());
			fw.write("name:" + field.getName() + "\n");
			fw.write("length:" + field.getLength() + "\n");
			fw.write("type:" + field.getType() + "\n");
			fw.write("\n");
			fw.flush();
		}
		fw.close();
		datadict.travelDataDict();
	}

	public void addField(FieldAttribute field) {
		dictMap.put(field.getName().toLowerCase(), field);
	}

	public FieldAttribute getField(String name) {
		return (FieldAttribute) dictMap.get(name.toLowerCase());
	}

	public void removeAllField() {
		if (dictMap != null) {
			dictMap.clear();
		} else {
			dictMap = new HashMap<String,FieldAttribute>();
		}
	}
	public void travelDataDict(){
		CommonUtil.debug("===== DataDict =====");
		for (Object key : datadict.dictMap.keySet()) {
			FieldAttribute field = datadict.getField(key.toString());
			CommonUtil.debug("name:" + field.getName());
			CommonUtil.debug("length:" + field.getLength());
			CommonUtil.debug("type:" + field.getType());
			CommonUtil.debug("");
		}
		CommonUtil.debug("====================");
		CommonUtil.debug("");
	}
}
