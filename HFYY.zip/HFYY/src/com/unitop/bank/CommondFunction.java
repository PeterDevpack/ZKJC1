package com.unitop.bank;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.unitop.bean.TSystemConstAndVariable;

public class CommondFunction {
	
	public static String GetLeaveNetPointByNetPoint(String NetPoint,
			String Leave) throws Exception {
		String Sql = "select organnum from organarchives  WHERE WDFLAG="
				+ Leave + " connect by  organnum = PRIOR n_parentnum "
				+ "start with organnum='" + NetPoint + "'";
		Map sql_parameters = new HashMap();
		DBOperation sql_DBOperation = new DBOperation();
		List sql_List = sql_DBOperation
				.commondQueryWithMap(Sql, sql_parameters);
		Map sql_Map = new HashMap();
		String s = "";
		if ((sql_List != null) && (sql_List.size() > 0)) {
			sql_Map = (Map) sql_List.get(0);
			s = getMapValueByKeyIgnoreCase(sql_Map, "organnum");
		}
		return s;
	}

	public static boolean isCanOperationDesNetPoint(String souwd, String deswd)
			throws Exception {
		boolean RetVal = false;
		if (souwd.equals(deswd)) {
			RetVal = true;
		} else {
			String sql = "select nvl(count(*),0) as count from organarchives t "
					+ "where t.organnum= '"
					+ deswd
					+ "' "
					+ "connect by prior t.organnum=t.n_parentnum "
					+ "start with t.organnum='" + souwd + "'";
			JdbcTemplate Sel_NetPoint = new JdbcTemplate(DataSourceFactory
					.getDataSourceByPool());

			RetVal = Sel_NetPoint.queryForInt(sql) > 0;
		}
		return RetVal;
	}

	public static String getNetPointFlagByAccount(String account)
			throws Exception {
		String sql = "select netpointflag from accountinfo "
				+ "where account=:account";
		Map sql_parameters = new HashMap();
		sql_parameters.put("account", account);
		DBOperation sql_DBOperation = new DBOperation();
		List sql_List = sql_DBOperation
				.commondQueryWithMap(sql, sql_parameters);
		Map sql_Map = new HashMap();
		String s = "";
		if ((sql_List != null) && (sql_List.size() > 0)) {
			sql_Map = (Map) sql_List.get(0);
			s = getMapValueByKeyIgnoreCase(sql_Map, "netpointflag");
		}
		return s;
	}

	public static String selectParamValue(String WangdBs, String CansYym)
			throws Exception {
		String sql = "select parametervalue from systemparameter "
				+ "where parameterrefername=:parameterrefername";// and
		// netpointflag=:netpointflag";
		Map sql_parameters = new HashMap();
		sql_parameters.put("parameterrefername", CansYym);
		DBOperation sql_DBOperation = new DBOperation();
		List sql_List = sql_DBOperation
				.commondQueryWithMap(sql, sql_parameters);
		Map sql_Map = new HashMap();
		String s = "";
		if ((sql_List != null) && (sql_List.size() > 0)) {
			sql_Map = (Map) sql_List.get(0);
			s = getMapValueByKeyIgnoreCase(sql_Map, "parametervalue");
		}
		return s;
	}

	public static String getMapValueByKeyIgnoreCase(Map sql_Map, String KeyValue) {
		String ReturnValue = "";
		/*
		 * Add By Unitop.gq at 2007-6-11 ��sql_Map�л�ȡKeyValue��ֵ,�����ִ�Сд
		 */
		for (Iterator i = sql_Map.entrySet().iterator(); i.hasNext();) {
			Map.Entry e = (Map.Entry) i.next();
			String sql_Map_Key = (String) e.getKey();
			if (sql_Map_Key.trim().equalsIgnoreCase(KeyValue)) {
				ReturnValue = (String) sql_Map.get(sql_Map_Key);
				break;
			}
			;
		}
		return ReturnValue;
	}

	public static void getDateAndTime(String[] s) {
		java.util.Date operateDate = new java.util.Date();
		java.text.SimpleDateFormat operateDateFormat = new java.text.SimpleDateFormat(
				"yyyy-MM-dd#HH:mm:ss");
		String data = operateDateFormat.format(operateDate).toLowerCase();
		String[] datatemp = data.split("#");
		s[0] = datatemp[0].trim();
		s[1] = datatemp[1].trim();
	}

	public static boolean DataCanUpLoad(String netpointflag, String Zhangh)
			throws Exception {
		boolean Result;
		String NotNomalOption = selectParamValue(netpointflag, "NotNomalOption");
		if (NotNomalOption.equals("����")) {
			Result = false;
			return Result;
		}
		Result = true;
		String WhetherUpload_NotTongcTd = selectParamValue(netpointflag,
				"WhetherUpload_NotTongcTd");
		if (WhetherUpload_NotTongcTd.equals("��"))
			return Result;
		String Sel_TongcTd = "select allexchange from accountinfo where account=:account";
		Map Sel_TongcTd_parameters = new HashMap();
		Sel_TongcTd_parameters.put("account", Zhangh);
		DBOperation Sel_TongcTd_DBOperation = new DBOperation();
		List Sel_TongcTd_List = Sel_TongcTd_DBOperation.commondQueryWithMap(
				Sel_TongcTd, Sel_TongcTd_parameters);
		Map Sel_TongcTd_Map = new HashMap();
		if ((Sel_TongcTd_List != null) && (Sel_TongcTd_List.size() > 0)) {
			Sel_TongcTd_Map = (Map) Sel_TongcTd_List.get(0);
		} else {
			Sel_TongcTd_Map.put("allexchange", "");
		}
		return getMapValueByKeyIgnoreCase(Sel_TongcTd_Map, "allexchange")
				.equals("ͨ");
	}

	public static boolean IfUpdWangdBs_SealInk(String Zhangh, String WangdBs) {
		String Sel_IfUpdWangdBs = "select NVL(count(*),0) as count from sealinkinfo where account="
				+ "'" + Zhangh + "' and netpointflag<>" + "'" + WangdBs + "'";
		JdbcTemplate jt = new JdbcTemplate(DataSourceFactory.getDataSourceByPool());
		return jt.queryForInt(Sel_IfUpdWangdBs) > 0;
	}

	public static void ProcessTimeStamp(String TmpZhangh,
			String UpdTimeStampType) {
	}

	// netpointflag,ip,zhangh,caozlb,guiydm,guiymc,guiywdbs
	public static void WriteYewclLog(Map parameters) throws Exception {
		String WhetherClerkManageLogTableUpd = selectParamValue(
				(String) parameters.get("netpointflag"),
				"WhetherClerkManageLogTableUpd");
		String[] datatemp = new String[2];
		CommondFunction.getDateAndTime(datatemp);
		String date = datatemp[0].trim();
		String time = datatemp[1].trim();
		if (WhetherClerkManageLogTableUpd.equals("��")) {
			StringBuffer sql = new StringBuffer();
			sql.append("insert into accountmanagelog");
			sql
					.append("(account,managedate,managetime,managetype,clerknum,clerkname,ip,str1,str2,str3) ");
			sql.append("values");
			sql
					.append("(:account,:managedate,:managetime,:managetype,:clerknum,:clerkname,:ip,:str1,:str2,:str3)");
			Map sqlparameters = new HashMap();
			sqlparameters.put("ip", parameters.get("ip"));
			sqlparameters.put("account", parameters.get("zhangh"));
			sqlparameters.put("managedate", date);
			sqlparameters.put("managetime", time);
			sqlparameters.put("managetype", parameters.get("caozlb"));
			sqlparameters.put("clerknum", parameters.get("guiydm"));
			sqlparameters.put("clerkname", parameters.get("guiymc"));

			String WhetherUseTaiwHerXunSpecial = selectParamValue(
					(String) parameters.get("netpointflag"),
					"WhetherUseTaiwHerXunSpecial");
			String CaozLb = "";
			if (CaozLb.length() == 4)
				((String) parameters.get("caozlb")).substring(0, 4);

			if ((WhetherClerkManageLogTableUpd.equals("��"))
					&& (CaozLb.equals("��������") || CaozLb.equals("�������") || CaozLb
							.equals("����У��"))) {
				sqlparameters.put("str1", parameters.get("guiywdbs"));
			} else {
				String Sel_Zhxx = "select * from accountinfo where account=:account";
				Map Sel_Zhxx_parameters = new HashMap();
				Sel_Zhxx_parameters.put("account", parameters.get("zhangh"));
				DBOperation Sel_Zhxx_DBOperation = new DBOperation();
				List Sel_Zhxx_List = Sel_Zhxx_DBOperation.commondQueryWithMap(
						Sel_Zhxx, Sel_Zhxx_parameters);
				Map Sel_Zhxx_Map = new HashMap();
				if ((Sel_Zhxx_List != null) && (Sel_Zhxx_List.size() > 0)) {
					Sel_Zhxx_Map = (Map) Sel_Zhxx_List.get(0);
				} else {
					Sel_Zhxx_Map.put("incomerange", "");
					Sel_Zhxx_Map.put("netpointflag", "");
				}
				if (WhetherUseTaiwHerXunSpecial.equals("��"))
					sqlparameters.put("str1", getMapValueByKeyIgnoreCase(
							Sel_Zhxx_Map, "incomerange"));
				else
					sqlparameters.put("str1", getMapValueByKeyIgnoreCase(
							Sel_Zhxx_Map, "netpointflag"));
			}
			sqlparameters.put("str2", "");
			sqlparameters.put("str3", "");
			DBOperation.updateDB(sql.toString(), sqlparameters);
		} else {
			StringBuffer sql = new StringBuffer();
			sql.append("insert into accountmanagelog");
			sql
					.append("(account,managedate,managetime,managetype,clerknum,clerkname,ip) ");
			sql.append("values");
			sql
					.append("(:account,:managedate,:managetime,:managetype,:clerknum,:clerkname,:ip)");

			Map sqlparameters = new HashMap();
			sqlparameters.put("ip", parameters.get("ip"));
			sqlparameters.put("account", parameters.get("zhangh"));
			sqlparameters.put("managedate", date);
			sqlparameters.put("managetime", time);
			sqlparameters.put("managetype", parameters.get("caozlb"));
			sqlparameters.put("clerknum", parameters.get("guiydm"));
			sqlparameters.put("clerkname", parameters.get("guiymc"));
			DBOperation.updateDB(sql.toString(), sqlparameters);
		}
	}

	// netpointflag,ip,zhangh,caozlb,guiydm,guiymc,guiywdbs,newguiydm,newguiymc
	public static void NewWriteYewclLog(Map parameters) throws Exception {
		String WhetherClerkManageLogTableUpd = selectParamValue(
				(String) parameters.get("netpointflag"),
				"WhetherClerkManageLogTableUpd");
		String[] datatemp = new String[2];
		CommondFunction.getDateAndTime(datatemp);
		String date = datatemp[0].trim();
		String time = datatemp[1].trim();
		if (WhetherClerkManageLogTableUpd.equals("��")) {
			StringBuffer sql = new StringBuffer();
			sql.append("insert into accountmanagelog");
			sql
					.append("(account,managedate,managetime,managetype,clerknum,clerkname,ip,str1,str2,str3)");
			sql.append("values");
			sql
					.append("(:account,:managedate,:managetime,:managetype,:clerknum,:clerkname,:ip,:str1,:str2,:str3)");
			Map sqlparameters = new HashMap();

			sqlparameters.put("ip", parameters.get("ip"));
			sqlparameters.put("account", parameters.get("zhangh"));
			sqlparameters.put("managedate", date);
			sqlparameters.put("managetime", time);
			sqlparameters.put("managetype", parameters.get("caozlb"));
			sqlparameters.put("clerknum", parameters.get("guiydm"));
			sqlparameters.put("clerkname", parameters.get("guiymc"));

			String Sel_Zhxx = "select * from accountinfo where account=:account";
			Map Sel_Zhxx_parameters = new HashMap();
			Sel_Zhxx_parameters.put("account", parameters.get("zhangh"));
			DBOperation Sel_Zhxx_DBOperation = new DBOperation();
			List Sel_Zhxx_List = Sel_Zhxx_DBOperation.commondQueryWithMap(
					Sel_Zhxx, Sel_Zhxx_parameters);
			Map Sel_Zhxx_Map = new HashMap();
			if ((Sel_Zhxx_List != null) && (Sel_Zhxx_List.size() > 0)) {
				Sel_Zhxx_Map = (Map) Sel_Zhxx_List.get(0);
			} else {
				Sel_Zhxx_Map.put("incomerange", "");
				Sel_Zhxx_Map.put("netpointflag", "");
			}

			String WhetherUseTaiwHerXunSpecial = selectParamValue(
					(String) parameters.get("netpointflag"),
					"WhetherUseTaiwHerXunSpecial");
			if (WhetherUseTaiwHerXunSpecial.equals("��"))
				sqlparameters.put("str1", getMapValueByKeyIgnoreCase(
						Sel_Zhxx_Map, "incomerange"));
			else
				sqlparameters.put("str1", getMapValueByKeyIgnoreCase(
						Sel_Zhxx_Map, "netpointflag"));
			sqlparameters.put("str2", parameters.get("newguiydm"));
			sqlparameters.put("str3", parameters.get("newguiymc"));
			DBOperation.updateDB(sql.toString(), sqlparameters);
		} else {
			StringBuffer sql = new StringBuffer();
			sql.append("insert into accountmanagelog");
			sql
					.append("(account,managedate,managetime,managetype,clerknum,clerkname,ip)");
			sql.append("values");
			sql
					.append("(:account,:managedate,:managetime,:managetype,:clerknum,:clerkname,:ip)");

			Map sqlparameters = new HashMap();
			sqlparameters.put("ip", parameters.get("ip"));
			sqlparameters.put("account", parameters.get("zhangh"));
			sqlparameters.put("managedate", date);
			sqlparameters.put("managetime", time);
			sqlparameters.put("managetype", parameters.get("caozlb"));
			sqlparameters.put("clerknum", parameters.get("newguiydm"));
			sqlparameters.put("clerkname", parameters.get("newguiymc"));
			DBOperation.updateDB(sql.toString(), sqlparameters);
		}
	}

	// netpointflag,ip,zhangh,guiydm,guiymc,guiywdbs
	public static void ProcessWriteYewclLog(Map parameters, String TmpType,
			String DbYinqbh, String YinqBgh) throws Exception {
		String CaozLb = "";
		if (TmpType.equals(TSystemConstAndVariable.AddYz))
			CaozLb = "����ӡ��~";
		else if (TmpType.equals(TSystemConstAndVariable.DelYz))
			CaozLb = "ɾ��ӡ��~";
		else if (TmpType.equals(TSystemConstAndVariable.ZuofYz))
			CaozLb = "����ӡ��~";
		else if (TmpType.equals(TSystemConstAndVariable.ChangeYz))
			CaozLb = "���ӡ��~";
		else if (TmpType.equals(TSystemConstAndVariable.AddQz))
			CaozLb = "����ǩ��~";
		else if (TmpType.equals(TSystemConstAndVariable.DelQz))
			CaozLb = "ɾ��ǩ��~";
		else if (TmpType.equals(TSystemConstAndVariable.ZuofQz))
			CaozLb = "����ǩ��~";
		else if (TmpType.equals(TSystemConstAndVariable.ChangeQz))
			CaozLb = "���ǩ��~";
		else if (TmpType.equals(TSystemConstAndVariable.GatherFromImage))
			CaozLb = "�ļ��ɼ�~";
		else if (TmpType.equals(TSystemConstAndVariable.CancelDel))
			CaozLb = "ȡ��ɾ��~";
		else if (TmpType.equals(TSystemConstAndVariable.LagDelete))
			CaozLb = "�ͺ�ɾ��~";
		else if (TmpType.equals(TSystemConstAndVariable.GuasYq))
			CaozLb = "��ʧӡǩ~";
		else if (TmpType.equals(TSystemConstAndVariable.JiegYq))
			CaozLb = "���ӡǩ~";
		else
			CaozLb = "��������~";
		CaozLb = CaozLb + DbYinqbh + "~" + YinqBgh;
		parameters.put("caozlb", CaozLb);
		WriteYewclLog(parameters);
	}
}