package com.unitop.bank;

import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.jdbc.datasource.DataSourceUtils;
/**
 * ���������
 * @author luoxiaoyi
 *
 */
public class TransHandle {
	
	private static TransHandle handle ;
	/**
	 * ��ȡ��������
	 * @return
	 */
	public static TransHandle getInstance(){
		if(null == handle ){
			handle = new TransHandle();
		}
		return handle;
	}
	/**
	 * ��������
	 * @return
	 * @throws SQLException
	 */
	public static Connection beginTrans() throws SQLException{
		Connection conn = null;
		conn = DataSourceUtils.getConnection(DataSourceFactory.getDataSourceByPool());
		conn.setAutoCommit(false);
		return conn;
	}
	/**
	 * �ύ����
	 * @return
	 * @throws SQLException
	 */
	public static Connection commitTrans() throws SQLException{
		Connection conn = null;
		conn = DataSourceUtils.getConnection(DataSourceFactory.getDataSourceByPool());
		conn.commit();
		return conn;
	}

	/**
	 * �ع�����
	 * @return
	 * @throws SQLException
	 */
	public static Connection rollbackTrans() throws SQLException{
		Connection conn = null;
		conn = DataSourceUtils.getConnection(DataSourceFactory.getDataSourceByPool());
		conn.rollback();
		return conn;
	}
}
