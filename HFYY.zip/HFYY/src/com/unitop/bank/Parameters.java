package com.unitop.bank;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.unitop.bean.Param;
import com.unitop.exception.UfSealException;

public class Parameters {
	private static Parameters instance = null;

	private HashMap<String,Param> parameters = new HashMap<String,Param>();

	public static Parameters getInstance() {
		if (instance == null) {
			instance = new Parameters();
			try {
				reload();
			} catch (Exception e) {
				CommonUtil.error("Parameters getInstance exception",e);
			}
		}
		return instance;
	}

	/**
	 * ����ϵͳ����
	 * @throws UfSealException
	 * @throws SQLException 
	 */
	@SuppressWarnings("unchecked")
	public static void reload() throws UfSealException, SQLException  {
		CommonUtil.debug("load Parameters..");
		instance.removeAllParameter();
		DBOperation dbo = new DBOperation();
		String sql = "select * from YQ_KONGZCS";
		List<Map<String,String>> l = dbo.commondQueryWithMap(sql, new HashMap());
		HashMap<String,String> map = null;
		for (int i = 0; i < l.size(); i++) {
			map = (HashMap<String,String>) l.get(i);
			Param param = new Param();
			param.setCansbs(map.get("CANSBS").toLowerCase());
			param.setCansfl(map.get("CANSFL").toLowerCase());
			param.setCanslx(map.get("CANSLX").toLowerCase());
			param.setCansmc(map.get("CANSMC").toLowerCase());
			param.setCanssm(map.get("CANSSM").toLowerCase());
			param.setCansz(map.get("CANSZ").toLowerCase());
			if("".equalsIgnoreCase(param.getCansbs())){
				CommonUtil.error("������ʶΪ�գ�");
				throw new UfSealException("������ʶΪ�գ�");
			} 
			instance.addParam(param);
		}
		instance.travelParameters();
	}
	
	public void addParam(Param param){
		parameters.put(param.getCansbs(), param);
	}
	public Param getParam(String cansbs){
		return (Param) parameters.get(cansbs);
	}
	public void removeAllParameter() {
		if (parameters == null) {
			parameters = new HashMap<String,Param>();
		} else {
			parameters.clear();
		}
	}
	
//	public String getValue(String k) {
//		return parameters.get(k);
//	}
	public void travelParameters(){
		CommonUtil.debug("===== Parameters =====");
		for(Object key : parameters.keySet()){
			CommonUtil.debug("key: " + key);
			Param param = (Param) parameters.get(key);
			CommonUtil.debug("������ʶ: " + param.getCansbs());
			CommonUtil.debug("��������: " + param.getCansmc());
			CommonUtil.debug("����ֵ: " + param.getCansz());
			CommonUtil.debug("��������: " + param.getCansfl());
			CommonUtil.debug("��������: " + param.getCanslx());
			CommonUtil.debug("����˵��: " + param.getCanssm());
		}
		CommonUtil.debug("======================");
		CommonUtil.debug("");
	}
}
