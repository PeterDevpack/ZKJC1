package com.unitop.bank;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.RdbmsOperation;
import org.springframework.util.Assert;

import com.unitop.bean.FieldAttribute;
import com.unitop.bean.Param;
import com.unitop.bean.ParsedSql;
import com.unitop.exception.UfSealException;
import com.unitop.util.Base64;

public class ParameterUtils {
	private static final char[] PARAMETER_SEPARATORS = new char[] { '"', '\'',
			':', '&', ',', ';', '(', ')', '|', '=', '+', '-', '*', '%', '/',
			'\\', '<', '>', '^' };

	public static Map parseStringParametersToObjects(Map stringMap) throws UfSealException {
		DataDict dataDict = DataDict.getInstance();
		Set key = stringMap.keySet();
		Map<String, Object> newMap = new HashMap<String, Object>();
		for (Iterator iter = key.iterator(); iter.hasNext();) {
			String element = (String) iter.next();
			FieldAttribute attribute = dataDict.getField(element);
			if (null == attribute) {
				throw new UfSealException(element+"���ֵ��п���δ����!");
			}
			String type = attribute.getType();
			if (type == null || "".equals(type)) {
				CommonUtil.info(type + " �ֶ����ֵ���û��������!");
			}
			if (type.equals("string")) {
				if ((stringMap.get(element)) == null) {
					newMap.put(element, new String(""));
				} else {
					newMap.put(element, stringMap.get(element));
				}
			} else if (type.equals("integer")) {
				if ((stringMap.get(element)) == null || "".equals(stringMap.get(element))) {
					newMap.put(element, new Integer(0));
				} else {
					newMap.put(element, new Integer((String) stringMap.get(element)));
				}
			} else if (type.equals("float")) {
				if ((stringMap.get(element)) == null) {
					newMap.put(element, new Double(0));
				} else {
					newMap.put(element, new Double((String) stringMap.get(element)));
				}
			} else if (type.equals("blob")) {
				String value = (String) stringMap.get(element);
				if (value.equals("")) {
					SqlLobValue lobValue = new SqlLobValue("");
					newMap.put(element, lobValue);
				} else {
					Parameters params = Parameters.getInstance();
					Param param = params.getParam("isBase64");
					byte[] b;
					if (null != param) {
						String paramVale = param.getCansz();
						if ("1".equals(paramVale)) {
							b = value.getBytes();
						} else {
							b = Base64.decode(value);
						}
					} else {
						b = Base64.decode(value);
					}
					SqlLobValue lobValue = new SqlLobValue(b);
					newMap.put(element, lobValue);
				}
			}
		}
		return newMap;
	}

	/**
	 * 
	 * @param operation
	 * @param oldsql
	 * @param parameterMap
	 * @throws UfSealException
	 */
	@SuppressWarnings("unchecked")
	public static void declareParameterType(RdbmsOperation operation, String oldsql, Map parameterMap) throws UfSealException {
		DataDict dataDict = DataDict.getInstance();
		ParsedSql parsedsql = parseSqlStatement(oldsql);
		Map newMap = new HashMap();
		String[] parameterNames = parsedsql.getParameterNames();
		for (int i = 0; i < parameterNames.length; i++) {
			String parameterName = parameterNames[i];
			newMap.put(parameterName.toLowerCase(), parameterMap.get(parameterName.toLowerCase()));
		}
		for (int i = 0; i < parameterNames.length; i++) {
			String element = parameterNames[i];
			FieldAttribute attribute = dataDict.getField(element.toLowerCase());
			String type = attribute.getType();
			if (type == null || "".equals(type)) {
				CommonUtil.info(type + " �ֶ����ֵ���û��������!");
				throw new UfSealException(type +  " �ֶ����ֵ���û��������!");
			}
			if (type.equals("string")) {
				operation.declareParameter(new SqlParameter(element.toLowerCase(), Types.VARCHAR));
			} else if (type.equals("integer")) {
				operation.declareParameter(new SqlParameter(element.toLowerCase(), Types.INTEGER));
			} else if (type.equals("float")) {
				operation.declareParameter(new SqlParameter(element.toLowerCase(), Types.DOUBLE));
			} else if (type.equals("blob")) {
				operation.declareParameter(new SqlParameter(element.toLowerCase(), Types.BLOB));
			} else {
				CommonUtil.error("�������Ͳ�����!");
				throw new UfSealException("�������Ͳ�����!");
			}
		}
	}

	public static ParsedSql parseSqlStatement(String sql) {
		Assert.notNull(sql, "SQL must not be null");
		List<String> parameters = new ArrayList<String>();
		Map<String,String> namedParameters = new HashMap<String,String>();
		ParsedSql parsedSql = new ParsedSql(sql);
		char[] statement = sql.toCharArray();
		StringBuffer newSql = new StringBuffer();
		boolean withinQuotes = false;
		char currentQuote = '-';
		int namedParameterCount = 0;
		int unnamedParameterCount = 0;
		int totalParameterCount = 0;
		int i = 0;
		while (i < statement.length) {
			char c = statement[i];
			if (withinQuotes) {
				if (c == currentQuote) {
					withinQuotes = false;
					currentQuote = '-';
				}
				newSql.append(c);
			} else {
				if (c == '"' || c == '\'') {
					withinQuotes = true;
					currentQuote = c;
					newSql.append(c);
				} else {
					if (c == ':' || c == '&') {
						int j = i + 1;
						while (j < statement.length
								&& !isParameterSeparator(statement[j])) {
							j++;
						}
						if (j - i > 1) {
							String parameter = sql.substring(i + 1, j);
							if (!namedParameters.containsKey(parameter)) {
								namedParameters.put(parameter, parameter);
								namedParameterCount++;
							}
							newSql.append("?");
							parameters.add(parameter);
							totalParameterCount++;
						} else {
							newSql.append(c);
						}
						i = j - 1;
					} else {
						newSql.append(c);
						if (c == '?') {
							unnamedParameterCount++;
							totalParameterCount++;
						}
					}
				}
			}
			i++;
		}
		parsedSql.setNewSql(newSql.toString());
		parsedSql.setParameterNames((String[]) parameters.toArray(new String[parameters.size()]));
		return parsedSql;
	}

	private static boolean isParameterSeparator(char c) {
		if (Character.isWhitespace(c)) {
			return true;
		}
		for (int i = 0; i < PARAMETER_SEPARATORS.length; i++) {
			if (c == PARAMETER_SEPARATORS[i]) {
				return true;
			}
		}
		return false;
	}
}
