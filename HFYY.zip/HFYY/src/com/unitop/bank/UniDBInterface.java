package com.unitop.bank;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

public class UniDBInterface {
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * ���ӽ����е��ü򵥽���
	 * 
	 * @param funcID
	 * @param paraMap
	 * @param List
	 *            :��ʾ�����������ʱ
	 * @return ����map��key������rows������error��;valueΪһ��List��List��Ϊmap��list�ĳ���Ϊ��¼��
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> execSql(String funcID,
			List<Map<String, String>> datasets, Connection conn) {
		Map<String, Object> reMap = new HashMap<String, Object>();
		try {
			FunctionConfiguration configration = FunctionConfiguration.getInstance();
			Function function = configration.getFunction(funcID);
			if (null == function) {
				throw new UfSealException(funcID + "���ײ�����");
			}
			String sqlType = function.getType();
			if (sqlType == null) {
				throw new Exception(sqlType + "��𲻴���");
			}
			int cntParam = datasets.size();
			if (1 == cntParam) {
				Map<String, String> paraMap = datasets.get(0);
				if (sqlType.equals("simpleQuery")) {
					DBOperation dbo = new DBOperation();
					List<Map<String, String>> list = dbo.commondQueryToList(
							function.getSql(), paraMap, conn);
					reMap.clear();
					reMap.put("error", "");
					reMap.put("rows", list);
				} else if (sqlType.equals("simpleTrans")) {
					DBOperation.updateSQL(function.getSql(), paraMap, conn);
					reMap.clear();
					reMap.put("error", "");
				}
			} else if (cntParam > 1) {
				for (int i = 0; i < cntParam; i++) {
					if (sqlType.equals("simpleTrans")) {
						DBOperation.updateSQL(function.getSql(), datasets
								.get(i), conn);
						reMap.clear();
						reMap.put("error", "");
					}
				}
			} else {
				reMap.clear();
				reMap.put("error", "�����б�Ϊ�գ�");
			}
			return reMap;
		} catch (Exception e) {
			CommonUtil.error(funcID + "Exception : ", e);
			String ErrMsg = "";
			if (e.toString() == "java.lang.NullPointerException") {
				ErrMsg = "�쳣��:" + e.toString();
			} else {
				ErrMsg = retrunErrorMsg(e);
			}
			reMap.clear();
			reMap.put("error", ErrMsg);
			return reMap;
		}
	}

	@SuppressWarnings("unchecked")
	public Map execSql(String funcID, Map paraMap) {
		Map<String, Object> reMap = new HashMap<String, Object>();
		try {
			FunctionConfiguration configration = FunctionConfiguration
					.getInstance();
			Function function = configration.getFunction(funcID);
			if (null == function) {
				throw new UfSealException(funcID + "���ײ�����");
			}
			String sqlType = function.getType();
			if (null == sqlType || 0 == sqlType.length())
				throw new Exception(sqlType + "��𲻴���");
			if (sqlType.equals("simpleQuery")) {
				DBOperation dbo = new DBOperation();
				List list = dbo.commondQueryWithMap(function.getSql(), paraMap);
				reMap.clear();
				reMap.put("error", "");
				reMap.put("rows", list);
			} else if (sqlType.equals("complexQuery")) {
				Class cls = Class.forName(this.validateURI(function.getId()));
				Class partypes[] = new Class[1];
				partypes[0] = Map.class;
				Method method = cls.getMethod("executeToMap", partypes);
				Object[] arglist = new Object[1];
				arglist[0] = paraMap;
				List list = (List) method.invoke(cls.newInstance(), arglist);
				reMap.clear();
				reMap.put("error", "");
				reMap.put("rows", list);
			} else if (sqlType.equals("simpleTrans")) {
				DBOperation.updateDB(function.getSql(), paraMap);
				reMap.clear();
				reMap.put("error", "");
			} else if (sqlType.equals("complexTrans")) {
				Class cls = Class.forName(this.validateURI(function.getId()));
				Class partypes[] = new Class[1];
				partypes[0] = Map.class;
				Method method = cls.getMethod("execute", partypes);
				Object[] arglist = new Object[1];
				arglist[0] = paraMap;
				String rMessage = (String) method.invoke(cls.newInstance(),
						arglist);
				List list = new ArrayList();
				list.add(rMessage);
				reMap.clear();
				reMap.put("error", "");
				reMap.put("rows", list);
			} else if (sqlType.equals("procedureTrans")) {
				DBOperation.excuteCall(function.getSql(), paraMap);
				reMap.clear();
				reMap.put("error", "");
			}
			return reMap;
		} catch (Exception e) {
			String ErrMsg = "";
			if (e.toString() == "java.lang.NullPointerException") {
				ErrMsg = "�쳣��:" + e.toString();
			} else {
				ErrMsg = retrunErrorMsg(e);
			}
			reMap.clear();
			reMap.put("error", ErrMsg);
			return reMap;
		}
	}

	/**
	 * ִ�н��ף���Ҫִ���Ͻ��ף�
	 * 
	 * @param funcID
	 * @param paraMap
	 * @return ����xml�ַ���
	 */
	@SuppressWarnings("unchecked")
	public String execSQL(String funcID, Map<String, String> paraMap) {
		String result = "";
		funcID = CommonOperation.exchangeURI(funcID);
		FunctionConfiguration configration = FunctionConfiguration
				.getInstance();
		Function function = configration.getFunction(funcID);
		try {
			if (null == function) {
				CommonUtil.info(funcID + "���ײ�����!");
				throw new UfSealException(funcID + "���ײ�����!");
			}
			String sqlType = function.getType();
			if (sqlType == null || "".equals(sqlType)) {
				CommonUtil.info(sqlType + "������𲻴���!");
				throw new UfSealException(sqlType + "������𲻴���!");
			}
			if (sqlType.equalsIgnoreCase("simpleQuery")) {
				result = DBOperation.commondQueryToXML(function.getSql(),
						paraMap);
			} else if (sqlType.equalsIgnoreCase("simpleTrans")) {
				DBOperation.updateDB(function.getSql(), paraMap);
				result = "<root error=''></root>";
			} else if (sqlType.equalsIgnoreCase("complexQuery")) {
				Class cls = Class.forName(this.validateURI(function.getId()));
				Class partypes[] = new Class[1];
				partypes[0] = Map.class;
				Method method = cls.getMethod("execute", partypes);
				Object[] arglist = new Object[1];
				arglist[0] = paraMap;
				result = (String) method.invoke(cls.newInstance(), arglist);
			} else if (sqlType.equalsIgnoreCase("complexTrans")) {
				Class cls = Class.forName(this.validateURI(function.getId()));
				Class partypes[] = new Class[1];
				partypes[0] = Map.class;
				Method method = cls.getMethod("execute", partypes);
				Object[] arglist = new Object[1];
				arglist[0] = paraMap;
				method.invoke(cls.newInstance(), arglist);
				result = "<root error=''></root>";
			} else if (sqlType.equalsIgnoreCase("procedureTrans")) {
				DBOperation.excuteCall(function.getSql(), paraMap);
				result = "<root error=''></root>";
			} else if (sqlType.equalsIgnoreCase("systemconfig")) {
				String controlflag = ((String) paraMap.get("controlflag"))
						.trim();
				if ("".equals(controlflag) || controlflag.length() == 0) {
					throw new UfSealException("���Ʋ���Ϊ�գ���������Ʋ�����");
				}
				if ("1001".equals(controlflag)) {
					FunctionConfiguration.reload();
				} else if ("1002".equals(controlflag)) {
					DataDict.reload();
				} else if ("1003".equals(controlflag)) {
					Parameters.reload();
				} else if ("1".equals(controlflag) || "0".equals(controlflag)
						|| "2".equals(controlflag) || "3".equals(controlflag)
						|| "-1".equals(controlflag)) {
					CommonUtil.util = new CommonUtil(controlflag);
				}
				result = "<root error=''></root>";
			}
			if (null == result || 0 == result.length()) {
				throw new UfSealException("������ͱ����Ƿ���ȷ�����ر���Ϊ�գ�");
			}
			return result;
		} catch (SQLException e) {
			CommonUtil.error("SQLException:", e);
			return generateErrorMsg(retrunErrorMsg(e));
		} catch (IOException e) {
			CommonUtil.error("IOException:", e);
			return generateErrorMsg(retrunErrorMsg(e));
		} catch (UfSealException e) {
			CommonUtil.error("UfSealException:", e);
			return generateErrorMsg(e.getMessage());
		} catch (Exception e) {
			CommonUtil.error("Exception:", e);
			return generateErrorMsg(retrunErrorMsg(e));
		}
	}

	/**
	 * ִ����ϡ������ཻ��
	 * 
	 * @param funcID
	 * @param paraMap
	 * @param datasets
	 * @return xml
	 */
	@SuppressWarnings("unchecked")
	public String execSQL(String funcID, Map paraMap, DataSets datasets) {
		String result = "";
		funcID = CommonOperation.exchangeURI(funcID);
		FunctionConfiguration configration = FunctionConfiguration.getInstance();
		Function function = configration.getFunction(funcID);
		try {
			if (null == function) {
				throw new UfSealException(funcID + "���ײ�����");
			}
			String sqlType = function.getType();
			if (null == sqlType || 0 == sqlType.length()) {
				throw new UfSealException(sqlType + "��𲻴���");
			}
			/*
			 * if (sqlType.equalsIgnoreCase("simpleQuery")) { result =
			 * DBOperation.commondQueryToXML(function.getSql(), paraMap); } else
			 */
			if (sqlType.equalsIgnoreCase("simpleTrans")) {
				List paramList = datasets.getParamMapValue(funcID);
				int cntParam = paramList.size();
				for (int i = 0; i < cntParam; i++) {
					DBOperation.updateDB(function.getSql(), (Map) paramList.get(i));
				}
				result = "<root error=''></root>";
			} else if (sqlType.equalsIgnoreCase("complexQuery")) {
				Class cls = Class.forName(this.validateURI(function.getId()));
				Class partypes[] = new Class[2];
				partypes[0] = Function.class;
				partypes[1] = DataSets.class;
				Method method = cls.getMethod("execute", partypes);
				Object[] arglist = new Object[2];
				arglist[0] = function;
				arglist[1] = datasets;
				result = (String) method.invoke(cls.newInstance(), arglist);
			} else if (sqlType.equalsIgnoreCase("complexTrans")) {
				Class cls = Class.forName(this.validateURI(function.getId()));
				Class partypes[] = new Class[2];
				partypes[0] = Function.class;
				partypes[1] = DataSets.class;
				Method method = cls.getMethod("execute", partypes);
				Object[] arglist = new Object[2];
				arglist[0] = function;
				arglist[1] = datasets;
				result = (String) method.invoke(cls.newInstance(), arglist);
				// result = "<root error=''></root>";
			} else if (sqlType.equalsIgnoreCase("procedureTrans")) {
				DBOperation.excuteCall(function.getSql(), paraMap);
				result = "<root error=''></root>";
			} else if (sqlType.equalsIgnoreCase("combinQuery")) {
				// ��ϲ�ѯ ���ض����ݼ�
				result = DBOperation.commondQueryToXML(function, datasets);
			} else if (sqlType.equalsIgnoreCase("combinTrans")) {
				DBOperation.updateDB(function, datasets);
				result = "<root error=''></root>";
			} else if (sqlType.equalsIgnoreCase("systemconfig")) {
				String controlflag = ((String) paraMap.get("controlflag"))
						.trim();
				if ("1001".equals(controlflag)) {
					FunctionConfiguration.reload();
				} else if ("1002".equals(controlflag)) {
					DataDict.reload();
				} else if ("1003".equals(controlflag)) {
					Parameters.reload();
				}
				result = "<root error=''></root>";
			}
			if (null == result || 0 == result.length()) {
				throw new UfSealException("������ͱ����Ƿ���ȷ�����ر���Ϊ�գ�");
			}
			return result;
		} catch (SQLException e) {
			CommonUtil.error("SQLException", e);
			return generateErrorMsg(retrunErrorMsg(e));
		} catch (IOException e) {
			CommonUtil.error("IOException", e);
			return generateErrorMsg(retrunErrorMsg(e));
		} catch (UfSealException e) {
			CommonUtil.error("UfSealException", e);
			return generateErrorMsg(e.getMessage());
		} catch (Exception e) {
			CommonUtil.error("Exception", e);
			return generateErrorMsg(retrunErrorMsg(e));
		}
	}

	// �����������
	public String execSQLForParameters(String funcID,
			Map<String, String> paraMap, DataSets dataSets) {
		String head = "<?xml version=\"1.0\" encoding=\"gb2312\"?>";
		String result = "";
		if (dataSets == null) {
			result = this.execSQL(funcID, paraMap);
		} else {
			result = this.execSQL(funcID, paraMap, dataSets);
		}
		if (!result.trim().startsWith("<?xml")) {
			result = head + result;
		}
		CommonUtil.info(result);
		return result;
	}

	private String generateErrorMsg(String message) {
		Element rootElement = new Element("root");
		rootElement.setAttribute("error", message);
		rootElement.setText("");
		Document myDocument = new Document(rootElement);
		XMLOutputter outputter = new XMLOutputter();
		outputter.setEncoding("gb2312");
		return outputter.outputString(myDocument);
	}

	private Throwable getNestedException(Throwable cause) {
		return cause.getCause();
	};

	private String retrunErrorMsg(Throwable cause) {
		String msg = cause.getMessage();
		Throwable parent = cause;
		Throwable child;
		while ((child = getNestedException(parent)) != null) {
			String msg2 = child.getMessage();
			if (msg2 != null) {
				if (msg != null) {
					msg = msg2;
				} else {
					msg = msg2;
				}
			}
			if (child instanceof NullPointerException) {
				break;
			}
			parent = child;
		}
		if (msg.length() > 200) {
			msg = msg.substring(1, 200);
		}
		return msg;
	}

	private String validateURI(String id) {
		return id.indexOf(".") == -1 ? CommonOperation.ClsComplextransPackagName
				+ id
				: id;
	}
}