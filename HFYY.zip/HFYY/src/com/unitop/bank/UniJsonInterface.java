package com.unitop.bank;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.lob.OracleLobHandler;

import com.unitop.bean.Function;
import com.unitop.bean.ParsedSql;
import com.unitop.exception.UfSealException;
import com.unitop.util.Base64;
import com.unitop.util.CommonOperation;

public class UniJsonInterface {
	protected final Log logger = LogFactory.getLog(getClass());
	
	public static OracleLobHandler lobHandler = new OracleLobHandler();
	/**
	 * ���ü򵥽���,����JsonArray
	 * 
	 * @param funcID
	 * @param paraMap
	 * @param List
	 *            :��ʾ�����������ʱ
	 * @return ����map��key������rows������error��;valueΪһ��JaonArray������Ϊ��¼��
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> execSql(String funcID,
			List<Map<String, String>> datasets, Connection conn) throws Exception {
		Map<String, Object> reMap = new HashMap<String, Object>();
		try {
			FunctionConfiguration configration = FunctionConfiguration
					.getInstance();
			Function function = configration.getFunction(funcID);
			if (null == function) {
				throw new UfSealException(funcID + "���ײ�����");
			}
			String sqlType = function.getType();
			if (sqlType == null) {       
				throw new Exception(sqlType + "��𲻴���");
			}
			int cntParam = datasets.size();
			if (1 == cntParam) {
				Map<String, String> paraMap = datasets.get(0);
				if (sqlType.equals("simpleQuery")) {
					DBOperation dbo = new DBOperation();
					JSONArray jsonArray = this.commodQueryToJsonArray(function.getSql(), paraMap, conn);
					reMap.clear();
					reMap.put("error", "");
					reMap.put("rows", jsonArray);
				} else if (sqlType.equals("simpleTrans")) {
//					System.out.println("functionsql:"+function.getSql());
					CommonUtil.info("functionsql:"+function.getSql());
					DBOperation.updateSQL(function.getSql(), paraMap, conn);
					reMap.clear();
					reMap.put("error", "");
				}
			} else if (cntParam > 1) {
				for (int i = 0; i < cntParam; i++) {
					if (sqlType.equals("simpleTrans")) {
						DBOperation.updateSQL(function.getSql(), datasets
								.get(i), conn);
						reMap.clear();
						reMap.put("error", "");
					}
				}
			} else {
				reMap.clear();
				reMap.put("error", "�����б�Ϊ�գ�");
			}
			return reMap;
		} catch (Exception e) {
			CommonUtil.error(funcID + "Exception : ", e);
			e.printStackTrace();
			/*String ErrMsg = "";
			if (e.toString() == "java.lang.NullPointerException") {
				ErrMsg = "�쳣��:" + e.toString();
			} else {
				ErrMsg = retrunErrorMsg(e);
			}
			reMap.clear();
			reMap.put("error", ErrMsg);
			return reMap;*/
			throw e;
		}
	}
	
	public static JSONArray commodQueryToJsonArray(String sql,Map paraMap,Connection conn) throws SQLException, IOException{
//		Connection conn = DataSourceUtils.getConnection(DataSourceFactory
//				.getDataSource());
		PreparedStatement ps=null;
		ResultSet rs =null;
		JSONArray jsonRet = null;
		//20171201 sunyp
		try{
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		ps = conn.prepareStatement(parsedSql.getNewSql());
		String[] parameters = parsedSql.getParameterNames();
		CommonOperation.doParserSql(ps, parameters, paraMap);
		rs = ps.executeQuery();
		ResultSetMetaData metaData = rs.getMetaData();
		int rsCount = metaData.getColumnCount();
		jsonRet = new JSONArray();
		while(rs.next()){
			JSONObject jsonObject = new JSONObject();
			for(int i=1;i<=rsCount;i++){
				String name = metaData.getColumnName(i);
				String value = "";
				if(null != rs.getObject(name)){
					if("yinjtp".equals(name.toLowerCase())){
						byte[] stream = lobHandler.getBlobAsBytes(rs, name);
						value = Base64.encodeBytes(stream);
					}else{
						value =	rs.getObject(name).toString();
					}
				}
				//�򵥽��ײ�ѯ���ݿ����ڣ�informixĬ���ֶ�Сд������ֻ��Ѳ�ѯ�����Ľ������columnת���ɴ�д����
				jsonObject.put(name.toUpperCase(), value);
			}
			jsonRet.add(jsonObject);
		}
		}catch(Exception e){
			try{if(rs != null){rs.close();}}catch(Exception e1){ }
			try{if(ps != null){ps.close();}}catch(Exception e2){ }
		}
		return jsonRet;
	}
	
	/**
	 * ���ü򵥸���
	 * 
	 * @param sql
	 * @param paraMap
	 * @throws UfSealException
	 * @throws SQLException
	 * @throws IOException
	 */
	public static void updateSQL(String sql, Map paraMap, Connection conn)
			throws UfSealException, SQLException, IOException {
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(parsedSql.getNewSql());
			String[] parameters = parsedSql.getParameterNames();
			CommonOperation.doParserSql(ps, parameters, paraMap);
			ps.execute();
		} catch (SQLException e) {
			CommonUtil.error("DBOperation updateDB SQLException", e);
			throw e;
		} catch (IOException e) {
			CommonUtil.error("DBOperation updateDB IOException", e);
			throw e;
		} finally {
			try {
				if (null != ps)
					ps.close();
			} catch (SQLException e) {
				throw e;
			}
		}
	}
	
	private String retrunErrorMsg(Throwable cause) {
		String msg = cause.getMessage();
		Throwable parent = cause;
		Throwable child;
		while ((child = getNestedException(parent)) != null) {
			String msg2 = child.getMessage();
			if (msg2 != null) {
				if (msg != null) {
					msg = msg2;
				} else {
					msg = msg2;
				}
			}
			if (child instanceof NullPointerException) {
				break;
			}
			parent = child;
		}
		if (msg.length() > 200) {
			msg = msg.substring(1, 200);
		}
		return msg;
	}
	
	private Throwable getNestedException(Throwable cause) {
		return cause.getCause();
	}
	
	public static void main(String[] args) throws SQLException, IOException {
		Connection conn = DataSourceUtils.getConnection(DataSourceFactory.getDataSourceByPool()
//				��getDataSource()
				);
		String sql = "select * from CI_JIEDCS";
		Map paraMap = new HashMap();
		JSONArray jsonRet = commodQueryToJsonArray(sql, paraMap, conn);
		System.out.println(jsonRet);
	}

}
