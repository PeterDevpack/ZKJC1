package com.unitop.bank.complextrans;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionStatus;

import com.unitop.bank.DataSourceFactory;
import com.unitop.bank.JUniDBInterface;
import com.unitop.bank.UniDBInterface;

public abstract class BaseTrans implements IComplexTrans {

	DataSourceTransactionManager txManager;
	TransactionStatus status;
	public UniDBInterface uniDBInterface = new UniDBInterface();
	public JUniDBInterface juniDBInterface = new JUniDBInterface();
	public DataSource dataSource =  DataSourceFactory.getDataSourceByPool();
	public Connection conn = null;
	
	public BaseTrans(){
		try {
			conn = dataSource.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void beginTrans() {
		try {
			if(null != conn)
			conn.setAutoCommit(false);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void rollback() {
		try {
			if(null != conn)
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	protected void commit() {
		try {
			if(null != conn)
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	protected void release() {
		try {
			if(null != conn)
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//����ҪƵ��������Դ
		//System.gc();
	}
	
//	protected void beginTrans() {
//		txManager = new DataSourceTransactionManager(dataSource);
//		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
//		def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
//		status = txManager.getTransaction(def);
//	}
//
//	protected void rollback() {
//		txManager.rollback(status);
//	}
//
//	protected void commit() {
//		txManager.commit(status);
//	}
	
}
