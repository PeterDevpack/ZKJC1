package com.unitop.bank.complextrans.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

/**
 * ɾ��ӡ�����ͺ�ɾ������ɾ����
 * 
 * @author Owner
 * 
 */
public class DeleteSealLag extends BaseTrans {

	public String execute(Function function, DataSets datasets)
			throws Exception {
		beginTrans();
		String xml = "";
		String error = "";
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();
		try {
			List<String> childTrans = function.getMutil().getList();
		

			// ��ɾ��ʱ��д��delSealag�Ĳ�����,��ִ��
			String delSealag = childTrans.get(0);
			List<Map<String, String>> paramList0 = datasets.getParamMap().get(
					delSealag);
			Map resultMap0 = uniDBInterface.execSql(delSealag, paramList0,conn);
			resultmap.put(delSealag, resultMap0);
			error += resultMap0.get("error");

			if (!"".equals(error)) {
				rollback();
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				release();
				return xml;
			} 
			// �����˻���ӡ�����״̬Ϊ��δ��
			String changeUserCheckState = childTrans.get(1);
			List<Map<String, String>> paramList1 = datasets.getParamMap().get(
					changeUserCheckState);
			Map resultMap1 = uniDBInterface.execSql(changeUserCheckState,
					paramList1,conn);
			resultmap.put(changeUserCheckState, resultMap1);
			error += resultMap1.get("error");
			if (!"".equals(error)) {
				rollback();
			} else {
				commit();
			}
			xml = CommonOperation.mapToXML(resultmap, function.getId());
		} catch (Exception e) {
			rollback();
			Map<String,Object> excMap = new HashMap<String,Object>();
			excMap.put("error", e.getMessage());
			resultmap.put("error",excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		} finally {
			release();
			return xml;
		}
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
