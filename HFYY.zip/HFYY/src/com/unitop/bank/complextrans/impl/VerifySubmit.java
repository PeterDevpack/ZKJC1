package com.unitop.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.UniJsonInterface;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.util.ExceptionUtil;
import com.unitop.util.sequence.SequenceObtain;
/**
 * ��ӡ����ύ
 * @author csq
 *
 */
public class VerifySubmit extends BaseTrans {
	
	@SuppressWarnings("finally")
	public String execute(Function function, DataSets datasets)
			throws Exception {

//		long l = System.currentTimeMillis();
		beginTrans();
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();// ���ս��
		
		Map paramMap = datasets.getParamMap();
		UniJsonInterface jsonInterface = new UniJsonInterface();

		List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
		tempList.add(new HashMap<String, String>());
		JSONObject dataObject = new JSONObject();
		dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate","",tempList,conn);
		JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
		String sysDate = jsonObjData1.getString("getdate");
		String date = sysDate.substring(0, 10);
		String time = sysDate.substring(11, 19);
		

		JSONObject retJson = new JSONObject();
		retJson.put("RETCODE", "0000");
		retJson.put("RETTEXT", "SINO:���׳ɹ�.");
		
		List list = (List)paramMap.get(function.getId());
		JSONObject json = (JSONObject) list.get(0);
		String act = json.getString("act");
//		String sequenceNum = json.getString("renwbs");//�����ʾ
		String sequenceNum = SequenceObtain.getSequenceUUID();//ҵ����ˮ��
		List<String> childTrans = function.getMutil().getList();
		String WriteYulyjyylogToDb = childTrans.get(0);//������ӡ��־д�����ݿ�(�ӽ���2)

		JSONArray sealsArray = new JSONArray();
		sealsArray=json.getJSONArray("SEALS");
		
		try{
			if("0".equals(act)){
			/**
			 * ��̨��ӡ����ύ
			 */
//				if("0001".equals(json.getString("yanyly"))){//������ˮ��
//					json.put("renwbs", UUID.randomUUID().toString().replaceAll("-", ""));
//				}
				//���½���ύ
				
				if(sealsArray!=null&&sealsArray.size()>0){
					for(int i=0;i<sealsArray.size();i++){
						List listWithSeal = new ArrayList();
						//���˻���Ϣ��֯����־��
						JSONObject sealJsonObj = (JSONObject) sealsArray.get(i);
						
						Map sealResult = (Map) JSONObject.toBean(sealJsonObj,Map.class);
						if("1".equals(sealResult.get("checkmode"))){	
						sealResult.put("pingzbsm", sequenceNum);
						sealResult.put("zhangh", json.get("zhangh"));
						sealResult.put("pingzh", json.get("checknum"));//---------ƾ֤��
						sealResult.put("yinjzl", sealResult.get("sealinktype"));
						sealResult.put("yinjbh", sealResult.get("sealinknum"));
						sealResult.put("guiyh", json.get("clerknum"));
						sealResult.put("guiym",  "");
						sealResult.put("clerkorgcode",json.get("guiyjgh"));
						if("1".equals(sealResult.get("checkresult"))){
							sealResult.put("yanyjg", "ͨ��");

						}else if("2".equals(sealResult.get("checkresult"))){
							sealResult.put("yanyjg", "δ��");
						}

						sealResult.put("yanyfs", "�Զ�");
						sealResult.put("henxzb", json.get("henxzb"));//-------�ͺ�����
						sealResult.put("shuxzb", json.get("shuxzb"));//-------������
						sealResult.put("yinzjd", json.get("yinzjd"));//-------�Ƕ�
						sealResult.put("yanyjb", json.get("yinyjb"));//-------��ӡ����
						sealResult.put("yanywgyy", json.get("weigyy"));
						sealResult.put("qiyrq", sealResult.get("qiyrq"));
						sealResult.put("checkdate", date);
						sealResult.put("checktime", time);
						sealResult.put("ip", "");//
						
						listWithSeal.add(sealResult);
						jsonInterface.execSql(WriteYulyjyylogToDb, listWithSeal, conn);
						}
					}
				}
				
				//��Ʊ����ύ
				List listWithAccount = new ArrayList();
				Map wholeBillMap = (Map) JSONObject.toBean(json, Map.class);
				if(!"0".equals(wholeBillMap.get("checkresult"))&&"1".equals(wholeBillMap.get("checkmode"))){
					wholeBillMap.put("ip", "");
					wholeBillMap.put("zhangh", wholeBillMap.get("zhangh"));
					wholeBillMap.put("pingzh", wholeBillMap.get("checknum"));//---ƾ֤��
					//2017-12-12 sunyp
					double d = Double.valueOf(wholeBillMap.get("money").toString()).doubleValue();
					wholeBillMap.put("jine", String.valueOf(d*100));
					wholeBillMap.put("checkdate",date );
					wholeBillMap.put("checktime", time);
					wholeBillMap.put("guiyh", wholeBillMap.get("clerknum"));
					wholeBillMap.put("guiym", "");
					wholeBillMap.put("clerkorgcode", wholeBillMap.get("guiyjgh"));
					wholeBillMap.put("shuangqgyh", wholeBillMap.get("shuangqgyh"));
					wholeBillMap.put("yanyjg", wholeBillMap.get("checkresult"));
					wholeBillMap.put("yanyfs", "�Զ�");
					if(wholeBillMap.get("xitlx").equals("1")){
						wholeBillMap.put("yanybs", "ZFYY");
					}else{
						wholeBillMap.put("yanybs", "DDYY");
					}
					
					wholeBillMap.put("remark", "");
					wholeBillMap.put("zuhgz", wholeBillMap.get("zuhgz"));
					wholeBillMap.put("xitlx", wholeBillMap.get("xitlx"));
					wholeBillMap.put("checktype", wholeBillMap.get("sealtype"));//��ӡ����
					String chuprq=(String) wholeBillMap.get("chuprq");
					chuprq=chuprq.substring(0,4)+"-"+chuprq.substring(4,6)+"-"+chuprq.substring(6,8);
					wholeBillMap.put("chuprq", chuprq);
					wholeBillMap.put("pingzbsm", sequenceNum);
					wholeBillMap.put("credencetype", wholeBillMap.get("credencetype"));//ƾ֤����
					wholeBillMap.put("tuxmc", "");
					wholeBillMap.put("accrgno", wholeBillMap.get("accorgno"));//--------�˻�������
					
					if("1".equals(wholeBillMap.get("checkresult"))){
						wholeBillMap.put("yanyjg", "ͨ��");
					}else if("2".equals(wholeBillMap.get("checkresult"))){
						wholeBillMap.put("yanyjg", "δ��");
					}else{
						wholeBillMap.put("yanyjg", "δ��");
					}
				
					listWithAccount.add(wholeBillMap);
					String WriteZhengpyylogToDb = childTrans.get(1);
					jsonInterface.execSql(WriteZhengpyylogToDb, listWithAccount, conn);
					
				}
			}
			commit();
			return retJson.toString();
		}catch(Exception e){
			rollback();
			e.printStackTrace();
			retJson.put("RETCODE", "1000");
			retJson.put("RETTEXT", "SINO:"+ExceptionUtil.exceptionTransfer(e));
		}finally{
			release();
			return retJson.toString();
		}
	}
	
	public String execute(Map parameters) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public JSONArray jexecute(Function function, DataSets datasets,
			JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
