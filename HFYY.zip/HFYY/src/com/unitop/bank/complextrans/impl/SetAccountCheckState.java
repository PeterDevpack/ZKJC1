package com.unitop.bank.complextrans.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

/**
 * �˻����ͨ��
 * 
 * @author Owner
 * 
 */
public class SetAccountCheckState extends BaseTrans {

	public String execute(Function function, DataSets datasets)
			throws Exception {
		beginTrans();
		String error = "";
		String xml = "";
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();
		try {
			List<String> childTrans = function.getMutil().getList();
			/*
			 * ����ӡ�����״̬Ϊ������
			 */
			String checkSeals = childTrans.get(0);
			Map resultMap0 = uniDBInterface.execSql(checkSeals, datasets
					.getParamMap().get(checkSeals),conn);
			resultmap.put(checkSeals, resultMap0);
			error += resultMap0.get("error");
			
			if (!"".equals(error)) {
				rollback();
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				release();
				return xml;
			} 
			/*
			 * ����������״̬Ϊ"����"
			 */
			String checkGroups = childTrans.get(1);
			Map resultMap1 = uniDBInterface.execSql(checkGroups, datasets
					.getParamMap().get(checkGroups),conn);
			resultmap.put(checkGroups, resultMap1);
			error += resultMap1.get("error");

			if (!"".equals(error)) {
				rollback();
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				release();
				return xml;
			} 
			/*
			 * �ж��˻����Ƿ��п��õ�ӡ��
			 */
			String getUsableSeal = childTrans.get(2);
			Map resultMap2 = uniDBInterface.execSql(getUsableSeal, datasets
					.getParamMap().get(getUsableSeal),conn);
			List<Map<String, String>> resultList2 = (List<Map<String, String>>) resultMap2
					.get("rows");
			
			/*
			 * �ж��˻����Ƿ��п��õ����
			 */
			String getUsableCombines = childTrans.get(3);
			Map resultMap3 = uniDBInterface.execSql(getUsableCombines, datasets
					.getParamMap().get(getUsableCombines),conn);
			List<Map<String, String>> resultList3 = (List<Map<String, String>>) resultMap3
					.get("rows");
			
			
			/*
			 * �ı�ӡ�������״̬	
			 */
			String changeAccountInfoState = childTrans.get(4);
			
			List paramList4 = datasets.getParamMap().get(changeAccountInfoState);
			Map paramMap4 = (Map) paramList4.get(0);
			if (resultList2 == null || resultList2.size() == 0) {
				paramMap4.put("youwyj", "��");
			} else {
				paramMap4.put("youwyj", "��");
			}
			paramMap4.put("yinjshzt", "����");
			if (resultList3 == null || resultList3.size() == 0) {
				paramMap4.put("youwzh", "��");

			} else {
				paramMap4.put("youwzh", "��");				
			}
			paramMap4.put("zuhshzt", "����");
			paramMap4.put("zhanghshzt", "����");
			Map resultMap4 = uniDBInterface.execSql(
					changeAccountInfoState, paramList4,conn);
			error += resultMap4.get("error");
			resultmap.put(changeAccountInfoState, resultMap4);
			if (!"".equals(error)) {
				rollback();
			} else {
				commit();
			}
			xml = CommonOperation.mapToXML(resultmap,function.getId());
		} catch (Exception e) {
			rollback();
			Map<String,Object> excMap = new HashMap<String,Object>();
			excMap.put("error", e.getMessage());
			resultmap.put("error",excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		}finally{
			release();
			return xml;
		}

	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
