/**
 *<dl>
 *<dt><b>����ܸ�Ҫ:</b></dt>
 *<dd></dd>
 *</dl>
 *@copyright :Copyright @2012, IBM ETP. All right reserved.
 *��Update History��
 * Version  Date        Company      Developer       Revise
 * -------   ----------       ---------        -------------       ------------
 * 1.00	  2012-3-12       IBM ETP      LiuShan		    create
 */
package com.unitop.bank.complextrans.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

/**
 * @author LiuShan
 *
 */
public class DoubleCheck extends BaseTrans{

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#execute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public String execute(Function function, DataSets datasets)
			throws Exception {
		String xml = "";
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();
		try {
			List<String> childTrans = function.getMutil().getList();
			String checkuserlogin = childTrans.get(0);
			List<Map<String, String>> list = datasets.getParamMap().get(checkuserlogin);
			Map resultmap0 = uniDBInterface.execSql(checkuserlogin, list,conn);
			// ��֤�˺Ż������Ƿ���ȷ
			List<Map> resultlist0 = (List) resultmap0.get("rows");
			if (resultlist0 == null || resultlist0.size() == 0){
				resultmap0.remove("rows");
				resultmap0.put("error", "��Ա�˺Ż��������");
				resultmap.put(checkuserlogin, resultmap0);
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}else{
				resultmap.put(checkuserlogin, resultmap0);
			}
			
			//�жϹ�Ա�Ƿ���Ȩ��
			String GetClerkQXExist = childTrans.get(1);
			Map resultMap1 = uniDBInterface.execSql(GetClerkQXExist, datasets
					.getParamMap().get(GetClerkQXExist),conn);
			List<Map> resultlist1 = (List) resultMap1.get("rows");
			if (resultlist1 == null || resultlist1.size() == 0) {
				resultMap1.put("error", "��Ա�޴˲���Ȩ�ޣ�");
				resultmap.put(GetClerkQXExist, resultMap1);
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}else{
				resultmap.put(GetClerkQXExist, resultMap1);
			}
			
			xml = CommonOperation.mapToXML(resultmap, function.getId());
		} catch (Exception e) {
			Map<String, Object> excMap = new HashMap<String, Object>();
			excMap.put("error", e.getMessage());
			resultmap.put("error", excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		}
		release();
		return xml;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#execute(java.util.Map)
	 */
	public String execute(Map<String, String> parameters) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
