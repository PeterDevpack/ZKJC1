package com.unitop.bank.complextrans.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

/**
 * ɾ����ϣ���ɾ����
 * 
 * @author Owner
 * 
 */
public class DeleteCombineReal extends BaseTrans {
	/*
	 * ��ô���GetUsableCombines��GetVerifyCombines��ֵ
	 * 
	 * @see
	 * com.unitop.bank.complextrans.IComplexTrans#execute(com.unitop.bean.Function
	 * , com.unitop.bean.DataSets)
	 */
	public String execute(Function function, DataSets datasets)
			throws Exception {

		beginTrans();
		String error = "";
		String xml = "";
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();
		try {

			List<String> childTrans = function.getMutil().getList();
			/*
			 * �����ݿ��ɾ�����
			 */
			String delSeal = childTrans.get(0);
			Map resultMap0 = uniDBInterface.execSql(delSeal, datasets
					.getParamMap().get(delSeal),conn);
			resultmap.put(delSeal, resultMap0);
			error += resultMap0.get("error");
			if (!"".equals(error)) {
				rollback();
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				release();
				return xml;
			} 
			
			/*
			 * �鿴��ǰ�˻����Ƿ��п��õ����,�п�����ϣ�isHaveUseableCombinsΪtrue
			 */
			String GetUsableCombines = childTrans.get(1);
			Map resultMap1 = uniDBInterface.execSql(GetUsableCombines, datasets
					.getParamMap().get(GetUsableCombines),conn);
			List<Map<String, String>> resultlist1 = (List<Map<String, String>>) resultMap1
					.get("rows");
			boolean isHaveUseableCombins =true;
			if(resultlist1==null||resultlist1.size()==0){
				isHaveUseableCombins = false;
			}
			
			//�鿴��ǰ�˻����Ƿ���δ������,��isCombinsUncheckΪtrue
			boolean isCombinsUncheck = true;
			if(isHaveUseableCombins){
				String GetVerifyCombines = childTrans.get(2);
				Map resultMap2 = uniDBInterface.execSql(GetVerifyCombines,
						datasets.getParamMap().get(GetVerifyCombines),conn);
				List<Map<String, String>> resultlist2 = (List<Map<String, String>>) resultMap2
						.get("rows");
				if(resultlist2==null||resultlist2.size()==0){
					isCombinsUncheck = false;
				}
			}else{
				isCombinsUncheck = false;
			}

			String changeAccountInfoCombineState = childTrans.get(3);
			List<Map<String, String>> paramList3 = datasets.getParamMap().get(
					changeAccountInfoCombineState);
			if(isHaveUseableCombins){
				paramList3.get(0).put("youwzh", "��");
			}else{
				paramList3.get(0).put("youwzh", "��");
			}
			if(isCombinsUncheck){
				paramList3.get(0).put("zuhshzt", "δ��");
			}else{
				paramList3.get(0).put("zuhshzt", "����");
			}
			Map resultMap3 = uniDBInterface.execSql(
					changeAccountInfoCombineState, paramList3,conn);
			error += resultMap3.get("error");
			resultmap.put(changeAccountInfoCombineState, resultMap3);
			if (!"".equals(error)) {
				rollback();
			} else {
				commit();
			}
			xml = CommonOperation.mapToXML(resultmap, function.getId());
		}catch (Exception e) {
			rollback();
			Map<String,Object> excMap = new HashMap<String,Object>();
			excMap.put("error", e.getMessage());
			resultmap.put("error",excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		} finally {
			release();
			return xml;
		}

	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
