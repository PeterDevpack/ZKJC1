package com.unitop.bank.complextrans.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

public class AddSeal extends BaseTrans {

	@SuppressWarnings("finally")
	public String execute(Function function, DataSets datasets)
			throws Exception {
		beginTrans();
		String error = "";
		String xml = "";
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();// ���ս��
		try {
			List<String> childTrans = function.getMutil().getList();
			String getYinjh = childTrans.get(0);
			List<Map<String, String>> paramlist0 = datasets.getParamMap().get(
					getYinjh);
			// ��ȡӡ�����
			Map<String, Object> map0 = uniDBInterface.execSql(getYinjh,
					paramlist0,conn);
			List<Map<String, String>> resultlist0 = (List<Map<String, String>>) map0
					.get("rows");
			Map<String, String> resultmap0 = resultlist0.get(0);
			String max_number = resultmap0.get("MAX_NUMBER_YINJBH");
			String yinjh = "" + (Integer.parseInt(max_number) + 1);

			String addseal = childTrans.get(1);
			List<Map<String, String>> paramlist1 = datasets.getParamMap().get(
					addseal);
			// ������ӡ����д�뵽datasets��
			paramlist1.get(0).put("yinjbh", yinjh);
			Map resultmap1 = uniDBInterface.execSql(addseal, paramlist1,conn);
			resultmap.put(addseal, resultmap1);
			error += resultmap1.get("error");
			
			if (!"".equals(error)) {
				rollback();
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				release();
				return xml;
			} 
			// �����˻�״̬��δ��
			String changeCheckState = childTrans.get(2);
			List<Map<String, String>> paramlist2 = datasets.getParamMap().get(
					changeCheckState);
			paramlist2.get(0).put("yinjbh", yinjh);
			Map resultmap2 = uniDBInterface.execSql(changeCheckState,
					paramlist2,conn);
			resultmap.put(changeCheckState, resultmap2);
			error += resultmap2.get("error");

			if (!"".equals(error)) {
				rollback();
			} else {
				commit();
			}
			xml = CommonOperation.mapToXML(resultmap, function.getId());
		} catch (Exception e) {
			rollback();
			Map<String, Object> excMap = new HashMap<String, Object>();
			excMap.put("error", e.getMessage());
			resultmap.put("error", excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		} finally {
			release();
			return xml;
		}
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
