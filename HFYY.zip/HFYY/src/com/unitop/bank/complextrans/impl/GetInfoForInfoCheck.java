package com.unitop.bank.complextrans.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.CommondFunction;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.util.CommonOperation;

/**
 * ��ȡ�˻���Ϣ�������
 * @author Owner
 *
 */
public class GetInfoForInfoCheck extends BaseTrans{

	public String execute(Function function, DataSets datasets)
			throws Exception {
		List<String> childTrans = function.getMutil().getList();
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();
		String getAccountInfo = childTrans.get(0);
		List<Map<String, String>> list = datasets.getParamMap().get(getAccountInfo);
		Map resultmap0= uniDBInterface.execSql(getAccountInfo,list,conn);
		//��֤�˻��Ƿ����
		List<Map> resultlist0  = (List) resultmap0.get("rows");
		if(resultlist0==null||resultlist0.size()==0){
			resultmap0.put("error", "�޴��˻���");
			resultmap.put(getAccountInfo, resultmap0);
			String xml = CommonOperation.mapToXML(resultmap, function.getId());
			return xml;
		}
		//�ж�Ȩ��
		Map<String, String> accountMap = resultlist0.get(0);
		String accountOrgnum = accountMap.get("JIGH");
		String getClerk = childTrans.get(3);
		Map resultMap3 = uniDBInterface.execSql(getClerk, datasets
				.getParamMap().get(getClerk),conn);
		String clerknum = datasets.getParamMap().get(getClerk).get(0).get("clerknum");
		boolean isCanOperDesAccount = false;
		if("".equals(clerknum)||clerknum==null){
			isCanOperDesAccount = true;
		}else{
			List<Map> resultlist3 = (List) resultMap3.get("rows");
			Map<String, String> clerkMap = resultlist3.get(0);
			String clerkOrgnum = (String) clerkMap.get("N_ORGANNUM");
			isCanOperDesAccount = CommondFunction
			.isCanOperationDesNetPoint(clerkOrgnum, accountOrgnum);
		}
//		boolean isCanOperDesAccount = true;
		if(!isCanOperDesAccount){
			resultmap0.remove("rows");
			resultmap0.put("error", "�Բ�������Ȩ�鿴���˺ţ�");
			resultmap.put(getAccountInfo, resultmap0);
			String xml = CommonOperation.mapToXML(resultmap, function.getId());
			return xml;
		}else{
			String zhanghzt = accountMap.get("ZHANGHZT");
			String zhanghshzt = accountMap.get("ZHANGHSHZT");
			String yinjshzt = accountMap.get("YINJSHZT");
			String zuhshzt = accountMap.get("ZUHSHZT");

			if("��Ч".equals(zhanghzt)){
				if("����".equals(zhanghshzt)&&"����".equals(yinjshzt)&&"����".equals(zuhshzt)){
					resultmap0.remove("rows");
					resultmap0.put("error","���˻�����");
					resultmap.put(getAccountInfo, resultmap0);
					String xml = CommonOperation.mapToXML(resultmap, function.getId());
					return xml;
				}
				resultmap.put(getAccountInfo, resultmap0);
			}else{
				resultmap0.remove("rows");
				resultmap0.put("error", "���˻�Ϊ"+zhanghzt+"״̬��");
				resultmap.put(getAccountInfo, resultmap0);
				String xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}
		}
		if("��".equals(accountMap.get("YOUWYJ"))){
		String getSeals = childTrans.get(1);
		List<Map<String, String>> paramlist1 = datasets.getParamMap().get(getSeals);
		Map resultmap1= uniDBInterface.execSql(getSeals,paramlist1,conn);
		resultmap.put(getSeals, resultmap1);
		}
		
		if("��".equals(accountMap.get("YOUWZH"))){
		String getSealCombins = childTrans.get(2);
		List<Map<String, String>> paramlist2 = datasets.getParamMap().get(getSealCombins);
		Map resultmap2= uniDBInterface.execSql(getSealCombins,paramlist2,conn);
		resultmap.put(getSealCombins, resultmap2);
		}
		
		String xml = CommonOperation.mapToXML(resultmap, function.getId());
		release();
		return xml;
	}

	public String execute(Map<String, String> parameters) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
}
