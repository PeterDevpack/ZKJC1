package com.unitop.bank.complextrans.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

public class DeleteSealReal extends BaseTrans {

	public String execute(Function function, DataSets datasets)
			throws Exception {
		beginTrans();
		String xml = "";
		String error = "";
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();
		try {
			List<String> childTrans = function.getMutil().getList();
			/*
			 * �����ݿ��ɾ��ӡ��
			 */
			String delSeal = childTrans.get(0);
			Map resultMap0 = uniDBInterface.execSql(delSeal, datasets
					.getParamMap().get(delSeal),conn);
			resultmap.put(delSeal, resultMap0);
			error += resultMap0.get("error");
			
			if (!"".equals(error)) {
				rollback();
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				release();
				return xml;
			} 
			/*
			 * �鿴��ǰ�˻����Ƿ��п��õ�ӡ��
			 */
			String GetUsableSeals = childTrans.get(1);
			Map resultMap1 = uniDBInterface.execSql(GetUsableSeals, datasets
					.getParamMap().get(GetUsableSeals),conn);
			List<Map<String, String>> resultlist1 = (List<Map<String, String>>) resultMap1
					.get("rows");
			//String useSealCountStr = resultlist1.get(0).get("USABLE_SEALS");

			// ����Ƿ��п���ӡ��
			boolean isUseseal = true;
			if(null==resultlist1||resultlist1.size()==0){
				isUseseal = false;
			}
			//�Ƿ���ӡ��δ��
			boolean isSealUnCheck = true;
			/*
			 * �鿴��ǰ�˻��µ�ӡ���Ƿ��Ѿ����
			 */
			if (isUseseal) {
				String GetVerifySeals = childTrans.get(2);
				
				Map resultMap2 = uniDBInterface.execSql(GetVerifySeals,
						datasets.getParamMap().get(GetVerifySeals),conn);
				List<Map<String, String>> resultlist2 = (List<Map<String, String>>) resultMap2
						.get("rows");
				if(null==resultlist2||resultlist2.size()==0){
					isSealUnCheck = false;
				}
			}else{
				isSealUnCheck = false;
			}

			String changeAccountInfoSealState = childTrans.get(3);
			List<Map<String, String>> paramList3 = datasets.getParamMap()
					.get(changeAccountInfoSealState);
			if(isUseseal)
				paramList3.get(0).put("youwyj", "��");
			else 
				paramList3.get(0).put("youwyj", "��");
			if(isSealUnCheck)
				paramList3.get(0).put("yinjshzt", "δ��");
			else 
				paramList3.get(0).put("yinjshzt", "����");

			Map resultMap3 = uniDBInterface.execSql(
					changeAccountInfoSealState, paramList3,conn);
			resultmap.put(changeAccountInfoSealState, resultMap3);
			error += resultMap3.get("error");
			
			if (!"".equals(error)) {
				rollback();
			} else {
				commit();
			}
			xml = CommonOperation.mapToXML(resultmap, function.getId());
		} catch (Exception e) {
			rollback();
			Map<String,Object> excMap = new HashMap<String,Object>();
			e.printStackTrace();
			excMap.put("error", e.getMessage());
			resultmap.put("error",excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		} finally {
			release();
			return xml;
		}
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
