package com.unitop.bank.complextrans.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

/**
 * �ӿ��ã���ȡ�˻���ӡ���������Ϣ������ӡ
 * @author Owner
 *
 */
public class AssistantGetCheckInfo extends BaseTrans {

	public String execute(Function function, DataSets datasets)
			throws Exception {
		List<String> childTrans = function.getMutil().getList();
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();
		String xml = "";
		String error="";
		try {
			
			//��ȡ�˻���Ϣ
			String assGetAccountInfo = childTrans.get(0);
			List<Map<String, String>> list = datasets.getParamMap().get(
					assGetAccountInfo);
			Map resultmap0 = uniDBInterface.execSql(assGetAccountInfo, list,
					conn);
			// ��֤�˻��Ƿ����
			List<Map> resultlist0 = (List) resultmap0.get("rows");
			if (resultlist0 == null || resultlist0.size() == 0) {
				resultmap0.put("error", "�޴��˻���");
				resultmap.put(assGetAccountInfo, resultmap0);
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}
			
			Map<String, String> accountMap = resultlist0.get(0);

			String zhanghzt = accountMap.get("ZHANGHZT");
			// �ж��˻��Ƿ���Ч
			if ("��Ч".equals(zhanghzt)) {
				resultmap.put(assGetAccountInfo, resultmap0);
			} else {
				resultmap0.remove("rows");
				resultmap0.put("error", "���˻�Ϊ" + zhanghzt + "״̬��");
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}
			// �ж��Ƿ���ӡ��
			if ("��".equals(accountMap.get("YOUWYJ"))) {
				String assGetSealsToCheck = childTrans.get(1);
				List<Map<String, String>> paramlist1 = datasets.getParamMap()
						.get(assGetSealsToCheck);
				Map resultmap1 = uniDBInterface.execSql(assGetSealsToCheck,
						paramlist1, conn);
				resultmap.put(assGetSealsToCheck, resultmap1);
				error+=resultmap1.get("error");
			} else {
				resultmap0.remove("rows");
				resultmap0.put("error", "���˻���ӡ����");
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}
			// �ж��������
			if ("��".equals(accountMap.get("YOUWZH"))) {
				String assGetGroupsToCheck = childTrans.get(2);
				List<Map<String, String>> paramlist2 = datasets.getParamMap()
						.get(assGetGroupsToCheck);
				Map resultmap2 = uniDBInterface.execSql(assGetGroupsToCheck,
						paramlist2, conn);
				resultmap.put(assGetGroupsToCheck, resultmap2);
				error+=resultmap2.get("error");
			}
			//��ȡ�ӿڲ���
			String getInterfaceConfig = childTrans.get(3);
			Map resultmap3 = uniDBInterface.execSql(getInterfaceConfig, datasets.getParamMap().get(getInterfaceConfig),conn);
			resultmap.put(getInterfaceConfig, resultmap3);
			error+=resultmap3.get("error");
			
			//��ȡƾ֤����
			String getBillConfig = childTrans.get(4);
			Map resultmap4  = uniDBInterface.execSql(getBillConfig, datasets.getParamMap().get(getBillConfig),conn);
			resultmap.put(getBillConfig, resultmap4);
			error+=resultmap4.get("error");
			
			
			List<Map> resultlist3 = (List) resultmap3.get("rows");
			String cansbs ="";
			String Y =datasets.getControlParamMap().get("YW_009");
			//��cansbsΪ�� YW_009�������ݵ�cansz��ֵ x�����x��Ϊ�գ�Y = x;���xΪ�գ�Y= ���Ʋ���CI_015��ֵ��
			if("".equals(Y)||Y==null){
				for(int i = 0;i<resultlist3.size();i++){
					cansbs = (String) resultlist3.get(i).get("CANSBS");
					if("YW_009".equals(cansbs)){
						Y = (String) resultlist3.get(i).get("CANSZ");
						break;
					}
				}
				
			}
			
			//���Y=���񡱣�����GetRenwxx��GetYYRZ��
			if("��".equals(Y)){
				String getRenwxx = childTrans.get(5);
				Map resultmap5  = uniDBInterface.execSql(getRenwxx, datasets.getParamMap().get(getRenwxx),conn);
				resultmap.put(getRenwxx, resultmap5);
				error+=resultmap5.get("error");

				String getYYRZ =childTrans.get(6);
				Map resultmap6  = uniDBInterface.execSql(getYYRZ, datasets.getParamMap().get(getYYRZ),conn);
				resultmap.put(getYYRZ, resultmap6);
				error+=resultmap6.get("error");
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String sysconfigtime = datasets.getControlParamMap().get("sysconfigtime");
			if("".equals(sysconfigtime)||sysconfigtime==null){
				String getSysConfig = childTrans.get(8);
				Map resultmap8 =uniDBInterface.execSql(getSysConfig, datasets.getParamMap().get(getSysConfig), conn);
				resultmap.put(getSysConfig, resultmap8);
			}else{
				String getSysConfigValue = childTrans.get(7);
				Map resultmap7 =uniDBInterface.execSql(getSysConfigValue, datasets.getParamMap().get(getSysConfigValue), conn);
				List<Map> resultlist7 = (List<Map>) resultmap7.get("rows");
				String dbconfigtime = (String) resultlist7.get(0).get("VALUE"); 
				//�Ƚ����ݿ��в���ʱ��ͱ��ز���ʱ��
				Date sysConfigDate = sdf.parse(sysconfigtime);
				Date dbConfigDate = sdf.parse(dbconfigtime);
				if(dbConfigDate.compareTo(sysConfigDate)==-1){
					String getSysConfig = childTrans.get(8);
					Map resultmap8 =uniDBInterface.execSql(getSysConfig, datasets.getParamMap().get(getSysConfig), conn);
					resultmap.put(getSysConfig, resultmap8);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Map<String,Object> excMap = new HashMap<String,Object>();
			excMap.put("error", e.getMessage());
			resultmap.put("error",excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		}finally{
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			return xml;
		}

	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
