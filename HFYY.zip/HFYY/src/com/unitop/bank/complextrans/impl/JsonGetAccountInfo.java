package com.unitop.bank.complextrans.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.UniJsonInterface;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.framework.util.StringUtil;
import com.unitop.util.ExceptionUtil;

public class JsonGetAccountInfo extends BaseTrans {

	@SuppressWarnings("finally")
	public String execute(Function function, DataSets datasets)
			throws Exception {

		Map paramMap = datasets.getParamMap();
		UniJsonInterface jsonInterface = new UniJsonInterface();
		
		List list = (List)paramMap.get(function.getId());
		JSONObject json = (JSONObject) list.get(0);
		String resource = json.has("resource")?json.getString("resource"):"";
		String act = json.getString("act");
		String xitlx = json.getString("xitlx");
		if(xitlx.equals("1")){
			json.accumulate("xitmc", "֧��");
		}else if(xitlx.equals("2")){
			json.accumulate("xitmc", "����");
		}
		String jine = json.getString("jine");
		//json.remove("jine");
		//���ȥ��С���㣬500.00->50000
		//���ݿ�洢Ҳ�Ǵ��û��С�������ʽ
		if(-1!=jine.indexOf(".")){
			jine = jine.replace(".","");
			json.put("jine", jine);
		}
		if (xitlx.equals("2")) {
			BigDecimal money=new BigDecimal(jine);
			if(money.doubleValue()>0){
				json.put("jine", jine);
			}else {
				json.put("jine", "1");
			}
		} 
		String chuprq=json.getString("qianfrq");
		String sealType = json.getString("sealtype");//��ӡ����
		
		json.accumulate("accno", json.get("zhangh"));
		json.accumulate("chuprq", json.get("qianfrq"));
		json.accumulate("guizbh", sealType);
		
		String clerkorg = json.getString("clerkorg");
		if(clerkorg==null||"".equals(clerkorg)){
			clerkorg= json.getString("TELLORGNO");
		}
		JSONObject accountInfo = new JSONObject();
			
		try{
			
			List listWithMap = new ArrayList();
			listWithMap.add(JSONObject.toBean(json, Map.class));
			List<String> childTrans = function.getMutil().getList();
			//�˻���Ϣ
			//2017-7-25 sun
			String AssGetAccountInfo = childTrans.get(0);//��ȡ�˻���Ϣ
			Map reMap = jsonInterface.execSql(AssGetAccountInfo, listWithMap, conn);
			JSONArray jsonArray = (JSONArray) reMap.get("rows");
			if(jsonArray.size()==0){
				accountInfo.put("RETCODE", "1002");
				accountInfo.put("RETTEXT", "SINO:�˻�������");
				return accountInfo.toString();
			}
			accountInfo = jsonArray.getJSONObject(0);
			accountInfo.put("RETCODE", "0000");
			accountInfo.put("RETTEXT", "SINO:���׳ɹ���");
			
			boolean isCanOperDesAccount = true;
			if("CPS".equals(resource)){//������ҵ���������У��ͨ��ͨ��
				isCanOperDesAccount = true;
			}else if("".equals(clerkorg)||clerkorg==null){
				isCanOperDesAccount = false;
			}
			String tingyrq=accountInfo.getString("TINGYRQ");
			String zhanghzt=accountInfo.getString("ZHANGHZT");
			if("��ʧ".equals(zhanghzt)){//�˻�״̬
				accountInfo.clear();
				accountInfo.put("RETCODE", "0007");
				accountInfo.put("RETTEXT", "SINO:���˻��ѹ�ʧ");
				return accountInfo.toString();
			} else if("����".equals(zhanghzt)){//�˻�״̬
				accountInfo.clear();
				accountInfo.put("RETCODE", "0012");
				accountInfo.put("RETTEXT", "SINO:���˻�������");
				return accountInfo.toString();
			}else if(!("4".equals(xitlx))){
				if (!(tingyrq.equals("") || null == tingyrq) && (chuprq.compareTo(tingyrq) >= 0)) {
					accountInfo.clear();
					accountInfo.put("RETCODE", "0008");
					accountInfo.put("RETTEXT", "SINO:���˻���ͣ��");
					return accountInfo.toString();
				}}
			
			if (!isCanOperDesAccount) {
	//			accountInfo.remove("rows");
				accountInfo.clear();
				accountInfo.put("RETCODE", "0006");
				accountInfo.put("RETTEXT", "SINO:��Ȩ�޲������˻�");
				return accountInfo.toString();
			} 
			
			//�����ѯ�������˺ŵ����˺��ֶ�zhuzh��Ϊ�գ���ô��ѯ���˺�Ϊ���˺ţ������˺��ֶε�ֵ���ý�������ٴβ�ѯ�˺���Ϣ
			//2017-7-25 sun
			//��ѯ�����˺���Ϣ�������ٴ���֤�Ƿ������ӡ
			if( !StringUtil.isEmpty(accountInfo.getString("ZHUZH"))){
				JSONObject json_zhuzh = new JSONObject();
				json_zhuzh.put("accno", accountInfo.get("ZHUZH"));
				json_zhuzh.put("zhangh", accountInfo.get("ZHUZH"));
				List listWithMap_zhuzh = new ArrayList();
				listWithMap_zhuzh.add(JSONObject.toBean(json_zhuzh, Map.class));
				Map reMap_zhuzh = jsonInterface.execSql(AssGetAccountInfo, listWithMap_zhuzh, conn);
				JSONArray jsonArray_zhuzh = (JSONArray) reMap_zhuzh.get("rows");
				if(jsonArray_zhuzh.size()==0){
					accountInfo.put("RETCODE", "1006");
					accountInfo.put("RETTEXT", "SINO:���˻�������");
					return accountInfo.toString();
				}
				JSONObject accountInfo_zhuzh = jsonArray_zhuzh.getJSONObject(0);
				
				String tingyrq_zhuzh=accountInfo_zhuzh.getString("TINGYRQ");
				String zhanghzt_zhuzh=accountInfo_zhuzh.getString("ZHANGHZT");
				if("��ʧ".equals(zhanghzt_zhuzh)){//�˻�״̬
					accountInfo.clear();
					accountInfo.put("RETCODE", "1007");
					accountInfo.put("RETTEXT", "SINO:���˻��ѹ�ʧ");
					return accountInfo.toString();
				} else if("����".equals(zhanghzt_zhuzh)){//�˻�״̬
					accountInfo.clear();
					accountInfo.put("RETCODE", "1008");
					accountInfo.put("RETTEXT", "SINO:���˻�������");
					return accountInfo.toString();
				}else if(!("4".equals(xitlx))){
					if (!(tingyrq_zhuzh.equals("") || null == tingyrq_zhuzh) && (chuprq.compareTo(tingyrq_zhuzh) >= 0)) {
						accountInfo.clear();
						accountInfo.put("RETCODE", "1009");
						accountInfo.put("RETTEXT", "SINO:���˻���ͣ��");
						return accountInfo.toString();
					}}
			}
			if ("2".equals(act)) {
				
				/**
				 * ��ȡӡ����Ϣ����ӡ
				 */
				System.out.println("act....>>>>|"+act);
				//��ȡӡ����Ϣ
			
				String getISatisfySealToCheck = childTrans.get(1);
				long l = System.currentTimeMillis();
				Map sealsMap = jsonInterface.execSql(getISatisfySealToCheck,
						listWithMap, conn);
				System.out.println("ID:" + l + "|��ѯӡ���ú�ʱ��"+(System.currentTimeMillis() - l));
				JSONArray sealsArray = (JSONArray) sealsMap.get("rows");
				if(sealsArray == null || sealsArray.size() == 0){
					String zhuzh = accountInfo.getString("ZHUZH");
					if (zhuzh != null && !"".equals(zhuzh)) {
						String getSatisfySealToCheckForzhuzh = childTrans.get(2);
						json.accumulate("zhuzh", zhuzh);
						List listzhuzhMap = new ArrayList();
						listzhuzhMap.add(JSONObject.toBean(json, Map.class));
						sealsMap = jsonInterface.execSql(getSatisfySealToCheckForzhuzh,listzhuzhMap, conn);
						sealsArray = (JSONArray) sealsMap.get("rows");
					}
				}
				
				if (sealsArray != null && sealsArray.size() > 0) {
					String getISatisfyZuheToCheck=childTrans.get(3);
					//��ȡ�����Ϣ
					Map groupsMap = jsonInterface.execSql(getISatisfyZuheToCheck, listWithMap, conn);
					JSONArray groupsArray =(JSONArray) groupsMap.get("rows");
					if(groupsArray==null||groupsArray.size()==0){
						String zhuzh = accountInfo.getString("ZHUZH");
						if(zhuzh != null && !"".equals(zhuzh)){
							String getSatisfyZuheToCheckForzhuzh=childTrans.get(4);
							List listZhuzhMap = new ArrayList();
							JSONObject jsonZhu=new JSONObject();
							jsonZhu=json;
							jsonZhu.remove("zhangh");
							jsonZhu.accumulate("zhangh", zhuzh);
							listZhuzhMap.add(JSONObject.toBean(json, Map.class));
							groupsMap = jsonInterface.execSql(getSatisfyZuheToCheckForzhuzh, listZhuzhMap, conn);
							groupsArray =(JSONArray) groupsMap.get("rows");
						}
					}
					
					if(groupsArray!=null&&groupsArray.size()==1){
						String zuhgz=groupsArray.getJSONObject(0).getString("ZUHGZ");
						zuhgz = zuhgz.replaceAll("C[0-9]*\\[", ",");
						zuhgz = zuhgz.replaceAll("&", ",");
						zuhgz = zuhgz.replaceAll("\\|", ",");
						zuhgz = zuhgz.replaceAll(" ", "");
						zuhgz = zuhgz.replaceAll("\\[", "");
						zuhgz = zuhgz.replaceAll("\\]", "");
						zuhgz = zuhgz.replaceAll("\\(", "");
						zuhgz = zuhgz.replaceAll("\\)", "");
						String[] yinjh = zuhgz.split(",");
						String _zuhgz = groupsArray.getJSONObject(0).getString("ZUHGZ");
						_zuhgz=_zuhgz.replaceAll("\\|", "U");
						_zuhgz=_zuhgz.replaceAll("\\[", "(");
						_zuhgz=_zuhgz.replaceAll("\\]", ")");
						
						JSONArray groupsArray_duiz = new JSONArray();
						JSONObject group_duiz = new JSONObject();
						group_duiz.accumulate("ZUHGZ", _zuhgz);
						groupsArray_duiz.add(group_duiz);
						accountInfo.put("GROUPS", groupsArray_duiz);
						
						for (int i = sealsArray.size() - 1; i >= 0; i--) {
							Boolean sealsFlag = false;
							for (int j = 0; j < yinjh.length; j++) {
								if (yinjh[j].equals(sealsArray.getJSONObject(i).getString("YINJBH"))) {
									sealsFlag = true;
									break;
								}
							}
							// ȥ�������û�е�ӡ��
							if (!sealsFlag) {
								sealsArray.remove(i);
							}
						}
					}else if(groupsArray!=null&&groupsArray.size()>1){
						String[] yinjh = null;
						StringBuilder _zuhgz = new StringBuilder();
						StringBuilder zuheSb1 = new StringBuilder();
						int objDataCount = groupsArray.size();
						for(int i=0;i<objDataCount;i++){
							String zuhgz=groupsArray.getJSONObject(i).getString("ZUHGZ");
							zuhgz = zuhgz.replaceAll("C[0-9]*\\[", ",");
							zuhgz = zuhgz.replaceAll("&", ",");
							zuhgz = zuhgz.replaceAll("\\|", ",");
							zuhgz = zuhgz.replaceAll(" ", "");
							zuhgz = zuhgz.replaceAll("\\[", "");
							zuhgz = zuhgz.replaceAll("\\]", "");
							zuhgz = zuhgz.replaceAll("\\(", "");
							zuhgz = zuhgz.replaceAll("\\)", "");
							zuheSb1.append(zuhgz+',');
						}
						for (int i = 0; i < objDataCount; i++) {
							_zuhgz.append("(");
							_zuhgz.append(groupsArray.getJSONObject(i).getString("ZUHGZ"));
							_zuhgz.append(")");
							if (!(i == objDataCount - 1)) {
								_zuhgz.append("|");
							}
							
						}
						yinjh = zuheSb1.toString().split(",");
						JSONArray groupsArray_duiz = new JSONArray();
						JSONObject group_duiz = new JSONObject();
						group_duiz.accumulate("ZUHGZ", _zuhgz.toString());
						groupsArray_duiz.add(group_duiz);
						accountInfo.put("GROUPS", groupsArray_duiz);
						
						for (int i = sealsArray.size() - 1; i >= 0; i--) {
							Boolean sealsFlag = false;
							for (int j = 0; j < yinjh.length; j++) {
								if (yinjh[j].equals(sealsArray.getJSONObject(i).getString("YINJBH"))) {
									sealsFlag = true;
									break;
								}
							}
							// ȥ�������û�е�ӡ��
							if (!sealsFlag) {
								sealsArray.remove(i);
							}
						}
					}else{
						
						//1Ԥ��ӡ�� 2������   3��Ԥ��ӡ���͹���   4��Ԥ��ӡ������
							
						String getYYgz = childTrans.get(5);
//						 long t=System.currentTimeMillis();
						groupsMap = jsonInterface.execSql(getYYgz,
								listWithMap, conn);
						// �������
//						 System.out.println("ID:"+t+"|��ѯ����ú�ʱ��"+(System.currentTimeMillis()-t));
						groupsArray = (JSONArray) groupsMap.get("rows");
						if (groupsArray!= null&&groupsArray.size()>0) {
							JSONObject group = groupsArray.getJSONObject(0);
							
							//������ӡ����
							if("4".equals(sealType)){
								String zuhgz = group.getString("BEIZ");
								String[] yinjh = zuhgz.split("\\|");
								int k=0;
								int g=0;
								StringBuffer zuhSb = new StringBuffer("");
								StringBuffer zuhSb1 = new StringBuffer("");
								Boolean sealsFlag = false;
								for (int i = sealsArray.size() - 1; i >= 0; i--) {
									sealsFlag = false;
									for (int j = 0; j < yinjh.length; j++) {
										String yinjlx=sealsArray.getJSONObject(i).getString("YINJLX");
										String yinjbh=sealsArray.getJSONObject(i).getString("YINJBH");
										if ((yinjh[j].equals(yinjlx)&&yinjlx.equals("������"))||(yinjh[j].equals(yinjlx)&&yinjlx.equals("����"))){
											if(k==0){
												zuhSb=zuhSb.append("C1(").append(yinjbh);
												k++;
												sealsFlag = true;
												break;
											}else if(k>=1){
												zuhSb=zuhSb.append(",").append(yinjbh);
												k++;
												sealsFlag = true;
												break;
											}
										}
										if ((yinjh[j].equals(yinjlx)&&yinjlx.equals("����"))||(yinjh[j].equals(yinjlx)&&yinjlx.equals("ǩ��"))){
											if(g==0){
												zuhSb1=zuhSb1.append("C1(").append(yinjbh);
												g++;
												sealsFlag = true;
												break;
											}else if(g>=1){
												zuhSb1=zuhSb1.append(",").append(yinjbh);
												g++;
												sealsFlag = true;
												break;
											}
										}
									}
									// ȥ�������û�е�ӡ��
									if (!sealsFlag) {
										sealsArray.remove(i);
									}
								}
								if(k>0){
									zuhSb=zuhSb.append(")");
								}
								if(g>0){
									zuhSb1=zuhSb1.append(")");
								}
								if(k>0&&g>0){
									zuhSb=zuhSb.append("&").append(zuhSb1.toString());
								}else{
									zuhSb=zuhSb.append(zuhSb1.toString());
								}
								//�������
								JSONArray groupsArray_duiz = new JSONArray();
								JSONObject group_duiz = new JSONObject();
								group_duiz.accumulate("ZUHGZ", zuhSb.toString());
								groupsArray_duiz.add(group_duiz);
								accountInfo.put("GROUPS", groupsArray_duiz);
							}else{
								// �����������
								String zuhgz = group.getString("BEIZ");
								String[] yinjh = zuhgz.split("\\|");

								Boolean sealsFlag = false;
								for (int i = sealsArray.size() - 1; i >= 0; i--) {
									sealsFlag = false;
									for (int j = 0; j < yinjh.length; j++) {

										if (yinjh[j].equals(sealsArray.getJSONObject(i).getString("YINJLX"))) {
											sealsFlag = true;
											break;
										}
									}
									// ȥ�������û�е�ӡ��
									if (!sealsFlag) {
										sealsArray.remove(i);
									}
								}
							}
							
						} else {
							for (int i = sealsArray.size() - 1; i >= 0; i--) {
								String yinjlx = sealsArray.getJSONObject(i)
										.getString("YINJLX");
								// ȥ������
								if ("����".equals(yinjlx)) {
									sealsArray.remove(i);
								}
							}
						}
					}	
					

					long t = System.currentTimeMillis();
					// �������
					System.out.println("ID:" + l + "|ӡ���߼������ܺ�ʱ��"
							+ (System.currentTimeMillis() - t));
					// ӡ��������뷵�ر��Ľṹ��

					if (sealsArray != null && sealsArray.size() > 0) {
						accountInfo.put("SEALS", sealsArray);
						accountInfo.put("YANYSF","1" );////��ҵ������ӡ�㷨�߼�         0��������ӡ    1���п�  2������
						System.out.println("ID:" + l + "|��ѯӡ���ú�ʱ��"+ (System.currentTimeMillis() - l));
						return accountInfo.toString();
					} else {
						accountInfo.put("RETCODE", "0011");
						accountInfo.put("RETTEXT", "�޶�Ӧӡ��");
						return accountInfo.toString();
					}

				} else {
					accountInfo.put("RETCODE", "0011");
					accountInfo.put("RETTEXT", "�޶�Ӧӡ��");
					return accountInfo.toString();
				}

			}
			
		}catch (Exception e) {
			e.printStackTrace();
			accountInfo.put("RETCODE", "1000");
			accountInfo.put("RETTEXT", "SINO:"+ExceptionUtil.exceptionTransfer(e));
		}finally{
			release();
			return accountInfo.toString();
		}
	}
	
	public String execute(Map parameters) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public JSONArray jexecute(Function function, DataSets datasets,
			JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
