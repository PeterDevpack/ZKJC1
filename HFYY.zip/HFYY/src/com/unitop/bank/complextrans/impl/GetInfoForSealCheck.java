package com.unitop.bank.complextrans.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.CommondFunction;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.util.CommonOperation;

/**
 * ��ȡ�˻���Ϣ������ӡ
 * 
 * @author Owner
 * 
 */
public class GetInfoForSealCheck extends BaseTrans {
/*
 * ϵͳ���ͣ������"����"�������������"֧��"����֧������
 * @see com.unitop.bank.complextrans.IComplexTrans#execute(com.unitop.bean.Function, com.unitop.bean.DataSets)
 */
	public String execute(Function function, DataSets datasets)
			throws Exception {
		List<String> childTrans = function.getMutil().getList();
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();
		String getAccountInfo = childTrans.get(0);
		List<Map<String, String>> list = datasets.getParamMap().get(
				getAccountInfo);
		Map resultmap0 = uniDBInterface.execSql(getAccountInfo, list,conn);
		// ��֤�˻��Ƿ����
		List<Map> resultlist0 = (List) resultmap0.get("rows");
		if (resultlist0 == null || resultlist0.size() == 0) {
			resultmap0.put("error", "�޴��˻���");
			resultmap.put(getAccountInfo, resultmap0);
			String xml = CommonOperation.mapToXML(resultmap, function.getId());
			return xml;
		}
		// �ж�Ȩ��
		Map<String, String> accountMap = resultlist0.get(0);
		String accountOrgnum = accountMap.get("JIGH");
		String shenghjghAcc = accountMap.get("SHENGHJGH");//�˻�ʡ�л�����
		String getClerk = childTrans.get(3);
		String clerknum = datasets.getParamMap().get(getClerk).get(0).get("clerknum");
		Map resultMap3 = uniDBInterface.execSql(getClerk, datasets
				.getParamMap().get(getClerk),conn);
		List<Map> resultlist3 = (List) resultMap3.get("rows");
		if(resultlist3==null||resultlist3.size()==0){
			resultMap3.remove("rows");
			resultMap3.put("error", "��Ա"+clerknum+"������!�޷���ȡ�˻������Ϣ��");
			resultmap.put(getClerk,resultMap3);
			String xml = CommonOperation.mapToXML(resultmap, function.getId());
			return xml;
		}
		Map<String, String> clerkMap = resultlist3.get(0);
		String clerkOrgnum = (String) clerkMap.get("N_ORGANNUM");
		String shenghjighClerk = clerkMap.get("SHENGHJGH");//��Աʡ�л�����
		boolean isCanOperDesAccount = false;
		if("��".equals(accountMap.get("TONGCTD"))){
			isCanOperDesAccount = true;
		}else if("ʡ".equals(accountMap.get("TONGCTD"))&&(shenghjighClerk.equals(shenghjghAcc))){
			isCanOperDesAccount = true;
		}else{	
			if("".equals(clerknum)||clerknum==null){
				isCanOperDesAccount = true;
			}else{
				isCanOperDesAccount = CommondFunction
				.isCanOperationDesNetPoint(clerkOrgnum, accountOrgnum);
			}
		}
		// boolean isCanOperDesAccount = true;
		
		/*
		 * �жϵ�ǰ�˻����������Ƿ�С�ڵ�ǰʱ��
		 */
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String qiyrq = accountMap.get("QIYRQ");
		Date start =sdf.parse(qiyrq);
		long start_long = start.getTime();
		long now = System.currentTimeMillis();
		if(start_long>now){
			resultmap0.remove("rows");
			resultmap0.put("error", "�Բ��𣬸��˻�δ���ã�");
			resultmap.put(getAccountInfo, resultmap0);
			String xml = CommonOperation.mapToXML(resultmap, function.getId());
			return xml;
		}
		/*		
		 * ��ȡԤ��ӡ��
		 */
		String getSeals = childTrans.get(1);
		List<Map<String, String>> paramlist1 = datasets.getParamMap().get(getSeals);
		Map resultmap1 = uniDBInterface.execSql(getSeals, paramlist1,conn);
		
		/*
		 * ��ȡ���
		 */
		String getSealCombins = childTrans.get(2);
		List<Map<String, String>> paramlist2 = datasets.getParamMap().get(
				getSealCombins);
		Map resultmap2 = uniDBInterface.execSql(getSealCombins, paramlist2,conn);
		
		if (!isCanOperDesAccount) {
			resultmap0.remove("rows");
			resultmap0.put("error", "�Բ�������Ȩ�鿴���˺ţ�");
			resultmap.put(getAccountInfo, resultmap0);
			String xml = CommonOperation.mapToXML(resultmap, function.getId());
			return xml;
		} else {
			String zhanghzt = accountMap.get("ZHANGHZT");
			String yinjshzt = accountMap.get("YINJSHZT");
			String zuhshzt = accountMap.get("ZUHSHZT");

			if("��Ч".equals(zhanghzt)){
				
			}else{
				resultmap0.remove("rows");
				resultmap0.put("error", "���˻�Ϊ"+zhanghzt+"״̬��");
				resultmap.put(getAccountInfo, resultmap0);
				String xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}
			//����ӡ��
			if ("��".equals(accountMap.get("YOUWYJ"))) {
				
				List resultlist1 = (List) resultmap1.get("rows");
				if (resultlist1 == null||resultlist1.size()==0) {
					resultmap0.remove("rows");
					resultmap0.put("error", "���˻��޿���ӡ��");
					resultmap.put(getAccountInfo, resultmap0);
					String xml = CommonOperation.mapToXML(resultmap, function.getId());
					return xml;
				} else {
					resultmap.put(getSeals, resultmap1);
				}
			}else{
				resultmap0.remove("rows");
				resultmap0.put("error", "���˻���ӡ����");
				resultmap.put(getAccountInfo,resultmap0);
				String xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}
			if ("��".equals(accountMap.get("YOUWZH"))) {
				List resultlist2 = (List) resultmap2.get("rows");
				resultmap.put(getSealCombins, resultmap2);
			}

			//����ж�
			if ("δ��".equals(yinjshzt)) {
				resultmap0.put("error", "��ʾ@���˻���ӡ��δ��");
				resultmap.put(getAccountInfo, resultmap0);
				resultmap.put(getSeals, resultmap1);
				resultmap.put(getSealCombins,resultmap2 );
				String xml = CommonOperation.mapToXML(resultmap, function
						.getId());
				return xml;
			} 
			
			
			if ("δ��".equals(zuhshzt)) {

				resultmap0.put("error", "��ʾ@���˻������δ��");
				resultmap.put(getAccountInfo, resultmap0);
				resultmap.put(getSeals, resultmap1);
				resultmap.put(getSealCombins,resultmap2 );
				String xml = CommonOperation.mapToXML(resultmap, function
						.getId());
				return xml;
			} else {
				resultmap.put(getAccountInfo, resultmap0);
			}
		}
	
		
		String xml = CommonOperation.mapToXML(resultmap, function.getId());
		release();
		return xml;
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
