package com.unitop.bank.complextrans.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

/**
 * ӡ�����
 * 
 * @author Owner
 * 
 */
public class ChangeSeal extends BaseTrans {

	public String execute(Function function, DataSets datasets)
			throws Exception {
		beginTrans();
		String error = "";
		String xml = "";
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();// ���ս��
		try {
			List<String> childTrans = function.getMutil().getList();
			/*
			 * ���ӡ�������
			 */
			String getMaxChangeNumber = childTrans.get(0);
			Map resultMap0 = uniDBInterface.execSql(getMaxChangeNumber,
					datasets.getParamMap().get(getMaxChangeNumber),conn);
			error += resultMap0.get("error");
			List<Map<String, String>> resultlist0 = (List<Map<String, String>>) resultMap0
					.get("rows");
			Map<String, String> yinjmap = resultlist0.get(0);
			String yinjbghStr = resultlist0.get(0).get("MAX_NUMBER_YINJBGH");

			int useSealCount = Integer.parseInt(yinjbghStr.substring(0,
					yinjbghStr.indexOf(".") != -1 ? yinjbghStr.indexOf(".")
							: yinjbghStr.length()));

			String yinjbgh = "" + (useSealCount + 1);
			/*
			 * ����������Ϣ
			 */
			String addSealinfo = childTrans.get(1);
			Map paramMap = datasets.getParamMap().get(addSealinfo).get(0);
			paramMap.put("yinjbgh", yinjbgh);
			Map resultMap1 = uniDBInterface.execSql(addSealinfo, datasets
					.getParamMap().get(addSealinfo),conn);
			resultmap.put(addSealinfo, resultMap1); 
			error += resultMap1.get("error");
			if (!"".equals(error)) {
				rollback();
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				release();
				return xml;
			} 
			/*
			 * ��ȡ���ݿ�ʱ��
			 */
//			String GetLaterDate = childTrans.get(2);
//			Map resultmap2 = uniDBInterface.execSql(GetLaterDate, datasets
//					.getParamMap().get(GetLaterDate),conn);
//			List resultlist2 = (List) resultmap2.get("rows");
//			Map datemap = (Map) resultlist2.get(0);
//			String deleteTime = (String) datemap.get("SYSDATE_STRING");// ���ϵͳʱ��
//			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//			Date systemdate = format.parse(systemTime);
//			long deltime = systemdate.getTime() + 60 * 60 * 24 * 1000;// ɾ��ʱ��
//			String deleteTime = format.format(new Date(deltime));
			/*
			 * ���ԭʼ��״̬
			 */
			String changeSeal = childTrans.get(2);
			List<Map<String, String>> paramList2 = datasets.getParamMap().get(
					changeSeal);
			Map resultMap2 = uniDBInterface.execSql(changeSeal, paramList2,conn);
			resultmap.put(changeSeal, resultMap2);
			error += resultMap2.get("error");
			if (!"".equals(error)) {
				rollback();
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				release();
				return xml;
			} 
			/*
			 * changeUserCheckState�����˻���ӡ�����״̬�ֶ�Ϊ��δ��
			 */
			String changeUserCheckState = childTrans.get(3);
			List<Map<String, String>> paramList3 = datasets.getParamMap().get(
					changeUserCheckState);
			Map resultMap3 = uniDBInterface.execSql(changeUserCheckState,
					paramList3,conn);
			resultmap.put(changeUserCheckState, resultMap3);
			error += resultMap3.get("error");

			xml = CommonOperation.mapToXML(resultmap, function.getId());
			if (!"".equals(error)) {
				rollback();
			} else {
				commit(); 
			}
		} catch (Exception e) {
			rollback(); 
			Map<String,Object> excMap = new HashMap<String,Object>();
			excMap.put("error", e.getMessage());
			resultmap.put("error",excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		}finally{
			release();
			return xml;
		}
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
