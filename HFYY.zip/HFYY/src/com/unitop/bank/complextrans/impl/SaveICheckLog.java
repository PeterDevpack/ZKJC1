package com.unitop.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

public class SaveICheckLog extends BaseTrans {

	public String execute(Function function, DataSets datasets)
			throws Exception {
		beginTrans();
		String error = "";
		String xml = "";
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();// ���ս��
		try {
			List<String> childTrans = function.getMutil().getList();
			/*
			 * ������Ʊ��ӡ��־��������Ϣ������ɾ���������� 
			 */
			String deleteRenWXX = childTrans.get(0);
			String addRenWXX = childTrans.get(1);

			Map resultMap0 = uniDBInterface.execSql(deleteRenWXX, datasets
					.getParamMap().get(deleteRenWXX),conn);
			resultmap.put(deleteRenWXX, resultMap0);
			error += resultMap0.get("error");
			
			resultMap0 = uniDBInterface.execSql(addRenWXX, datasets
					.getParamMap().get(addRenWXX),conn);
			resultmap.put(addRenWXX, resultMap0);
			error += resultMap0.get("error");

			if (!"".equals(error)) {
				rollback();
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				release();
				return xml;
			} 
			/*
			 * ����������־�������ڣ������
			 */
			String deleteYYRZ = childTrans.get(2);
			String addYYRZ = childTrans.get(3);
			List paramlists = datasets.getParamMap().get(addYYRZ);
			
			Map resultMap1 = null;
			String addYYRZerror = "";
			
			resultMap1 = uniDBInterface.execSql(deleteYYRZ, datasets.getParamMap().get(deleteYYRZ),conn);
			addYYRZerror+=resultMap1.get("error");
			resultMap1.put("error", addYYRZerror);
			resultmap.put(deleteYYRZ, resultMap1);
			error += resultMap1.get("error");
			
			for (int i = 0; i < paramlists.size(); i++) {
				List param1 = new ArrayList();
				param1.add(paramlists.get(i));
				// ��ɾ��������־��������			
			    resultMap1 = uniDBInterface.execSql(addYYRZ, param1,conn);
			    addYYRZerror+=resultMap1.get("error");
				resultMap1.put("error", addYYRZerror);
				resultmap.put(addYYRZ, resultMap1);
				error += resultMap1.get("error");
				
			}
			if (!"".equals(error)) {
				rollback();
			} else {
				commit();
			}
			xml = CommonOperation.mapToXML(resultmap, function.getId());
		} catch (Exception e) {
			e.printStackTrace();
			rollback();
			Map<String,Object> excMap = new HashMap<String,Object>();
			excMap.put("error", e.getMessage());
			resultmap.put("error",excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		} finally {
			release();
			return xml;
		}
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
