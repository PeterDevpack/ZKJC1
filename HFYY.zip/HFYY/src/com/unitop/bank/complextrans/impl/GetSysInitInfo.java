package com.unitop.bank.complextrans.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;
public class GetSysInitInfo extends BaseTrans{

	public String execute(Function function, DataSets datasets)
			throws Exception {
		List<String> childTrans = function.getMutil().getList();
		Map<String, Map<String, Object>> resultmap = new HashMap<String, Map<String, Object>>();
		String xml = "";
		try {
		
			String getClerk = childTrans.get(0);
			Map resultMap0 = uniDBInterface.execSql(getClerk, datasets
					.getParamMap().get(getClerk),conn);
			List<Map> resultlist0  = (List) resultMap0.get("rows");
			if(resultlist0.size()==0||resultlist0==null){
				resultMap0.put("error", "�޴˹�Ա��");
				resultmap.put(getClerk, resultMap0);
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}
			resultmap.put(getClerk, resultMap0);
			
			String getClerkQX = childTrans.get(1);
			Map resultMap1 = uniDBInterface.execSql(getClerkQX, datasets
					.getParamMap().get(getClerkQX),conn);
			List<Map> resultlist1  = (List) resultMap1.get("rows");
			if(resultlist1.size()==0||resultlist0==null){
				/*��ȡ����Ȩ��*/
				String getAllQx= childTrans.get(6);
				Map resultMap6=uniDBInterface.execSql(getAllQx,datasets
						.getParamMap().get(getAllQx),conn);
				resultmap.put(getClerkQX, resultMap6);
			}else{
				resultmap.put(getClerkQX, resultMap1);
			}
			
			String getAllOrganAsOrganNumber = childTrans.get(2);
			Map<String, String> clerkMap = resultlist0.get(0);
			List<Map<String, String>> paramList1 = datasets.getParamMap().get(getAllOrganAsOrganNumber);
			paramList1.get(0).put("organnum", clerkMap.get("N_ORGANNUM"));
			Map resultMap2 = uniDBInterface.execSql(getAllOrganAsOrganNumber, paramList1,conn);
			List<Map> resultlist2 = (List) resultMap2.get("rows");
			if(resultlist2==null||resultlist2.size()==0){
				resultMap2.put("error", "�޴˻�����Ϣ��");
				resultmap.put(getAllOrganAsOrganNumber, resultMap2);
				xml = CommonOperation.mapToXML(resultmap, function.getId());
				return xml;
			}else{
				resultmap.put(getAllOrganAsOrganNumber, resultMap2);
			}
			Map controlParamMap = datasets.getControlParamMap();
			String sysconfigtime = (String) controlParamMap.get("sysconfigtime");//ϵͳ�����������ʱ��
			String attributetime =(String) controlParamMap.get("attributetime"); //������չ�������ʱ��
			String getSysConfig = childTrans.get(3);
			String GetSysConfigValue = childTrans.get(4);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			boolean ifdownload = true;
			
		if("".equals(sysconfigtime)||sysconfigtime==null){
				Map resultMap3 = uniDBInterface.execSql(getSysConfig, datasets.getParamMap().get(getSysConfig),conn);
				resultmap.put(getSysConfig, resultMap3);
			}else{
				Map resultMap4 = uniDBInterface.execSql(GetSysConfigValue, datasets.getParamMap().get(GetSysConfigValue),conn);
				List<Map> resultlist4 = (List) resultMap4.get("rows");
				String value = (String) resultlist4.get(0).get("VALUE");
				Date valueDate = sdf.parse(value);
				Date sysconfigtimeDate = sdf.parse(sysconfigtime);
				//���sysconfigtimeDate<valueDate,���getSysConfig
				if(sysconfigtimeDate.compareTo(valueDate)==-1){
					Map resultMap3 = uniDBInterface.execSql(getSysConfig, datasets.getParamMap().get(getSysConfig),conn);
					resultmap.put(getSysConfig, resultMap3);
				}else{
					ifdownload = false;
				}
			}
			String getAttribute = childTrans.get(5);
			
			//���ڸ��ݴ����attributetime�ж����Ƿ�Ϊ��
			if("".equals(attributetime)||attributetime==null){
				Map resultMap5 = uniDBInterface.execSql(getAttribute, datasets.getParamMap().get(getAttribute),conn);
				resultmap.put(getAttribute, resultMap5);
			}else{
				Map resultMap3 = uniDBInterface.execSql(getSysConfig, datasets.getParamMap().get(getSysConfig),conn);
				List<Map> resultlist3 = (List) resultMap3.get("rows");
				String attributetimeDB="";
				for(int i=0;i<resultlist3.size();i++){
					if("sysconfigtime".equals(resultlist3.get(i).get("KEY"))){
						attributetimeDB= (String) resultlist3.get(i).get("VALUE");	//��ȡ���ݿ��е�������չ�������ʱ��
					}
				}
		
				Date attributetimeDBDate = sdf.parse(attributetimeDB);
				Date attributetimeDate = sdf.parse(attributetime);
				//��sysconfig.XMLû�����ظ�����������attribute.XML 
				if(ifdownload&&(attributetimeDate.compareTo(attributetimeDBDate)==-1)){
					Map resultMap5 = uniDBInterface.execSql(getAttribute, datasets.getParamMap().get(getAttribute),conn);
					resultmap.put(getAttribute, resultMap5);
				}
			}
			xml = CommonOperation.mapToXML(resultmap, function.getId());
		}catch (Exception e) {
			e.printStackTrace();
			Map<String,Object> excMap = new HashMap<String,Object>();
			excMap.put("error", e.getMessage());
			resultmap.put("error",excMap);
			xml = CommonOperation.mapToXML(resultmap, function.getId());
			throw new UfSealException(e.getMessage());
		}finally{
			return xml;
		}
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.unitop.bank.complextrans.IComplexTrans#jexecute(com.unitop.bean.Function, com.unitop.bean.DataSets)
	 */
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
//	public static void main(String[] args) throws ParseException {
//	String s = "2012-02-14 14:53:46";
//	String l = "2012-02-13 13:39:17";
//	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//	Date s1 = sdf.parse(s);
//	Date l1 = sdf.parse(l);
//	System.out.println(s1.compareTo(l1));
//}
}
