package com.unitop.bank.complextrans;

import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bean.DataSets;
import com.unitop.bean.Function;

public interface IComplexTrans {
	
	public JSONArray jexecute(Function function ,DataSets datasets, JSONObject jsonRet) throws Exception;
	
	public String execute(Function function ,DataSets datasets) throws Exception;
	
	public String execute(Map<String, String> parameters) throws Exception;
	
}
