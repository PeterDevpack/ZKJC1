package com.unitop.bank;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

public class Load extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {
		super.init();
		FunctionConfiguration.getInstance();
		DataDict.getInstance();
		Parameters.getInstance();
		
	}

}
