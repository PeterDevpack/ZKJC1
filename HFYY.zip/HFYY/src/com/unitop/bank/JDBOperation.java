package com.unitop.bank;

/**
 * @author Daniel
 * @2013-3-6
 * @TODO
 */
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.lob.OracleLobHandler;

import com.unitop.bean.DataSets;
import com.unitop.bean.FieldAttribute;
import com.unitop.bean.Function;
import com.unitop.bean.ParsedSql;
import com.unitop.exception.UfSealException;
import com.unitop.util.Base64;
import com.unitop.util.CommonOperation;

public class JDBOperation {

	public static OracleLobHandler lobHandler = new OracleLobHandler();

	/**
	 * �������״���
	 * 
	 * @param sql
	 * @param paraMap
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static void updateDB(String sql, Map paraMap) throws Exception {
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		SqlUpdate su = new SqlUpdate(DataSourceFactory.getDataSourceByPool(), parsedSql.getNewSql());
		String[] parameters = parsedSql.getParameterNames();
		Map newMap = new HashMap();
		try {
			for (int i = 0; i < parameters.length; i++) {
				String parameter = parameters[i];
				newMap.put(parameter.toLowerCase(), paraMap.get(parameter.toLowerCase()));
			}
			Map objectMap = ParameterUtils.parseStringParametersToObjects(newMap);
			ParameterUtils.declareParameterType(su, sql, paraMap);
			su.compile();
			Object[] parameterValues = NamedParameterUtils.buildValueArray(sql.toLowerCase(), objectMap);
			su.update(parameterValues);
		}
		catch (DataAccessException e) {
			throw e;
		}
	}

	/**
	 * ���ؽ������ÿ��һ��Map�����������ֵ������ֵ���ַ�������
	 * 
	 * @param sql
	 * @param paraMap
	 * @return
	 * @throws UfSealException
	 * @throws SQLException
	 */
	@SuppressWarnings("unchecked")
	public List commondQueryWithMap(String sql, Map paraMap) throws UfSealException, SQLException {
		DataSource dataSource = DataSourceFactory.getDataSourceByPool();
		CommondQuery sqlQuery = new CommondQuery(dataSource, NamedParameterUtils.parseSqlStatementIntoString(sql));
		Map newMap = ParameterUtils.parseStringParametersToObjects(paraMap);
		ParameterUtils.declareParameterType(sqlQuery, sql, paraMap);
		sqlQuery.compile();
		Object[] parameterValues = NamedParameterUtils.buildValueArray(sql, newMap);
		return sqlQuery.execute(parameterValues);
	}

	private class CommondQuery extends MappingSqlQuery {
		private OracleLobHandler lobHandler;

		CommondQuery(DataSource dataSource, String sql) {
			super(dataSource, sql);
			lobHandler = new OracleLobHandler();
		}

		public Object mapRow(ResultSet rs, int rowNumber) throws SQLException {
			ResultSetMetaData metaData = rs.getMetaData();
			Map<String, String> rowMap = new HashMap<String, String>();
			DataDict dataDict = DataDict.getInstance();
			// ��ʽ��double���ͺ�float ����
			DecimalFormat dformat = new DecimalFormat("####0.00");
			int count = metaData.getColumnCount();
			for (int i = 1; i < count + 1; i++) {
				String name = metaData.getColumnName(i);
				if (null != name && name.trim().length() > 0) {
					name = name.toLowerCase();
					FieldAttribute field = dataDict.getField(name);
					if (null == field) {
						int type = metaData.getColumnType(i);
						if (type == Types.INTEGER) {
							Integer value = new Integer(rs.getInt(i));
							if (value == null)
								rowMap.put(metaData.getColumnName(i), "");
							else
								rowMap.put(metaData.getColumnName(i), value.toString());
						} else if (type == Types.FLOAT || type == Types.NUMERIC) {
							Double value = new Double(rs.getDouble(i));
							if (value == null)
								rowMap.put(metaData.getColumnName(i), "");
							else
								rowMap.put(metaData.getColumnName(i), dformat.format(value));
						} else if (type == Types.VARCHAR) {
							String value = rs.getString(i);
							if (value == null)
								rowMap.put(metaData.getColumnName(i), "");
							else
								rowMap.put(metaData.getColumnName(i), value.toString());
						} else if (type == Types.BLOB || type == Types.LONGVARBINARY) {
							byte[] stream = lobHandler.getBlobAsBytes(rs, i);
							if (stream != null && stream.length > 0)
								rowMap.put(metaData.getColumnName(i), Base64.encodeBytes(stream));
							else
								rowMap.put(metaData.getColumnName(i), "");
						} else
							CommonUtil.info("no found this Type: " + metaData.getColumnName(i) + " type: " + type);
					} else if ("integer".equals(field.getType())) {
						Integer value = new Integer(rs.getInt(i));
						if (value == null)
							rowMap.put(metaData.getColumnName(i), "");
						else
							rowMap.put(metaData.getColumnName(i), value.toString());
					} else if ("blob".equals(field.getType())) {
						byte[] stream = lobHandler.getBlobAsBytes(rs, i);
						if (stream != null && stream.length > 0)
							rowMap.put(metaData.getColumnName(i), Base64.encodeBytes(stream));
						else
							rowMap.put(metaData.getColumnName(i), "");
					} else if ("string".equals(field.getType())) {
						String value = rs.getString(i);
						if (value == null)
							rowMap.put(metaData.getColumnName(i), "");
						else
							rowMap.put(metaData.getColumnName(i), value.toString());
					} else {
						CommonUtil.error(field.getType() + " ���ô����������������");
					}
				}
			}
			return rowMap;
		}
	}

	/**
	 * �򵥲�ѯ�������ת��Ϊjson
	 * 
	 * @param sql
	 * @param paraMap
	 * @return
	 * @throws IOException
	 * @throws SQLException
	 * @throws UfSealException
	 */
	public static JSONArray commondQueryToJSONArray(String funcID, String sql, Map<String, String> paraMap) throws SQLException, IOException, UfSealException {
		System.out.println("===" + sql);
//		Iterator it = paraMap.entrySet().iterator();
//		while(it.hasNext()){
//			Map.Entry<Object, Object> entry = (Entry<Object, Object>) it.next();
//			Object key = entry.getKey();//map�е�key
//			Object value = entry.getValue();//����key��Ӧ��value
//			System.out.println("====" + key + " " + value);
//		}
		Connection conn = DataSourceUtils.getConnection(DataSourceFactory.getDataSourceByPool());
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		PreparedStatement ps = conn.prepareStatement(parsedSql.getNewSql());
		String[] parameters = parsedSql.getParameterNames();
		CommonOperation.jdoParserSql(funcID, ps, parameters, paraMap);
		ResultSet rs = ps.executeQuery();
		ResultSetMetaData metaData = rs.getMetaData();
		JSONArray jsonArray = new JSONArray();
		int rsCount = 0;// �����жϽ����������
		while (rs.next()) {
			rsCount++;
			JSONObject jsonTemp = new JSONObject();
			for (int i = 1; i <= metaData.getColumnCount(); i++) {
				String name = metaData.getColumnName(i).toLowerCase();
				String value = "";
				if (null != rs.getObject(name)) {
					if ("yinjtp".equals(name.toLowerCase())) {
						byte[] stream = lobHandler.getBlobAsBytes(rs, name);
						value = Base64.encodeBytes(stream);
					} else {
						value = rs.getObject(name).toString();
					}
				}
				jsonTemp.put(name, value);
			}
			jsonArray.add(jsonTemp);
		}
		// ���ؽ����Ϊ������jsonarray�в����jsonobject -->.net����
		if (0 == rsCount) {
			JSONObject jsonTemp = new JSONObject();
			jsonArray.add(jsonTemp);
		}
		try {
			rs.close();
		}
		catch (SQLException e) {
			throw e;
		}
		try {
			ps.close();
		}
		catch (SQLException e) {
			throw e;
		}
		try {
			conn.close();
		}
		catch (SQLException e) {
			throw e;
		}
		return jsonArray;
	}

	/**
	 * hubowen
	 * 
	 * @param sql
	 * @param paraMap
	 * @throws SQLException
	 * @throws IOException
	 * @throws UfSealException
	 */
	@SuppressWarnings("unchecked")
	public static void updateDB(Function function, DataSets datasets) throws SQLException, IOException, UfSealException {
		ArrayList childList = function.getMutil().getList();
		if (childList != null) {
			PreparedStatement ps = null;
			Connection conn = null;
			try {
				conn = DataSourceUtils.getConnection(DataSourceFactory.getDataSourceByPool());
				conn.setAutoCommit(false);
				for (int i = 0; i < childList.size(); i++) {
					// ȡ�ӽ���
					String funcID = (String) childList.get(i);
					funcID = CommonOperation.exchangeURI(funcID);
					FunctionConfiguration configration = FunctionConfiguration.getInstance();
					Function func = configration.getFunction(funcID);
					List paramList = datasets.getParamMapValue(funcID);
					if (null == paramList || 0 == paramList.size()) {
						throw new UfSealException(funcID + " �ý��׵Ĳ����б�Ϊ�գ�");
					}
					// ȡ������
					for (int j = 0; j < paramList.size(); j++) {
						try {
							HashMap paraMap = (HashMap) paramList.get(j);
							ParsedSql parsedSql = ParameterUtils.parseSqlStatement(func.getSql());
							ps = conn.prepareStatement(parsedSql.getNewSql());
							String[] parameters = parsedSql.getParameterNames();
							CommonOperation.jdoParserSql(funcID, ps, parameters, paraMap);
							ps.execute();
						}
						catch (SQLException e) {
							CommonUtil.error("DBOperation updateDB exception", e);
							throw e;
						}
					}
				}
				conn.commit();
			}
			catch (SQLException e) {
				CommonUtil.error("DBOperation updateDB exception 2", e);
				try {
					conn.rollback();
				}
				catch (SQLException e1) {
					throw e;
				}
				throw e;
			}
			finally {
				try {
					ps.close();
				}
				catch (SQLException e) {
					throw e;
				}
				try {
					conn.close();
				}
				catch (SQLException e) {
					throw e;
				}
			}
		}
	}

	/**
	 * ���ӽ��׵��ü򵥸���
	 * 
	 * @param sql
	 * @param paraMap
	 * @throws UfSealException
	 * @throws SQLException
	 * @throws IOException
	 */
	public static void updateSQL(String funcID, String sql, Map<String, String> paraMap, Connection conn) throws UfSealException, SQLException, IOException {
		//System.out.println("===sql=====" + sql);
		
//		Iterator it = paraMap.entrySet().iterator();
//		while(it.hasNext()){
//			Map.Entry<Object, Object> entry = (Entry<Object, Object>) it.next();
//			Object key = entry.getKey();//map�е�key
//			Object value = entry.getValue();//����key��Ӧ��value
//			System.out.println("====" + key + " " + value);
//		}
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(parsedSql.getNewSql());
			String[] parameters = parsedSql.getParameterNames();
			CommonOperation.jdoParserSql(funcID, ps, parameters, paraMap);
			ps.execute();
		}
		catch (SQLException e) {
			CommonUtil.error("DBOperation updateDB SQLException", e);
			throw e;
		}
		catch (IOException e) {
			CommonUtil.error("DBOperation updateDB IOException", e);
			throw e;
		}
		finally {
			try {
				if (null != ps)
					ps.close();
			}
			catch (SQLException e) {
				throw e;
			}
		}
	}
	
}
