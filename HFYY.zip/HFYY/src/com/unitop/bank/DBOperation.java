package com.unitop.bank;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.lob.OracleLobHandler;

import com.unitop.bean.DataSets;
import com.unitop.bean.FieldAttribute;
import com.unitop.bean.Function;
import com.unitop.bean.Param;
import com.unitop.bean.ParsedSql;
import com.unitop.exception.UfSealException;
import com.unitop.util.Base64;
import com.unitop.util.CommonOperation;

public class DBOperation {

	public static OracleLobHandler lobHandler = new OracleLobHandler();

	/**
	 * �������״���
	 * 
	 * @param sql
	 * @param paraMap
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public static void updateDB(String sql, Map paraMap) throws Exception {
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		SqlUpdate su = new SqlUpdate(DataSourceFactory.getDataSourceByPool(), parsedSql.getNewSql());
		String[] parameters = parsedSql.getParameterNames();
		Map newMap = new HashMap();
		try {
			for (int i = 0; i < parameters.length; i++) {
				String parameter = parameters[i];
				newMap.put(parameter.toLowerCase(), paraMap.get(parameter.toLowerCase()));
			}
			Map objectMap = ParameterUtils.parseStringParametersToObjects(newMap);
			ParameterUtils.declareParameterType(su, sql, paraMap);
			su.compile();
			Object[] parameterValues = NamedParameterUtils.buildValueArray(sql.toLowerCase(), objectMap);
			su.update(parameterValues);
		} catch (DataAccessException e) {
			throw e;
		}
	}

	/**
	 * ���ô洢����
	 * 
	 * @param sql
	 * @param paraMap
	 * @throws SQLException
	 * @throws IOException
	 * @throws UfSealException 
	 */
	@SuppressWarnings("unchecked")
	public static void excuteCall(String sql, Map paraMap) throws SQLException,
			IOException, UfSealException {
		Connection conn = DataSourceUtils.getConnection(DataSourceFactory
				.getDataSourceByPool());
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		PreparedStatement ps = conn.prepareCall(parsedSql.getNewSql());
		String[] parameters = parsedSql.getParameterNames();
		CommonOperation.doParserSql(ps, parameters, paraMap);
		ps.execute();
		conn.commit();
		try {
			ps.close();
		} catch (SQLException e) {
			throw e;
		}
		try {
			conn.close();
		} catch (SQLException e) {
			throw e;
		}
	}

	/**
	 * �򵥽��׷��ؽ������xml�ļ�
	 * 
	 * @param sql
	 * @param paraMap
	 * @return
	 * @throws Exception
	 */
	public static String commondQuery(String sql, Map paraMap) throws Exception {
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		Connection conn = DataSourceUtils.getConnection(DataSourceFactory
				.getDataSourceByPool());
		PreparedStatement ps = conn.prepareStatement(parsedSql.getNewSql());
		String[] parameters = parsedSql.getParameterNames();
		DataDict dataDict = DataDict.getInstance();

		for (int i = 0; i < parameters.length; i++) {
			String parameter = parameters[i];
			FieldAttribute attribute = dataDict.getField(parameter);
			if (attribute.getType().equals("string")) {
				ps.setString(i + 1, (String) paraMap.get(parameter));
			} else if (attribute.getType().equals("integer")) {
				ps.setInt(i + 1, Integer.valueOf(
						(String) paraMap.get(parameter)).intValue());
			} else if (attribute.getType().equals("float")) {
				ps.setDouble(i + 1, Double.valueOf(
						(String) paraMap.get(parameter)).doubleValue());
			} else if (attribute.getType().equals("blob")) {
				byte[] b = Base64.decode((String) paraMap.get(parameter));
				InputStream in = new ByteArrayInputStream(b);
				ps.setBinaryStream(i + 1, in, b.length);
				in.close();
			}
		}
		Element rootElement = new Element("root");
		Element rowsElement = new Element("rows");
		Element fieldnameElement = new Element("FieldNames");
		Document myDocument = new Document(rootElement);
		ResultSet rs = ps.executeQuery();
		ResultSetMetaData metaData = rs.getMetaData();
		try {
			int count = metaData.getColumnCount();
			rootElement.setAttribute("error", "");
			for (int i = 1; i < count + 1; i++) {
				String name = metaData.getColumnName(i);
				Element fieldElement = new Element("FieldName");
				if (name != null && name.trim().length() > 0) {
					name = name.toLowerCase();
					FieldAttribute field = dataDict.getField(name);
					fieldElement.setAttribute("Name", name);
					fieldElement.setAttribute("Type", field.getType());
					fieldElement.setAttribute("Length", field.getLength());
				} else {
					fieldElement.setAttribute("Name", "aa" + i);
					int type = metaData.getColumnType(i);
					if (type == Types.INTEGER)
						fieldElement.setAttribute("Type", "integer");
					else if (type == Types.FLOAT || type == Types.NUMERIC)
						fieldElement.setAttribute("Type", "float");
					else if (type == Types.VARCHAR)
						fieldElement.setAttribute("Type", "string");
					else if (type == Types.BLOB)
						fieldElement.setAttribute("Type", "blob");
					fieldElement.setAttribute("Length", "500");
				}
				fieldnameElement.addContent(fieldElement);
			}
			rootElement.addContent(fieldnameElement);
			// ��ʽ��double���ͺ�float ����
			DecimalFormat dformat = new DecimalFormat("####0.00");
			while (rs.next()) {
				Element row = new Element("row");

				for (int i = 1; i < count + 1; i++) {
					int type = metaData.getColumnType(i);
					String name = metaData.getColumnName(i);
					name = name.toLowerCase();
					if ((name == null) || (name.trim().length() == 0))
						name = "aa" + i;
					if (type == Types.INTEGER || type == Types.BIGINT
							|| type == Types.SMALLINT || type == Types.TINYINT) {
						Integer value = new Integer(rs.getInt(i));
						if (value != null)
							row.setAttribute(name, value.toString());
						else
							row.setAttribute(name, "");
					} else if (type == Types.FLOAT || type == Types.NUMERIC
							|| type == Types.DOUBLE || type == Types.REAL
							|| type == Types.DECIMAL) {
						Double value = new Double(rs.getDouble(i));
						if (value != null)
							row.setAttribute(name, dformat.format(value));
						else
							row.setAttribute(name, "");
					} else if (type == Types.VARCHAR || type == Types.CHAR) {
						String value = rs.getString(i);
						if (value != null)
							row.setAttribute(name, value);
						else
							row.setAttribute(name, "");
					} else if (type == Types.BLOB
							|| type == Types.LONGVARBINARY
							|| type == Types.CLOB
							|| type == Types.LONGVARBINARY
							|| type == Types.VARBINARY) {
						byte[] stream = CommonOperation.lobHandler
								.getBlobAsBytes(rs, i);
						if (stream != null && stream.length > 0)
							row.setAttribute(name, Base64.encodeBytes(stream));
						else
							row.setAttribute(name, "");
					} else {
					}
				}
				rowsElement.addContent(row);
			}
			rootElement.addContent(rowsElement);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		XMLOutputter outputter = new XMLOutputter();
		outputter.setEncoding("gb2312");
		return outputter.outputString(myDocument);
	}

	/**
	 * ���ؽ������ÿ��һ��Map�����������ֵ������ֵ���ַ�������
	 * 
	 * @param sql
	 * @param paraMap
	 * @return
	 * @throws UfSealException
	 * @throws SQLException
	 */
	@SuppressWarnings("unchecked")
	public List commondQueryWithMap(String sql, Map paraMap)
			throws UfSealException, SQLException {
		DataSource dataSource = DataSourceFactory.getDataSourceByPool();
		CommondQuery sqlQuery = new CommondQuery(dataSource,
				NamedParameterUtils.parseSqlStatementIntoString(sql));
		Map newMap = ParameterUtils.parseStringParametersToObjects(paraMap);
		ParameterUtils.declareParameterType(sqlQuery, sql, paraMap);
		sqlQuery.compile();
		Object[] parameterValues = NamedParameterUtils.buildValueArray(sql,
				newMap);
		return sqlQuery.execute(parameterValues);
	}

	private class CommondQuery extends MappingSqlQuery {
		private OracleLobHandler lobHandler;

		CommondQuery(DataSource dataSource, String sql) {
			super(dataSource, sql);
			lobHandler = new OracleLobHandler();
		}

		public Object mapRow(ResultSet rs, int rowNumber) throws SQLException {
			ResultSetMetaData metaData = rs.getMetaData();
			Map<String, String> rowMap = new HashMap<String, String>();
			DataDict dataDict = DataDict.getInstance();
			// ��ʽ��double���ͺ�float ����
			DecimalFormat dformat = new DecimalFormat("####0.00");
			int count = metaData.getColumnCount();
			for (int i = 1; i < count + 1; i++) {
				String name = metaData.getColumnName(i);
				if (null != name && name.trim().length() > 0) {
					name = name.toLowerCase();
					FieldAttribute field = dataDict.getField(name);
					if (null == field) {
						int type = metaData.getColumnType(i);
						if (type == Types.INTEGER) {
							Integer value = new Integer(rs.getInt(i));
							if (value == null)
								rowMap.put(metaData.getColumnName(i), "");
							else
								rowMap.put(metaData.getColumnName(i), value
										.toString());
						} else if (type == Types.FLOAT || type == Types.NUMERIC) {
							Double value = new Double(rs.getDouble(i));
							if (value == null)
								rowMap.put(metaData.getColumnName(i), "");
							else
								rowMap.put(metaData.getColumnName(i), dformat
										.format(value));
						} else if (type == Types.VARCHAR) {
							String value = rs.getString(i);
							if (value == null)
								rowMap.put(metaData.getColumnName(i), "");
							else
								rowMap.put(metaData.getColumnName(i), value
										.toString());
						} else if (type == Types.BLOB
								|| type == Types.LONGVARBINARY) {
							byte[] stream = lobHandler.getBlobAsBytes(rs, i);
							if (stream != null && stream.length > 0)
								rowMap.put(metaData.getColumnName(i), Base64
										.encodeBytes(stream));
							else
								rowMap.put(metaData.getColumnName(i), "");
						} else
							CommonUtil.info("no found this Type: "
									+ metaData.getColumnName(i) + " type: "
									+ type);
					} else if ("integer".equals(field.getType())) {
						Integer value = new Integer(rs.getInt(i));
						if (value == null)
							rowMap.put(metaData.getColumnName(i), "");
						else
							rowMap.put(metaData.getColumnName(i), value
									.toString());
					} else if ("blob".equals(field.getType())) {
						byte[] stream = lobHandler.getBlobAsBytes(rs, i);
						if (stream != null && stream.length > 0)
							rowMap.put(metaData.getColumnName(i), Base64
									.encodeBytes(stream));
						else
							rowMap.put(metaData.getColumnName(i), "");
					} else if ("string".equals(field.getType())) {
						String value = rs.getString(i);
						if (value == null)
							rowMap.put(metaData.getColumnName(i), "");
						else
							rowMap.put(metaData.getColumnName(i), value
									.toString());
					} else {
						CommonUtil.error(field.getType() + " ���ô����������������");
					}
				}
			}
			return rowMap;
		}
	}

	/**
	 * �򵥲�ѯ�������ת��Ϊxml
	 * 
	 * @param sql
	 * @param paraMap
	 * @return
	 * @throws IOException
	 * @throws SQLException
	 * @throws UfSealException
	 */
	public static String commondQueryToXML(String sql,
			Map<String, String> paraMap) throws SQLException, IOException,
			UfSealException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String StrXML = null;
		try{
			conn = DataSourceUtils.getConnection(DataSourceFactory
					.getDataSourceByPool());
			ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
			ps = conn.prepareStatement(parsedSql.getNewSql());
			String[] parameters = parsedSql.getParameterNames();
			CommonOperation.doParserSql(ps, parameters, paraMap);
			rs = ps.executeQuery();
			StrXML= CommonOperation.resultSetToXML(rs);
		}catch(Exception e){
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e1) {
				e.printStackTrace();
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e1) {
				e.printStackTrace();
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e.printStackTrace();
			}
		}
		
		return StrXML;
	}
	
	/**
	 * hubowen
	 * 
	 * @param sql
	 * @param paraMap
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 * @throws UfSealException 
	 */
	@SuppressWarnings("unchecked")
	public static String commondQueryToXML(Function function, DataSets datasets)
			throws SQLException, IOException, UfSealException {
		StringBuffer xml = new StringBuffer();
		ResultSet rs = null;
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DataSourceUtils.getConnection(DataSourceFactory
					.getDataSourceByPool());
			ArrayList childList = function.getMutil().getList();
			if (childList != null) {
				xml.append("<root error=''>");
				xml.append("<multi>");
				for (int i = 0; i < childList.size(); i++) {
					// ȡ�ӽ���
					String funcID = (String) childList.get(i);
					funcID = CommonOperation.exchangeURI(funcID);
					FunctionConfiguration configration = FunctionConfiguration
							.getInstance();
					Function func = configration.getFunction(funcID);
					List paramList = datasets.getParamMapValue(funcID);
					// ȡ������
					for (int j = 0; j < paramList.size(); j++) {
						HashMap paraMap = (HashMap) paramList.get(j);
						ParsedSql parsedSql = ParameterUtils
								.parseSqlStatement(func.getSql());
						ps = conn.prepareStatement(parsedSql.getNewSql());
						String[] parameters = parsedSql.getParameterNames();
						CommonOperation.doParserSql(ps, parameters, paraMap);
						rs = ps.executeQuery();
						try {
							String strXML = CommonOperation.resultSetToXML(rs,
									funcID);
							strXML = strXML.substring(strXML.indexOf("<data"));
							xml.append(strXML);

						} catch (SQLException e) {
							CommonUtil.debug(
									"DBOperation commondQueryToXML exception",
									e);
							throw e;
						}
					}
				}
				xml.append("</multi>");
				xml.append("</root>");

				return xml.toString();
			} else {
				xml.append("<root error=''>");
				xml.append("</root>");
				return xml.toString();
			}
		} catch (SQLException e) {
			CommonUtil.error("DBOperation commondQueryToXML2 exception", e);
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		/*	rs.close();
			ps.close();
			conn.close();*/
		}
	}

	/**
	 * hubowen
	 * 
	 * @param sql
	 * @param paraMap
	 * @throws SQLException
	 * @throws IOException
	 * @throws UfSealException
	 */
	@SuppressWarnings("unchecked")
	public static void updateDB(Function function, DataSets datasets)
			throws SQLException, IOException, UfSealException {
		ArrayList childList = function.getMutil().getList();
		if (childList != null) {
			PreparedStatement ps = null;
			Connection conn = null;
			try {
				conn = DataSourceUtils.getConnection(DataSourceFactory
						.getDataSourceByPool());
				conn.setAutoCommit(false);
				for (int i = 0; i < childList.size(); i++) {
					// ȡ�ӽ���
					String funcID = (String) childList.get(i);
					funcID = CommonOperation.exchangeURI(funcID);
					FunctionConfiguration configration = FunctionConfiguration
							.getInstance();
					Function func = configration.getFunction(funcID);
					List paramList = datasets.getParamMapValue(funcID);
					if (null == paramList || 0 == paramList.size()) {
						throw new UfSealException(funcID + " �ý��׵Ĳ����б�Ϊ�գ�");
					}
					// ȡ������
					for (int j = 0; j < paramList.size(); j++) {
						try {
							HashMap paraMap = (HashMap) paramList.get(j);
							ParsedSql parsedSql = ParameterUtils
									.parseSqlStatement(func.getSql());
							ps = conn.prepareStatement(parsedSql.getNewSql());
							String[] parameters = parsedSql.getParameterNames();
							CommonOperation
									.doParserSql(ps, parameters, paraMap);
							ps.execute();
						} catch (SQLException e) {
							CommonUtil.error("DBOperation updateDB exception",
									e);
							throw e;
						}
					}
				}
				conn.commit();
			} catch (SQLException e) {
				CommonUtil.error("DBOperation updateDB exception 2", e);
				try {
					conn.rollback();
				} catch (SQLException e1) {
					throw e;
				}
				throw e;
			} finally {
				try {
					ps.close();
				} catch (SQLException e) {
					throw e;
				}
				try {
					conn.close();
				} catch (SQLException e) {
					throw e;
				}
			}
		}
	}

	/**
	 * ���ӽ��׵��ü򵥲�ѯ���׽ӿ�
	 * 
	 * @param sql
	 * @param paraMap
	 * @param dataSource
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 * @throws UfSealException
	 */
	public List commondQueryToList(String sql, Map paraMap, Connection conn)
			throws SQLException, IOException, UfSealException {
		ResultSet rs = null;
		PreparedStatement ps = null;
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			DataDict dataDict = DataDict.getInstance();
			ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
			ps = conn.prepareStatement(parsedSql.getNewSql());
			String[] parameters = parsedSql.getParameterNames();
			CommonOperation.doParserSql(ps, parameters, paraMap);
			rs = ps.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int count = metaData.getColumnCount();
			// ��ʽ��double���ͺ�float ����
			DecimalFormat dformat = new DecimalFormat("####0.00");
			while (rs.next()) {
				Map<String, String> resultMap = new HashMap<String, String>();
				for (int i = 1; i < count + 1; i++) {
					int type = metaData.getColumnType(i);
					String name = metaData.getColumnName(i);
					name = name.toUpperCase();
					if ((null != name) && !(name.trim().length() == 0)) {
						FieldAttribute field = dataDict.getField(name);
						// �ж��ֵ��Ƿ���ڣ�����ֵ���ڣ�ʹ�ý���������ͻ�ȡ�ֶ�ֵ
						if (field == null) {
							if (type == Types.INTEGER || type == Types.BIGINT
									|| type == Types.SMALLINT
									|| type == Types.TINYINT) {
								Integer value = new Integer(rs.getInt(i));
								if (value != null) {
									resultMap.put(name, value.toString());
								} else {
									resultMap.put(name, "");
								}
							} else if (type == Types.FLOAT
									|| type == Types.NUMERIC
									|| type == Types.DOUBLE
									|| type == Types.REAL
									|| type == Types.DECIMAL) {
								Double value = new Double(rs.getDouble(i));
								if (value != null) {
									resultMap.put(name, dformat.format(value));
								} else {
									resultMap.put(name, "");
								}
							} else if (type == Types.VARCHAR
									|| type == Types.CHAR) {
								String value = rs.getString(i);
								if (value != null) {
									resultMap.put(name, value);
								} else {
									resultMap.put(name, "");
								}
							} else if (type == Types.BLOB
									|| type == Types.LONGVARBINARY
									|| type == Types.CLOB
									|| type == Types.LONGVARBINARY
									|| type == Types.VARBINARY) {
								byte[] stream = lobHandler
										.getBlobAsBytes(rs, i);
								if (stream != null && stream.length > 0) {
									Parameters params = Parameters
											.getInstance();
									Param param = params.getParam("isBase64");
									if (null != param) {
										String paramVale = param.getCansz();
										if ("1".equals(paramVale)) {
											resultMap.put(name, new String(
													stream));
										} else {
											resultMap.put(name, Base64
													.encodeBytes(stream));
										}
									} else {
										resultMap.put(name, Base64
												.encodeBytes(stream));
									}
								} else {
									resultMap.put(name, "");
								}
							}
							// �ֵ���ڣ������ֵ����ͽ���ÿ���ֶε�ֵ
						} else if ("integer".equals(field.getType())) {
							Integer value = new Integer(rs.getInt(i));
							if (null != value) {
								resultMap.put(name, value.toString());
							} else {
								resultMap.put(name, "");
							}
						} else if ("blob".equals(field.getType())) {
							byte[] stream = lobHandler.getBlobAsBytes(rs, i);
							if (null != stream && stream.length > 0) {
								Parameters params = Parameters.getInstance();
								Param param = params.getParam("isBase64");
								if (null != param) {
									String paramVale = param.getCansz();
									if ("1".equals(paramVale)) {
										resultMap.put(name, new String(stream));
									} else {
										resultMap.put(name, Base64
												.encodeBytes(stream));
									}
								} else {
									resultMap.put(name, Base64
											.encodeBytes(stream));
								}
							} else {
								resultMap.put(name, "");
							}

						} else if ("string".equals(field.getType())) {
							String value = rs.getString(i);
							if (null != value) {
								resultMap.put(name, value);
							} else {
								resultMap.put(name, "");
							}
						} else {
							CommonUtil.error(field.getType() + "���ô����������������");
							throw new UfSealException(field.getType()
									+ "���ô����������������");
						}
					} else {
						CommonUtil.error(name + "�ֶ���Ϊ�գ�");
						throw new UfSealException(name + " �ֶ�Ϊ�գ�");
					}
				}
				list.add(resultMap);
			}
		} catch (SQLException e) {
			CommonUtil.error("DBOperation commondQueryToXML2 exception", e);
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try {
				if (null != rs)
					rs.close();
			} catch (SQLException e) {
				throw e;
			}
			try {
				if (null != ps)
					ps.close();
			} catch (SQLException e) {
				throw e;
			}
		}
		return list;
	}

	/**
	 * ���ӽ��׵��ü򵥸���
	 * 
	 * @param sql
	 * @param paraMap
	 * @throws UfSealException
	 * @throws SQLException
	 * @throws IOException
	 */
	public static void updateSQL(String sql, Map<String, String> paraMap, Connection conn) throws UfSealException, SQLException, IOException {
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(parsedSql.getNewSql());
			String[] parameters = parsedSql.getParameterNames();
			CommonOperation.doParserSql(ps, parameters, paraMap);
			ps.execute();
		} catch (SQLException e) {
			CommonUtil.error("DBOperation updateDB SQLException", e);
			throw e;
		} catch (IOException e) {
			CommonUtil.error("DBOperation updateDB IOException", e);
			throw e;
		} finally {
			try {
				if (null != ps)
					ps.close();
			} catch (SQLException e) {
				throw e;
			}
		}
	}
}
