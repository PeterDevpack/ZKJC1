package com.unitop.bank;

import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sinodata.bank.JResponseManager;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
import com.unitop.util.CommonOperation;

/**
 * @author Daniel
 * @2013-2-26
 * @TODO
 */
public class JUniDBInterface {
	protected final Log logger = LogFactory.getLog(getClass());

	// �����������
	public JSONArray execSQLForParameters(String funcID, Map<String, String> paraMap, DataSets dataSets, JSONObject jsonRet) throws Exception {
		JSONArray responseArray = new JSONArray();
		if (dataSets == null) {
			responseArray = this.execSQL(funcID, paraMap);
		} else {
			responseArray = this.execSQL(funcID, paraMap, dataSets, jsonRet);
		}
		CommonUtil.info(responseArray.toString());
		return responseArray;
	}

	public JSONArray execSQL(String funcID, Map<String, String> paraMap) throws Exception {
		JSONArray responseArray = new JSONArray();
		funcID = CommonOperation.jexchangeURI(funcID);
		FunctionConfiguration configration = FunctionConfiguration.getInstance();
		Function function = configration.getFunction(funcID);
		try {
			String sqlType = function.getType();
			if (sqlType.equalsIgnoreCase("simpleQuery")) {
				JSONArray objectArray = new JSONArray();
				objectArray = JDBOperation.commondQueryToJSONArray(funcID, function.getSql(), paraMap);
				JSONObject jsonObj = new JSONObject();
				JResponseManager.jrObjSet(jsonObj, objectArray);
				responseArray.add(jsonObj);
			} else if (sqlType.equalsIgnoreCase("simpleTrans")) {
				JDBOperation.updateDB(function.getSql(), paraMap);
			} else if (sqlType.equalsIgnoreCase("systemconfig")) {
				String controlflag = ((String) paraMap.get("controlflag")).trim();
				if ("".equals(controlflag) || controlflag.length() == 0) {
					throw new UfSealException("���Ʋ���Ϊ�գ���������Ʋ�����");
				}
				if ("1001".equals(controlflag)) {
					FunctionConfiguration.reload();
				} else if ("1002".equals(controlflag)) {
					DataDict.reload();
				} else if ("1003".equals(controlflag)) {
					Parameters.reload();
				} else if ("1".equals(controlflag) || "0".equals(controlflag) || "2".equals(controlflag) || "3".equals(controlflag) || "-1".equals(controlflag)) {
					CommonUtil.util = new CommonUtil(controlflag);
				}
			}
			return responseArray;
		}
		catch (SQLException e) {
			CommonUtil.error("SQLException:", e);
			throw e;
		}
		catch (IOException e) {
			CommonUtil.error("IOException:", e);
			throw e;
		}
		catch (UfSealException e) {
			CommonUtil.error("UfSealException:", e);
			throw e;
		}
		catch (Exception e) {
			CommonUtil.error("Exception:", e);
			throw e;
		}
	}

	/**
	 * ִ����ϡ������ཻ��
	 * 
	 * @param funcID
	 * @param paraMap
	 * @param datasets
	 * @return xml
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public JSONArray execSQL(String funcID, Map paraMap, DataSets datasets, JSONObject jsonRet) throws Exception {
		JSONArray responseArray = new JSONArray();	
		funcID = CommonOperation.jexchangeURI(funcID);
		FunctionConfiguration configration = FunctionConfiguration.getInstance();
		Function function = configration.getFunction(funcID);
		try {
			String sqlType = function.getType();
			if (sqlType.equalsIgnoreCase("complexQuery")) {
				Class cls = Class.forName(this.jvalidateURI(function.getId()));
				Class partypes[] = new Class[3];
				partypes[0] = Function.class;
				partypes[1] = DataSets.class;
				partypes[2] = JSONObject.class;
				Method method = cls.getMethod("jexecute", partypes);
				Object[] arglist = new Object[3];
				arglist[0] = function;
				arglist[1] = datasets;
				arglist[2] = jsonRet;
 				responseArray = JSONArray.fromObject(method.invoke(cls.newInstance(), arglist));
			} else if (sqlType.equalsIgnoreCase("complexTrans")) {
				Class cls = Class.forName(this.jvalidateURI(function.getId()));
				Class partypes[] = new Class[3];
				partypes[0] = Function.class;
				partypes[1] = DataSets.class;
				partypes[2] = JSONObject.class;
				Method method = cls.getMethod("jexecute", partypes);
				Object[] arglist = new Object[3];
				arglist[0] = function;
				arglist[1] = datasets;
				arglist[2] = jsonRet;
				responseArray = JSONArray.fromObject(method.invoke(cls.newInstance(), arglist));
			} else if (sqlType.equalsIgnoreCase("systemconfig")) {
				String controlflag = ((String) paraMap.get("controlflag")).trim();
				if ("1001".equals(controlflag)) {
					FunctionConfiguration.reload();
				} else if ("1002".equals(controlflag)) {
					DataDict.reload();
				} else if ("1003".equals(controlflag)) {
					Parameters.reload();
				}
			}
			return responseArray;
		}
		catch (SQLException e) {
			CommonUtil.error("SQLException", e);
			throw e;
		}
		catch (IOException e) {
			CommonUtil.error("IOException", e);
			throw e;
		}
		catch (UfSealException e) {
			CommonUtil.error("UfSealException", e);
			throw e;
		}
		catch (Exception e) {
			CommonUtil.error("Exception", e);
			throw e;
		}
	}

	/**
	 * ���ӽ����е��ü򵥽���(�÷������ر����д��Զ���objName)
	 */
	public JSONObject execSql(String funcID, String objRetName, List<Map<String, String>> datasets, Connection conn) throws Exception {
		JSONObject childJsonObj = new JSONObject();
		try {
			FunctionConfiguration configration = FunctionConfiguration.getInstance();
			Function function = configration.getFunction(funcID);
			if (null == function) {
				throw new UfSealException(funcID + "����ID������");
			}
			String sqlType = function.getType();
			if (sqlType == null) {
				throw new UfSealException(sqlType + "������𲻴���");
			}
			int cntParam = datasets.size();
			if (1 == cntParam) {
				Map<String, String> paraMap = datasets.get(0);
				if (sqlType.equals("simpleQuery")) {
					JSONArray objectArray = new JSONArray();
					objectArray = JDBOperation.commondQueryToJSONArray(funcID, function.getSql(), paraMap);
					childJsonObj = JResponseManager.jrObjSet(childJsonObj, objectArray, objRetName);
				} else if (sqlType.equals("simpleTrans")) {
					JDBOperation.updateSQL(funcID, function.getSql(), paraMap, conn);
				}
			} else if (cntParam > 1) {
				//********************************************************
				// һ��Ľ�����,���ڲ�ѯ����cntParam�������1
				Map<String, String> paraMap = datasets.get(0);
				if(sqlType.equals("simpleQuery")) {
					JSONArray objectArray = new JSONArray();
					objectArray = JDBOperation.commondQueryToJSONArray(funcID, function.getSql(), paraMap);
					childJsonObj = JResponseManager.jrObjSet(childJsonObj, objectArray, objRetName);
				}
				//********************************************************
				System.out.println(datasets);
				for (int i = 0; i < cntParam; i++) {
					if (sqlType.equals("simpleTrans")) {
						
						System.out.println("function Id:"+funcID+"=="+datasets.get(i));
						JDBOperation.updateSQL(funcID, function.getSql(), datasets.get(i), conn);
					}
				}
			} else {}
			return childJsonObj;
		}
		catch (Exception e) {
			CommonUtil.error(funcID + "Exception : ", e);
			throw e;
		}
	}

	/**
	 * ���ӽ����е��ü򵥽���(�÷������ر�����objNameΪ��"")
	 */
	public JSONArray execSql(String funcID, List<Map<String, String>> datasets, Connection conn) throws Exception {
		JSONArray responseArray = new JSONArray();
		try {
			FunctionConfiguration configration = FunctionConfiguration.getInstance();
			Function function = configration.getFunction(funcID);
			String sqlType = function.getType();
			int cntParam = datasets.size();
			if (1 == cntParam) {
				Map<String, String> paraMap = datasets.get(0);
				if (sqlType.equals("simpleQuery")) {
					JSONArray objectArray = new JSONArray();
					objectArray = JDBOperation.commondQueryToJSONArray(funcID, function.getSql(), paraMap);
					JSONObject jsonObj = new JSONObject();
					JResponseManager.jrObjSet(jsonObj, objectArray);
					responseArray.add(jsonObj);
				} else if (sqlType.equals("simpleTrans")) {
					JDBOperation.updateSQL(funcID, function.getSql(), paraMap, conn);
				}
			} else if (cntParam > 1) {
				for (int i = 0; i < cntParam; i++) {
					if (sqlType.equals("simpleTrans")) {
						JDBOperation.updateSQL(funcID, function.getSql(), datasets.get(i), conn);
					}
				}
			} else {}
			return responseArray;
		}
		catch (Exception e) {
			CommonUtil.error(funcID + "Exception : ", e);
			throw e;
		}
	}
	
	private String jvalidateURI(String id) {
		return id.indexOf(".") == -1 ? CommonOperation.JClsComplextransPackagName + id : id;
	}

}
