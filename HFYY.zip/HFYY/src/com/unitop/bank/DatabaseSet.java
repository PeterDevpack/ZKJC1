package com.unitop.bank;

import java.io.Serializable;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.andromda.core.common.ResourceUtils;
import org.andromda.core.common.XmlObjectFactory;

import com.unitop.bean.DbElementAttribute;

public class DatabaseSet implements Serializable {

	private static final String DEFAULT_URI = "DatabaseSet.xml";

	private Map DatabaseSetMap = new HashMap();

	private static DatabaseSet dbset;

	public static DatabaseSet getInstance(final URL uri) {
		if (dbset == null)
			dbset = (DatabaseSet) XmlObjectFactory.getInstance(
					DatabaseSet.class).getObject(uri);

		
		return dbset;
	}

	public static DatabaseSet getInstance() {
		if (dbset == null) {
			URL configurationURL = ResourceUtils.getResource(DEFAULT_URI);
			dbset = (DatabaseSet) XmlObjectFactory.getInstance(
					DatabaseSet.class).getObject(configurationURL);
		}
		return dbset;
	}

	@SuppressWarnings("unchecked")
	public void addDbElement(DbElementAttribute dbelement) {
		DatabaseSetMap.put(dbelement.getName(), dbelement);
	}

	public DbElementAttribute getDbElement(String name) {
		return (DbElementAttribute) DatabaseSetMap.get(name);
	}

}
