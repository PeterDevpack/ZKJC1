package com.unitop.bank;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.unitop.bean.ParsedSql;
import com.unitop.bean.TFieldType;
import com.unitop.util.Base64;


public class QueryPackage { 

	private ByteArrayOutputStream dataOutPutStream;

	public ByteArrayOutputStream getDataOutPutStream() {
		return dataOutPutStream;
	}

	public QueryPackage() {
		dataOutPutStream = new ByteArrayOutputStream();
	}

	public void AddADOQuery(String sql, Map hm) throws Exception {
		// д��sql
		writeSql(sql);
		Map map = new HashMap();
		ParsedSql parsedSql = ParameterUtils.parseSqlStatement(sql);
		String[] paranames = parsedSql.getParameterNames();
		for (int i = 0; i < paranames.length; i++) {
			String parameter = paranames[i];
			map.put(parameter, hm.get(parameter));
		}
		Map newMap = ParameterUtils.parseStringParametersToObjects(map);

		for (int i = 0; i < paranames.length; i++) {
			String paraname = paranames[i];
			// д�����������
			int type = getParameterTypeValue(paraname);
			dataOutPutStream.write(getIntByteStream(type));
			// д������ĳ���
			dataOutPutStream
					.write(getIntByteStream(getParameterLength(paraname)));

			// д�����ֵ
			if (type == TFieldType.ftInteger) {
				Integer value = (Integer) newMap.get(paraname);
				dataOutPutStream.write(getIntByteStream(5));
				dataOutPutStream.write(getIntByteStream(value.intValue()));
				dataOutPutStream.write(0);
			} else if (type == TFieldType.ftString) {
				String value = (String) newMap.get(paraname);
				byte[] bytes = value.getBytes("gb2312");
				dataOutPutStream.write(getIntByteStream(bytes.length + 2));
				dataOutPutStream.write(bytes);
				dataOutPutStream.write(0);
				dataOutPutStream.write(0);
			} else if (type == TFieldType.ftFloat) {
				Double value = (Double) newMap.get(paraname);
				dataOutPutStream.write(getIntByteStream(9));
				dataOutPutStream
						.write(getDoubleByteStream(value.doubleValue()));
				dataOutPutStream.write(0);
			} else if (type == TFieldType.ftBlob) {
				String value = (String) hm.get(paraname);
				byte[] b = Base64.decode(value);
				if (b != null) {
					dataOutPutStream.write(getIntByteStream(b.length + 1));
					dataOutPutStream.write(b);
				}
				else
				{
					dataOutPutStream.write(1);
				}
				dataOutPutStream.write(0);
			}
		}
	}

	private void writeSql(String sql) throws IOException,
			UnsupportedEncodingException {
		// д������
		dataOutPutStream.write(getIntByteStream(1));
		// д��sql�ĳ���
		byte[] bytes = sql.getBytes("gb2312");
		dataOutPutStream.write(getIntByteStream(bytes.length));
		// д��sql
		dataOutPutStream.write(bytes);
	}

	public void ProcessTimeStamp() {

	}

	public void EndAdd() throws Exception {
	/*	
	 String sql = "insert into uppackage values(:code,:package,:up_date,:uptime,:upflage)";
		java.util.Date operateDate = new java.util.Date();
		java.text.SimpleDateFormat operateDateFormat = new java.text.SimpleDateFormat(
				"yyyy-MM-dd#HH:mm:ss");
		String data = operateDateFormat.format(operateDate).toLowerCase();
		String[] datatemp = data.split("#");
		String data1 = datatemp[0].trim();
		String time = datatemp[1].trim();
		long code = getMaxPackageCode();
		String scode = new Long(code).toString();

		Map map = new HashMap();
		map.put("code", scode);
		String s = Base64.encodeBytes(dataOutPutStream.toByteArray());
		map.put("package", s);
		map.put("up_date", data1);
		map.put("uptime", time);
		map.put("upflage", "δ�ϴ�");
		DBOperation.updateDB(sql, map);
		dataOutPutStream.close();
	 */
		}

	// public void WriteYewclLog(String GetLocalIP, String ZhangH,
	// String ManageDate, String ManageTime, String CaozLb, String GuiyDm,
	// String GuiyMc, String GuiYWdbs, String netpointflag, Connection conn)
	// throws Exception {
	// PreparedStatement statement = null;
	// PreparedStatement statement1 = null;
	// ResultSet rs = null;
	// try {
	//
	// String sql = "insert into
	// accountmanagelog(account,managedate,managetime,managetype,clerknum,clerkname,ip,str1,str2,str3)
	// values(?,?,?,?,?,?,?,?,?,?)";
	// String sql1 = "select * from accountinfo where account=?";
	// String sql2 = "insert into accountmanagelog
	// (account,managedate,managetime,managetype,clerknum,clerkname,ip)values(?,?,?,?,?,?,?)";
	// String temp = getSystemParameter(netpointflag,
	// "WhetherUseTaiwHerXunSpecial");
	// if (getSystemParameter(netpointflag,
	// "WhetherClerkManageLogTableUpd").equals("��")) {
	// statement = conn.prepareStatement(sql);
	// statement.setString(7, GetLocalIP);
	// statement.setString(1, ZhangH);
	// statement.setString(2, ManageDate);
	// statement.setString(3, ManageTime);
	// statement.setString(4, CaozLb);
	// statement.setString(5, GuiyDm);
	// statement.setString(6, GuiyMc);
	//
	// if (temp.equals("��") && (CaozLb.substring(1, 8).equals("��������"))
	// || (CaozLb.substring(1, 8).equals("�������"))
	// || (CaozLb.substring(1, 8).equals("����У��"))) {
	// statement.setString(8, GuiYWdbs);
	// } else {
	// statement1 = conn.prepareStatement(sql1);
	// statement1.setString(1, ZhangH);
	// rs = statement1.executeQuery();
	// if (temp.equals("��")) {
	// statement.setString(8, rs.getString(10));
	// } else {
	// statement.setString(8, rs.getString(2));
	// }
	//
	// }
	//
	// statement.setString(9, "");
	// statement.setString(10, "");
	//
	// statement.executeUpdate();
	// } else {
	// statement = conn.prepareStatement(sql2);
	// statement.setString(7, GetLocalIP);
	// statement.setString(1, ZhangH);
	// statement.setString(2, ManageDate);
	// statement.setString(3, ManageTime);
	// statement.setString(4, CaozLb);
	// statement.setString(5, GuiyDm);
	// statement.setString(6, GuiyMc);
	// statement.executeUpdate();
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// throw e;
	// } finally {
	// try {
	// if (statement != null) {
	// statement.close();
	// }
	// if (statement1 != null) {
	// statement1.close();
	// }
	// if (rs != null) {
	// rs.close();
	// }
	// } catch (Exception e) {
	//
	// e.printStackTrace();
	// throw e;
	// }
	// }
	// }

	// public boolean DataCanUpLoad(String account, String netpointflag,
	// Connection conn) throws Exception {
	// boolean result;
	// ResultSet rs = null;
	// Statement stmt = null;
	// if (getSystemParameter(netpointflag, "NotNomalOption").equals("����")) {
	// result = false;
	//
	// return result;
	// } else {
	// result = true;
	// }
	// if (getSystemParameter(netpointflag, "WhetherUpload_NotTongcTd")
	// .equals("��")) {
	// return result;
	// }
	// try {
	// stmt = conn.createStatement();
	// String sql = "select allexchange from accountinfo where account="
	// + account;
	// rs = stmt.executeQuery(sql);
	// String allexchange = "";
	// while (rs.next()) {
	// allexchange = rs.getString(1);
	// }
	// if (allexchange.equals("ͨ")) {
	// result = true;
	// } else {
	// result = false;
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// throw e;
	// } finally {
	// try {
	// if (rs != null) {
	// rs.close();
	// }
	// if (stmt != null) {
	// stmt.close();
	// }
	// } catch (Exception e) {
	//
	// e.printStackTrace();
	// throw e;
	// }
	// }
	// return result;
	// }

	private long getMaxPackageCode() throws Exception {
		JdbcTemplate jt = new JdbcTemplate(DataSourceFactory.getDataSourceByPool());
		return jt.queryForLong("select max(code) + 1 from uppackage");

	}

	public InputStream getInputStreamBase(String img) {
		byte[] bytes1 = Base64.decode(img);
		ByteArrayOutputStream imgtemp = new ByteArrayOutputStream();
		imgtemp.write(bytes1, 0, bytes1.length);
		String imgt = imgtemp.toString();
		byte[] bytes = imgt.getBytes();
		ByteArrayInputStream input = new ByteArrayInputStream(bytes);
		return input;
	}

	public String getInputStreamString(InputStream in) throws Exception {
		byte[] buffer = new byte[1024];
		String sealinkimage = "";
		int ch = 0;
		while ((ch = in.read(buffer)) != -1) {
			sealinkimage = sealinkimage + Base64.encodeBytes(buffer);
		}
		return sealinkimage;
	}

	private static byte[] getIntByteStream(int v) {
		byte[] bytes = new byte[4];
		bytes[0] = (byte) (0xff & v);
		bytes[1] = (byte) (0xff & (v >> 8));
		bytes[2] = (byte) (0xff & (v >> 16));
		bytes[3] = (byte) (0xff & (v >> 24));
		return bytes;
	}

	private static byte[] getDoubleByteStream(double d) {
		long v = Double.doubleToLongBits(d);
		byte[] bytes = new byte[9];
		bytes[0] = (byte) (0xff & v);
		bytes[1] = (byte) (0xff & (v >> 8));
		bytes[2] = (byte) (0xff & (v >> 16));
		bytes[3] = (byte) (0xff & (v >> 24));
		bytes[4] = (byte) (0xff & (v >> 32));
		bytes[5] = (byte) (0xff & (v >> 40));
		bytes[6] = (byte) (0xff & (v >> 48));
		bytes[7] = (byte) (0xff & (v >> 56));
		return bytes;
	}

	private int getParameterTypeValue(String paraName) throws Exception {
		String type = DataDict.getInstance().getField(paraName).getType();
		if (type.equals("string")) {
			return TFieldType.ftString;
		} else if (type.equals("integer")) {
			return TFieldType.ftInteger;
		} else if (type.equals("float")) {
			return TFieldType.ftFloat;
		} else if (type.equals("blob")) {
			return TFieldType.ftBlob;
		} else {
			throw new Exception("�������ʹ���");
		}
	}

	public int getParameterLength(String paraname) {
		String length = DataDict.getInstance().getField(paraname).getLength();
		return Integer.valueOf(length).intValue();
	}

//	public static void main(String[] args) {
//		 QueryPackage p = new QueryPackage();
//		 Map hm = new HashMap();
//		 hm.put("a", "123");
//		 hm.put("b", "456");
//		 hm.put("c", "789");
//		 hm.put("d", "1234");
//		 try {
//			p.AddADOQuery("insert into aa(a,b,c,d) values(:a,:b,:c,:d)", hm);
//			 p.EndAdd();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}

}
