package com.unitop.bank;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.andromda.core.common.XmlObjectFactory;

import com.unitop.bean.Function;
import com.unitop.bean.MultiTrans;
import com.unitop.exception.UfSealException;
/**
 * ���ؽ���
 * @author luoxiaoyi
 * 
 */
public class FunctionConfiguration implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * ���׼���
	 */
	private Map<String,Function> funcMap = new HashMap<String,Function>();

	private static FunctionConfiguration configuration;
	/**
	 * �������캯��
	 * @return
	 */
	public static FunctionConfiguration getInstance() {
		if (configuration == null) {
			configuration = new FunctionConfiguration();
			try {
				reload();
			} catch (Exception e) {
				e.printStackTrace();
				CommonUtil.error("FunctionConfiguration getInstance exception",e);
			}
		}
		return configuration;
	}

	/**
	 * @deprecated
	 * @param uri
	 * @return
	 */
	public static FunctionConfiguration getInstance(final URL uri) {
		if (configuration == null)
			configuration = (FunctionConfiguration) XmlObjectFactory
					.getInstance(FunctionConfiguration.class).getObject(uri);
		return configuration;
	}
	/**
	 * �����ݿ��м��ؽ��׵ķ���
	 * @throws UfSealException 
	 * @throws IOException 
	 * @throws SQLException 
	 */
	@SuppressWarnings("unchecked")
	public static void reload() throws UfSealException, IOException, SQLException  {
		configuration.removeAllFunction();
		// ��ѯ���ݿ�YQ_JIAOYNR
		 List<Map<String, String>> list = new DBOperation().commondQueryWithMap("select * from YQ_JIAOYNR", new HashMap<String, String>());
		// ����function
		for (int i = 0; i < list.size(); i++) {
			Map<String,String> row = (Map<String, String>) list.get(i);
			Function function = new Function();
			function.setType(row.get("JIAOYLX"));
			function.setId(row.get("JIAOYID"));
			function.setSql(row.get("JIAOYNR"));
			function.setRemark(row.get("JIAOYBZ"));
			// multi
			String children = row.get("JIAOYZH");
			if (children != null && !"".equals(children.trim())) {
				MultiTrans multi = new MultiTrans();
				String[] splits = children.split(",");
				for (int n = 0; n < splits.length; n++) {
					String child = splits[n].trim();
					multi.addToList(child);
				}
				function.setMutil(multi);
			}
			configuration.addFunction(function);
		}
		// ���Ϊ�ı��ļ�
		File file = new File("../FunctionConfig.txt");
		if (!file.exists()) {
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file, false);
		for (Object key : configuration.funcMap.keySet()) {
			Function function = configuration.getFunction((String) key);
			fw.write("id:" + function.getId() + "\n");
			fw.write("type:" + function.getType() + "\n");
			fw.write("sql:" + function.getSql() + "\n");
			fw.write("remark:" + function.getRemark() + "\n");
			MultiTrans multi = function.getMutil();
			if (multi != null) {
				fw.write("multi{\n");
				List<String> multilist = multi.getList();
				for (int i = 0; i < multilist.size(); i++) {
					fw.write("childID:" + multilist.get(i) + "\n");
				}
				fw.write("}\n");
			}
			fw.write("\n");
			fw.flush();
		}
		fw.close();
		configuration.travelFunctionConfiguration();
	}
	/**
	 * ���ӽ���
	 * @param function
	 */
	public void addFunction(Function function) {
		funcMap.put(function.getId().toLowerCase(), function);
	}
	/**
	 * ��ý���
	 * @param functionID
	 * @return
	 */
	public Function getFunction(String functionID) {
		return funcMap.get(functionID.toLowerCase());
	}
	/**
	 * ɾ�����׼����е����н���
	 */
	public void removeAllFunction() {
		if (funcMap != null) {
			funcMap.clear();
		} else {
			funcMap = new HashMap<String,Function>();
		}
	}
	/**
	 * ����̨�������
	 */
	public void travelFunctionConfiguration(){
		CommonUtil.debug("===== FunctionConfiguration =====");
		for (Object key : configuration.funcMap.keySet()) {
			Function function = configuration.getFunction((String) key);
			CommonUtil.debug("id:" + function.getId());
			CommonUtil.debug("type:" + function.getType());
			CommonUtil.debug("sql:" + function.getSql());
			CommonUtil.debug("remark:" + function.getRemark());
			MultiTrans multi = function.getMutil();
			if (multi != null) {
				CommonUtil.debug("multi{");
				List<String> multilist = multi.getList();
				for (int i = 0; i < multilist.size(); i++) {
					CommonUtil.debug("childid:" + multilist.get(i) + "");
				}
				CommonUtil.debug("}");
			}
			CommonUtil.debug("\n");
		}
		CommonUtil.debug("=================================\n");
	}
}
