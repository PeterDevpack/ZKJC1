package com.unitop.sysmgr.form;

import org.apache.struts.action.ActionForm;

public class DanbwhgxbForm extends ActionForm {

	private String id;
	private String zhubbh;
	private String zibbh;
	private String zhubzd;
	private String zibzd;
	private String shifljzd;
	private String zhibwhmc;
	
	public String getZhibwhmc() {
		return zhibwhmc;
	}

	public void setZhibwhmc(String zhibwhmc) {
		this.zhibwhmc = zhibwhmc;
	}
	
	public String getShifljzd() {
		return shifljzd;
	}
	public void setShifljzd(String shifljzd) {
		this.shifljzd = shifljzd;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getZhubbh() {
		return zhubbh;
	}
	public void setZhubbh(String zhubbh) {
		this.zhubbh = zhubbh;
	}
	public String getZibbh() {
		return zibbh;
	}
	public void setZibbh(String zibbh) {
		this.zibbh = zibbh;
	}
	public String getZhubzd() {
		return zhubzd;
	}
	public void setZhubzd(String zhubzd) {
		this.zhubzd = zhubzd;
	}
	public String getZibzd() {
		return zibzd;
	}
	public void setZibzd(String zibzd) {
		this.zibzd = zibzd;
	}
}
