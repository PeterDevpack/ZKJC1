package com.unitop.sysmgr.form;

import java.util.List;

import org.apache.struts.action.ActionForm;

public class PassRateForm extends ActionForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4575014572705314618L;

	
	private String riqfw;
	private String orgname;
	private String orgCode;
	private int include;
	private List selected;
	private String riqend;
	private String jigh;
	private String xitlx;
	
	public String getXitlx() {
		return xitlx;
	}

	public void setXitlx(String xitlx) {
		this.xitlx = xitlx;
	}

	public String getJigh() {
		return jigh;
	}

	public void setJigh(String jigh) {
		this.jigh = jigh;
	}

	public String getOrgname() {
		return orgname;
	}

	public void setOrgname(String orgname) {
		this.orgname = orgname;
	}

	public String getRiqend() {
		return riqend;
	}

	public void setRiqend(String riqend) {
		this.riqend = riqend;
	}

	public List getSelected() {
		return selected;
	}

	public void setSelected(List selected) {
		this.selected = selected;
	}

	public int getInclude() {
		return include;
	}
	
	public void setInclude(int include) {
		this.include = include;
	}
	/**
	 * @return the orgCode
	 */
	public String getOrgCode() {
		return orgCode;
	}


	/**
	 * @param orgCode the orgCode to set
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}


	/**
	 * @return the riqfw
	 */
	public String getRiqfw() {
		return riqfw;
	}


	/**
	 * @param riqfw the riqfw to set
	 */
	public void setRiqfw(String riqfw) {
		this.riqfw = riqfw;
	}


	
	public PassRateForm() {
		super();
	}
	
	
}

