package com.unitop.sysmgr.form;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

public class LoginForm extends ActionForm {

	private static final long serialVersionUID = -1164577900848657742L;

	private String orgCode;

	private String code;

	private String password;

	public String getCode() {
		return code;
	}

	public void setCode(String string) {
		code = string;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String string) {
		password = string;
	}

	public LoginForm() {
	}

	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		super.reset(mapping, request);
		this.orgCode = null;
		code = null;
		password = null;
	}

	@Override
	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {
		ActionErrors errors = new ActionErrors();
		if (request.getServletPath().equals("/login.do"))
		{
			if (code == null || code.equals("")) 
			{
				errors.add("error logname", new ActionMessage("errors.required", "��Ա����"));
			}
			if (password == null || password.equals(""))
			{
				errors.add("error passwords", new ActionMessage("errors.required", "����"));
			}
		}
		return errors;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	@Override
	public String toString() {
		return "LoginForm [orgCode=" + orgCode + ", code=" + code
				+ ", password=" + password + "]";
	}
	
}
