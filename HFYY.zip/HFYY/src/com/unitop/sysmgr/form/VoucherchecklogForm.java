package com.unitop.sysmgr.form;

import org.apache.struts.action.ActionForm;

public class VoucherchecklogForm extends ActionForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5504274923101966155L;
	private String orgnum;

	public String getOrgnum() {
		return orgnum;
	}

	public void setOrgnum(String orgnum) {
		this.orgnum = orgnum;
	}
	
	
}
