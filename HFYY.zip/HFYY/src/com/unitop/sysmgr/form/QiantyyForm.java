package com.unitop.sysmgr.form;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

public class QiantyyForm extends ActionForm {

	private static final long serialVersionUID = 1L;
	private String account;
	private String accountname;
	private String accountstate;
	private String address;
	private String allexchange;
	private String billperiod;
	private String checkperiod;
	private Long creditgrade;
	private String englishname;
	private String enterprisecharacter;
	private String incomerange;
	private String industrycharacter;
	private String linkman;
	private String netpointflag;
	private String opendate;
	private String opendate1;//
	private String phone;
	private String postalcode;
	private Double registercapital;
	private String remark;
	private String startdate;
	private String startdate1;//
	private Long timestampnum;
	private String yearcheckdate;
	private String sealstate;
	private String yinqbz;
	private String account2;
	private String orgcode;

	private String shenghjgh;
	private String oldaccount;

	private String include;
	private String rengwms;//��������

	public QiantyyForm() {
		super();
	}

	public QiantyyForm(String account, String accountname,
			String accountstate, String address, String allexchange,
			String billperiod, String checkperiod, Long creditgrade,
			String englishname, String enterprisecharacter, String incomerange,
			String industrycharacter, String linkman, String netpointflag,
			String opendate, String phone, String postalcode,
			Double registercapital, String remark, String startdate,
			Long timestampnum, String yearcheckdate, String sealstate,
			String yinqbz, String orgcode, String shenghjgh, String oldaccount,
			String include, String opendate1, String startdate1) {
		super();
		this.account = account;
		this.accountname = accountname;
		this.accountstate = accountstate;
		this.address = address;
		this.allexchange = allexchange;
		this.billperiod = billperiod;
		this.checkperiod = checkperiod;
		this.creditgrade = creditgrade;
		this.englishname = englishname;
		this.enterprisecharacter = enterprisecharacter;
		this.incomerange = incomerange;
		this.industrycharacter = industrycharacter;
		this.linkman = linkman;
		this.netpointflag = netpointflag;
		this.opendate = opendate;
		this.phone = phone;
		this.postalcode = postalcode;
		this.registercapital = registercapital;
		this.remark = remark;
		this.startdate = startdate;
		this.timestampnum = timestampnum;
		this.yearcheckdate = yearcheckdate;
		this.sealstate = sealstate;
		this.yinqbz = yinqbz;
		this.orgcode = orgcode;
		this.shenghjgh = shenghjgh;
		this.oldaccount = oldaccount;
		this.include = include;
		this.startdate1 = startdate1;
		this.opendate1 = opendate1;

	}

	@Override
	public void reset(ActionMapping arg0, HttpServletRequest arg1) {
		super.reset(arg0, arg1);
		this.account = null;
		this.accountname = null;
		this.accountstate = null;
		this.address = null;
		this.allexchange = null;
		this.billperiod = null;
		this.checkperiod = null;
		this.creditgrade = null;
		this.englishname = null;
		this.enterprisecharacter = null;
		this.incomerange = null;
		this.industrycharacter = null;
		this.linkman = null;
		this.netpointflag = null;
		this.opendate = null;
		this.phone = null;
		this.postalcode = null;
		this.registercapital = null;
		this.remark = null;
		this.startdate = null;
		this.timestampnum = null;
		this.yearcheckdate = null;
		this.sealstate = null;
		this.yinqbz = null;
		this.orgcode = null;
		this.shenghjgh = null;
		this.oldaccount = null;
		this.include = "-1";
		this.opendate1 = null;
		this.startdate1 = null;
	}
	public String getRengwms() {
		return rengwms;
	}

	public void setRengwms(String rengwms) {
		this.rengwms = rengwms;
	}
	public String getOpendate1() {
		return opendate1;
	}

	public void setOpendate1(String opendate1) {
		this.opendate1 = opendate1;
	}

	public String getStartdate1() {
		return startdate1;
	}

	public void setStartdate1(String startdate1) {
		this.startdate1 = startdate1;
	}

	public String getInclude() {
		return include;
	}

	public void setInclude(String include) {
		this.include = include;
	}

	public String getOldaccount() {
		return oldaccount;
	}

	public void setOldaccount(String oldaccount) {
		this.oldaccount = oldaccount;
	}

	public String getShenghjgh() {
		return shenghjgh;
	}

	public void setShenghjgh(String shenghjgh) {
		this.shenghjgh = shenghjgh;
	}

	public String getAccount() {
		return this.account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getAccountname() {
		return this.accountname;
	}

	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}

	public String getAccountstate() {
		return this.accountstate;
	}

	public void setAccountstate(String accountstate) {
		this.accountstate = accountstate;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAllexchange() {
		return this.allexchange;
	}

	public void setAllexchange(String allexchange) {
		this.allexchange = allexchange;
	}

	public String getBillperiod() {
		return this.billperiod;
	}

	public void setBillperiod(String billperiod) {
		this.billperiod = billperiod;
	}

	public String getCheckperiod() {
		return this.checkperiod;
	}

	public void setCheckperiod(String checkperiod) {
		this.checkperiod = checkperiod;
	}

	public Long getCreditgrade() {
		return this.creditgrade;
	}

	public void setCreditgrade(Long creditgrade) {
		this.creditgrade = creditgrade;
	}

	public String getEnglishname() {
		return this.englishname;
	}

	public void setEnglishname(String englishname) {
		this.englishname = englishname;
	}

	public String getEnterprisecharacter() {
		return this.enterprisecharacter;
	}

	public void setEnterprisecharacter(String enterprisecharacter) {
		this.enterprisecharacter = enterprisecharacter;
	}

	public String getIncomerange() {
		return this.incomerange;
	}

	public void setIncomerange(String incomerange) {
		this.incomerange = incomerange;
	}

	public String getIndustrycharacter() {
		return this.industrycharacter;
	}

	public void setIndustrycharacter(String industrycharacter) {
		this.industrycharacter = industrycharacter;
	}

	public String getLinkman() {
		return this.linkman;
	}

	public void setLinkman(String linkman) {
		this.linkman = linkman;
	}

	public String getNetpointflag() {
		return this.netpointflag;
	}

	public void setNetpointflag(String netpointflag) {
		this.netpointflag = netpointflag;
	}

	public String getOpendate() {
		return this.opendate;
	}

	public void setOpendate(String opendate) {
		this.opendate = opendate;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPostalcode() {
		return this.postalcode;
	}

	public void setPostalcode(String postalcode) {
		this.postalcode = postalcode;
	}

	public Double getRegistercapital() {
		return this.registercapital;
	}

	public void setRegistercapital(Double registercapital) {
		this.registercapital = registercapital;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStartdate() {
		return this.startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public Long getTimestampnum() {
		return this.timestampnum;
	}

	public void setTimestampnum(Long timestampnum) {
		this.timestampnum = timestampnum;
	}

	public String getYearcheckdate() {
		return this.yearcheckdate;
	}

	public void setYearcheckdate(String yearcheckdate) {
		this.yearcheckdate = yearcheckdate;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("account", getAccount())
				.toString();
	}

	public String getSealstate() {
		return sealstate;
	}

	public void setSealstate(String sealstate) {
		this.sealstate = sealstate;
	}

	public String getYinqbz() {
		return yinqbz;
	}

	public void setYinqbz(String yinqbz) {
		this.yinqbz = yinqbz;
	}

	public String getAccount2() {
		return account2;
	}

	public void setAccount2(String account2) {
		this.account2 = account2;
	}

	public String getOrgcode() {
		return orgcode;
	}

	public void setOrgcode(String orgcode) {
		this.orgcode = orgcode;
	}

	public ActionErrors validate(ActionMapping arg0, HttpServletRequest arg1) {
		ActionErrors errors = new ActionErrors();
		if (arg1.getServletPath().equals("/accountcustom.do")) {
			if ((opendate != null && opendate.trim().length() > 0)
					&& (opendate1 != null && opendate1.trim().length() > 0)
					&& (startdate != null && startdate.trim().length() > 0)
					&& (startdate1 != null && startdate1.trim().length() > 0)) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				try {
					Date open = format.parse(opendate);
					Date open1 = format.parse(opendate1);
					Date start = format.parse(startdate);
					Date start1 = format.parse(startdate1);

					if (open1.compareTo(open) < 0 && !open.equals(open1))
						errors.add("error date", new ActionMessage(
								"errors.detail", "����ʱ��εĽ������ڲ���С�ڿ�ʼ���ڣ�"));
					if (start1.compareTo(start) < 0 && !start1.equals(start))
						errors.add("error date", new ActionMessage(
								"errors.detail", "����ʱ��εĽ������ڲ���С�ڿ�ʼ���ڣ�"));
					if (start.compareTo(open)<0&&!open.equals(start)){
						errors.add("error date", new ActionMessage(
								"errors.detail", "�������ڲ���С�ڿ������ڣ�"));
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		return errors;
	}

}
