package com.unitop.sysmgr.form;

import org.apache.struts.action.ActionForm;

public class PilyyForm extends ActionForm {

}

