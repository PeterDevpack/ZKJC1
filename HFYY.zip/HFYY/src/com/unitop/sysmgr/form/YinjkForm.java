package com.unitop.sysmgr.form;

import org.apache.struts.action.ActionForm;

public class YinjkForm extends ActionForm{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3730035817730783426L;
	private String zhangh;
	private String yinjkh;
	private String jigh;
	private String kagid;
	private String ceng;
	private String choutwz;
	private String zhengmwjm;
	private String fanmwjm;
	private String qiyrq;
	private String shifzk;
	private String yewlx;
	
	
	public String getZhangh() {
		return zhangh;
	}
	public void setZhangh(String zhangh) {
		this.zhangh = zhangh;
	}
	public String getYinjkh() {
		return yinjkh;
	}
	public void setYinjkh(String yinjkh) {
		this.yinjkh = yinjkh;
	}
	public String getJigh() {
		return jigh;
	}
	public void setJigh(String jigh) {
		this.jigh = jigh;
	}
	public String getKagid() {
		return kagid;
	}
	public void setKagid(String kagid) {
		this.kagid = kagid;
	}
	public String getCeng() {
		return ceng;
	}
	public void setCeng(String ceng) {
		this.ceng = ceng;
	}
	public String getChoutwz() {
		return choutwz;
	}
	public void setChoutwz(String choutwz) {
		this.choutwz = choutwz;
	}
	
	public String getZhengmwjm() {
		return zhengmwjm;
	}
	public void setZhengmwjm(String zhengmwjm) {
		this.zhengmwjm = zhengmwjm;
	}
	public String getFanmwjm() {
		return fanmwjm;
	}
	public void setFanmwjm(String fanmwjm) {
		this.fanmwjm = fanmwjm;
	}
	public String getQiyrq() {
		return qiyrq;
	}
	public void setQiyrq(String qiyrq) {
		this.qiyrq = qiyrq;
	}
	public String getShifzk() {
		return shifzk;
	}
	public void setShifzk(String shifzk) {
		this.shifzk = shifzk;
	}
	public String getYewlx() {
		return yewlx;
	}
	public void setYewlx(String yewlx) {
		this.yewlx = yewlx;
	}
   
	public YinjkForm(String zhangh, String yinjkh, String jigh, String kagid,
			String ceng, String choutwz, String zhengmwjm, String fanmwjm,
			String qiyrq, String shifzk, String yewlx) {
		super();
		this.zhangh = zhangh;
		this.yinjkh = yinjkh;
		this.jigh = jigh;
		this.kagid = kagid;
		this.ceng = ceng;
		this.choutwz = choutwz;
		this.zhengmwjm = zhengmwjm;
		this.fanmwjm = fanmwjm;
		this.qiyrq = qiyrq;
		this.shifzk = shifzk;
		this.yewlx = yewlx;
	}
	public YinjkForm() {
		super();
	}
	
	
	
}
