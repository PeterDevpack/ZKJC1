package com.unitop.sysmgr.form;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.unitop.framework.util.DateTool;
import com.unitop.sysmgr.service.PromptService;

public class OrgChangeForm extends ActionForm {

	private static final long serialVersionUID = 5504274923101966132L;

	private String account;

	private String oldaccount;

	private String netpointflag;

	private String checknum;

	private String clerknum;

	private String begindate;

	private String enddate;

	private String begindate1;

	private String enddate1;

	private String checkresult;

	private String checkmode;
	
	private String sequence;//��ˮ��	
	
	private String orgnum;
	
	private String jigh;
	
	private String billtype;
	
	

	public String getBilltype() {
		return billtype;
	}

	public void setBilltype(String billtype) {
		this.billtype = billtype;
	}

	public String getJigh() {
		return jigh;
	}

	public void setJigh(String jigh) {
		this.jigh = jigh;
	}

	public String getOrgnum() {
		return orgnum;
	}

	public void setOrgnum(String orgnum) {
		this.orgnum = orgnum;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	public String getBegindate1() {
		return begindate1;
	}

	public void setBegindate1(String begindate1) {
		this.begindate1 = begindate1;
	}

	public String getEnddate1() {
		return enddate1;
	}

	public void setEnddate1(String enddate1) {
		this.enddate1 = enddate1;
	}

	public String getNetpointflag() {
		return netpointflag;
	}

	public void setNetpointflag(String netpointflag) {
		this.netpointflag = netpointflag;
	}

	public String getOldaccount() {
		return oldaccount;
	}

	public void setOldaccount(String oldaccount) {
		this.oldaccount = oldaccount;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String string) {
		account = string;
	}

	public String getChecknum() {
		return checknum;
	}

	public void setChecknum(String string) {
		checknum = string;
	}

	public OrgChangeForm(){
	}

	@Override
	public void reset(ActionMapping arg0, HttpServletRequest arg1) {
		super.reset(arg0, arg1);
		this.sequence=null;
		this.account = null;
		this.checknum = null;
		this.clerknum = null;
		this.checkmode = "ȫ��";
		this.checkresult = "ȫ��";
		this.oldaccount = null;
		this.netpointflag = null;
		if (!arg1.getServletPath().equals("/voucherchecklog.do"))
		{
			begindate = DateTool.getNowDayForYYYMMDD().substring(0,7)+"-01";
			enddate = DateTool.getNowDayForYYYMMDD();
			begindate1 = DateTool.getNowDayForYYYMMDD().substring(0,7)+"-01";
			enddate1 = DateTool.getNowDayForYYYMMDD();
		}
		
	}

	@Override
	public ActionErrors validate(ActionMapping arg0, HttpServletRequest arg1) {
		ActionErrors errors = new ActionErrors();
		ServletContext servletContext= arg1.getSession().getServletContext();
		WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
		PromptService promptService = (PromptService)wac.getBean("PromptServiceImpl");
		
		if (arg1.getServletPath().equals("/voucherchecklog.do")) {
			//
//			if(sequence == null || sequence.trim().length() == 0){				
//				if (account == null || account.trim().length() == 0) {
//					if (clerknum == null || clerknum.trim().length() == 0) {
//						errors.add("error num", new ActionMessage("errors.detail",
//								promptService.getPromptMsg("YYF-voucherchecklog", new HashMap())));
//					}
//
//				}
//			}
			
			if (account != null && account.trim().length() > 0) {
				int index = account.indexOf("'");
				if (index != -1)
					errors.add("error code", new ActionMessage("errors.detail",
							"�˺��������"));
			}
			//end
			if (checknum != null && checknum.trim().length() > 0) {
				int index = checknum.indexOf("'");
				if (index != -1)
					errors.add("error code", new ActionMessage("errors.detail",
							"ƾ֤���������"));
			}
			if (begindate == null || begindate.trim().length() == 0) {
				errors.add("error begindate", new ActionMessage(
						"errors.required", "��ʼ����"));
			}
			if (enddate == null || enddate.trim().length() == 0) {
				errors.add("error enddate", new ActionMessage(
						"errors.required", "��������"));
			}
			if ((begindate != null && begindate.trim().length() > 0) && (enddate != null && enddate.trim().length() > 0)) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date begin;
				try {
					begin = format.parse(begindate);
					Date end = format.parse(enddate);
					if (end.compareTo(begin) < 1 && !begin.equals(end))
						errors.add("error date", new ActionMessage( "errors.detail", "�������ڲ���С�ڿ�ʼ���ڣ�"));
					long day = (end.getTime() - begin.getTime()) / (24 * 60 * 60 * 1000);
					if (day > 90) errors.add("error date", new ActionMessage( "errors.detail", "���ڷ�Χ���ܳ���90�죡"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else if ((arg1.getServletPath().equals("/batchsealchecklog.do"))
				|| (arg1.getServletPath().equals("/sealcheckCustom.do") || (arg1
						.getServletPath().equals("/sealcheck.do"))
						&& arg1.getParameter("method").equals("save"))) {
			/*
			if (account == null || account.trim().length() == 0) {

				if (clerknum == null || clerknum.trim().length() == 0) {
					errors.add("error num", new ActionMessage("errors.detail",
							promptService.getPromptMsg("YYF-voucherchecklog", new HashMap())));
				}

			}*/
			
			//			
			if(sequence == null || sequence.trim().length() == 0){
//				System.out.println("�������");
				if (account == null || account.trim().length() == 0) {
					if (clerknum == null || clerknum.trim().length() == 0) {
						errors.add("error num", new ActionMessage("errors.detail",
								promptService.getPromptMsg("YYF-voucherchecklog", new HashMap())));
					}

				}
			}
			//end
			if (account != null && account.trim().length() > 0) {				
				int index = account.indexOf("'");
				if (index != -1)
					errors.add("error code", new ActionMessage("errors.detail",
							"�˺��������"));
			}
			if (checknum != null && checknum.trim().length() > 0) {				
				int index = checknum.indexOf("'");
				if (index != -1)
					errors.add("error code", new ActionMessage("errors.detail",
							"ƾ֤���������"));
			}
			if (clerknum != null && clerknum.trim().length() > 0) {				
				int index = clerknum.indexOf("'");
				if (index != -1)
					errors.add("error code", new ActionMessage("errors.detail",
							"��Ա�����������"));
			}
			if (begindate == null || begindate.trim().length() == 0) {				
				errors.add("error begindate", new ActionMessage(
						"errors.required", "��ʼ����"));
			}
			if (enddate == null || enddate.trim().length() == 0) {				
				errors.add("error enddate", new ActionMessage(
						"errors.required", "��������"));
			}
			if ((begindate != null && begindate.trim().length() > 0)
					&& (enddate != null && enddate.trim().length() > 0)) {				
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date begin;
				try {
					begin = format.parse(begindate);
					Date end = format.parse(enddate);
					if (end.compareTo(begin) < 1 && !begin.equals(end))
						errors.add("error date", new ActionMessage(
								"errors.detail", "�������ڲ���С�ڿ�ʼ���ڣ�"));
					long day = (end.getTime() - begin.getTime())
							/ (24 * 60 * 60 * 1000);
					if (day > 93)
						errors.add("error date", new ActionMessage(
								"errors.detail", "���ڷ�Χ���ܳ���3���£�"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else if (arg1.getServletPath().equals("/sealchecklog.do")) {
			if(account == null ||account.trim().length()==0||checknum==null||checknum.trim().length()==0){
				errors.add("error num", new ActionMessage(
						"errors.detail", promptService.getPromptMsg("YYF-sealchecklog", new HashMap())));
			}
			if (account != null && account.trim().length() > 0) {
				int index = account.indexOf("'");
				if (index != -1)
					errors.add("error code", new ActionMessage("errors.detail",
							"�˺��������"));
			}
			if (checknum != null && checknum.trim().length() > 0) {
				int index = checknum.indexOf("'");
				if (index != -1)
					errors.add("error code", new ActionMessage("errors.detail",
							"ƾ֤���������"));
			}
		} else if (arg1.getServletPath().equals("/sealcheckcustom.do")) {
			if ((begindate != null && begindate.trim().length() > 0)
					&& (enddate != null && enddate.trim().length() > 0)) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date begin;
				try {
					begin = format.parse(begindate);
					Date end = format.parse(enddate);
					if (end.compareTo(begin) < 1 && !begin.equals(end))
						errors.add("error date", new ActionMessage(
								"errors.detail", "�������ڲ���С�ڿ�ʼ���ڣ�"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else if (arg1.getServletPath().equals("/orgCheckLog.do")) {
			if (begindate == null || begindate.trim().length() == 0) {
				errors.add("error begindate", new ActionMessage(
						"errors.required", "��ʼ����"));
			}
			if (enddate == null || enddate.trim().length() == 0) {
				errors.add("error enddate", new ActionMessage(
						"errors.required", "��������"));
			}
			if ((begindate != null && begindate.trim().length() > 0) && (enddate != null && enddate.trim().length() > 0)) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date begin;
				try {
					begin = format.parse(begindate);
					Date end = format.parse(enddate);
					if (end.compareTo(begin) < 1 && !begin.equals(end))
						errors.add("error date", new ActionMessage( "errors.detail", "�������ڲ���С�ڿ�ʼ���ڣ�"));
					long day = (end.getTime() - begin.getTime()) / (24 * 60 * 60 * 1000);
					if (day > 90) errors.add("error date", new ActionMessage( "errors.detail", "���ڷ�Χ���ܳ���90�죡"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		return errors;
	}

	public String getBegindate() {
		return begindate;
	}

	public void setBegindate(String begindate) {
		this.begindate = begindate;
	}

	public String getCheckmode() {
		return checkmode;
	}

	public void setCheckmode(String checkmode) {
		this.checkmode = checkmode;
	}

	public String getCheckresult() {
		return checkresult;
	}

	public void setCheckresult(String checkresult) {
		this.checkresult = checkresult;
	}

	public String getClerknum() {
		return clerknum;
	}

	public void setClerknum(String clerknum) {
		this.clerknum = clerknum;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

}
