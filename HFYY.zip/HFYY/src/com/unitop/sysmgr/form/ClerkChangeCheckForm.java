package com.unitop.sysmgr.form;

import org.apache.struts.action.ActionForm;

@SuppressWarnings("serial")
public class ClerkChangeCheckForm extends ActionForm {
	
	private String orgCode1;
	private String guiyuanh;
	private String begindate;
	private String enddate;
	
	public String getGuiyuanh() {
		return guiyuanh;
	}
	public void setGuiyuanh(String guiyuanh) {
		this.guiyuanh = guiyuanh;
	}
	public String getBegindate() {
		return begindate;
	}
	public void setBegindate(String begindate) {
		this.begindate = begindate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getOrgCode1() {
		return orgCode1;
	}
	public void setOrgCode1(String orgCode1) {
		this.orgCode1 = orgCode1;
	}
	
}
