package com.unitop.sysmgr.form;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.unitop.framework.util.DateTool;

public class ZhanghForm extends ActionForm{
		
	private static final long serialVersionUID = 1L;
	private String account;
	private String jigh;
	private String jigh1;
	private String youwyj;
	private String zhanghshzt;
	private String zhanghxz;
	private String begindate;
	private String enddate;
	private String zhanghzt;
	private String jigh2;
	private String include;
	
	
	
	
	public String getInclude() {
		return include;
	}

	public void setInclude(String include) {
		this.include = include;
	}

	public String getJigh2() {
		return jigh2;
	}

	public void setJigh2(String jigh2) {
		this.jigh2 = jigh2;
	}

	public ZhanghForm() {
		super();
	}

	public ZhanghForm(String account,String jigh,String jigh1,String youwyj,String zhanghshzt,String zhanghxz,String begindate,String enddate,String zhanghzt) {
		super();
		this.account = account;
		this.jigh = jigh;
		this.jigh1 = jigh1;
		this.youwyj = youwyj;
		this.zhanghshzt = zhanghshzt;
		this.zhanghxz = zhanghxz;
		this.begindate = begindate;
		this.enddate =enddate;
		this.zhanghzt = zhanghzt;
	}
	@Override
	public void reset(ActionMapping arg0, HttpServletRequest arg1) {
		super.reset(arg0, arg1);
		this.account = null;
		this.jigh = null;
		this.jigh1 = null;
		this.youwyj = null;
		this.zhanghshzt = null;
		this.zhanghxz = null;
		this.zhanghzt = null;
		if (arg1.getServletPath().equals("/zhanghgjcx.do"))
		{
			begindate = DateTool.getNowDayForYYYMMDD().substring(0,7)+"-01";
			enddate = DateTool.getNowDayForYYYMMDD();
		}
	}

	@Override
	public ActionErrors validate(ActionMapping arg0, HttpServletRequest arg1) {
		ActionErrors errors = new ActionErrors();
		if (arg1.getServletPath().equals("/zhanghgjcx.do")&&!arg1.getParameter("method").equals("enter")) {
			if ((begindate != null && begindate.trim().length() > 0) && (enddate != null && enddate.trim().length() > 0)) {
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date begin;
				try {
					begin = format.parse(begindate);
					Date end = format.parse(enddate);
					if (end.compareTo(begin) < 1 && !begin.equals(end))
						errors.add("error date", new ActionMessage( "errors.detail", "�������ڲ������ڿ�ʼ���ڣ�"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return errors;
	}
	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getJigh() {
		return jigh;
	}

	public void setJigh(String jigh) {
		this.jigh = jigh;
	}

	public String getJigh1() {
		return jigh1;
	}

	public void setJigh1(String jigh1) {
		this.jigh1 = jigh1;
	}

	public String getYouwyj() {
		return youwyj;
	}

	public void setYouwyj(String youwyj) {
		this.youwyj = youwyj;
	}

	public String getZhanghshzt() {
		return zhanghshzt;
	}

	public void setZhanghshzt(String zhanghshzt) {
		this.zhanghshzt = zhanghshzt;
	}

	public String getZhanghxz() {
		return zhanghxz;
	}

	public void setZhanghxz(String zhanghxz) {
		this.zhanghxz = zhanghxz;
	}

	public String getBegindate() {
		return begindate;
	}

	public void setBegindate(String begindate) {
		this.begindate = begindate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public String getZhanghzt() {
		return zhanghzt;
	}

	public void setZhanghzt(String zhanghzt) {
		this.zhanghzt = zhanghzt;
	}

}
