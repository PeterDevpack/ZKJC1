package com.unitop.sysmgr.dao;

import java.util.List;

import com.unitop.sysmgr.bo.Zhanghb;
import com.unitop.sysmgr.bo.Zhanghxz;

/**
 * �˻�����Dao
 * @author guodx
 *
 */
public interface ZhanghxzDao extends BaseDataResourcesInterface {
	public List<Zhanghxz> getZhanghxzList();
	public List<Zhanghb> getUncheckTasks(String jigh,String wdf,String clerkcode);
	public void insertLink(String zh,String glzh,String hum,String zhjgh,String khh,String kaihrq,String glzhlb);
	public void updateLink(String zh);
}
