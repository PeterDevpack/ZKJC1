package com.unitop.sysmgr.dao;

import java.util.List;


public interface YinjlxgxDao extends BaseDataResourcesInterface{
	//��ȡƾ֤ӡ����ϵ�ӿ�
public List getYinjlxgxList(String jigh,String pingzh);



}
