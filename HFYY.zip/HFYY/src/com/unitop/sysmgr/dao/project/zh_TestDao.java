package com.unitop.sysmgr.dao.project;

public class zh_TestDao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
