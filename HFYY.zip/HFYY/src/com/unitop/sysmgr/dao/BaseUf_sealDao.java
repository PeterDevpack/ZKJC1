package com.unitop.sysmgr.dao;

import java.util.List;
import java.util.Map;

public interface BaseUf_sealDao {
	public List execSql(String functionId, Map pmap);
}
