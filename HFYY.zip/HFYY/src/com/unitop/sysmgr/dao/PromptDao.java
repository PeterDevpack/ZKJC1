package com.unitop.sysmgr.dao;

import java.util.Map;

public interface PromptDao  extends BaseDataResourcesInterface {
	 public Map<String,String> getPromptMsg();
}
