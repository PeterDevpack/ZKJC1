package com.unitop.sysmgr.dao;

public interface AjaxDao  extends BaseDataResourcesInterface {

	public String ajax(String id,String message) throws Exception;
}
