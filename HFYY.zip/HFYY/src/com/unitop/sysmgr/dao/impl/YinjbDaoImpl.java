package com.unitop.sysmgr.dao.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.dao.YinjbDao;
@Repository("YinjbDaoImpl")
public class YinjbDaoImpl extends BaseDataResources implements YinjbDao {


	public void delYinj(String zhangh){
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			String sql = "delete yinjb where zhangh=:zhangh";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("zhangh", zhangh);
			query.executeUpdate();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	public List getYinj(String zhangh) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List list = null;
		try{
			Query query = session.createQuery("from Yinjb where zhangh=:zhangh");
			query.setString("zhangh", zhangh);
			list = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}

	public boolean hasYinj(String zhangh){
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List list = null;
		int count = 0;
		try{
			Query query = session.createSQLQuery("select count(*) from yinjb where zhangh=:zhangh");
			query.setString("zhangh", zhangh);
			list = query.list();
			count = (Integer) list.get(0);
//			count = Integer.valueOf((String) obj[0]);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
		return (count>0)?true:false;
	}

	public void updateYinj(String zhangh) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String tingyrq=format.format(new Date());
		try{
			String sql = "update yinjb set tingyrq=:tingyrq where zhangh=:zhangh and (tingyrq is null or tingyrq='')";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("tingyrq", tingyrq);
			query.setString("zhangh", zhangh);
			query.executeUpdate();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	/**
	 * �����˻���ȡ����δ�����������
	 * @param zhangh
	 * @return
	 */
	public String getQiyrq(String zhangh){
		Session session = super.getBaseHibernateDao().getHibernateSession();
		String qiyrq = "";
		try{
			String sql = "select distinct qiyrq from yinjb where zhangh=:zhangh and (tingyrq is null or tingyrq='')";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("zhangh", zhangh);
			qiyrq = (String)query.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
		return qiyrq;
	}
	//��ȡ��������ӡ������ʱ��
	public String getQiyrq_(String zhangh){
		Session session = super.getBaseHibernateDao().getHibernateSession();
		String qiyrq = "";
		try{
			String sql = "select max(QIYRQ) from yinjb where yinjshzt = '����' and zhangh =:zhangh  ";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("zhangh", zhangh);
			qiyrq = (String)query.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
		return qiyrq;
	}
}
