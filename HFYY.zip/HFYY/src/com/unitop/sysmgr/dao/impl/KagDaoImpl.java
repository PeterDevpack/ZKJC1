package com.unitop.sysmgr.dao.impl;

/***********************************************************************
 * Module:  KagDaoImpl.java
 * Author:  Administrator
 * Purpose: Defines the Class KagDaoImpl
 ***********************************************************************/

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.bo.Kag;
import com.unitop.sysmgr.dao.KagDao;

@Repository("KagDaoImpl")
public class KagDaoImpl extends BaseDataResources implements KagDao {
	public void save(Kag kag) {
		Session session = this.getBaseHibernateDao().getHibernateSession();
		try {
			session.save(kag);
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	/** @param kag */
	public void update(Kag kag) {
		// TODO: implement
	}

	/** @param jigh */
	public List<Kag> kaglist(String orgcode) {
		Session session = this.getBaseHibernateDao().getHibernateSession();
		String hql = "from Kag where jigh = '" + orgcode + "'";
		Query query = session.createQuery(hql);
		List<Kag> list = query.list();
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
		return list;
	}

	/** @param kagid */
	public void delete(String kagid) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try {

			Kag kag = (Kag) session.get(Kag.class, kagid);
			session.delete(kag);
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	/** @param kagid */
	public Kag getKagById(String kagid) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Kag kag = null;
		try {
			kag = (Kag) session.get(Kag.class, kagid);
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
		return kag;
	}
}