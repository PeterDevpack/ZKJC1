package com.unitop.sysmgr.dao.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.dao.YinjzhbDao;
@Repository("YinjzhbDaoImpl")
public class YinjzhbDaoImpl extends BaseDataResources implements YinjzhbDao {

	public void delYinjzh(String zhangh) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			String sql = "delete yinjzhb where zhangh=:zhangh";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("zhangh", zhangh);
			query.executeUpdate();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	public List getYinjzh(String zhangh) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List list = null;
		try{
			Query query = session.createQuery("from Yinjzhb where id.zhangh=:zhangh");
			query.setString("zhangh", zhangh);
			list = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}

	public void updateYinjzh(String zhangh) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String tingyrq=format.format(new Date());
		try{
			String sql = "update yinjzhb set TINGYRQ=:tingyrq where zhangh=:zhangh";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("tingyrq", tingyrq);
			query.setString("zhangh", zhangh);
			query.executeUpdate();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}

}
