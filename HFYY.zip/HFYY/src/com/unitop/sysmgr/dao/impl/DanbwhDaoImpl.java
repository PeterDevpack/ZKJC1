package com.unitop.sysmgr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.sinodata.table.model.Dictionary;
import com.sinodata.table.model.SqlParameter;
import com.sinodata.table.model.Table;
import com.unitop.config.DBinfoConig;
import com.unitop.sysmgr.bo.Danbwh;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.dao.DanbwhDao;

@Repository("DanbwhDaoImpl")
public class DanbwhDaoImpl extends BaseDataResources implements DanbwhDao {

	public void add(Danbwh danbwh) throws SQLException {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		session.save(danbwh);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);

	}

	public void delete(String gongnid) throws SQLException {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Danbwh danbwh = (Danbwh) session.get(Danbwh.class, gongnid);
		session.delete(danbwh);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);

	}

	public Danbwh find(String gongnid) throws SQLException {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Danbwh danbwh = (Danbwh) session.get(Danbwh.class, gongnid);
		this.getBaseHibernateDao().closeSession(session);
		return danbwh;
	}

	public List getAll() throws SQLException {
		List list = null;
		Session session = this.getBaseHibernateDao().getHibernateSession();
		try {
			Query query = session.createQuery("from Danbwh");
			list = query.list();
			if (list == null)list = new ArrayList();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}

	public void update(Danbwh danbwh) throws SQLException {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		session.saveOrUpdate(danbwh);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);

	}
	
	
	// DML���ִ��
	public void doDML(Table table) throws Exception {
		Connection conn = null;
		PreparedStatement pre = null;
		try {
			conn = super.getBaseJDBCDao().getConnection();
			pre = conn.prepareStatement(table.getSqlString());
			this.doPreparedStatement(pre, table);
			pre.execute();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		} finally {
			this.getBaseJDBCDao().closeConnection(conn, pre, null);
		}
	}

	// DML���ִ��-����rows
	public int doDMLForUpdate(Table table) throws Exception {
		int UPDATE_COUNTS = 0;
		Connection conn = null;
		PreparedStatement pre = null;
		try {
			conn = super.getBaseJDBCDao().getConnection();
			pre = conn.prepareStatement(table.getSqlString());
			this.doPreparedStatement(pre, table);
			UPDATE_COUNTS = pre.executeUpdate();
		} catch (Exception e) {
			throw new Exception(e);
		} finally {
			this.getBaseJDBCDao().closeConnection(conn, pre, null);
		}
		return UPDATE_COUNTS;
	}

	// ��ѯ���ִ�� ���ؼ���ͳһСд
	public List<Map> doSelect(Table table) throws Exception {
		List<Map> list = new ArrayList<Map>();
		PreparedStatement pre = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		Connection conn = null;
		try {
			conn = super.getBaseJDBCDao().getConnection();
			pre = conn.prepareStatement(table.getSqlString());
			this.doPreparedStatement(pre, table);
			rs = pre.executeQuery();
			rsmd = pre.getMetaData();
			while (rs.next()) {
				Map<String, Object> map = new LinkedHashMap<String, Object>();
				for (int i = 0; i < rsmd.getColumnCount(); i++) 
				{
					// System.out.println(rsmd);
					Object getColumnValueObject = rs.getObject(i + 1);
					getColumnValueObject = (null) == getColumnValueObject ? "": getColumnValueObject;
					map.put(rsmd.getColumnName(i + 1).toLowerCase(),getColumnValueObject);
					// System.out.println(rsmd);
				}
				list.add(map);
			}
		} catch (SQLException e) {
			System.out.println("�쳣SQL:" + table.getSqlString());
			throw new Exception(e);
		} finally {
			this.getBaseJDBCDao().closeConnection(conn, pre, rs);

		}
		return list;
	}
	// ��ѯ���ִ�� ���ؼ���ͳһ��д
	public List<Map> doSelectForUpperCase(Table table) throws Exception {
		List<Map> list = new ArrayList<Map>();
		PreparedStatement pre = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		Connection conn = null;
		try {
			conn = super.getBaseJDBCDao().getConnection();
			pre = conn.prepareStatement(table.getSqlString());
			this.doPreparedStatement(pre, table);
			rs = pre.executeQuery();
			rsmd = pre.getMetaData();
			while (rs.next()) {
				Map<String, Object> map = new LinkedHashMap<String, Object>();
				for (int i = 0; i < rsmd.getColumnCount(); i++) 
				{
					Object getColumnValueObject = rs.getObject(i + 1);
					getColumnValueObject = (null) == getColumnValueObject ? "": getColumnValueObject;
					map.put(rsmd.getColumnName(i + 1).toUpperCase(),getColumnValueObject);
				}
				list.add(map);
			}
		} catch (SQLException e) {
			System.out.println("�쳣SQL:" + table.getSqlString());
			throw new Exception(e);
		} finally {
			this.getBaseJDBCDao().closeConnection(conn, pre, rs);
		}
		return list;
	}

	// ��ѯ���ִ�� ��ҳ�ӿ�
	public TabsBo doSelectForPage(Table table, int index, int pageCounts)throws Exception {
		TabsBo TabsBo = new TabsBo();
		TabsBo.setDangqym(index);
		TabsBo.setFenysl(pageCounts);

		StringBuffer SQL = null;
		List<Map> list = new ArrayList<Map>();
		PreparedStatement pre = null;
		PreparedStatement countspre = null;
		ResultSet rs = null;
		ResultSet countsrs = null;
		ResultSetMetaData rsmd = null;
		Connection conn = null;
		try {
			conn = super.getBaseJDBCDao().getConnection();
			String countsSqlStr = "select count(*) from ("+ table.getSqlString() + ")";
			countspre = conn.prepareStatement(countsSqlStr);
			this.doPreparedStatement(countspre, table);
			countsrs = countspre.executeQuery();
			countsrs.next();
			Integer counts = Integer.valueOf(countsrs.getObject(1).toString());
			TabsBo.setCounts(counts.intValue());

			String db_type = DBinfoConig.getDBType();
			if ("oracle".equals(db_type)) 
			{
				// SQL=new StringBuffer("SELECT * FROM (SELECT  ROWNUM ���,A.* FROM () A WHERE ROWNUM <= ?) WHERE ��� > ?");
				SQL = new StringBuffer("SELECT * FROM (SELECT  ROWNUM ���,A.* FROM () A )");
				SQL.insert(43, table.getSqlString());
			} else {
				SQL = new StringBuffer("SELECT * FROM (SELECT B.*, ROWNUMBER() OVER() AS RN FROM () AS B )AS A WHERE A.RN BETWEEN ? AND ?");
				SQL.insert(58, table.getSqlString());
			}
			pre = conn.prepareStatement(SQL.toString());
			if ("oracle".equals(db_type)) {
				/*pre.setLong(table.getSqlParameter().size()+1,index*pageCounts); 
				  pre.setLong(table.getSqlParameter().size()+2,(index-1)*pageCounts);*/
			} else {
				pre.setLong(table.getSqlParameter().size() + 1, (index - 1)* pageCounts + 1);
				pre.setLong(table.getSqlParameter().size() + 2, (index)* pageCounts);
			}
			this.doPreparedStatement(pre, table);
			rs = pre.executeQuery();
			rsmd = pre.getMetaData();
			while (rs.next()) {
				Map<String, Object> map = new HashMap<String, Object>();
				for (int i = 0; i < rsmd.getColumnCount(); i++) 
				{
					Object getColumnValueObject = rs.getObject(i + 1);
					getColumnValueObject = (null) == getColumnValueObject ? "": getColumnValueObject;
					map.put(rsmd.getColumnName(i + 1).toLowerCase(),getColumnValueObject);
				}
				list.add(map);
			}
			TabsBo.setList(list);
		} catch (SQLException e) {
			System.out.println(SQL);
			e.printStackTrace();
			throw new Exception(e);
		} finally {
			this.getBaseJDBCDao().closeConnection(null, countspre, countsrs);
			this.getBaseJDBCDao().closeConnection(conn, pre, rs);
		}
		return TabsBo;
	}

	// ��ѯ���ִ�� ����
	public long getPageCounts(Table table) throws Exception {
		StringBuffer CountsSQL = new StringBuffer("SELECT count(*) as counts FROM()");
		CountsSQL.insert(31, table.getSqlString());
		long counts = 0;
		PreparedStatement pre = null;
		ResultSet rs = null;
		Connection conn = null;
		try {
			conn = super.getBaseJDBCDao().getConnection();
			pre = conn.prepareStatement(CountsSQL.toString());
			rs = pre.executeQuery();
			while (rs.next()) {
				counts = rs.getLong("counts");
			}

		} catch (SQLException e) {
			throw new Exception(e);
		} finally {
			this.getBaseJDBCDao().closeConnection(conn, pre, rs);
		}
		return counts;
	}

	// ����DML���ִ��
	public void doSWDML(List list) throws SQLException {
		Connection conn = null;
		PreparedStatement pre = null;
		try {
			conn = super.getBaseJDBCDao().getConnection();
			conn.setAutoCommit(false);
			for (int i = 0; i < list.size(); i++) 
			{
				Table table = (Table) list.get(i);
				System.out.println(table.getSqlString());
				pre = conn.prepareStatement(table.getSqlString());
				this.doPreparedStatement(pre, table);
				pre.execute();
			}
			conn.commit();
		} catch (Exception e) {
			conn.rollback();
			throw new SQLException("�����ύ����ʧ��!��˲����ͽ����Ƿ���ȷ!�쳣��" + e.getMessage());
		} finally {
			this.getBaseJDBCDao().closeConnection(conn, pre, null);
		}
	}

	/*
	 * SQL��ֵ ���ڲ���
	 */
	private void doPreparedStatement(PreparedStatement pre, Table table)throws Exception {
		Map SqlParameter = table.getSqlParameter();
		if (SqlParameter != null) 
		{
			for (int i = 1; i <= SqlParameter.size(); i++) 
			{
				SqlParameter sqlParameter = (SqlParameter) SqlParameter.get(i);
				if (sqlParameter != null) 
				{
					if ("string".equals(sqlParameter.getType().toLowerCase())) 
					{
						pre.setString(i, sqlParameter.getValue());
					}
					if ("int".equals(sqlParameter.getType().toLowerCase())) 
					{
						pre.setInt(i, Integer.valueOf(sqlParameter.getValue()));
					}
					if ("long".equals(sqlParameter.getType().toLowerCase())) 
					{
						pre.setLong(i, Long.valueOf(sqlParameter.getValue()));
					}
					if ("float".equals(sqlParameter.getType().toLowerCase())) 
					{
						pre.setFloat(i, Float.valueOf(sqlParameter.getValue()));
					}
					if ("double".equals(sqlParameter.getType().toLowerCase())) 
					{
						pre.setDouble(i,Double.valueOf(sqlParameter.getValue()));
					}
				}
			}
		}
	}

	public List<Map> page(String sql, int index, int pageCounts)throws Exception {
		List<Map> list = new ArrayList<Map>();
		StringBuffer CountsSQL = new StringBuffer("SELECT count(*) as counts FROM()");
		StringBuffer SQL = null;
		Connection conn = null;
		PreparedStatement pre1 = null;
		PreparedStatement pre2 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSetMetaData rsmd = null;
		try {
			String db_type = DBinfoConig.getDBType();
			if ("oracle".equals(db_type)) 
			{
				SQL = new StringBuffer("SELECT * FROM (SELECT  ROWNUM ���,A.* FROM () A WHERE ROWNUM <= ?) WHERE ��� > ?");
				SQL.insert(43, sql);
			} else {
				SQL = new StringBuffer("SELECT * FROM (SELECT B.*, ROWNUMBER() OVER() AS RN FROM () AS B )AS A WHERE A.RN BETWEEN ? AND ?");
				SQL.insert(58, sql);
			}

			CountsSQL.insert(31, sql);
			conn = super.getBaseJDBCDao().getConnection();
			pre1 = conn.prepareStatement(CountsSQL.toString());
			rs1 = pre1.executeQuery();
			while (rs1.next()) {
				Map<String, Object> map = new LinkedHashMap<String, Object>();
				map.put("counts", rs1.getObject("counts"));
				list.add(map);
			}
			pre2 = conn.prepareStatement(SQL.toString());
			System.out.println(SQL.toString());
			if ("oracle".equals(db_type)) {
				pre2.setInt(1, (index + 1) * pageCounts);
				pre2.setInt(2, index * pageCounts);
			} else {
				pre2.setInt(1, index * pageCounts);
				pre2.setInt(2, (index + 1) * pageCounts);
			}

			rs2 = pre2.executeQuery();
			rsmd = pre2.getMetaData();
			while (rs2.next()) {
				Map<String, Object> map = new LinkedHashMap<String, Object>();
				for (int i = 0; i < rsmd.getColumnCount(); i++) {
					Object getColumnValueObject = rs2.getObject(i + 1);
					getColumnValueObject = (null) == getColumnValueObject ? "": getColumnValueObject;
					map.put(rsmd.getColumnName(i + 1).toLowerCase(),getColumnValueObject);
				}
				list.add(map);
			}
		} catch (SQLException e) {
			throw new Exception(e);
		} finally {
			this.getBaseJDBCDao().closeConnection(null, pre2, rs2);
			this.getBaseJDBCDao().closeConnection(conn, pre1, rs1);
		}
		return list;
	}

	// ��ȡ��������
	public Map getTable(String tableName) throws Exception {
		Map lineMap = new HashMap();
		PreparedStatement pre = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		Connection conn = null;
		try {
			conn = super.getBaseJDBCDao().getConnection();
			pre = conn.prepareStatement("select * from " + tableName);
			rs = pre.executeQuery();
			rsmd = pre.getMetaData();
			if (rsmd != null) 
			{
				int count = rsmd.getColumnCount();
				for (int i = 1; i <= count; i++) 
				{
					Dictionary dictionary = new Dictionary();
					dictionary.setField(rsmd.getColumnName(i).toLowerCase());
					dictionary.setType(rsmd.getColumnTypeName(i).toLowerCase());
					dictionary.setColumnSize(rsmd.getColumnDisplaySize(i));
					dictionary.setReadOnly(rsmd.isReadOnly(i));
					dictionary.setIsNullable(rsmd.isNullable(i));
					lineMap.put(rsmd.getColumnName(i).toLowerCase(), dictionary);

				}
			}
		} catch (SQLException e) {
			throw new Exception(e);
		} finally {
			this.getBaseJDBCDao().closeConnection(conn, pre, rs);
		}
		return lineMap;
	}

	// ��ȡ���ݿ�����
	public String getDBtype() {
		String db_type = DBinfoConig.getDBType();
		return db_type;
	}
}
