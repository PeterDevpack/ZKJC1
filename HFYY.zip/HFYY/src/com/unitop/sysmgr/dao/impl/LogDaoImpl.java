package com.unitop.sysmgr.dao.impl;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.bo.Usermanage;
import com.unitop.sysmgr.bo.Yinjcyrzb;
import com.unitop.sysmgr.dao.LogDao;

@Repository("logDaoImpl")
public class LogDaoImpl extends BaseDataResources implements LogDao {

	//yonghwhb ������
	public void addyonghwhb(Usermanage usermanage) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try {
			session.save(usermanage);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	public void insertyinjrz(Yinjcyrzb yin) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try {
			session.save(yin);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}

}
