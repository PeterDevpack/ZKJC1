package com.unitop.sysmgr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.unitop.config.DBinfoConig;
import com.unitop.exception.BusinessException;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.OrgLog;
import com.unitop.sysmgr.bo.sys.OrgDj;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.dao.SystemControlParametersDao;

@Repository("OrgDaoImpl")
public class OrgDaoImpl extends BaseDataResources  implements OrgDao{
	
	@Resource
	public SystemControlParametersDao SystemControlParametersDao;	
	public List<Org> getPId(String wdf,String orgcode){
		Session session =  super.getBaseHibernateDao().getHibernateSession();		
			try {		
				List<Org> list=new ArrayList();
				String db_type = DBinfoConig.getDBType();
				String sql="";
				if("oracle".equals(db_type))
				{
					//oracle
					 sql = "select * from (select * from organarchives where organnum in (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:organnum) where wdflag='"+wdf+"'";
				}else{
					//DB2
					sql = "select * from (select * from organarchives where organnum in (select * from TABLE(ORGFUNCTION(:organnum)) AS test)) where wdflag='"+wdf+"'";
				}
				Query query = session.createSQLQuery(sql);
				query.setString("organnum", orgcode);								
				List list1 = query.list();
				for (Iterator iter = list1.iterator(); iter.hasNext();) 
				{
					 Org org=new Org();
					 Object[] element = (Object[])iter.next();				
				org.setCode((String)element[0]);
				org.setName((String)element[1]);
				org.setParentCode((String)element[10]);				
				org.setShOrgCode((String)element[13]);				
				org.setWdflag((String)element[12]);
				list.add(org);
				}				
				return list;
			}catch(Exception e){				
			e.printStackTrace();
			return null;
			}finally{				
			this.getBaseHibernateDao().closeSession(session);		
			}
		
			
	}
	
	//��ȡ���������еĵȼ�
	public List<OrgDj>getAlldj(String wdf){
		Session session =  super.getBaseHibernateDao().getHibernateSession();		
			try {		
				List<OrgDj> list=new ArrayList();
				String db_type = DBinfoConig.getDBType();
				String sql="";
				if("oracle".equals(db_type))
				{
					sql="select * from YINHDJ connect by prior id=pid start with id='"+wdf+"'";
				}else{
					sql="select * from YINHDJ where id in (select * from TABLE(YINHDJFUNCTION('"+wdf+"')) AS test)";
				}
				Query query = session.createSQLQuery(sql);											
				List list1 = query.list();
				for (Iterator iter = list1.iterator(); iter.hasNext();) 
				{
					 OrgDj org=new OrgDj();
					 Object[] element = (Object[])iter.next();								
					 org.setId((String)element[0]);
					 org.setName((String)element[1]);
					 org.setPid((String)element[2]);
					 list.add(org);
				}				
				return list;
			}catch(Exception e){				
			e.printStackTrace();
			return null;
			}finally{
			this.getBaseHibernateDao().closeSession(session);		
			}
	}
	
	//��������䶯
		public void createOrgLog(OrgLog orgLog){
			Session session =  super.getBaseHibernateDao().getHibernateSession();		
				try {								
					Query query = session.createSQLQuery("insert into orgChangeLog (clerkName, clerkNum, operateType, operateContent, operateDate, oldOrgnum, newOrgnum,clerkOrgnum )"
														+" values (:clerkName, :clerkNum, :operateType, :operateContent, :operateDate, :oldOrgnum, :newOrgnum,:clerkOrgnum)");	
					
					query.setString("clerkName", orgLog.getClerkName());
					query.setString("clerkNum", orgLog.getClerkNum());
					query.setString("operateType", orgLog.getOperateType());
					query.setString("operateContent", orgLog.getOperateContent());
					query.setString("operateDate", orgLog.getOperateDate());
					query.setString("oldOrgnum", orgLog.getOldOrgnum());
					query.setString("newOrgnum", orgLog.getNewOrgnum());
					query.setString("clerkOrgnum",orgLog.getClerkOrg());
					
					query.executeUpdate();
				}catch(Exception e){				
				e.printStackTrace();				
				}finally{
				this.getBaseHibernateDao().closeSession(session);		
				}
		}
	//��ȡ���л���  
	@SuppressWarnings("unchecked")
	public List getAllOrg() {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		List list = null;
		try{
			list = session.createSQLQuery("from Org order by org.code").list();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}
	
	
	
	
	@SuppressWarnings("null")
	public List getAllOrg2() {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		List<Org> list = new ArrayList<Org>();
		try{
			List list1 = session.createSQLQuery("select * from ORGANARCHIVES").list();
			for (Iterator iter = list1.iterator(); iter.hasNext();) 
			{
				 Org org=new Org();
				 Object[] element = (Object[])iter.next();				
				 org.setCode((String)element[0]);
				 org.setName((String)element[1]);
				 org.setParentCode((String)element[10]);				
				 org.setShOrgCode((String)element[13]);				
				 org.setWdflag((String)element[12]);
				 org.setZhiszh((String)element[16]);
				 list.add(org);
			}				
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}
	
	//�޸Ļ���
	public void updateOrg (Org bo) throws BusinessException {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try{
			session.saveOrUpdate(bo);
			session.flush();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	//�޸��ϼ�����	
	public void updateForParentCode(String newOrg,String oldOrg){
		Session session =  super.getBaseHibernateDao().getHibernateSession();		
			try {		
							
				Query query = session.createSQLQuery("update ORGANARCHIVES set N_PARENTNUM='"+newOrg+"' where N_PARENTNUM='"+oldOrg+"'");											
				query.executeUpdate();
						
			}catch(Exception e){				
			e.printStackTrace();		
			}finally{
			this.getBaseHibernateDao().closeSession(session);		
			}
	}
	//��ȡ����
	public Org getOrgByCode(String code) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		Org org = null;
		try{
			org = (Org)session.get(Org.class, code);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return org;
	}

	private static Log log = LogFactory.getLog(OrgDaoImpl.class);

	public boolean CanOperDesOrg(String OperOrg, String DesOrg) {
		log.info("CanOperDesOrg[" + OperOrg + ", " + DesOrg + "]");
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		boolean ReturnValue = false;
		try {
			if (OperOrg.equals(DesOrg)) {
				ReturnValue = true;
			} else {
				String sql = "";
				String db_type = DBinfoConig.getDBType();
				if("oracle".equals(db_type))
				{
					sql="SELECT organnum as C FROM organarchives"
						+ "WHERE organnum IN ("
						+ "select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:OperOrg"
						+ ") AND organnum=:DesOrg";
				}else{
					sql="SELECT organnum as C FROM organarchives"
						+ "WHERE organnum IN (select * from TABLE(ORGFUNCTION(:OperOrg))) AND organnum=:DesOrg";
				}
					SQLQuery qu = session.createSQLQuery(sql);
					qu.setString("OperOrg", OperOrg);
					qu.setString("DesOrg", DesOrg);
					List list = qu.list();
					ReturnValue = list.size() ==1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			this.getBaseHibernateDao().closeSession(session);
		}
		return ReturnValue;
	}

	public void deleteOrg(Org org) throws BusinessException {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		String code = org.getCode();
		try{
			session.delete(org);
			session.createSQLQuery("delete from Yinjzhb a where a.zhangh in (select zhangh from zhanghb b where b.jigh='"+code+"' )").executeUpdate();
			session.createSQLQuery("delete from Yinjb s where s.zhangh in(select zhangh from zhanghb where jigh='"+code+"')").executeUpdate();
			session.createSQLQuery("delete from guiyjsgxb where guiyid in (select clerknum from clerktable c where c.n_organnum='"+code+"')").executeUpdate();
			super.getBaseHibernateDao().getDaoHibernateTemplate().bulkUpdate("delete Clerk c where c.orgcode = ?",new Object[] {code});
			super.getBaseHibernateDao().getDaoHibernateTemplate().bulkUpdate("delete Zhanghb a where a.jigh = ?",new Object[] { code });			
			session.createSQLQuery("delete from pingzpzb  where jigh='"+code+"'").executeUpdate();
			session.createQuery("delete Pingzxtlxgxb  where id.jigh ='"+code+"' ").executeUpdate();	
			session.createQuery("delete Pingzyjlxgxb  where id.jigh ='"+code+"' ").executeUpdate();	
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	
	public void deleteOrgBycode(Org org) throws BusinessException {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try{
			session.delete(org);			
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	public Org findOrgByOrgannum(String organnum) throws Exception {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Org org = null;
		try{
			org = (Org)session.get(Org.class, organnum);
			session.close();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return org;
	}

	public List getNetpointflag(String code) throws Exception {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		String orgcode = code.substring(0, 6);
		List<String> list = new ArrayList<String>();
		String query = "select a.account,a.netpointflag from accountinfo a,accountexpand t "
			+ "where a.account = t.account(+) and t.str10 <> ' ' and "
			+ "substr(a.netpointflag,0,6) like :orgcode";
		String sql = "";
		String db_type = DBinfoConig.getDBType();
		if("oracle".equals(db_type))
		{
			sql="select organnum from organarchives connect by prior organnum=n_parentnum "
				+ "start with organnum= :code";
		}else{
			sql="select * from TABLE(ORGFUNCTION(:code))";
		}
		try{
			SQLQuery query1 = session.createSQLQuery(sql);
			query1.setString("code", code);
			SQLQuery query2 = session.createSQLQuery(query);
			query2.setString("orgcode", orgcode+"%");
			List list1 = query1.list();
			if(list1==null)  list1=new ArrayList();
			List list2 = query2.list();
			if(list2==null)  list2=new ArrayList();
		for (Iterator iter2 = list2.iterator(); iter2.hasNext();) 
		  {
			 Object[] element = (Object[])iter2.next();
			 list.add((String)element[1]);
		  }
		for (Iterator iter1 = list1.iterator(); iter1.hasNext();) 
		{
			 Object[] element = (Object[])iter1.next();
			 list.add((String)element[0]);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
		
	}

	public Org getOrgByOrgCode(String orgCode) {
		Org org = null;
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try{
			org = (Org)session.get(Org.class, orgCode);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return org;
	}

	public List getOrgChildrenByCode(String code) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		List<Org> list1=new ArrayList<Org>();
		List<Org> list = null;
		try{
			if (code == null || code.length() == 0)
			{
				 list = session.createQuery("from Org  where parentCode is null order by code").list();
				
			}else{
				Query query = session.createQuery("from Org  where parentCode =:code order by code");
				query.setString("code", code);
				list=query.list();
				if(list == null) list = new ArrayList();
				for(Org org:list){
					if(org.getName().contains("(")){
						continue;
					}
					list1.add(org);
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
		return list1 ;
	}

	public String getOrgByDjAndShangjjgh(String dj,String jigh){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		List list = null;
		String allorg="";
		try{			
			String sql="";
			String db_type = DBinfoConig.getDBType();
			if("oracle".equals(db_type))
			{
				//oracle
				sql = "select * from organarchives where organnum in (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum='"+jigh+"') and WDFLAG='"+dj+"'";
			}else{
				//DB2
				sql = "select * from organarchives where organnum in (select * from TABLE(ORGFUNCTION('"+jigh+"')) AS test) and WDFLAG='"+dj+"'";
			}	
				
			list = session.createSQLQuery(sql).list();
			
			for (Object object : list) {
				Object[] o = (Object[]) object;				
				allorg+=(String) o[0];				
			}				
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
		return allorg ;
	}
	
	
	public List<Org> getOrgNumByCode(String code) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		List<Org> list1=new ArrayList<Org>();
		List list = null;
		try{
			if (code == null || code.length() == 0)
			{
				 list = session.createQuery("from Org  where parentCode is null order by code").list();
				
			}else{
				String sql = "";
				String db_type = DBinfoConig.getDBType();
				if("oracle".equals(db_type))
				{
					//oracle
					 sql = "select * from organarchives where N_PARENTNUM in (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:organnum)";
				}else{
					//DB2 
					sql = "select * from organarchives where N_PARENTNUM in (select * from TABLE(ORGFUNCTION(:organnum)) AS test)";
				}
				//Query query = session.createQuery("from Org  where WDFLAG =:code");
				Query query = session.createSQLQuery(sql);
				query.setString("organnum", code);
				list=query.list();
				
				for (Iterator iter = list.iterator(); iter.hasNext();) 
					{
					 Org org=new Org();
					 Object[] element = (Object[])iter.next();
					 org.setCode((String)element[0]);
					 org.setName((String)element[1]);
					 org.setParentCode((String)element[10]);
					 org.setWdflag(element[12].toString());	
					 org.setPaymentCode((String)element[11]);
					 org.setShOrgCode((String)element[13]);
					 org.setTctd((String)element[14]);
					 
					 list1.add(org);
					}
				
				if(list == null) list = new ArrayList();
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
		return list1 ;
	}
	
	
//	public List getOrgList(String parentCode) {
//		List list = null;
//		Session session =  super.getBaseHibernateDao().getHibernateSession();
//		try{
//			String sql = "from Org org where parentCode="+parentCode+" or code="+parentCode+" order by org.code";
//			list = session.createQuery(sql).list();
//		}catch (Exception e) {
//			e.printStackTrace();
//		}finally{
//			this.getBaseHibernateDao().closeSession(session);
//		}
//		return list;
//		
//	}
	public List<Org> getOrgList(String parentCode) {
		List list=null;
		List relist = new ArrayList();	
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try{
			String sql = "";
			String db_type = DBinfoConig.getDBType();
			if("oracle".equals(db_type))
			{
				//oracle
				 sql = "select * from organarchives where organnum in (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum='"+parentCode+"')";
			}else{
				//DB2 
				sql = "select * from organarchives where organnum in (select * from TABLE(ORGFUNCTION('"+parentCode+"')) AS test)";
			}
			
			list = session.createSQLQuery(sql).list();
			
			for (Object object : list) {
				Object[] o = (Object[]) object;
				Org org = new Org();
				org.setCode((String) o[0]);
				org.setParentCode((String) o[10]);
				org.setName((String) o[1]);				
				relist.add(org);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return relist;
		
	}
	
	public Org getParentCode(String code) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		Org org = null;
		try{
			org = (Org)session.get(Org.class, code);
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return org;
	}

	public void mergeOrg(String oldCode, String newCode)throws BusinessException {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		String cbjb=null;
		Transaction transaction = null;
		try {
			cbjb= ""+(Integer.valueOf(SystemControlParametersDao.findSystemControlParameterById("org_ranking").toString())+1);
			transaction = session.beginTransaction();
			Org newOrg = this.getOrgByCode(newCode);
			Org oldOrg = this.getOrgByCode(oldCode);
			if (newOrg == null)
				throw new BusinessException("��������'" + newCode + "'������");
			else if (!newOrg.getWdflag().equals(cbjb))
				throw new BusinessException("����'" + newCode + "'����"+cbjb+"������");
			/*else if (!newOrg.getShOrgCode().equals(oldOrg.getShOrgCode())) {
				throw new BusinessException("����������ͬһ��ʡ����");
			}*/ else if (oldCode.equals(newCode))
				throw new BusinessException("����������Ч");
			Org bo = this.getOrgByCode(oldCode);
			session.delete(bo);
			String updateSql1 = "delete Clerk c where c.orgcode = "+oldCode;
			String updateSql2 = "update Accountinfo a set a.netpointflag = "+newCode+" where a.netpointflag = "+oldCode;
			session.createSQLQuery(updateSql1);
			session.createSQLQuery(updateSql2);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	public void updateOrg(String account, String orgcode) throws Exception {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see com.unitop.sysmgr.dao.OrgDao#exportOrg(java.lang.String)
	 */
	public List<Org> exportOrg(String orgcode) {
		Session session = getBaseHibernateDao().getHibernateSession();
		List<Org> list1 = new ArrayList<Org>();
		try{
			String sql = "select organnum,organname,n_parentnum,n_paymentnum,wdflag,shenghjgh,tongdgz " +
				"from organarchives where n_parentnum= :orgcode  or organnum= :orgcode order by n_parentnum";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("orgcode", orgcode);
			List list = query.list();
			if(list==null) list=new ArrayList();
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Object[] element = (Object[]) iter.next();
				Org org = new Org();
				org.setCode((String) element[0]);
				org.setName((String) element[1]);
				org.setParentCode((String) element[2]);
				org.setPaymentCode((String)element[3]);
				org.setWdflag((String)element[4]);
				org.setShOrgCode((String) element[5]);
				org.setTctd((String) element[6]);
				list1.add(org);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			super.getBaseHibernateDao().closeSession(session);
		}
		return list1;
	}

	/**
	 * @see com.unitop.sysmgr.dao.OrgDao#importOrg(com.unitop.sysmgr.bo.Org)
	 */
	public boolean importOrg(Org org) {
		Session session = getBaseHibernateDao().getHibernateSession();
		boolean rs = false;
		try{
			String sql = "insert into organarchives (ORGANNUM, ORGANNAME, N_PARENTNUM, N_PAYMENTNUM, WDFLAG, SHENGHJGH, TONGDGZ) " +
				" values (:ORGANNUM, :ORGANNAME, :N_PARENTNUM, :N_PAYMENTNUM, :WDFLAG, :SHENGHJGH, :TONGDGZ)";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("ORGANNUM", org.getCode());
			query.setString("ORGANNAME", org.getName());
			query.setString("N_PARENTNUM", org.getParentCode());
			query.setString("N_PAYMENTNUM", org.getPaymentCode());
			query.setString("WDFLAG", org.getWdflag());
			query.setString("SHENGHJGH", org.getShOrgCode());
			query.setString("TONGDGZ", org.getTctd());
			query.executeUpdate();
			rs=true;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			super.getBaseHibernateDao().closeSession(session);
		}
		return rs;
	}

	/* (non-Javadoc)
	 * @see com.unitop.sysmgr.dao.OrgDao#getAllOrg(java.lang.String)
	 */
	public List<Org> getAllOrg(String orgcode) {	
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List<Org> list1 = new ArrayList<Org>();
		String sql = "";
		String db_type = DBinfoConig.getDBType();
		if("oracle".equals(db_type))
		{
			sql="select organnum,organname,n_parentnum,n_paymentnum,wdflag,shenghjgh,tongdgz ,ZHISZH from organarchives " +
				" where organnum in (select organnum from organarchives connect by " +
				" prior organnum=n_parentnum start with organnum= :organnum)";
		}else{
			sql="select organnum,organname,n_parentnum,n_paymentnum,wdflag,shenghjgh,tongdgz ,ZHISZH from organarchives " +
				" where organnum in (select * from TABLE(ORGFUNCTION(:organnum)) AS test)";
		}
		try{	
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("organnum", orgcode);
			List list = query.list();
			if(list==null)  list=new ArrayList();
		for (Iterator iter = list.iterator(); iter.hasNext();) 
		{
			 Org org=new Org();
			 Object[] element = (Object[])iter.next();
			 org.setCode((String)element[0]);
			 org.setName((String)element[1]);
			 org.setParentCode((String)element[2]);
			 org.setPaymentCode(String.valueOf(element[3]));
			 org.setWdflag(element[4].toString());
			 org.setShOrgCode((String)element[5]);
			 org.setTctd((String)element[6]);
			 org.setZhiszh((String)element[7]);
			 list1.add(org);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list1;
	}
	//��ȡ���п���Ļ�������
	public List<Org> getKagOrgs(String orgcode) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List<Org> list1 = new ArrayList<Org>();
		String sql = "";
		String db_type = DBinfoConig.getDBType();
		if("oracle".equals(db_type))
		{
			sql="select organnum,organname,n_parentnum,n_paymentnum,wdflag,shenghjgh,tongdgz from organarchives " +
				" where organnum in (select organnum from organarchives connect by " +
				" prior organnum=n_parentnum start with organnum= :organnum) and organnum in(select jigh from kagb)";
		}else{
			sql="select organnum,organname,n_parentnum,n_paymentnum,wdflag,shenghjgh,tongdgz from organarchives " +
				" where organnum in (select * from TABLE(ORGFUNCTION(:organnum)) AS test) and organnum in(select jigh from kagb) ";
		}
		try{
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("organnum", orgcode);
			List list = query.list();
			if(list==null)  list=new ArrayList();
		for (Iterator iter = list.iterator(); iter.hasNext();) 
		{
			 Org org=new Org();
			 Object[] element = (Object[])iter.next();
			 org.setCode((String)element[0]);
			 org.setName((String)element[1]);
			 org.setParentCode((String)element[2]);
			 org.setPaymentCode(String.valueOf(element[3]));
			 org.setWdflag(String.valueOf(element[4]));
			 org.setShOrgCode((String)element[5]);
			 org.setTctd((String)element[6]);
			 list1.add(org);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list1;
	}

	/* (non-Javadoc)
	 * @see com.unitop.sysmgr.dao.OrgDao#getOrgCount(java.lang.String)
	 */
	public int getOrgCount(String code) {
		Connection con = super.getBaseJDBCDao().getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		int count = 0;
		String sql = "select count(*) from organarchives where n_parentnum=? ";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, code);
			rs = ps.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			this.getBaseJDBCDao().closeConnection(con, ps, rs);
		}
		return count;
	}
	
	public int getOrgCountAll(String code) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		int element=0;
		String sql = "";
		String db_type = DBinfoConig.getDBType();
		if("oracle".equals(db_type))
		{
			sql="select count(organnum) from organarchives "+
			" where organnum in (select organnum from organarchives connect by " +
			" prior organnum=n_parentnum start with organnum=:organnum)";
		}else{
			sql="select count(organnum) from TABLE(ORGFUNCTION(:organnum))";
		}
		try{
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("organnum", code);
		    element = new Integer(query.uniqueResult().toString());
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			session.flush();
			this.getBaseHibernateDao().closeSession(session);
		}
		return element;
	}
	
	//��ȡ����ͨ��ͨ�һ����б�
	public List getOrgListForTCTD(String wdflag,String shenghOrgCode) {
		List list = null;
		if (wdflag.equals("0"))
		{
			list = super.getBaseHibernateDao().getDaoHibernateTemplate().find("from Org o where o.wdflag = '1' order by o.code");
		}else
			list = super.getBaseHibernateDao().getDaoHibernateTemplate().find("from Org o where o.wdflag = '1' and o.code=?  order by o.code",new Object[] {shenghOrgCode});
		return list;
	}
	
	//���»���ͨ��ͨ�� ��ϵ
	public void updateForOrg(String orgCode, String tctd) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try {
			String sql = "update organarchives set tongdgz=:tctd where organnum=:organnum or shenghjgh=:shenghjgh";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("tctd", tctd);
			query.setString("organnum", orgCode);
			query.setString("shenghjgh", orgCode);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	
	//���»���ͨ��ͨ�� ��ϵ
	public boolean validateOrg(String str1, String str2) {
		boolean flag = false;
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try {
			String sql = "";
			String db_type = DBinfoConig.getDBType();
			if("oracle".equals(db_type))
			{
				sql="select * from (select organnum from organarchives connect by prior organnum=n_parentnum  start with organnum =:organnum) where organnum=:organnum_";
			}else{
				sql="select * from (select * from TABLE(ORGFUNCTION(:organnum))) where organnum=:organnum_";
			}
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("organnum", str1);
			query.setString("organnum_", str2);
			List list = query.list();
			if(list!=null)
			{
				flag = list.size()>0?true:false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.flush();
			this.getBaseHibernateDao().closeSession(session);
		}
		return flag;
	}
	
	/**
	 * ɾ�����л���
	 */
	public void deleteAllOrg(){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		SQLQuery query = session.createSQLQuery("delete from organarchives");
		try{
			query.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
	}
	
	/**
	 * Ϊ�Զ�ͬ���Ļ�������wdflag��־
	 * @param root wdflagΪ1�Ļ��������ڵ�
	 */
	public void addWDFlag(String root){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try{
			SQLQuery query1 = session.createSQLQuery("update organarchives set wdflag='1' where organnum=:root");
			query1.setString("root", root);
			query1.executeUpdate();
			SQLQuery query2 = session.createSQLQuery("update organarchives set wdflag='2' where n_parentnum=:root");
			query2.setString("root", root);
			query2.executeUpdate();
			SQLQuery query3 = session.createSQLQuery("update organarchives a set a.wdflag='3' where exists (select 1 from organarchives b where b.wdflag='2' and a.n_parentnum=b.organnum)");
			query3.executeUpdate();
			SQLQuery query4 = session.createSQLQuery("update organarchives a set a.wdflag='4' where exists (select 1 from organarchives b where b.wdflag='3' and a.n_parentnum=b.organnum)");
			query4.executeUpdate();
			session.flush();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
	}
	public String getOrgByName(String orgName){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		String str=null;
		try{
			String sql="select organnum from ORGANARCHIVES where organname='"+orgName+"'";		
			SQLQuery query = session.createSQLQuery(sql);		
			List list = query.list();
			for(int i=0; i<list.size();i++){
			str=(String) list.get(0);			
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return str;
	};
	
	public List<Org> getOrgBywdf(String wdf,String jigh){
		Session session =  super.getBaseHibernateDao().getHibernateSession();		
		try {		
			List<Org> list=new ArrayList();
			String sql = "";
			String db_type = DBinfoConig.getDBType();
			if("oracle".equals(db_type))
			{
				//oracle
				 sql = "select * from ORGANARCHIVES where WDFLAG='"+wdf+"' and organnum in (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum='"+jigh+"')";
			}else{
				//DB2 
				sql = "select * from ORGANARCHIVES where WDFLAG='"+wdf+"' and organnum in (select * from TABLE(ORGFUNCTION('"+jigh+"')))";
			}
			
			Query query = session.createSQLQuery(sql);										
			List list1 = query.list();
			for (Iterator iter = list1.iterator(); iter.hasNext();) 
			{
			Org org=new Org();
			Object[] element = (Object[])iter.next();				
			org.setCode((String)element[0]);
			org.setName((String)element[1]);
			org.setParentCode((String)element[10]);				
			org.setShOrgCode((String)element[13]);				
			org.setWdflag((String)element[12]);
			list.add(org);
			}				
			return list;
		}catch(Exception e){				
		e.printStackTrace();
		return null;
		}finally{				
		this.getBaseHibernateDao().closeSession(session);		
		}
	}
}
