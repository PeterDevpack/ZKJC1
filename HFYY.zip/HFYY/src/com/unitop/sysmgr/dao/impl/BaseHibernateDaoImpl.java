package com.unitop.sysmgr.dao.impl;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.dao.BaseHibernateDao;
@Repository("BaseHibernateDaoImpl")
public class BaseHibernateDaoImpl  extends HibernateDaoSupport  implements BaseHibernateDao {
	
	private static ThreadLocal thread = new ThreadLocal();
	
	@Resource(name="sessionFactory")    
    public void setSuperSessionFactory(SessionFactory sessionFactory){ 
        super.setSessionFactory(sessionFactory); 
    }
	
	public HibernateTemplate getDaoHibernateTemplate() {
		return super.getHibernateTemplate();
	}

	// getHibernateSession();
	public Session getHibernateSession(){
		if(thread.get() != null)
		{
			return  (Session)thread.get();
		}else{
			return  this.getSession();
		}
	}
	
	//�ر�session
	public void closeSession(Session session){
		if(thread.get() == null)
		{
			session.flush();
			session.close();
			session=null;
		}
	}

	public void set_Session(Session session) {
		thread.set(session);
	}
	
	//�ͷ�����
	public void shifSession() {
		try{
		if(thread.get() != null)
		{
			Session session_ = (Session)thread.get();
			session_.flush();
			session_.clear();
			session_.close();
			thread.set(null);
		}	
		}catch (Exception e) {
			e.printStackTrace();
		}
	}	
}