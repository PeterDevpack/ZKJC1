package com.unitop.sysmgr.dao.impl;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.config.DBinfoConig;
import com.unitop.sysmgr.bo.Jigtgl;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.dao.PassRateDao;
import com.unitop.sysmgr.dao.TabsDao;
import com.unitop.sysmgr.service.OrgService;

@Repository("passRateDao")
public class PassRateDaoImpl extends BaseDataResources  implements PassRateDao{
	@Resource
	private OrgService OrgService;
	@Resource
	private TabsDao TabsDao;
	
	public TabsBo getAccPassRate(String beginDate,String endDate,String org,String orgname,TabsBo tabsBo){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
//		String[] s = org.split(",");
//		String jigh="";
//		for(int i=0;i<s.length;i++){
//			if(i==0){
//				jigh+=("'"+s[i]+"'");
//			}else{
//				jigh+=(", '"+s[i]+"'");
//			}
//		}
		List relist = new ArrayList();		
		try{				 					
			String sql="select * from "
					+ "(select b.hum, b.account,'Ʊ' as leix, nvl(zongs,0) as zongs,nvl(zid,0) as zid, nvl(fuz,0) as fuz,nvl "
					+ "(reng,0) as reng, cast(cast(nvl(zid*100,0) as float)/zongs as decimal(10,2)) as zidtgl,cast(cast(nvl(fuz*100,0) as float)/zongs as decimal(10,2)) as fuztgl,cast(cast(nvl(reng*100,0) as float)/zongs as decimal(10,2)) as rengtgl " 
					+ ",b.jigh from "
					+ "		(select CLERKORGCODE as jigh,z.hum,account,count(*) as zongs from credencechecklog, (select zhangh,hum from zhanghb) z  where "
					+ "		yanybs!='DZXT' and checkdate between  '"+beginDate+"' and '"+endDate+"'and account=z.zhangh  group by account,CLERKORGCODE, z.hum ) b "
					+ "	left join "
					+ "		(select clerkorgcode as jigh1,account,count(*) as zid "
					+ "		from credencechecklog where yanybs!='DZXT' and checkdate between  '"+beginDate+"' and '"+endDate+"' "
					+ "		and checkmode='�Զ�' and checkresult='ͨ��' group by account,clerkorgcode"
					+ "		) c on b.account = c.account and b.jigh = c.jigh1 "
					+ "	left join "
					+ "		(select clerkorgcode as jigh2,account,count(*) as fuz "
					+ "		from credencechecklog where yanybs!='DZXT' and checkdate between  '"+beginDate+"' and '"+endDate+"'  and "
					+ "		checkmode='����' and  checkresult='ͨ��'   group by account,clerkorgcode"
					+ "		) d on b.account = d.account and b.jigh = d.jigh2 "
					+ "	left join "
					+ "		(select clerkorgcode as jigh3,account,count(*) as reng "
					+ "		from credencechecklog c where yanybs!='DZXT' and checkdate between  '"+beginDate+"' and '"+endDate+"'  and "
					+ "		checkmode='�˹�' and   checkresult='ͨ��' group by account,clerkorgcode"
					+ "		) e on b.account = e.account and b.jigh = e.jigh3 "
					+ ")where jigh in(select organnum from organarchives connect by prior organnum=n_parentnum start with organnum='"+org+"') "
					+ "			and zongs >3 and (zidtgl+fuztgl) < 60 order by (zidtgl+fuztgl)  " ;

//			SQLQuery query = session.createSQLQuery(sql);					
//			List list = query.list();
			List list2 = new ArrayList<Jigtgl>();
//			if(list==null){ list=new ArrayList();}
			TabsBo tabsBoModle = TabsDao.pagingObjectForSql(sql, tabsBo.getDangqym(), tabsBo.getFenysl(), null);
			
			for (Iterator iter = tabsBoModle.getList().iterator(); iter.hasNext();) {
				Jigtgl xm=new Jigtgl();
				Object[] element = (Object[]) iter.next();				
				xm.setZhangh((String) element[1]);
				xm.setHum((String) element[0]);
				xm.setYanyzs( (String) element[3].toString());
				//xm.setTonggzs( (String) element[2].toString());
				//xm.setTonggl( (String) element[3].toString());
				if(null != element[4]){xm.setZidtgzs((String) element[4].toString());}
				if(null != element[7]){xm.setZidtgl((String) element[7].toString());}
				if(null != element[5]){xm.setFuztgzs((String) element[5].toString());}
				if(null != element[8]){xm.setFuztgl((String) element[8].toString());}	
				if(null != element[6]){xm.setRengtgzs((String) element[6].toString());}
				if(null != element[9]){xm.setRengtgl((String) element[9].toString());}
				if(null != element[10]){xm.setJigh((String) element[10].toString());}
				Org orgnum = OrgService.getOrgByCode((String)element[10]);
				if(null != orgnum&&!"".equals(orgnum)){xm.setJigmc(orgnum.getName());}
				list2.add(xm);
			}
			tabsBo.setList(list2);
			tabsBo.setCounts(tabsBoModle.getCounts());
			return tabsBo;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return tabsBo;
	}
	//����ͨ����ͳ��
	//��������Ų�ѯ
	public List<Jigtgl> getOrgPassRate(String beginDate,String endDate,String org){		
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		String[] s = org.split(",");
		String jiglist="";
		for(int i=0;i<s.length;i++){
			if(i==0){
				jiglist+=("'"+s[i]+"'");
			}else{
				jiglist+=(", '"+s[i]+"'");
			}
		}	
		try{				 					
			String sql = "SELECT *"
					+" FROM ("
					+"	SELECT b.organname, 'Ʊ' AS leix, nvl(zongs, 0) AS zongs, nvl(zid, 0) AS zid, nvl(fuz, 0) AS fuz, nvl(reng, 0) AS reng, cast(cast(nvl(zid * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS zidtgl, cast(cast(nvl(fuz * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS fuztgl, cast(cast(nvl(reng * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS rengtgl, b.clerkorgcode, b.wdflag"
					+"	FROM ("
					+"		SELECT clerkorgcode, count(*) AS zongs, f.organname, f.wdflag"
					+"		FROM credencechecklog g, ("
					+"				SELECT wdflag, organnum, organname"
					+"				FROM organarchives"
					+"				WHERE organnum IN ("+jiglist+")"
					+"				) f"
					+"		WHERE yanybs!='DZXT' and clerkorgcode IN ("+jiglist+") AND f.organnum = clerkorgcode AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"'"
					+"		GROUP BY clerkorgcode, f.organname, f.wdflag"
					+"		) b"
					+"	LEFT JOIN ("
					+"		SELECT clerkorgcode, count(*) AS zid"
					+"		FROM credencechecklog"
					+"		WHERE yanybs!='DZXT' and clerkorgcode IN ("+jiglist+") AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�Զ�' AND checkresult = 'ͨ��'"
					+"		GROUP BY clerkorgcode"
					+"		) c ON b.clerkorgcode = c.clerkorgcode"
					+"	LEFT JOIN ("
					+"		SELECT clerkorgcode, count(*) AS fuz"
					+"		FROM credencechecklog"
					+"		WHERE yanybs!='DZXT' and clerkorgcode IN ("+jiglist+") AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '����' AND checkresult = 'ͨ��'"
					+"		GROUP BY clerkorgcode"
					+"		) d ON b.clerkorgcode = d.clerkorgcode"
					+"	LEFT JOIN ("
					+"		SELECT clerkorgcode, count(*) AS reng"
					+"		FROM credencechecklog c"
					+"		WHERE yanybs!='DZXT' and clerkorgcode IN ("+jiglist+") AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�˹�' AND checkresult = 'ͨ��'"
					+"		GROUP BY clerkorgcode"
					+"		) e ON b.clerkorgcode = e.clerkorgcode"
					+"	)";		
			
			SQLQuery query = session.createSQLQuery(sql);					
			List list = query.list();
			List<Jigtgl> list2 = new ArrayList<Jigtgl>();
			if(list==null){ list=new ArrayList<Jigtgl>();}
			
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Jigtgl xm=new Jigtgl();
				Object[] element = (Object[]) iter.next();
				xm.setJigmc((String) element[0]);
				xm.setJigh((String) element[9]);
				xm.setOrgflag((String) element[10]);
				xm.setYanyzs( (String) element[2].toString());
				int xitzs= Integer.parseInt(element[3].toString())+Integer.parseInt(element[4].toString());
				float xittgl=(float)xitzs*100/Integer.parseInt(element[2].toString());
				xm.setXittgzs(String.valueOf(xitzs));	
				DecimalFormat df = new DecimalFormat("0.00");
				xm.setXittgl(df.format(xittgl)); 
				//xm.setTonggzs( (String) element[2].toString());
				//xm.setTonggl( (String) element[3].toString());
				if(null != element[3]){xm.setZidtgzs((String) element[3].toString());}
				if(null != element[6]){xm.setZidtgl((String) element[6].toString());}
				if(null != element[4]){xm.setFuztgzs((String) element[4].toString());}
				if(null != element[7]){xm.setFuztgl((String) element[7].toString());}	
				if(null != element[5]){xm.setRengtgzs((String) element[5].toString());}
				if(null != element[8]){xm.setRengtgl((String) element[8].toString());}				
				list2.add(xm);
			}
			return list2;	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}		
	}
//�ܼ�
	public Jigtgl queryTotalJgBy(String org,String beginDate,String endDate)throws Exception{
		List<Jigtgl>list = null;
		String[] s = org.split(",");
		String jigh="";
		for(int i=0;i<s.length;i++){
			if(i==0){
				jigh+=("'"+s[i]+"'");
			}else{
				jigh+=(", '"+s[i]+"'");
			}
		}
		Session session = this.getBaseHibernateDao().getHibernateSession();
		try{				
			String sql = "SELECT b.organname, 'Ʊ' AS leix, nvl(zongs, 0) AS zongs, nvl(zid, 0) AS zid, nvl(fuz, 0) AS fuz, nvl(reng, 0) AS reng, cast(cast(nvl(zid * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS zidtgl, cast(cast(nvl(fuz * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS fuztgl, cast(cast(nvl(reng * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS rengtgl, b.wdflag"
						+" FROM ("
						+"	SELECT f.organnum, count(*) AS zongs, f.organname, f.wdflag"
						+"	FROM credencechecklog g, ("
						+"			SELECT wdflag, organnum, organname"
						+"			FROM organarchives"
						+"			WHERE organnum IN ("+jigh+")"
						+"			) f"
						+"	WHERE yanybs!='DZXT' and clerkorgcode IN ("+jigh+") AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"'"
						+"	GROUP BY clerkorgcode, f.organnum, f.organname, f.wdflag"
						+"	) b"
						+" LEFT JOIN ("
						+"	SELECT clerkorgcode, count(*) AS zid"
						+"	FROM credencechecklog"
						+"	WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�Զ�' AND checkresult = 'ͨ��' AND clerkorgcode IN ("+jigh+")"
						+"	GROUP BY clerkorgcode"
						+"	) c ON b.organnum = c.clerkorgcode"
						+" LEFT JOIN ("
						+"	SELECT clerkorgcode, count(*) AS fuz"
						+"	FROM credencechecklog"
						+"	WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '����' AND checkresult = 'ͨ��' AND clerkorgcode IN ("+jigh+")"
						+"	GROUP BY clerkorgcode"
						+"	) d ON b.organnum = d.clerkorgcode"
						+" LEFT JOIN ("
						+"	SELECT clerkorgcode, count(*) AS reng"
						+"	FROM credencechecklog c"
						+"	WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�˹�' AND checkresult = 'ͨ��' AND clerkorgcode IN ("+jigh+")"
						+"	GROUP BY clerkorgcode"
						+"	) e ON b.organnum = e.clerkorgcode";
			
				SQLQuery query = session.createSQLQuery(sql);	
				
				//Query query=session.createSQLQuery(sql).addEntity(XXXX.class);
				//query.setFirstResult((pageIndex-1)*pageSize) ;
				//query.setMaxResults(pageSize);
				
				
				List list1 = query.list();
				Jigtgl xm=new Jigtgl();
				for (Iterator iter = list1.iterator(); iter.hasNext();) {
					
					Object[] element = (Object[]) iter.next();					
					xm.setJigmc((String) element[0]);									
					xm.setYanyzs( (String) element[2].toString());
					//xm.setTonggzs( (String) element[2].toString());
					//xm.setTonggl( (String) element[3].toString());
					if(null != element[3]){xm.setZidtgzs((String) element[3].toString());}
					if(null != element[6]){xm.setZidtgl((String) element[6].toString());}
					if(null != element[4]){xm.setFuztgzs((String) element[4].toString());}
					if(null != element[7]){xm.setFuztgl((String) element[7].toString());}	
					if(null != element[5]){xm.setRengtgzs((String) element[5].toString());}
					if(null != element[8]){xm.setRengtgl((String) element[8].toString());}
				}			
				return xm;	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
	}
	public List<Jigtgl> queryDJJgBy(String jigh,String beginDate,String endDate, String wdf,String xitlx)throws Exception
	{
		List<Jigtgl> list =  new ArrayList<Jigtgl>();
		Session session = this.getBaseHibernateDao().getHibernateSession();
//		String[] s = org.split(",");
//		String jigh="";
//		for(int i=0;i<s.length;i++){
//			if(i==0){
//				jigh+=("'"+s[i]+"'");
//			}else{
//				jigh+=(", '"+s[i]+"'");
//			}
//		}
		try{
			String sql = "";
			String db_type = DBinfoConig.getDBType();

			String xtlxmc = "";
			if(xitlx.equals("1"))
				xtlxmc = "֧��";
			else if(xitlx.equals("2"))
				xtlxmc = "����";
			else if(xitlx.equals("3"))
				xtlxmc = "����";
			else if(xitlx.equals("0"))
				xtlxmc = "ȫ��";
			if("oracle".equals(db_type))
			{
				if("3".equals(wdf)){
					sql = "select nvl(j.N_PARENTNUM,c.CLERKORGCODE) fhh ,j.ORGANNUM,sum(1) zongs, "
						+"				  sum(case when c.CHECKMODE='�˹�' and  c.CHECKRESULT='ͨ��' then 1 ELSE 0 end) reng, "
						+"                sum(case when c.CHECKMODE='����' and  c.CHECKRESULT='ͨ��' then 1 ELSE 0 end) fuz, "
						+"                sum(case when c.CHECKMODE='�Զ�' and  c.CHECKRESULT='ͨ��' then 1 ELSE 0 end) zid "
						+"                "
						+" from credencechecklog c left join organarchives j on c.CLERKORGCODE = j.organnum and j.WDFLAG = 3 "
						+" where c.CLERKORGCODE in (select ORGANNUM from ORGANARCHIVES connect by prior ORGANNUM = N_PARENTNUM  start with ORGANNUM ='"+jigh+"') "
						+"       and  c.yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' ";
					if(xtlxmc!="ȫ��")
						sql+= " and c.XITLX = '"+xitlx+"'";
					sql += " group by  grouping sets(nvl(j.N_PARENTNUM ,c.CLERKORGCODE),j.ORGANNUM)";
					
					sql = " select case when fh.ORGANNAME is null then zhf.ORGANNAME||'-'||zh.ORGANNAME else fh.ORGANNAME end organname,'' ywlx, "
							+" sj.zongs,sj.zid,sj.fuz,sj.reng,cast(cast(nvl(sj.zid * 100, 0) AS FLOAT) / sj.zongs AS DECIMAL(10, 2)) AS zidtgl"
						+"	,cast(cast(nvl(sj.fuz * 100, 0) AS FLOAT) / sj.zongs AS DECIMAL(10, 2)) AS fuztgl,cast(cast(nvl(sj.reng * 100, 0) AS FLOAT) /sj.zongs AS DECIMAL(10, 2)) AS rengtgl  "
						+" from ("+sql+")sj "
						+" left join organarchives fh on sj.fhh=fh.ORGANNUM "
						+" left join organarchives zh on sj.ORGANNUM=zh.ORGANNUM "
						+" left join organarchives zhf on zh.N_PARENTNUM=zhf.ORGANNUM "
						+"  where sj.fhh is not null or zhf.ORGANNUM is not null "
						+"  order by  case when   fh.ORGANNAME is null then zhf.ORGANNAME||'-'||zh.ORGANNAME else fh.ORGANNAME end ";
				}
				else if("2".equals(wdf)){ 
					sql = "select nvl(j.N_PARENTNUM,c.CLERKORGCODE) jgh,sum(1) zongs, "
							+"				  sum(case when c.CHECKMODE='�˹�' and  c.CHECKRESULT='ͨ��' then 1 ELSE 0 end) reng, "
							+"                sum(case when c.CHECKMODE='����' and  c.CHECKRESULT='ͨ��' then 1 ELSE 0 end) fuz, "
							+"                sum(case when c.CHECKMODE='�Զ�' and  c.CHECKRESULT='ͨ��' then 1 ELSE 0 end) zid "
							+"                "
							+" from credencechecklog c left join organarchives j on c.CLERKORGCODE = j.organnum and j.WDFLAG = 3 "
							+" where c.CLERKORGCODE in (select ORGANNUM from ORGANARCHIVES connect by prior ORGANNUM = N_PARENTNUM  start with ORGANNUM ='"+jigh+"') "
							+"       and  c.yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' ";
						if(xtlxmc!="ȫ��")
							sql+= " and c.XITLX = '"+xitlx+"'";
						sql += "  group by  nvl(j.N_PARENTNUM,c.CLERKORGCODE) ";
						
						sql = " select jg.ORGANNAME,'' ywlx,sj.zongs,sj.zid,sj.fuz,sj.reng,cast(cast(nvl(sj.zid * 100, 0) AS FLOAT) / sj.zongs AS DECIMAL(10, 2)) AS zidtgl"
							+"	,cast(cast(nvl(sj.fuz * 100, 0) AS FLOAT) / sj.zongs AS DECIMAL(10, 2)) AS fuztgl,cast(cast(nvl(sj.reng * 100, 0) AS FLOAT) / sj.zongs AS DECIMAL(10, 2)) AS rengtgl  "
							+" from ("+sql+")sj left join organarchives jg on sj.jgh =jg.organnum  order by jg.ORGANNAME ";
				}
			}else{
				//DB2 
				sql="SELECT b.organname,'Ʊ' AS leix,nvl(zongs, 0) AS zongs,nvl(zid, 0) AS zid,nvl(fuz, 0) AS fuz,nvl(reng, 0) AS reng,cast(cast(nvl(zid * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS zidtgl"
						+"	,cast(cast(nvl(fuz * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS fuztgl,cast(cast(nvl(reng * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS rengtgl,b.organnum,b.N_PARENTNUM,b.wdflag "
						+"FROM ("
						+"	SELECT sum(zongs) AS zongs,organname,organnum,N_PARENTNUM,wdflag"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS zongs FROM credencechecklog g WHERE yanybs!='DZXT' and CLERKORGCODE IN (SELECT * FROM TABLE (ORGFUNCTION('"+jigh+"')) AS test) AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' GROUP BY CLERKORGCODE)"
						+"	,(SELECT wdflag,organnum,organname,N_PARENTNUM FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum,N_PARENTNUM,wdflag"
						+"	) b "
						+"LEFT JOIN ("
						+"	SELECT sum(zid) AS zid,organname,organnum"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS zid FROM credencechecklog WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�Զ�' AND checkresult = 'ͨ��' AND CLERKORGCODE IN (SELECT * FROM TABLE (ORGFUNCTION('"+jigh+"')) AS test) GROUP BY CLERKORGCODE)"
						+"	,(SELECT wdflag,organnum,organname FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum"
						+"	) c ON b.organnum = c.organnum "
						+"LEFT JOIN ("
						+"	SELECT sum(fuz) AS fuz,organname,organnum"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS fuz FROM credencechecklog WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '����' AND checkresult = 'ͨ��' AND CLERKORGCODE IN (SELECT * FROM TABLE (ORGFUNCTION('"+jigh+"')) AS test) GROUP BY CLERKORGCODE)"
						+"		,(SELECT wdflag,organnum,organname FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum"
						+"	) d ON b.organnum = d.organnum "
						+"LEFT JOIN ("
						+"	SELECT sum(reng) AS reng,organname,organnum"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS reng FROM credencechecklog c WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�˹�' AND checkresult = 'ͨ��' AND CLERKORGCODE IN (SELECT * FROM TABLE (ORGFUNCTION('"+jigh+"')) AS test) GROUP BY CLERKORGCODE)"
						+"		,(SELECT wdflag,organnum,organname FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum"
						+"	) e ON b.organnum = e.organnum";
			}
			
			SQLQuery query = session.createSQLQuery(sql);	
				
				//Query query=session.createSQLQuery(sql).addEntity(XXXX.class);
				//query.setFirstResult((pageIndex-1)*pageSize) ;
				//query.setMaxResults(pageSize);
				
				
				List list1 = query.list();
				for (Iterator iter = list1.iterator(); iter.hasNext();) {

					Jigtgl xm=new Jigtgl();
					Object[] element = (Object[]) iter.next();					
					xm.setJigmc((String) element[0]);
					
					xm.setXitlx(xtlxmc);
					
//					xm.setJigh((String) element[9]);
//					xm.setParentOrg((String) element[10]);
//					xm.setOrgflag((String) element[11]);
					
					xm.setYanyzs( (String) element[2].toString());
					
					int xitzs= Integer.parseInt(element[3].toString())+Integer.parseInt(element[4].toString());
					float xittgl=(float)xitzs*100/Integer.parseInt(element[2].toString());
					xm.setXittgzs(String.valueOf(xitzs));	
					DecimalFormat df = new DecimalFormat("0.00");
					xm.setXittgl(df.format(xittgl));
					//xm.setTonggzs( (String) element[2].toString());
					//xm.setTonggl( (String) element[3].toString());
					if(null != element[3]){xm.setZidtgzs((String) element[3].toString());}
					if(null != element[6]){xm.setZidtgl((String) element[6].toString());}
					if(null != element[4]){xm.setFuztgzs((String) element[4].toString());}
					if(null != element[7]){xm.setFuztgl((String) element[7].toString());}	
					if(null != element[5]){xm.setRengtgzs((String) element[5].toString());}
					if(null != element[8]){xm.setRengtgl((String) element[8].toString());}
					list.add(xm);
				}			
				return list;	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
		
	}
	
//��ѯ�����Լ��¼�
	public Jigtgl queryAllJgBy(String jigh,String beginDate,String endDate, String wdf,String xitlx) throws Exception {
		List<Jigtgl>list = null;
		Session session = this.getBaseHibernateDao().getHibernateSession();
//		String[] s = org.split(",");
//		String jigh="";
//		for(int i=0;i<s.length;i++){
//			if(i==0){
//				jigh+=("'"+s[i]+"'");
//			}else{
//				jigh+=(", '"+s[i]+"'");
//			}
//		}
		try{
			String sql = "";
			String db_type = DBinfoConig.getDBType();
			String xtlxmc = "";
			if(xitlx.equals("1"))
				xtlxmc = "֧��";
			else if(xitlx.equals("2"))
				xtlxmc = "����";
			else if(xitlx.equals("3"))
				xtlxmc = "����";
			else if(xitlx.equals("0"))
				xtlxmc = "ȫ��";
			if("oracle".equals(db_type))
			{
				//oracle
				/*sql="SELECT b.organname,'Ʊ' AS leix,nvl(zongs, 0) AS zongs,nvl(zid, 0) AS zid,nvl(fuz, 0) AS fuz,nvl(reng, 0) AS reng,cast(cast(nvl(zid * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS zidtgl"
						+"	,cast(cast(nvl(fuz * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS fuztgl,cast(cast(nvl(reng * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS rengtgl,b.organnum,b.N_PARENTNUM,b.wdflag "
						+"FROM ("
						+"	SELECT sum(zongs) AS zongs,organname,organnum,N_PARENTNUM,wdflag"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS zongs FROM credencechecklog g WHERE yanybs!='DZXT' and CLERKORGCODE IN (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum='"+jigh+"') AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' GROUP BY CLERKORGCODE)"
						+"	,(SELECT wdflag,organnum,organname,N_PARENTNUM FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum,N_PARENTNUM,wdflag"
						+"	) b "
						+"LEFT JOIN ("
						+"	SELECT sum(zid) AS zid,organname,organnum"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS zid FROM credencechecklog WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�Զ�' AND checkresult = 'ͨ��' AND CLERKORGCODE IN (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum='"+jigh+"') GROUP BY CLERKORGCODE)"
						+"	,(SELECT wdflag,organnum,organname FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum"
						+"	) c ON b.organnum = c.organnum "
						+"LEFT JOIN ("
						+"	SELECT sum(fuz) AS fuz,organname,organnum"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS fuz FROM credencechecklog WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '����' AND checkresult = 'ͨ��' AND CLERKORGCODE IN (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum='"+jigh+"') GROUP BY CLERKORGCODE)"
						+"		,(SELECT wdflag,organnum,organname FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum"
						+"	) d ON b.organnum = d.organnum "
						+"LEFT JOIN ("
						+"	SELECT sum(reng) AS reng,organname,organnum"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS reng FROM credencechecklog c WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�˹�' AND checkresult = 'ͨ��' AND CLERKORGCODE IN (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum='"+jigh+"') GROUP BY CLERKORGCODE)"
						+"		,(SELECT wdflag,organnum,organname FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum"
						+"	) e ON b.organnum = e.organnum";*/
				
				
				sql = "select '"+jigh+"' jgh,'"+xtlxmc+"' ywlx ,sum(1) zongs, "
					+"				  sum(case when c.CHECKMODE='�˹�' and  c.CHECKRESULT='ͨ��' then 1 ELSE 0 end) reng, "
					+"                sum(case when c.CHECKMODE='����' and  c.CHECKRESULT='ͨ��' then 1 ELSE 0 end) fuz, "
					+"                sum(case when c.CHECKMODE='�Զ�' and  c.CHECKRESULT='ͨ��' then 1 ELSE 0 end) zid "
					+"                "
					+" from credencechecklog c left join organarchives j on c.CLERKORGCODE = j.organnum and j.WDFLAG = 3 "
					+" where c.CLERKORGCODE in (select ORGANNUM from ORGANARCHIVES connect by prior ORGANNUM = N_PARENTNUM  start with ORGANNUM ='"+jigh+"') "
					+"       and  c.yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' ";
				if(xtlxmc!="ȫ��")
					sql+= " and c.XITLX = '"+xitlx+"'";
				
				sql = " select b.organname,a.ywlx,a.zongs,a.zid,a.fuz,a.reng,cast(cast(nvl(a.zid * 100, 0) AS FLOAT) / a.zongs AS DECIMAL(10, 2)) AS zidtgl"
					+"	,cast(cast(nvl(a.fuz * 100, 0) AS FLOAT) / a.zongs AS DECIMAL(10, 2)) AS fuztgl,cast(cast(nvl(a.reng * 100, 0) AS FLOAT) / a.zongs AS DECIMAL(10, 2)) AS rengtgl,b.organnum,b.N_PARENTNUM,b.wdflag "
					+" from ("+sql+") a left join organarchives b on a.jgh = b.organnum ";
				
			}else{
				//DB2 
				sql="SELECT b.organname,'Ʊ' AS leix,nvl(zongs, 0) AS zongs,nvl(zid, 0) AS zid,nvl(fuz, 0) AS fuz,nvl(reng, 0) AS reng,cast(cast(nvl(zid * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS zidtgl"
						+"	,cast(cast(nvl(fuz * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS fuztgl,cast(cast(nvl(reng * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS rengtgl,b.organnum,b.N_PARENTNUM,b.wdflag "
						+"FROM ("
						+"	SELECT sum(zongs) AS zongs,organname,organnum,N_PARENTNUM,wdflag"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS zongs FROM credencechecklog g WHERE yanybs!='DZXT' and CLERKORGCODE IN (SELECT * FROM TABLE (ORGFUNCTION('"+jigh+"')) AS test) AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' GROUP BY CLERKORGCODE)"
						+"	,(SELECT wdflag,organnum,organname,N_PARENTNUM FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum,N_PARENTNUM,wdflag"
						+"	) b "
						+"LEFT JOIN ("
						+"	SELECT sum(zid) AS zid,organname,organnum"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS zid FROM credencechecklog WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�Զ�' AND checkresult = 'ͨ��' AND CLERKORGCODE IN (SELECT * FROM TABLE (ORGFUNCTION('"+jigh+"')) AS test) GROUP BY CLERKORGCODE)"
						+"	,(SELECT wdflag,organnum,organname FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum"
						+"	) c ON b.organnum = c.organnum "
						+"LEFT JOIN ("
						+"	SELECT sum(fuz) AS fuz,organname,organnum"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS fuz FROM credencechecklog WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '����' AND checkresult = 'ͨ��' AND CLERKORGCODE IN (SELECT * FROM TABLE (ORGFUNCTION('"+jigh+"')) AS test) GROUP BY CLERKORGCODE)"
						+"		,(SELECT wdflag,organnum,organname FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum"
						+"	) d ON b.organnum = d.organnum "
						+"LEFT JOIN ("
						+"	SELECT sum(reng) AS reng,organname,organnum"
						+"	FROM (SELECT CLERKORGCODE,count(*) AS reng FROM credencechecklog c WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�˹�' AND checkresult = 'ͨ��' AND CLERKORGCODE IN (SELECT * FROM TABLE (ORGFUNCTION('"+jigh+"')) AS test) GROUP BY CLERKORGCODE)"
						+"		,(SELECT wdflag,organnum,organname FROM organarchives WHERE organnum = '"+jigh+"') GROUP BY organname,organnum"
						+"	) e ON b.organnum = e.organnum";
			}
			
			SQLQuery query = session.createSQLQuery(sql);	
				
				//Query query=session.createSQLQuery(sql).addEntity(XXXX.class);
				//query.setFirstResult((pageIndex-1)*pageSize) ;
				//query.setMaxResults(pageSize);
				
				
				List list1 = query.list();
				Jigtgl xm=new Jigtgl();
				for (Iterator iter = list1.iterator(); iter.hasNext();) {
					
					Object[] element = (Object[]) iter.next();					
					xm.setJigmc((String) element[0]);
					/*if(xitlx.equals("0")){
					
						xm.setXitlx("ȫ��");
					}
					else if(xitlx.equals("1")){
						xm.setXitlx("֧��");
					}
					else if(xitlx.equals("2")){
						xm.setXitlx("����");
					}
					else if(xitlx.equals("3")){
						xm.setXitlx("����");
					}*/
					xm.setXitlx(xtlxmc);
					
					xm.setJigh((String) element[9]);
					xm.setParentOrg((String) element[10]);
					xm.setOrgflag((String) element[11]);
					
					xm.setYanyzs( (String) element[2].toString());
					
					int xitzs= Integer.parseInt(element[3].toString())+Integer.parseInt(element[4].toString());
					float xittgl=(float)xitzs*100/Integer.parseInt(element[2].toString());
					xm.setXittgzs(String.valueOf(xitzs));	
					DecimalFormat df = new DecimalFormat("0.00");
					xm.setXittgl(df.format(xittgl));
					//xm.setTonggzs( (String) element[2].toString());
					//xm.setTonggl( (String) element[3].toString());
					if(null != element[3]){xm.setZidtgzs((String) element[3].toString());}
					if(null != element[6]){xm.setZidtgl((String) element[6].toString());}
					if(null != element[4]){xm.setFuztgzs((String) element[4].toString());}
					if(null != element[7]){xm.setFuztgl((String) element[7].toString());}	
					if(null != element[5]){xm.setRengtgzs((String) element[5].toString());}
					if(null != element[8]){xm.setRengtgl((String) element[8].toString());}
				}			
				return xm;	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
		
	}	
	
	//�������Ų�ѯ
//=========================
	public Jigtgl queryJgBy(String org,String beginDate,String endDate, String wdf) throws Exception {
	List<Jigtgl>list = null;
	Session session = this.getBaseHibernateDao().getHibernateSession();
	String[] s = org.split(",");
	String jigh="";
	for(int i=0;i<s.length;i++){
		if(i==0){
			jigh+=("'"+s[i]+"'");
		}else{
			jigh+=(", '"+s[i]+"'");
		}
	}
	try{				
		String sql=  "SELECT b.organname,'Ʊ' AS leix,nvl(zongs, 0) AS zongs,nvl(zid, 0) AS zid,nvl(fuz, 0) AS fuz,nvl(reng, 0) AS reng,cast(cast(nvl(zid * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS zidtgl,cast(cast(nvl(fuz * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS fuztgl,cast(cast(nvl(reng * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS rengtgl,b.wdflag,b.organnum,b.N_PARENTNUM "
					+"FROM ("
					+"	SELECT f.organnum,count(*) AS zongs,f.organname,f.wdflag,f.N_PARENTNUM"
					+"	FROM credencechecklog g,(SELECT wdflag,organnum,organname,N_PARENTNUM FROM organarchives WHERE organnum = "+jigh+") f "
					+"	WHERE yanybs!='DZXT' and CLERKORGCODE = "+jigh+" AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' "
					+"	GROUP BY CLERKORGCODE,f.organnum,f.organname,f.wdflag,f.N_PARENTNUM "
					+"	) b "
					+"LEFT JOIN ( "
					+"	SELECT CLERKORGCODE,count(*) AS zid "
					+"	FROM credencechecklog"
					+"	WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�Զ�' AND checkresult = 'ͨ��' AND CLERKORGCODE = "+jigh
					+"	GROUP BY CLERKORGCODE"
					+"	) c ON b.organnum = c.CLERKORGCODE "
					+"LEFT JOIN ("
					+"	SELECT CLERKORGCODE,count(*) AS fuz"
					+"	FROM credencechecklog"
					+"	WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '����' AND checkresult = 'ͨ��' AND CLERKORGCODE = "+jigh
					+"	GROUP BY CLERKORGCODE"
					+"	) d ON b.organnum = d.CLERKORGCODE "
					+"LEFT JOIN ("
					+"	SELECT CLERKORGCODE,count(*) AS reng"
					+"	FROM credencechecklog c"
					+"	WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�˹�' AND checkresult = 'ͨ��' AND CLERKORGCODE = "+jigh
					+"	GROUP BY CLERKORGCODE"
					+"	) e ON b.organnum = e.CLERKORGCODE";
			SQLQuery query = session.createSQLQuery(sql);	
			
			//Query query=session.createSQLQuery(sql).addEntity(XXXX.class);
			//query.setFirstResult((pageIndex-1)*pageSize) ;
			//query.setMaxResults(pageSize);
			
			
			List list1 = query.list();
			Jigtgl xm=new Jigtgl();
			for (Iterator iter = list1.iterator(); iter.hasNext();) {
				
				Object[] element = (Object[]) iter.next();
				xm.setJigmc((String) element[0]);	
				xm.setJigh((String) element[10]);
				xm.setOrgflag((String) element[9]);
				xm.setParentOrg((String) element[11]);
				xm.setYanyzs( (String) element[2].toString());
				int xitzs=  Integer.parseInt(element[3].toString())+ Integer.parseInt(element[4].toString());
				float xittgl=(float)xitzs*100/ Integer.parseInt(element[2].toString());
				xm.setXittgzs(String.valueOf(xitzs));	
				DecimalFormat df = new DecimalFormat("0.00");
				xm.setXittgl(df.format(xittgl)); 
				//xm.setTonggzs( (String) element[2].toString());
				//xm.setTonggl( (String) element[3].toString());
				if(null != element[3]){xm.setZidtgzs((String) element[3].toString());}
				if(null != element[6]){xm.setZidtgl((String) element[6].toString());}
				if(null != element[4]){xm.setFuztgzs((String) element[4].toString());}
				if(null != element[7]){xm.setFuztgl((String) element[7].toString());}	
				if(null != element[5]){xm.setRengtgzs((String) element[5].toString());}
				if(null != element[8]){xm.setRengtgl((String) element[8].toString());}
			}			
			return xm;	
	}catch(Exception e){
		e.printStackTrace();
		return null;
	}finally{
		this.getBaseHibernateDao().closeSession(session);
	}
	
	
}
	
//=========================
	//���м���
	public List getOrgPassRateByWdf(String beginDate,String endDate,String wdf,String jigh){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		List relist = new ArrayList();		
		try{
			String sql = "";
			String db_type = DBinfoConig.getDBType();
			if("oracle".equals(db_type))
			{
				//oracle
				sql = "SELECT *"
						+" FROM ("
						+"	SELECT b.organname, 'Ʊ' AS leix, nvl(zongs, 0) AS zongs, nvl(zid, 0) AS zid, nvl(fuz, 0) AS fuz, nvl(reng, 0) AS reng, cast(cast(nvl(zid * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS zidtgl, cast(cast(nvl(fuz * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS fuztgl, cast(cast(nvl(reng * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS rengtgl, b.clerkorgcode"
						+"	FROM ("
						+"		SELECT clerkorgcode, count(*) AS zongs, f.organname"
						+"		FROM credencechecklog g, ("
						+"				SELECT wdflag, organnum, organname"
						+"				FROM organarchives"
						+"				WHERE wdflag = '"+wdf+"'"
						+"				) f"
						+"		WHERE yanybs!='DZXT' and f.organnum = clerkorgcode AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"'"
						+"		GROUP BY clerkorgcode, f.organname"
						+"		) b"
						+"	LEFT JOIN ("
						+"		SELECT clerkorgcode, count(*) AS zid"
						+"		FROM credencechecklog"
						+"		WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�Զ�' AND checkresult = 'ͨ��'"
						+"		GROUP BY clerkorgcode"
						+"		) c ON b.clerkorgcode = c.clerkorgcode"
						+"	LEFT JOIN ("
						+"		SELECT clerkorgcode, count(*) AS fuz"
						+"		FROM credencechecklog"
						+"		WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '����' AND checkresult = 'ͨ��'"
						+"		GROUP BY clerkorgcode"
						+"		) d ON b.clerkorgcode = d.clerkorgcode"
						+"	LEFT JOIN ("
						+"		SELECT clerkorgcode, count(*) AS reng"
						+"		FROM credencechecklog c"
						+"		WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�˹�' AND checkresult = 'ͨ��'"
						+"		GROUP BY clerkorgcode"
						+"		) e ON b.clerkorgcode = e.clerkorgcode"
						+"	)"
						+" WHERE clerkorgcode IN ("
						+"		select organnum from organarchives connect by prior organnum=n_parentnum start with organnum='"+jigh+"'"
						+"		)";
			}else{
				//DB2 
				sql = "SELECT *"
						+" FROM ("
						+"	SELECT b.organname, 'Ʊ' AS leix, nvl(zongs, 0) AS zongs, nvl(zid, 0) AS zid, nvl(fuz, 0) AS fuz, nvl(reng, 0) AS reng, cast(cast(nvl(zid * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS zidtgl, cast(cast(nvl(fuz * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS fuztgl, cast(cast(nvl(reng * 100, 0) AS FLOAT) / zongs AS DECIMAL(10, 2)) AS rengtgl, b.clerkorgcode"
						+"	FROM ("
						+"		SELECT clerkorgcode, count(*) AS zongs, f.organname"
						+"		FROM credencechecklog g, ("
						+"				SELECT wdflag, organnum, organname"
						+"				FROM organarchives"
						+"				WHERE wdflag = '"+wdf+"'"
						+"				) f"
						+"		WHERE yanybs!='DZXT' and f.organnum = clerkorgcode AND checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"'"
						+"		GROUP BY clerkorgcode, f.organname"
						+"		) b"
						+"	LEFT JOIN ("
						+"		SELECT clerkorgcode, count(*) AS zid"
						+"		FROM credencechecklog"
						+"		WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�Զ�' AND checkresult = 'ͨ��'"
						+"		GROUP BY clerkorgcode"
						+"		) c ON b.clerkorgcode = c.clerkorgcode"
						+"	LEFT JOIN ("
						+"		SELECT clerkorgcode, count(*) AS fuz"
						+"		FROM credencechecklog"
						+"		WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '����' AND checkresult = 'ͨ��'"
						+"		GROUP BY clerkorgcode"
						+"		) d ON b.clerkorgcode = d.clerkorgcode"
						+"	LEFT JOIN ("
						+"		SELECT clerkorgcode, count(*) AS reng"
						+"		FROM credencechecklog c"
						+"		WHERE yanybs!='DZXT' and checkdate BETWEEN '"+beginDate+"' AND '"+endDate+"' AND checkmode = '�˹�' AND checkresult = 'ͨ��'"
						+"		GROUP BY clerkorgcode"
						+"		) e ON b.clerkorgcode = e.clerkorgcode"
						+"	)"
						+" WHERE clerkorgcode IN ("
						+"		SELECT *"
						+"		FROM TABLE (ORGFUNCTION('"+jigh+"'))"
						+"		)";
			}
			
			SQLQuery query = session.createSQLQuery(sql);					
			List list = query.list();
			List list2 = new ArrayList<Jigtgl>();
			if(list==null){ list=new ArrayList();}
			
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Jigtgl xm=new Jigtgl();
				Object[] element = (Object[]) iter.next();
				xm.setJigmc((String) element[0]);									
				xm.setYanyzs( (String) element[2].toString());
				//xm.setTonggzs( (String) element[2].toString());
				//xm.setTonggl( (String) element[3].toString());
				if(null != element[3]){xm.setZidtgzs((String) element[3].toString());}
				if(null != element[6]){xm.setZidtgl((String) element[6].toString());}
				if(null != element[4]){xm.setFuztgzs((String) element[4].toString());}
				if(null != element[7]){xm.setFuztgl((String) element[7].toString());}	
				if(null != element[5]){xm.setRengtgzs((String) element[5].toString());}
				if(null != element[8]){xm.setRengtgl((String) element[8].toString());}				
				list2.add(xm);
			}
			return list2;	
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}		
	}
}

