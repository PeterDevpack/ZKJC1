package com.unitop.sysmgr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.dao.BaseJDBCDao;

@Repository("BaseJDBCDaoImpl")
public class BaseJDBCDaoImpl implements BaseJDBCDao {
	
	private static ThreadLocal thread = new ThreadLocal();
	
	private DataSource dataSource;
	
	@Resource(name="dataSource")
	public void setJDBCDataSource(DataSource dataSource) throws SQLException{
		 this.dataSource = dataSource;
	}

	public Connection getConnection() {
		if(thread.get() != null)
		{
			return (Connection) thread.get();
		}else{
			Connection c = null ;
			try {
				c = this.dataSource.getConnection();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return c;
		}
	}

	public void set_Connection(Connection conn) {
		try {
			conn.setAutoCommit(false);
			thread.set(conn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void shifConnection() {
		try {
			if(thread.get()!=null)
			{ 
				Connection connection = (Connection) thread.get();
				connection.setAutoCommit(true);
				connection.close();
				connection = null;
				thread.remove();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void closeConnection(Connection connection) {
		if(thread.get()==null)
		{
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void closeConnection(Connection con,PreparedStatement pstmt,ResultSet rs){
		if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		if(pstmt!=null)
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		if(con!=null)
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
}
