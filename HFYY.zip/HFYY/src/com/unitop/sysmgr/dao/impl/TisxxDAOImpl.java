package com.unitop.sysmgr.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.bo.Tisxx;
import com.unitop.sysmgr.dao.TisxxDAO;
@Repository("TisxxDAOImpl")
public class TisxxDAOImpl extends BaseDataResources implements TisxxDAO {

	public void deleteTisxx(String msgId) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Tisxx tisxx = (Tisxx) session.get(Tisxx.class, msgId);
		session.delete(tisxx);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
	}

	public List<Tisxx> findAllTisxx() {
		Session session  = getBaseHibernateDao().getHibernateSession();
		String hql = "from Tisxx t order by t.msgId";
		Query query = session.createQuery(hql);
		List<Tisxx> list = query.list();
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
		return list;
	}

	public Tisxx findTisxx(String msgId) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Tisxx tisxx = (Tisxx) session.get(Tisxx.class, msgId);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
		return tisxx;
	}

	public void insertTisxx(Tisxx tisxx) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		session.save(tisxx);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
	}

	public void updateTisxx(Tisxx tisxx) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		session.saveOrUpdate(tisxx);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
	}
}
