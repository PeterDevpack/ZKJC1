package com.unitop.sysmgr.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.bo.Zhanghb;
import com.unitop.sysmgr.bo.Zhanghxz;
import com.unitop.sysmgr.dao.ZhanghxzDao;
/**
 * �˻�����Daoʵ����
 * @author guodx
 *
 */

@Repository("ZhanghxzDao")
public class ZhanghxzDaoImpl extends BaseDataResources implements ZhanghxzDao {
	/**
	 * ��ѯ��ǰ��¼��Աδ������������Ҫȥ����ǰ��Ա�½����߱��δ��
	 */
	public List<Zhanghb> getUncheckTasks(String jigh,String wdf,String clerkcode){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		List<Zhanghb> list = new ArrayList<Zhanghb>();
		try{
			String sql="";
			//��ѯδ����˺� �� ��Ӧ����������
			
	/*		if("3".equals(wdf)){
				sql = "select y.qiyrq,z.* from "
					  +"(select  distinct zhangh,qiyrq from yinjb  where yinjshzt='δ��' and kaihynum !=:clerkcode group by zhangh,qiyrq) y " 
					  +" left join "
					  +"(select zhangh,hum,jigh,kehh,kaihrq,youwyj,youwzh,yinjshzt,zhanghshzt,zhanghzt,zhanghxz,zhuzh,beiz from zhanghb ) z "
					  +" on y.zhangh=z.zhangh "
					  +" WHERE z.jigh in (select * from TABLE(ORGFUNCTION(:jigh)))";
			}else{			
				sql = "select y.qiyrq,z.* from "
					  +"(select  distinct zhangh,qiyrq from yinjb  where yinjshzt='δ��' and kaihynum !=:clerkcode group by zhangh,qiyrq) y " 
					  +" left join "
					  +"(select zhangh,hum,jigh,kehh,kaihrq,youwyj,youwzh,yinjshzt,zhanghshzt,zhanghzt,zhanghxz,zhuzh,beiz,guiyjgh from zhanghb where ZHANGHZT ='��Ч') z on y.zhangh=z.zhangh WHERE z.guiyjgh =:guiyjgh and z.yinjshzt='δ��'";
	//		}*/
			
			/*
			sql = "select y.qiyrq,z.* from "
					+"(select zhangh,hum,jigh,kehh,kaihrq,youwyj,youwzh,yinjshzt,zhanghshzt,zhanghzt,zhanghxz,zhuzh,beiz from zhanghb "
					+"        where youwyj ='��' and yinjshzt ='δ��' " 
					+"				and jigh in (SELECT organnum FROM organarchives START WITH organnum= :guiyjgh CONNECT BY PRIOR organnum=n_parentnum )" 
					+") z " 
					+" right join (select distinct zhangh,qiyrq  from yinjb where yinjshzt='δ��' and kaihynum !=:clerkcode group by zhangh,qiyrq) y "
					+" on y.zhangh=z.zhangh ";
			*/
			
			sql = "select y.qiyrq,a.* from "
				+" (select distinct zhangh,qiyrq  from yinjb where yinjshzt='δ��' and kaihynum !=:clerkcode group by zhangh,qiyrq) y "
				+" left join zhanghb a on a.zhangh = y.zhangh "
				+" left join organarchives wd on a.jigh = wd.organnum "
				+" left join organarchives fh on wd.n_parentnum = fh.organnum "
				//+" left join organarchives zh on fh.n_parentnum = zh.organnum "
				+" where :guiyjgh in (wd.organnum,fh.organnum ) and a.zhanghzt ='��Ч' and a.yinjshzt='δ��' ";
			
			
			
			
			SQLQuery query = session.createSQLQuery(sql);
			
			query.setResultTransformer(Transformers.aliasToBean(Zhanghb.class));
			query.setString("guiyjgh", jigh);
			query.setString("clerkcode", clerkcode);
			query.addScalar("zhangh", Hibernate.STRING);
			query.addScalar("hum", Hibernate.STRING);
			query.addScalar("jigh", Hibernate.STRING);
			query.addScalar("kehh", Hibernate.STRING);
			query.addScalar("kaihrq", Hibernate.STRING);
			query.addScalar("youwyj", Hibernate.STRING);
			query.addScalar("youwzh", Hibernate.STRING);
			query.addScalar("yinjshzt", Hibernate.STRING);
			query.addScalar("zhanghshzt", Hibernate.STRING);
			query.addScalar("zhanghzt", Hibernate.STRING);
			query.addScalar("zhanghxz", Hibernate.STRING);
			query.addScalar("zhuzh", Hibernate.STRING);
			query.addScalar("beiz", Hibernate.STRING);
			query.addScalar("qiyrq", Hibernate.STRING);
			query.addScalar("guiyjgh", Hibernate.STRING);
			
			query.addScalar("lianxr", Hibernate.STRING);
			query.addScalar("dianh", Hibernate.STRING);
			query.addScalar("diz", Hibernate.STRING);
			query.addScalar("jiesywsqr", Hibernate.STRING);
			query.addScalar("jiesywsqrdh", Hibernate.STRING);
			
			//ZZ181224
			query.addScalar("shefzid", Hibernate.STRING);
			query.addScalar("youzbm", Hibernate.STRING);
			query.addScalar("tongctd", Hibernate.STRING);
	
			list = query.list();
	//		for(Zhanghb zhanghb: list){		
			for(Iterator<Zhanghb> it = list.iterator();it.hasNext();){
				Zhanghb zhanghb = it.next();
				String zhangh = zhanghb.getZhangh();
				String qiyrq = zhanghb.getQiyrq();
				//��ѯδ����˺ŵĽ���Ա���߱��Ա
				sql = "select clerknum from accountmanagelog where account=:zhangh and qiyrq=:qiyrq and managetime= "
					  +"(select max(managetime) from accountmanagelog where account=:zhangh and qiyrq=:qiyrq and (managetype='����' or managetype='���'))";
	
				query = session.createSQLQuery(sql);
				query.setString("zhangh", zhangh);
				query.setString("qiyrq", qiyrq);
				Object result = query.uniqueResult();
				if(clerkcode.equals(String.valueOf(result))){
			//		list.remove(zhanghb);	//�����޸��쳣
					it.remove();
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{			
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}
	
	//��ѯδ��������
   /*public Map<String,String> getcountInfo(String jigh,String wdf){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		Map<String,String>map = new HashMap<String, String>();
		String sql="";
		if("3".equals(wdf)){
			sql="select YINJSHZT,count(*) from zhanghb where jigh in(select * from TABLE(ORGFUNCTION('"+jigh+"'))) group by YINJSHZT";
		}else{			
			sql="select YINJSHZT,count(*) from zhanghb where jigh='"+jigh+"' group by YINJSHZT";
		}
		
		SQLQuery query = session.createSQLQuery(sql);
		List list = query.list();
		for(Object o: list){
			Object[] ob=(Object[])o;
			
				String shenh1=(String)ob[0];
				String shenh2=String.valueOf(ob[1]);
				if("δ��".equals(shenh1)){
					map.put("δ��",shenh2 );
				}
//				if("����".equals(shenh1)){
//					map.put("����",shenh2 );
//				}
//				if("δ��".equals(shenh1)){
//					map.put("δ��", shenh2);
//				}
			}
						
		this.getBaseHibernateDao().closeSession(session);
		return map;
	}*/
	
	/**
	 * �����˻������б�
	 */
	public List<Zhanghxz> getZhanghxzList() {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		Query query = session.createQuery("from Zhanghxz");
		List list = query.list();
		this.getBaseHibernateDao().closeSession(session);
		return list;
	}
	public void insertLink(String zh,String glzh,String hum,String zhjgh,String khh,String kaihrq,String glzhlb){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		Query query = session.createSQLQuery("insert into zhanghb (zhangh,zhuzh,hum,fuyrq,jigh,TONGCTD,youwyj,youwzh,yinjshzt,zhanghshzt,zuhshzt,zhanghzt,zhanghxz,kehh,kaihrq,guiyjgh) values('"+glzh+"','"+zh+"','"+hum+"','"+kaihrq+"','"+zhjgh+"','��','��','��','����','����','����','��Ч','"+glzhlb+"','"+khh+"','"+kaihrq+"','"+zhjgh+"')");
		query.executeUpdate();
		this.getBaseHibernateDao().closeSession(session);
		
	}
	public void updateLink(String zh){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		super.getBaseHibernateDao().set_Session(session);
//		Query query = session.createSQLQuery("update zhanghb set zhuzh = '',ZHANGHZT='����' WHERE zhangh = '"+zh+"'");
		Query query = session.createSQLQuery("INSERT INTO DISABLE_ZHANGHB (ZHANGH, KEHH, HUM, JIGH, DIZ, YOUZBM, LIANXR, DIANH, KAIHRQ, TONGCTD, HUOBH, YOUWYJ, YOUWZH, YINJSHZT, ZHANGHSHZT, ZUHSHZT, ZHANGHZT, ZHANGHXZ, YANYJB, YANYJG, BEIZ, ZHUZH, FUYRQ, QUXFYRQ, JIANKBS, TINGYRQ, GUIYJGH,JIESYWSQR,JIESYWSQRDH,SHEFZID) "
				+ "select * from zhanghb where zhangh ='"+zh+"'");
		query.executeUpdate();
		
		Query query1 = session.createSQLQuery("delete from zhanghb where zhangh ='"+zh+"'");
		query1.executeUpdate();
		
		this.getBaseHibernateDao().shifSession();
		
	}
}
