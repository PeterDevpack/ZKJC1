package com.unitop.sysmgr.dao.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.unitop.config.DBinfoConig;
import com.unitop.config.SystemConfig;
import com.unitop.exception.BusinessException;
import com.unitop.framework.util.PasswordUtil;
import com.unitop.framework.util.StringUtil;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.ClerkPasswordHistory;
import com.unitop.sysmgr.bo.Guiyjsgxb;
import com.unitop.sysmgr.bo.GuiyjsgxbId;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.dao.ClerkDao;
@Repository("ClerkDaoImpl")
public class ClerkDaoImpl  extends BaseDataResources  implements ClerkDao {

	public void saveOrUpdate(Clerk clerk) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			session.saveOrUpdate(clerk);
			session.flush();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	public boolean CanOperDesClerkCode(Clerk OperClerk, String DesClerkCode)
			throws BusinessException {
		return false;
	}

	public void deleteClerk(Clerk clerk) throws BusinessException {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			session.delete(clerk);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	public String[] getClerkIP(String clerkCode) {
		return null;
	}
	
	public Clerk getClerkByCode(String code) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Clerk clerk = null;
		try{
			clerk = (Clerk)session.get(Clerk.class,code);
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return clerk;		
	}

	public List<Clerk> getClerkByOrgcode(String orgcode) {
		Session session = getBaseHibernateDao().getHibernateSession();
		List<Clerk> result = new ArrayList<Clerk>();
		try{
			String sql = "select * from getclerklist where n_organnum = :orgcode";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("orgcode", orgcode);
			List<Clerk> list = query.list();
			String errStr = "0";
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Object[] element = (Object[]) iter.next();
				Clerk clerk = new Clerk();
				clerk.setName((String) element[0]);
				clerk.setCode((String) element[1]);
				clerk.setCreator((String) element[2]);
				clerk.setErrortime(StringUtil.isInteger(element[3]));
				result.add(clerk);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return result;
	}
	/**
	 * 20170705�޸� sun
	 */
	public List<Clerk> getClerkByOrgcode_(String orgcode) {
		Session session = getBaseHibernateDao().getHibernateSession();
		List<Clerk> result = new ArrayList<Clerk>();
		try{
			String sql = "select * from getclerklist where n_organnum = :orgcode";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("orgcode", orgcode);
			List<Clerk> list = query.list();
			String errStr = "0";
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Object[] element = (Object[]) iter.next();
				Clerk clerk = new Clerk();
				clerk.setName((String) element[0]);
				clerk.setCode((String) element[1]);
				clerk.setCreator((String) element[2]);
				clerk.setErrortime(StringUtil.isInteger(element[3]));
				clerk.setOrgcode((String)element[4]);
				result.add(clerk);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return result;
	}

	/**
	 * @see com.unitop.sysmgr.dao.ClerkDao#exportClerk(java.lang.String)
	 */
	public List exportClerk(String orgcode) {
		Session session = getBaseHibernateDao().getHibernateSession();
		List<Clerk> list1 = new ArrayList<Clerk>();
		try{
			String sql = "select c.clerknum,c.clerkname,c.clerkpwd,c.postnum,c.n_updatedate,c.n_organnum,c.n_logdate,c.n_creator,o.ORGANNAME,wdflag " +
				"from clerktable c,(select ORGANNAME,ORGANNUM from ORGANARCHIVES)o where o.ORGANNUM=n_organnum and n_organnum= :orgcode";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("orgcode", orgcode);
			List list = query.list();
			if(list==null) list=new ArrayList();
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Object[] element = (Object[]) iter.next();
				Clerk clerk = new Clerk();
				clerk.setCode((String) element[0]);
				clerk.setName((String) element[1]);
				clerk.setPassword((String) element[2]);
				clerk.setPostCode((String) element[3]);
				clerk.setUpdateDate(String.valueOf(element[4]));
				clerk.setOrgcode((String) element[5]);
				clerk.setLogDate((String) element[6]);
				clerk.setCreator((String) element[7]);
				clerk.setOrgname((String) element[8]);
				clerk.setWdFlag((String) element[9]);
				list1.add(clerk);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			super.getBaseHibernateDao().closeSession(session);
		}
		return list1;
	}

	/**
	 * @see com.unitop.sysmgr.dao.ClerkDao#importClerk(java.lang.String)
	 */
	public boolean importClerk(Clerk clerk) throws Exception {
		Session session = getBaseHibernateDao().getHibernateSession();
		Date currentTime =new Date();
		SimpleDateFormat sf= new SimpleDateFormat("yyyy-MM-dd");
		String date = sf.format(currentTime);
		String password=SystemConfig.getInstance().getValue("adminPassword");
		boolean rs = false;
		try{
			String sql = "insert into clerktable(clerknum,clerkname,clerkpwd,postnum,n_organnum,n_creator,shenghjgh,wdflag,N_UPDATEDATE) "+ 
						 "values(:clerknum,:clerkname,:clerkpwd,:postnum,:organnum,:creator,:shenghjgh,:wdflag,:date)";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("clerknum", clerk.getCode());
			query.setString("clerkname", clerk.getName());
			
			query.setString("clerkpwd",PasswordUtil.encodePwd(password));
			query.setString("postnum", "");
			query.setString("organnum", clerk.getOrgcode());
			query.setString("creator", clerk.getCreator());
			query.setString("date",date);
			query.setString("shenghjgh", clerk.getShOrgCode());
			query.setString("wdflag", clerk.getWdFlag());
			query.executeUpdate();
			rs=true;
			//ά����Ա��ɫ��ϵ����
			String juesStirng = clerk.getPostCode();
			String[] juesStirngs = juesStirng.split(",");
			String[] _juesStirngs = new String[juesStirngs.length];
			for(int i =0 ;i<juesStirngs.length;i++)
			{
				_juesStirngs[i]= StringUtil.substringBetween(juesStirngs[i], "[", ":");
			}
			this.updateClerkRoles(clerk.getCode(),_juesStirngs,"");
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			super.getBaseHibernateDao().closeSession(session);
		}
		return rs;
	}
	/**
	 * ��������ר��	��ָ��������Ŀ¼�����������ڡ���Ա������Ŀ¼�����򡿹���
	 * @param _orgList
	 * @param rootOrgNum
	 * @param orgList
	 * @return
	 */
	private List<Org> sortOrg(List<Org> _orgList,String rootOrgNum,List<Org> orgList){
		for(Org org:_orgList){
			if(rootOrgNum.equals(org.getParentCode())){
				orgList.add(org);
				sortOrg(_orgList,org.getCode(),orgList);
			}
		}
		return orgList;
	}
	
	/**
	 * ��������ר�ã���Ա����ʱ���ݻ�����˳������
	 * @param orgcode
	 * @return
	 */
	public List<Clerk> getAllClerkByOrgcodeForJZ(String orgcode) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List<Clerk> clerkList = new ArrayList<Clerk>();
		String db_type = DBinfoConig.getDBType();
		String sql1="";
		if("oracle".equals(db_type))
		{
			//oracle�Ȳ��ָ�������������¼�����
			sql1 = "select ORGANNUM as code,ORGANNAME as name,N_PARENTNUM as parentCode,N_PAYMENTNUM as paymentCode,WDFLAG as wdflag,SHENGHJGH as shOrgCode,TONGDGZ as tctd,GUANLJG as guanljg,ZHISZH as zhiszh "
					+ " from ORGANARCHIVES where organnum in (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:organnum)";
		}else{
			//db2�Ȳ��ָ�������������¼�����
			sql1 = "select ORGANNUM as code,ORGANNAME as name,N_PARENTNUM as parentCode,N_PAYMENTNUM as paymentCode,WDFLAG as wdflag,SHENGHJGH as shOrgCode,TONGDGZ as tctd,GUANLJG as guanljg,ZHISZH as zhiszh "
					+ " from ORGANARCHIVES where organnum in (select * from TABLE(ORGFUNCTION(:organnum)))";
		}
		
		SQLQuery query = session.createSQLQuery(sql1);
		query.setResultTransformer(Transformers.aliasToBean(Org.class));
		query.setString("organnum", orgcode);
		query.addScalar("code", Hibernate.STRING);
		query.addScalar("name", Hibernate.STRING);
		query.addScalar("parentCode", Hibernate.STRING);
		query.addScalar("paymentCode", Hibernate.STRING);
		query.addScalar("wdflag", Hibernate.STRING);
		query.addScalar("shOrgCode", Hibernate.STRING);
		query.addScalar("tctd", Hibernate.STRING);
		query.addScalar("guanljg", Hibernate.STRING);
		query.addScalar("zhiszh", Hibernate.STRING);
		List<Org> _orgList = query.list();
		//����������
		List<Org> orgList = new ArrayList<Org>();	//�����Ļ�������
		for(Org org:_orgList){						//���Ӹ�����
			if(orgcode.equals(org.getCode())){
				orgList.add(org);
			}
		}
		sortOrg(_orgList,orgcode,orgList);
		//��ȡ���еĹ�Ա
		String sql2 = "select clerknum as code,clerkname as name,clerkpwd as password,postnum as postCode,n_updatedate as updateDate,n_organnum as orgcode,n_logdate as logDate,n_creator as creator from clerktable " ;
		query = session.createSQLQuery(sql2);
		query.setResultTransformer(Transformers.aliasToBean(Clerk.class));
		query.addScalar("code", Hibernate.STRING);
		query.addScalar("name", Hibernate.STRING);
		query.addScalar("password", Hibernate.STRING);
		query.addScalar("postCode", Hibernate.STRING);
		query.addScalar("updateDate", Hibernate.STRING);
		query.addScalar("orgcode", Hibernate.STRING);
		query.addScalar("logDate", Hibernate.STRING);
		query.addScalar("creator", Hibernate.STRING);
		List<Clerk> list = query.list();
		//���ݻ���˳�����Ա����
		for(Org org:orgList){
			for(Clerk clerk:list){
				if((org.getCode()).equals(clerk.getOrgcode())){
					clerk.setOrgname(org.getName());
					clerkList.add(clerk);
				}
			}
		}
		
		this.getBaseHibernateDao().closeSession(session);
		return clerkList;	
	}

	
	/* (non-Javadoc)
	 * @see com.unitop.sysmgr.dao.ClerkDao#getAllClerkByOrgcode(java.lang.String)
	 */
	public List<Clerk> getAllClerkByOrgcode(String orgcode) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List<Clerk> list1 = new ArrayList<Clerk>();
		String sql = "";
		String db_type = DBinfoConig.getDBType();
		if("oracle".equals(db_type))
		{
//			sql="select clerknum,clerkname,clerkpwd,postnum,n_updatedate,n_organnum,n_logdate,n_creator,shenghjgh,wdflag from clerktable " +
//				" where n_organnum in (select organnum from organarchives connect by " +
//				" prior organnum=n_parentnum start with organnum= :organnum)";
			sql="select clerknum,clerkname,clerkpwd,postnum,n_updatedate,n_organnum,n_logdate,n_creator,o.ORGANNAME,wdflag from clerktable " +
					", (select ORGANNAME,ORGANNUM from ORGANARCHIVES)o where n_organnum in (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:organnum) and o.ORGANNUM=n_organnum";
		}else{
			sql="select clerknum,clerkname,clerkpwd,postnum,n_updatedate,n_organnum,n_logdate,n_creator,o.ORGANNAME,wdflag from clerktable " +
		", (select ORGANNAME,ORGANNUM from ORGANARCHIVES)o where n_organnum in (select * from TABLE(ORGFUNCTION(:organnum))) and o.ORGANNUM=n_organnum";
		}
		try{
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("organnum", orgcode);
			List list = query.list();
			if(list==null)  list=new ArrayList();
		for (Iterator iter = list.iterator(); iter.hasNext();){
			 Clerk clerk=new Clerk();
			 Object[] element = (Object[])iter.next();
			 clerk.setCode((String)element[0]);
			 clerk.setName((String)element[1]);
//			 clerk.setPassword((String)element[2]);
			 clerk.setPostCode((String)element[3]);
			 clerk.setUpdateDate(String.valueOf(element[4]));
			 clerk.setOrgcode((String)element[5]);
			 clerk.setLoginDate((String)element[6]);
			 clerk.setCreator((String)element[7]);
			 clerk.setOrgname((String)element[8]);
			 clerk.setWdFlag((String)element[9]);		 
			 list1.add(clerk);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list1;	
	}
	
	public Clerk getClerkCountByIp(String ip) {
		List list = null;
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			Query query = session.createQuery("select c.code,c.name from Clerk c where c.ip=?");
			query.setString(0, ip);
			list = query.list();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
		if(list!=null&&list.size()!=0)
		{
			Object[] o  =  (Object[]) list.get(list.size()-1);
			Clerk clerk = new Clerk();
			clerk.setCode((String) o[0]);
			clerk.setName((String) o[1]);
			return clerk;
		}else{
			return null;
		}
	}
	public void setErrorNum(String clerkNum,String errorNum) throws Exception{
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			Query query = session.createQuery("update Clerk c set c.errortime =:errortime where code = :code");
			query.setInteger("errortime",Integer.parseInt(errorNum));
			query.setString("code", clerkNum);
			query.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	
	public void updateClerkRoles(String guiyid,String[] jues,String beiz) throws Exception{
		Session session = super.getBaseHibernateDao().getHibernateSession();
		SQLQuery query = null;
		try {
			String deletesql = "delete from guiyjsgxb where guiyid = '"+guiyid+"'";
			query = session.createSQLQuery(deletesql);
			query.executeUpdate();
			
			for(int i=0;i<jues.length;i++)
			{
				String insertsql = "insert into guiyjsgxb values('"+guiyid+"','"+jues[i]+"','"+beiz+"')";	
				query = session.createSQLQuery(insertsql);
				query.executeUpdate();
			}
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	
	//ɾ����Ա��ɫ��ϵ����Ӧ��ɫ����
	public void deleteGuiyjsgxb(String guiyid) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try {
			String queryString = "delete Guiyjsgxb where id.guiyid=:guiyid";//ע�⣺id.guiyid=:guiyid�ĵȺź���һ�������ǡ�id.guiyid��
		    Query query = session.createQuery(queryString);
			query.setString("guiyid", guiyid);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	
	//��ѯ��Ա��ɫ��ϵ����Ӧ��ɫ����
	public List selectGuiyjsgxb(String juesid) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List list = null;
		try {
			Query query = session.createQuery("from  Guiyjsgxb where id.juesid=:juesid");
			query.setString("juesid", juesid);
			list = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}
	
	//�����Ա��ɫ��ϵ����Ӧ��ɫ����
	public void saveClerkRoles(String guiyid, String[] jues) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			for(int i=0;i<jues.length;i++)
			{
				Guiyjsgxb guiyjsgxb = new Guiyjsgxb();
				guiyjsgxb.setId(new GuiyjsgxbId());
				guiyjsgxb.getId().setGuiyid(guiyid);
				guiyjsgxb.getId().setJuesid(jues[i]);
				session.save(guiyjsgxb);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	public long getClerkCounts() {
		long clerk_counts = 0;
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			String hql="select count(*) as count from Clerk"; 
			Query query=session.createQuery(hql); 
			clerk_counts=((Number)query.iterate().next()).intValue(); 
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return clerk_counts;
	}
	/**
	 * ����ר��  ȥ���޸����벻������������벻����ͬ������
	 */
	public void changePassword(Clerk clerk, String password) throws BusinessException {
		Date rightNow = Calendar.getInstance().getTime();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String date = format.format(rightNow);
		
		clerk.setUpdateDate(date);
		clerk.setPassword(PasswordUtil.encodePwd(password));
		super.getBaseHibernateDao().getDaoHibernateTemplate().saveOrUpdate(clerk);
		clerk.setPassword(password);
	}
	//�޸Ĺ�Ա����
	public void changePassword1(Clerk clerk, String password) throws BusinessException {
		SystemConfig systemConfig = SystemConfig.getInstance();
		List list = super.getBaseHibernateDao().getDaoHibernateTemplate().find( "from ClerkPasswordHistory c where c.clerkCode = ? order by c.updateDate",new Object[] { clerk.getCode() });
		for (int i = 0; i < list.size(); i++)
		{
			ClerkPasswordHistory element = (ClerkPasswordHistory) list.get(i);
			if (password.equals(PasswordUtil.decodePwd(element.getPassword())))
			{
				throw new BusinessException("�������" + systemConfig.getValue("updatepasswordtimes") + "���ѱ�ʹ��");
			}
		}
		try {
			Date rightNow = Calendar.getInstance().getTime();
			SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");
			String date1 = format1.format(rightNow);
			String date2 = format2.format(rightNow);
			if (list.size() < Integer.valueOf(systemConfig.getValue("updatepasswordtimes"))) 
			{
				ClerkPasswordHistory history = new ClerkPasswordHistory();
				history.setClerkCode(clerk.getCode());
				history.setPassword(PasswordUtil.encodePwd(clerk.getPassword()));
				history.setUpdateDate(date1);
				super.getBaseHibernateDao().getDaoHibernateTemplate().save(history);
			} else {
				ClerkPasswordHistory history = (ClerkPasswordHistory) list.get(0);
				history.setClerkCode(clerk.getCode());
				history.setPassword(PasswordUtil.encodePwd(clerk.getPassword()));
				history.setUpdateDate(date1);
				super.getBaseHibernateDao().getDaoHibernateTemplate().update(history);
			}
			clerk.setUpdateDate(date2);
			clerk.setPassword(PasswordUtil.encodePwd(password));
			super.getBaseHibernateDao().getDaoHibernateTemplate().saveOrUpdate(clerk);
			clerk.setPassword(password);
		} catch (Exception e) {
			throw new BusinessException("�����޸�ʧ�ܣ�");
		}
//		throw new BusinessException("�����޸ĳɹ���");
	}
	//��ѯ��Ա��Ӧ��ɫ��Ϣ
	public List getRoleByClerk(String clerknum) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List list = null;
		try {
			Query query = session.createQuery("from Role where juesid in (select id.juesid from Guiyjsgxb where id.guiyid=:guiyid)");
			query.setString("guiyid", clerknum);
			list = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}
	/**
	 * ���ݹ�Ա��ѯ�����ڸù�Ա������ɫ
	 */
	public List getElseRoleByClerk(String clerknum,String juesjb) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List list = null;
		try {
			Query query = session.createQuery("from Role where juesjb<=:juesjb and juesid not in (select id.juesid from Guiyjsgxb where id.guiyid=:guiyid)");
			query.setString("guiyid", clerknum);
			query.setString("juesjb", juesjb);
			list = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}
	
	/**
	 * ɾ�����й�Ա��Ϣ
	 */
	public void deleteAllClerk(){
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try {
			SQLQuery query = session.createSQLQuery("delete from clerktable");
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
		
	}
	
	/**
	 * ���ӹ�Ա��ɫ��ϵ
	 * @param guiyjsgxb
	 * @throws Exception
	 */
	public void addClerkRoles(Guiyjsgxb guiyjsgxb) throws Exception{
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try {
			session.saveOrUpdate(guiyjsgxb);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
	}
	public void updateOrg(String newOrg,String oldOrg){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try {
			String sql = "update CLERKTABLE set N_ORGANNUM=:newOrg where N_ORGANNUM=:oldOrg";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("newOrg", newOrg);
			query.setString("oldOrg", oldOrg);
			
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	//	����ר��
	public void updateOrg1(String newOrg,String oldOrg,String wdfalg) throws Exception{
		Session session =  super.getBaseHibernateDao().getHibernateSession();		
			String sql = "update CLERKTABLE set N_ORGANNUM=:newOrg, WDFLAG=:wdflag where N_ORGANNUM=:oldOrg";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("newOrg", newOrg);
			query.setString("oldOrg", oldOrg);
			query.setString("wdflag", wdfalg);
			query.executeUpdate();
			this.getBaseHibernateDao().closeSession(session);
	}
}
