package com.unitop.sysmgr.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.bo.Yewgz;
import com.unitop.sysmgr.dao.YewgzDAO;
@Repository("YewgzDAOImpl")
public class YewgzDAOImpl extends BaseDataResources implements YewgzDAO{

	public List<Yewgz> findAllYewgz() {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Query query = session.createQuery("from Yewgz order by yuansname");
		List<Yewgz> list = query.list();
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
		return list;
	}
	
	public void deleteYewgz(String yuansid) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Yewgz yewgz = (Yewgz) session.get(Yewgz.class, yuansid);
		session.delete(yewgz);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
	}

	public void insertYewgz(Yewgz yewgz) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		session.save(yewgz);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
		
	}

	public void updateYewgz(Yewgz yewgz) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		session.saveOrUpdate(yewgz);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
	}

	public Yewgz findYewgz(String yuansid) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		Yewgz yewgz = (Yewgz) session.get(Yewgz.class, yuansid);
		session.flush();
		this.getBaseHibernateDao().closeSession(session);
		return yewgz;
	}

}
