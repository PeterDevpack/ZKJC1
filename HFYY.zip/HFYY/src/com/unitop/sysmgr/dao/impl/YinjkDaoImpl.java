package com.unitop.sysmgr.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.bo.KagRenw;
import com.unitop.sysmgr.bo.Yinjk;
import com.unitop.sysmgr.bo.YinjkId;
import com.unitop.sysmgr.dao.YinjkDao;
import com.unitop.sysmgr.form.YinjkForm;

@Repository("YinjkDaoImpl")
public class YinjkDaoImpl extends BaseDataResources implements YinjkDao {

	public List<Yinjk> getYinjk(YinjkForm yinjkForm) {
		Session session = this.getBaseHibernateDao().getHibernateSession();
		String hql = "select zhangh,jigh,kagid,ceng,choutwz,case yewlx when '0' then '����' else '��ʷ' end as yewlx,shifzk,qiyrq from yinjk where kagid<>'' and";
		String zhangh = yinjkForm.getZhangh();
		String yewlx = yinjkForm.getYewlx();
		String jigh = yinjkForm.getJigh();
		String hqlwhere = "";
		if (zhangh != null && !"".equals(zhangh)) {
			hqlwhere += " zhangh='" + zhangh + "' and";
		}
		if (yewlx != null && !"".equals(yewlx)) {
			hqlwhere += " yewlx='" + yewlx + "' and";
		}
		if (jigh != null && !"".equals(jigh)) {
			hqlwhere += " jigh='" + jigh + "' and";
		}
		hql+=hqlwhere;
		hql = hql.substring(0, hql.length() - 3);
		hql+=" group by (zhangh,jigh,kagid,ceng,choutwz,yewlx,shifzk,qiyrq)";
		System.out.println(hql);
		List<Yinjk> yinjklist=new ArrayList<Yinjk>();
		try {
			Query query = session.createSQLQuery(hql);
			List list = query.list();
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Yinjk yinjk = new Yinjk();
			    Object[] element = (Object[])iter.next();
			    YinjkId yinjkid = new YinjkId();
			    yinjkid.setZhangh((String) element[0]);
			    yinjk.setYinjkid(yinjkid);
			    yinjk.setJigh((String) element[1]);
			    yinjk.setKagid((String) element[2]);
			    yinjk.setCeng(element[3].toString());
			    yinjk.setChoutwz(element[4].toString());
			    yinjk.setYewlx((String) element[5]);
			    yinjk.setShifzk(element[6].toString());
			    yinjk.getYinjkid().setQiyrq(element[7].toString());
			    yinjklist.add(yinjk);
			}
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return yinjklist;
	}

	public Yinjk getYinjkByZhangh(String zhangh,String yinjkh) {
		Session session = this.getBaseHibernateDao().getHibernateSession();
		Yinjk yinjk = null;
		try {
			Query query = session.createQuery("from Yinjk where zhangh=:zhangh and yinjkh=:yinjkh ");
			query.setString("zhangh", zhangh);
			query.setString("yinjkh", yinjkh);
			yinjk = (Yinjk) query.uniqueResult();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return yinjk;
	}
	
	//ӡ������ѯ
	public List<Yinjk> getYinjkByZhangh(String zhangh) {
		Session session = this.getBaseHibernateDao().getHibernateSession();
		List<Yinjk> list=new ArrayList<Yinjk>();
		try {
			//����ӡ������ѯ
			//Query query = session.createQuery("from Yinjk where zhangh=:zhangh and yewlx='0'");
			Query query = session.createQuery("from Yinjk where zhangh=:zhangh");
			query.setString("zhangh", zhangh);
			list=query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}
	
	//�����������ڻ�ȡӡ������Ϣ
	public List<Yinjk> getYinjkByQiyrq(String zhangh,String qiyrq) {
		Session session = this.getBaseHibernateDao().getHibernateSession();
		List<Yinjk> list=new ArrayList<Yinjk>();
		try {
			Query query = session.createQuery("from Yinjk where zhangh=:zhangh and qiyrq=:qiyrq ");
			query.setString("zhangh", zhangh);
			query.setString("qiyrq", qiyrq);
			list = query.list();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list;
	}

	public void updateShifzk(String yinjkUpdateSql) {
		Session session = this.getBaseHibernateDao().getHibernateSession();
		try {
			SQLQuery sqlQuery = session.createSQLQuery(yinjkUpdateSql);
			sqlQuery.executeUpdate();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}

	//����ӡ������Ϣ
	public void saveyinjk(Yinjk yinjk) {
		Session session = this.getBaseHibernateDao().getHibernateSession();
		try {
			session.saveOrUpdate(yinjk);
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
			throw new HibernateException("����ӡ������Ϣʧ�ܣ�");
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
	}

	//��ȡӡ������
	public KagRenw getYinjkh(String renwbs) 
	{
		Session session = super.getBaseHibernateDao().getHibernateSession();
		String hql = "from KagRenw where renwbs =:renwbs ";
		KagRenw kagRenw = null;
		try {
			Query query = session.createQuery(hql);
			query.setString("renwbs", renwbs);
			kagRenw  = (KagRenw) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
			throw new HibernateException("��ȡӡ������ʧ�ܣ�");
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return kagRenw;
	}

	//��ȡӡ������Ϣ
	public Yinjk getYinjk(String zhangh, String yinjkh, String qiyrq) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		String hql = "from Yinjk where zhangh =:zhangh and yinjkh =:yinjkh and qiyrq=:qiyrq";
		Yinjk yinjk = null;
		try {
			Query query = session.createQuery(hql);
			query.setString("zhangh", zhangh);
			query.setString("yinjkh", yinjkh);
			query.setString("qiyrq", qiyrq);
			yinjk  = (Yinjk) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
			throw new HibernateException("��ȡӡ������Ϣʧ�ܣ�");
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return yinjk;
	}
	
	//ɾ��ӡ����
	public void deleteYinjk(String zhangh, String yinjkh, String qiyrq) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		String hql = "delete Yinjk where yinjkid.zhangh =:zhangh and yinjkid.yinjkh =:yinjkh and yinjkid.qiyrq=:qiyrq";
		try {
			Query query = session.createQuery(hql);
			query.setString("zhangh", zhangh);
			query.setString("yinjkh", yinjkh);
			query.setString("qiyrq", qiyrq);
			query.executeUpdate();
		} catch (HibernateException e) {
			e.printStackTrace();
			throw new HibernateException("ɾ��ӡ����ʧ�ܣ�");
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	
	//ɾ���˻��µ�ӡ����
	public void deleteYinjk(String zhangh) {
		Session session = super.getBaseHibernateDao().getHibernateSession();
		String hql = "delete Yinjk where yinjkid.zhangh =:zhangh";
		try {
			Query query = session.createQuery(hql);
			query.setString("zhangh", zhangh);
			query.executeUpdate();
		} catch (HibernateException e) {
			e.printStackTrace();
			throw new HibernateException("ɾ���˻��µ�ӡ����ʧ�ܣ�");
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
	}

}