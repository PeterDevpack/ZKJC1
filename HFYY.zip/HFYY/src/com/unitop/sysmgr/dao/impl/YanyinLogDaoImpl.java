package com.unitop.sysmgr.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.sysmgr.dao.YanyinLogDao;
@Repository("YanyinLogDaoImpl")
public class YanyinLogDaoImpl extends BaseDataResources  implements YanyinLogDao {
	
	//������Ʊ Ʊ�ݺű���
	public int validateZhengppjh(String piaojh) {
		int totalRows = 0;
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			String hql = "select count(id.account) from Zhengprz where checknum=:piaojh";
			Query query = session.createQuery(hql);
			query.setString("piaojh", piaojh);
			List rList = query.list();
			totalRows = Integer.valueOf(rList.get(0).toString());
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return totalRows;
	}

	//���ص���  Ʊ�ݺű���
	public int validateDanzppjh(String piaojh) {
		int totalRows = 0;
		Session session = super.getBaseHibernateDao().getHibernateSession();
		try{
			String hql = "select count(account) from Danzrz where checknum=:piaojh";
			Query query = session.createQuery(hql);
			query.setString("piaojh", piaojh);
			List rList = query.list();
			totalRows = Integer.valueOf(rList.get(0).toString());
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return totalRows;
	}
	

	
}