package com.unitop.sysmgr.dao.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.unitop.config.DBinfoConig;
import com.unitop.sysmgr.bo.ScData;
import com.unitop.sysmgr.bo.Yinjb;
import com.unitop.sysmgr.bo.Zhanghb;
import com.unitop.sysmgr.dao.ZhanghbDao;

@Repository("ZhanghbDaoImpl")
public class ZhanghbDaoImpl  extends BaseDataResources implements ZhanghbDao {
	//������������
	public ScData getZhanghInfoFromSC(String zhangh){
		Session session =  super.getBaseHibernateDao().getHibernateSession();		
		ScData scdata;
		try {
			SQLQuery query = session.createSQLQuery("select zhangh,hum from PLHEXZHB a where a.zhangh='"+zhangh+"'");
			scdata = new ScData();
			List list=query.list();
			for (Iterator iter = list.iterator(); iter.hasNext();) 
			{	
				Object[] element = (Object[])iter.next();
				//ת���˻�����
				//String zhanghxz="����";
			  /*if("1".equals(zhanghxz)){ zhanghxz="������";}
				if("2".equals(zhanghxz)){ zhanghxz="һ�㻧";}
				if("3".equals(zhanghxz)){ zhanghxz="��ʱ��";}
				if("4".equals(zhanghxz)){ zhanghxz="ר�û�";}
				if("7".equals(zhanghxz)){ zhanghxz="����";}*/
				
				//SQLQuery s_keh = session.createSQLQuery("select KEHMC from S_KEHB where kehh='"+(String)element[1]+"'");				
				//String kehmc=(String)s_keh.uniqueResult();
				//if("".equals(kehmc)||kehmc==null){
				//	scdata.setHum((String)element[1]);
			//	}else{scdata.setHum(kehmc);}				 
				 scdata.setZhangh((String)element[0]);
				 scdata.setHum((String)element[1]);
				 scdata.setKehh((String)element[0]);
				// String hang=String.format("%02d",Integer.valueOf((String) element[2]));
				// String bumh=String.format("%03d",Integer.valueOf((String) element[3]));
				 
				 scdata.setZhanghxz("һ�㻧");
				 
			}
			return scdata;
		} catch (HibernateException e) {
			session.close();
			e.printStackTrace();
			return null;
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		
	
	}
	//�����ʺ���Ϣ
	public Zhanghb getZhanghb(String zhangh) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		Zhanghb Zhanghb =(Zhanghb)  session.get(Zhanghb.class, zhangh);
		this.getBaseHibernateDao().closeSession(session);
		return Zhanghb;
	}
	
	//�����ʺ���Ϣ
	public void updateZhanghb(Zhanghb zhangh) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		session.saveOrUpdate(zhangh);
		this.getBaseHibernateDao().closeSession(session);
//		super.getBaseHibernateDao().getDaoHibernateTemplate().saveOrUpdate(zhangh);
	}
	
	//ɾ���ʺ�
	public void deleteZhanghb(Zhanghb zhangh) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		session.delete(zhangh);
		this.getBaseHibernateDao().closeSession(session);
//		super.getBaseHibernateDao().getDaoHibernateTemplate().delete(zhangh);
	}

	public List getKehh(String keh,String jigh){
		Session session = super.getBaseHibernateDao().getHibernateSession();
		List<Zhanghb> list1 = new ArrayList<Zhanghb>();
		String sql = "";
		String db_type = DBinfoConig.getDBType();

			
			if(keh==null||"".equals(keh)){
				if("oracle".equals(db_type))
				{
					//oracle
					 sql = "select * from zhanghb where jigh in (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:jigh)";
				}else{
					//DB2 
					sql = "select * from zhanghb where jigh in (select * from TABLE(ORGFUNCTION(:jigh)))";
				}
			}else{
				if("oracle".equals(db_type))
				{
					//oracle
					 sql = "select * from zhanghb where kehh= :keh and jigh in (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:jigh)";
				}else{
					//DB2 
					sql = "select * from zhanghb where kehh= :keh and jigh in (select * from TABLE(ORGFUNCTION(:jigh)))";
				}
			}
		try{
			SQLQuery query = session.createSQLQuery(sql);
			if(!(keh==null||"".equals(keh))){
				query.setString("keh", keh);
			}			
			query.setString("jigh", jigh);
			List list = query.list();
			if(list==null)  list=new ArrayList();
			Zhanghb zhanghb=new Zhanghb();
		for (Iterator iter = list.iterator(); iter.hasNext();) 
		{
			 Object[] element = (Object[])iter.next();
			 zhanghb.setZhangh((String)element[0]);
			 zhanghb.setKehh((String)element[1]);
			 zhanghb.setJigh((String)element[3]);
			 zhanghb.setHum((String)element[2]);
			 zhanghb.setKaihrq((String)element[8]);
			 zhanghb.setTongctd((String)element[9]);
			 zhanghb.setHuobh((String)element[10]);
			 zhanghb.setYouwyj((String)element[11]);
			 zhanghb.setYouwzh((String)element[12]);
			 zhanghb.setYinjshzt((String)element[13]);
			 zhanghb.setZhanghshzt((String)element[14]);
			 zhanghb.setZuhshzt((String)element[15]);
			 zhanghb.setZhanghzt((String)element[16]);
			 zhanghb.setZhanghxz((String)element[17]);
			 zhanghb.setYinjkbh((String)element[18]);
			 zhanghb.setZhuzh((String)element[21]);
			 zhanghb.setFuyrq((String)element[22]);
			 zhanghb.setJiankbs((String)element[24]);
			 zhanghb.setTingyrq((String)element[25]);
			 
			 list1.add(zhanghb);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return list1;
	}
	
	//�����ʺ�ͨ��ͨ�� ��ϵ
	public void updateForAccount(String orgCode, String tctd) {
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try {
			String sql = "update zhanghb set tongctd=:tctd where jigh in (select organnum from organarchives where shenghjgh=:shenghjgh)";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("tctd", tctd);
			query.setString("shenghjgh", orgCode);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	public void updateOrg(String newOrg,String oldOrg){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try {
			String sql = "update zhanghb set jigh=:newOrg where jigh=:oldOrg";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("newOrg", newOrg);
			query.setString("oldOrg", oldOrg);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	
	//�˻�Ǩ�Ƹ����˻����·���
	public void updateOrgAndGuiYJGH(String newOrg,String oldOrg){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try {
			String sql = "update zhanghb set jigh=:newOrg ,guiyjgh=:newOrg where jigh=:oldOrg";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("newOrg", newOrg);
			query.setString("oldOrg", oldOrg);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
		}
	}
	public void updateRizb(String newOrg,String oldOrg){
		Session session =  super.getBaseHibernateDao().getHibernateSession();
		try {
			String sql = "update CREDENCECHECKLOG set CLERKORGCODE=:newOrg where CLERKORGCODE=:oldOrg";
			SQLQuery query = session.createSQLQuery(sql);
			query.setString("newOrg", newOrg);
			query.setString("oldOrg", oldOrg);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.getBaseHibernateDao().closeSession(session);
	}
}
	//��ȡ��ǰ����ʹ�õ�ӡ����Ϣ
	public Yinjb getYinjb(String zhangh){
		Session session = super.getBaseHibernateDao().getHibernateSession();
		String sql = "";
//			sql="select qiyrq,tingyrq,yinjshzt from yinjb where zhangh='"+zhangh+"' and qiyrq<=to_char(sysdate, 'YYYY-MM-DD')  and (case when tingyrq=''or tingyrq is null then '2999-12-01' else tingyrq end)>to_char(sysdate, 'YYYY-MM-DD')";
			sql="select distinct qiyrq,tingyrq,yinjshzt from yinjb where qiyrq=(select max(qiyrq) from yinjb where zhangh='"+zhangh+"') and zhangh='"+zhangh+"' ";
			Yinjb yinjb=new Yinjb();
		try{
			SQLQuery query = session.createSQLQuery(sql);					
			List list=query.list();			
		for (Iterator iter = list.iterator(); iter.hasNext();){
			 Object[] element = (Object[])iter.next();
			 yinjb.setYinjshzt((String) element[2]);			 
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			this.getBaseHibernateDao().closeSession(session);
		}
		return yinjb;
	}
}
