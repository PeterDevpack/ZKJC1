package com.unitop.sysmgr.dao;

import com.unitop.sysmgr.bo.Usermanage;
import com.unitop.sysmgr.bo.Yinjcyrzb;

public interface LogDao {
	
	//yonghwhb ������
	public void addyonghwhb(Usermanage usermanage); 
	//yinjrz  ������
	public void insertyinjrz(Yinjcyrzb yin);

}
