package com.unitop.sysmgr.dao;

import java.util.List;

import com.unitop.sysmgr.bo.ScData;
import com.unitop.sysmgr.bo.Yinjb;
import com.unitop.sysmgr.bo.Zhanghb;

/*
 * �ʺű�����
 */
public interface ZhanghbDao   extends BaseDataResourcesInterface{
	public ScData getZhanghInfoFromSC(String zhangh);
	public Yinjb getYinjb(String zhang);
	public Zhanghb getZhanghb(String zhangh);
	public void updateZhanghb(Zhanghb zhangh);
	public void deleteZhanghb(Zhanghb zhangh);
	public List getKehh(String keh,String jigh);
	public void updateForAccount(String orgCode, String tctd);
	public void updateOrg(String newOrg,String oldOrg);
	
	public void updateRizb(String newOrg,String oldOrg);
	public void updateOrgAndGuiYJGH(String newOrg,String oldOrg);
}
