package com.unitop.sysmgr.dao;

import java.util.List;

public interface XitlxgxDao extends BaseDataResourcesInterface{
	
	public List getXitlxgxList(String jigh,String pingzh);//��ȡƾ֤ϵͳ��ϵ�ӿ�

}
