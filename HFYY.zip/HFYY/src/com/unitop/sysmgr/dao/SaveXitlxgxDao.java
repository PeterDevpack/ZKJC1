package com.unitop.sysmgr.dao;

import java.util.List;

public interface SaveXitlxgxDao extends BaseDataResourcesInterface{
	public void saveXitlxgx(String jigh,String pingzh,List xitList,List yinjList);//��ȡ������Ϣ�ӿ�
}
