package com.unitop.sysmgr.dao;

import java.util.List;

import com.unitop.sysmgr.bo.Jigtgl;
import com.unitop.sysmgr.bo.TabsBo;
public interface PassRateDao  extends BaseDataResourcesInterface {
	
	public TabsBo getAccPassRate(String riqfw,String riqend,String jigh,String orgname,TabsBo TabsBo);
	
	public List<Jigtgl> getOrgPassRate(String riqfw,String riqfwend,String jigh);
	public List getOrgPassRateByWdf(String riqfw,String riqfwend,String wdf,String jigh);
	public Jigtgl queryJgBy(String jigh,String begindate,String enddate,String wdf) throws Exception;
	public Jigtgl queryAllJgBy(String jigh,String beginDate,String endDate, String wdf,String xitlx)throws Exception;
	public List<Jigtgl> queryDJJgBy(String jigh,String beginDate,String endDate, String wdf,String xitlx)throws Exception;
	public Jigtgl queryTotalJgBy(String jigh,String beginDate,String endDate)throws Exception;
}

