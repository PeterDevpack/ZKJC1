package com.unitop.sysmgr.dao;

import java.util.List;
import java.util.Map;

import com.unitop.sysmgr.bo.TabsBo;

/**
 * �����ҳ�����ļ��нӿ�
 * @author lhz
 *
 */
public interface TabsDao {
	public TabsBo pagingForHql(String hql,int page,int max,Map parameterMap);
	public List pagingEntityForSql(String sql,int page,int max,Map parameterMap,Class entity,String[] columns);
	public TabsBo pagingObjectForSql(String sql,int page,int max,Map parameterMap);
	public TabsBo pagingMapForSql(String sql,int page,int max,Map parameterMap);
	public String yinjkh(String account,String date);
	public Map<String,String> qiyrq(String account,String date);
	public Map<String,String> shuangqy(String account,String zhuzh);
	public String shenhy(String account,String date);
	public TabsBo pagingYinjcyrzbForSql(String sql,int page,int max,Map parameterMap,Class yinjcyrzb,String[] columns);
}
