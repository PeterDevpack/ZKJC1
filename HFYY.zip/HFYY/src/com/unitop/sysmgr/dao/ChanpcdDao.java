package com.unitop.sysmgr.dao;

import java.sql.SQLException;
import java.util.Map;

public interface ChanpcdDao  extends BaseDataResourcesInterface  {
	public Map getAllFromChanpgncd ()throws SQLException;
}
