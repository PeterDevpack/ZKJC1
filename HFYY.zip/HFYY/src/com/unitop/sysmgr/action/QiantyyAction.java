package com.unitop.sysmgr.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.exception.BusinessException;
import com.unitop.framework.util.JsonSystemTool;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.PiaojyxwjbId;
import com.unitop.sysmgr.bo.Zhanghb;
import com.unitop.sysmgr.bo.Zhanghxz;
import com.unitop.sysmgr.form.AccountinfoForm;
import com.unitop.sysmgr.service.AccountImageServcie;
import com.unitop.sysmgr.service.OrgService;
import com.unitop.sysmgr.service.ZhanghbService;
import com.unitop.sysmgr.service.ZhanghxzService;
@Controller("/qiantyy")
public class QiantyyAction  extends ExDispatchAction{

	@Resource
	private ZhanghbService ZhanghbService;
	@Resource
	private AccountImageServcie AccountImageServcie;
	@Resource
	private ZhanghxzService zhanghxzService;
	@Resource
	private OrgService orgService;
	
	public boolean CanOperDesOrg(String DesOrg, String OperOrg)
	{
		return this.getSystemMgrService().CanOperDesOrg(OperOrg, DesOrg);
	}
	
	/*
	 * �°���ʺ���ת
	 */
	public ActionForward net_view(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			//����Ա��Ϣ��ʽ��>json
			String jsonClerkrStr = JsonSystemTool.toJsonForClerkForZhang(clerk);
			request.setAttribute("jsonClerkrStr", jsonClerkrStr);
			return actionMapping.findForward("accountinfo.net.view.success");
	}
	
	/*
	 * �°���ʺŲ�ѯ
	 */
	public ActionForward net_select(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String zhangh = request.getParameter("zhangh");
		try{
			Zhanghb zhanghb = ZhanghbService.getZhanghb(zhangh);
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.view.success", "û��Ȩ�޲鿴�˺�:["+zhanghb.getZhangh()+"]");
			}
			if(zhanghb==null)
			{
				return this.showMessageJSP(actionMapping, request, "accountinfo.net.view.success", "û���ҵ��˺�!");
			}
			request.setAttribute("Zhanghb", zhanghb);
			} catch (Exception e) {
				return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.view.success");
			}finally{
				//����Ա��Ϣ��ʽ��>json
				String jsonClerkrStr = JsonSystemTool.toJsonForClerkForZhang(clerk);
				request.setAttribute("jsonClerkrStr", jsonClerkrStr);
			}
			return actionMapping.findForward("accountinfo.net.view.success");
	}
	
	/*
	 * �°���˺Ų�ѯ excel����
	 */
	public ActionForward net_excel(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			String zhangh = request.getParameter("zhangh");
			try{
					Zhanghb Zhanghb = ZhanghbService.getZhanghb(zhangh);
					response.setHeader("Content-Type", "application/octet-stream");
					response.setHeader("Content-Disposition", "attachment;   filename=\"log.csv\"");
					WritableWorkbook book;
					book = Workbook.createWorkbook(response.getOutputStream());
					
					WritableSheet sheet = book.createSheet("Accountinfo", 0);
					
					Label name = new Label(0, 0, "�˺�");
					sheet.addCell(name);
					name = new Label(0, 1, Zhanghb.getZhangh());
					sheet.addCell(name);
					
					name = new Label(1, 0, "������");
					sheet.addCell(name);
					name = new Label(1, 1, Zhanghb.getJigh());
					sheet.addCell(name);
					
					name = new Label(2, 0, "����");
					sheet.addCell(name);
					name = new Label(2, 1, Zhanghb.getHum());
					sheet.addCell(name);
					
					name = new Label(3, 0, "��ַ");
					sheet.addCell(name);
					name = new Label(3, 1, Zhanghb.getDiz());
					sheet.addCell(name);
					
					name = new Label(4, 0, "��������");
					sheet.addCell(name);
					name = new Label(4, 1, Zhanghb.getYouzbm());
					sheet.addCell(name);
					
					name = new Label(5, 0, "��������");
					sheet.addCell(name);
					name = new Label(5, 1, Zhanghb.getKaihrq());
					sheet.addCell(name);
					
//					name = new Label(6, 0, "��������");
//					sheet.addCell(name);
//					name = new Label(6, 1, Zhanghb.getQiyrq());
//					sheet.addCell(name);
					
					name = new Label(6, 0, "�ͻ���");
					sheet.addCell(name);
					name = new Label(6, 1, Zhanghb.getKehh());
					sheet.addCell(name);
					
					name = new Label(7, 0, "���Һ�");
					sheet.addCell(name);
					name = new Label(7, 1, Zhanghb.getHuobh());
					sheet.addCell(name);
					
					name = new Label(8, 0, "�Ƿ�ͨ��ͨ�һ�");
					sheet.addCell(name);
					name = new Label(8, 1, Zhanghb.getTongctd());
					sheet.addCell(name);
					
					name = new Label(9, 0, "�Ƿ���ӡ��");
					sheet.addCell(name);
					name = new Label(9, 1, Zhanghb.getYouwyj());
					sheet.addCell(name);
					
					name = new Label(10, 0, "�Ƿ���ӡ�����");
					sheet.addCell(name);
					name = new Label(10, 1, Zhanghb.getYouwzh());
					sheet.addCell(name);
					
					name = new Label(11, 0, "�˻�״̬");
					sheet.addCell(name);
					name = new Label(11, 1, Zhanghb.getZhanghshzt());
					sheet.addCell(name);
					
					name = new Label(12, 0, "ӡ��״̬");
					sheet.addCell(name);
					name = new Label(12, 1, Zhanghb.getYinjshzt());
					sheet.addCell(name);
					
					name = new Label(13, 0, "���״̬");
					sheet.addCell(name);
					name = new Label(13, 1, Zhanghb.getZuhshzt());
					sheet.addCell(name);
					
					name = new Label(14, 0, "��ע");
					sheet.addCell(name);
					name = new Label(14, 1, Zhanghb.getBeiz());
					sheet.addCell(name);
					
					book.write();
					book.close();
					request.getRequestDispatcher("").forward(request, response);
			} catch (Exception e) {
				return this.errrForLogAndException(e, actionMapping, request, null);
			}
			return null;
	}

	
	/*
	 * �˺���ϸ��ѯ .net
	 */
	public ActionForward scanAccountinfo(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		try {
			String zhangh = request.getParameter("zhangh");
			Zhanghb Zhanghb = ZhanghbService.getZhanghb(zhangh);
			request.setAttribute("Zhanghb", Zhanghb);
			return actionMapping.findForward("accountinfo.net.scan.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request,"accountinfo.net.scan.success");
		}finally{
			//����Ա��Ϣ��ʽ��>json
			String jsonClerkrStr = JsonSystemTool.toJsonForClerkForZhang(clerk);
			request.setAttribute("jsonClerkrStr", jsonClerkrStr);
		}
	}

	//�����ָ� ��ת
	public ActionForward recoverAccountForNetView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.resume.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.resume.success");
		}
	}
	
	//�����ָ�
	public ActionForward recoverAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.resume.success", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.resume.success", "û��Ȩ�������ָ����˺�:["+accountinfoform.getAccount()+"]");
			}
			//��֤�˻�״̬
			if("����".equals(zhanghb.getZhanghzt())){
				ZhanghbService.recoverAccount(zhanghb.getZhangh());
				String content = "�����ָ�(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
				this.createManageLog(clerk.getCode(), content);
				this.createAccountManageLog(zhanghb.getZhangh() ,"�����ָ�","�����ָ�", clerk);
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.resume.success","�����ָ��ɹ�!");
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.resume.success","�˺ţ�["+zhanghb.getZhangh()+"]���ɽ��������ָ�,��ǰ״̬Ϊ��["+zhanghb.getZhanghzt()+"]��");
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.resume.success");
		}
	}
	
	//���� ��ת
	public ActionForward coverAccountForNetView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.xiaohu");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.xiaohu");
		}
	}
	
	//����
	public ActionForward coverAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu", "û��Ȩ���������˺�:["+accountinfoform.getAccount()+"]��");
			}
			//��֤�˻�״̬
			if("��Ч".equals(zhanghb.getZhanghzt())){
				ZhanghbService.closeAccount(zhanghb.getZhangh());
				String content = "����(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
				this.createManageLog(clerk.getCode(), content);
				this.createAccountManageLog(zhanghb.getZhangh() ,"����", "����", clerk);
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu","�����ɹ�!");
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu","�˺ţ�["+zhanghb.getZhangh()+"]���ɽ�������,��ǰ״̬Ϊ��["+zhanghb.getZhanghzt()+"]��");
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.xiaohu");
		}
	}
	
	//�˺Ž�� ��ת
	public ActionForward jiegAccountForNetView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.zhanghjg.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghjg.success");
		}
	}
	
	//�˺Ž��
	public ActionForward jiegAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "û��Ȩ�޽���˺�:["+accountinfoform.getAccount()+"]");
			}
			//��֤�˻�״̬
			if("��ʧ".equals(zhanghb.getZhanghzt()))
			{	
				ZhanghbService.recoverAccount(zhanghb.getZhangh());
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success","�˺ţ�["+zhanghb.getZhangh()+"]���ɽ��н��,��ǰ״̬Ϊ��["+zhanghb.getZhanghzt()+"]");
			}
			String content = "��ҳɹ�(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
			this.createManageLog(clerk.getCode(), content);
			this.createAccountManageLog(zhanghb.getZhangh() ,"�˻����", "�˻����", clerk);
			return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success","�˺Ž�ҳɹ�!");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghjg.success");
		}
	}
	
	//�˺Žⶳ ��ת
	public ActionForward jiedAccountForNetView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.zhanghjd.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghjd.success");
		}
	}
	
	//�˺Žⶳ
	public ActionForward jiedAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjd.success", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjd.success", "û��Ȩ�������˺�:["+accountinfoform.getAccount()+"]");
			}
			//��֤�˻�״̬
			if("����".equals(zhanghb.getZhanghzt()))
			{	
				ZhanghbService.recoverAccount(zhanghb.getZhangh());
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjd.success","�˺ţ�["+zhanghb.getZhangh()+"]���ɽ��нⶳ,��ǰ״̬Ϊ��["+zhanghb.getZhanghzt()+"]");
			}
			String content = "�ⶳ�ɹ�(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
			this.createManageLog(clerk.getCode(), content);
			this.createAccountManageLog(zhanghb.getZhangh() , "�˻��ⶳ","�˻��ⶳ", clerk);
			return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjd.success","�˺Žⶳ�ɹ�!");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghjd.success");
		}
	}
	
	//����ɾ�� ��ת
	public ActionForward physicsDeleteForNetForView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.physicsdelete.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.physicsdelete.success");
		}
	}
	
	//�°�����ɾ��
	public ActionForward physicsDeleteForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success", "�˻�������!");
			}
			//��֤�˻��Ƿ�Ϊ���˻������˻����ܽ�������ɾ��        by wp
			List list = ZhanghbService.getzzhlist(accountinfoform.getAccount());
			if(list.size()>0){
				return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success", "��ǰ�˻�Ϊ���˻�������ִ������ɾ������!");	
			}
			//��֤��ǰ��Ա�����˺�Ȩ�� ɾ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.physicsdelete.success", "û��Ȩ��ɾ���˺�:["+accountinfoform.getAccount()+"]");
			}
			ZhanghbService.physicsdelete(zhanghb.getZhangh());
			String content = "�˻�����ɾ��(�˺�Ϊ"+zhanghb.getZhangh()+";��Ա��:"+clerk.getCode()+")";
			this.createManageLog(clerk.getCode(), content);
			this.createAccountManageLog(zhanghb.getZhangh(),"�˻�ɾ��","�˻�ɾ��",clerk);
			return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success","�˻�����ɾ�������ɹ�!");
		} catch (Exception e) {
			return this.errrForLogAndException(e,actionMapping,request,"accountinfo.net.physicsdelete.success");
		}
	}

	/**
	 * 
	 * <dl>
	 * <dt><b>getAccountForNet:��.net���˻����л�ȡ�˻�����</b></dt>
	 * <dd></dd>
	 * </dl>
	 */
	public ActionForward getAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String account = request.getParameter("account");
		String accountname = "";
		String allexchange = "";
		String englishname = "";
		String accountstate = "";
		String isZhuzh = "0";//0:�������˻���1�����˻�
		try {
			Zhanghb accountinfo = ZhanghbService.getZhanghb(account);
			if (accountinfo != null)
			{
				accountname = accountinfo.getHum();
				allexchange = accountinfo.getTongctd();
				englishname = accountinfo.getKehh()==null?"":accountinfo.getKehh();
				accountstate = accountinfo.getZhanghzt();
				List zlist  = ZhanghbService.getzzhlist(account);//���˻��б�
				//�ж��˻��Ƿ�������˻�
				if(zlist!=null&&zlist.size()>=1)isZhuzh="1";
			}
			response.setContentType("text/xml");
			response.setLocale(Locale.SIMPLIFIED_CHINESE);
			response.setCharacterEncoding("GBK");
			PrintWriter out = response.getWriter();
			String accountin = accountname + "," + allexchange + "," + englishname + "," + accountstate+","+isZhuzh;
			out.println(accountin);
			out.close();
			return null;
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, null);
		}

	}
	
	/*
	 * ����Ʊ��Ӱ��
	 */
	public ActionForward getBillImage(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			String zhangh = request.getParameter("zhangh");
			String wenjbh = request.getParameter("wenjbh");
			try {
				ServletOutputStream out = response.getOutputStream();
				PiaojyxwjbId id = new PiaojyxwjbId();
				id.setZhangh(zhangh);
				id.setWenjbh(wenjbh);
				AccountImageServcie.downloadBillImage(id,out);
				out.close();
				out=null;
				return null;
			} catch (Exception e) {
				return this.errrForLogAndException(e, actionMapping, request, null);
			}
	}
	
	/*
	 * �����˻�ӡ����Ӱ��
	 */
	public ActionForward downloadYinjkImage(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			String zhangh=request.getParameter("zhangh");
			String yinjkh=request.getParameter("yinjkh");
			String billcm=request.getParameter("billcm");
			try {
				ServletOutputStream out = response.getOutputStream();
				AccountImageServcie.downloadYinjkImage(zhangh, yinjkh, billcm, out);
				out.close();
				out=null;
				return null;
			} catch (Exception e) {
				return this.errrForLogAndException(e, actionMapping, request, null);
			}
	}
	
	/*
	 * ��ȡ�˺�ӡ������Ϣ
	 */
	public ActionForward getAcccountYjkImageList(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
				String account = request.getParameter("account");
			try {
				List list = AccountImageServcie.getZhanghYjkList(account);
				if(list ==null||list.size()==0)
				{
					return this.showMessageJSP(actionMapping, request, "accountinfo.image", "û���ҵ����˺ŵ�Ԥ��ӡ������");
				}
				request.setAttribute("accountList", list);
				return actionMapping.findForward("accountinfo.image");
			} catch (Exception e) {
				e.printStackTrace();
				return this.errrForLogAndException(e, actionMapping, request, "accountinfo.image");
			}
	}
	
	/*
	 * ��ȡ�˺�ӡ������Ϣ
	 */
	public ActionForward getYinjkListByQiyrq(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
				String zhangh = request.getParameter("zhangh");
				String qiyrq = request.getParameter("qiyrq");
			try {
				List list = AccountImageServcie.getYinjkByQiyrq(zhangh, qiyrq);
				if(list ==null||list.size()==0)
				{
					return this.showMessageJSP(actionMapping, request, "accountinfo.image", "û���ҵ����˺ŵ�Ԥ��ӡ������");
				}
				request.setAttribute("accountList", list);
				return actionMapping.findForward("accountinfo.image");
			} catch (Exception e) {
				e.printStackTrace();
				return this.errrForLogAndException(e, actionMapping, request, "accountinfo.image");
			}
	}
	
	/*
	 * ��ȡƱ����Ϣ
	 */
	public ActionForward getPiaojImageList(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
				String zhangh = request.getParameter("zhangh");
				String pingzbsm = request.getParameter("pingzbsm");
			try {
				List list = AccountImageServcie.getBillImgList(zhangh,pingzbsm);
				if(list ==null||list.size()==0)
				{
					return this.showMessageJSP(actionMapping, request, "accountinfo.image", "û���ҵ���Ʊ�ݣ�");
				}
				request.setAttribute("accountList", list);
				return actionMapping.findForward("accountinfo.bill");
			} catch (Exception e) {
				e.printStackTrace();
				return this.errrForLogAndException(e, actionMapping, request, "accountinfo.bill");
			}
	}

	//�˻�������תҳ��
	public ActionForward zhanghdjView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.zhanghdj.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghdj.success");
		}
	}
	
	//����
	public ActionForward zhanghdj(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success", "û��Ȩ�޶��ᣬ�˺�:["+accountinfoform.getAccount()+"]��");
			}
			//��֤�˻�״̬
			if("��Ч".equals(zhanghb.getZhanghzt())){
				ZhanghbService.dongjAccount(zhanghb.getZhangh());
				String content = "����(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
				this.createManageLog(clerk.getCode(), content);
				this.createAccountManageLog(zhanghb.getZhangh() ,"����", "����", clerk);
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success","�˻�����ɹ�!");
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success","�˺ţ�["+zhanghb.getZhangh()+"]���ɽ����˻�����,��ǰ״̬Ϊ��["+zhanghb.getZhanghzt()+"]��");
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghdj.success");
		}
	}
	
	//�˻���ʧ��תҳ��
	public ActionForward zhanghgsView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.zhanghgs.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghgs.success");
		}
	}
	

	//��ʧ
	public ActionForward zhanghgs(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghgs.success", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghgs.success", "û��Ȩ�޹�ʧ���˺�:["+accountinfoform.getAccount()+"]��");
			}
			//��֤�˻�״̬
			if("��Ч".equals(zhanghb.getZhanghzt())){
				ZhanghbService.guasAccount(zhanghb.getZhangh());
				String content = "��ʧ�˻�(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
				this.createManageLog(clerk.getCode(), content);
				this.createAccountManageLog(zhanghb.getZhangh() ,"��ʧ�˻�", "��ʧ�˻�", clerk);
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghgs.success","��ʧ�ɹ�!");
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghgs.success","�˺ţ�["+zhanghb.getZhangh()+"]���ɽ����˻���ʧ,��ǰ״̬Ϊ��["+zhanghb.getZhanghzt()+"]��");
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghgs.success");
		}
	}
	
	//ӡ��������תҳ��
	public ActionForward openAccount(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			
			return actionMapping.findForward("accountinfo.openaccount");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.openaccount");
		}
	}
	
	//ӡ�������תҳ��
	public ActionForward changeSeals(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			
			return actionMapping.findForward("accountinfo.changeseals");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.changeseals");
		}
	}
	
	//�����޸���תҳ��
	public ActionForward changeAccountInfo(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			
			return actionMapping.findForward("accountinfo.changeaccountinfo");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.changeaccountinfo");
		}
	}
	
	//ӡ����ӡ��תҳ��
	public ActionForward accInfoCheck(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);			
			return actionMapping.findForward("forword.qiantyy");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.accinfocheck");
		}
	}
	
	
	
	//��ӡ��ѯ��ת
	public ActionForward accInfoCheck_query(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);			
			return actionMapping.findForward("forword.qiantyy_query");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.accinfocheck");
		}
	}
	
	
	//�˺Ź�����תҳ��
	public ActionForward accountLink(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			
			return actionMapping.findForward("accountinfo.accountlink");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.accountlink");
		}
	}
	
	/*
	 * ��ѯ�˻���Ϣ
	 */
	public ActionForward getAccountInfo(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String zhangh = request.getParameter("zh");
			Zhanghb zhanghb;
			PrintWriter out;
			try {
				zhanghb = ZhanghbService.getZhanghb(zhangh);
				//��֤��ǰ��Ա�����˺�Ȩ��
				boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
				if(!bool)
				{
					response.setContentType("text/xml");
					response.setLocale(Locale.SIMPLIFIED_CHINESE);
					response.setCharacterEncoding("GBK");
					out = response.getWriter();
					String accountinfo = "false";
					out.println(accountinfo);
					out.close();
					return null;
//					return super.showMessageJSP(actionMapping, request, "accountinfo.net.view.success", "û��Ȩ�޲鿴�˺�:["+zhanghb.getZhangh()+"]");
				}
				request.setAttribute("Zhanghb", zhanghb);
				String zh = zhanghb.getZhangh();
				String zzh = zhanghb.getZhuzh();
				String hm = zhanghb.getHum();
				String zhlb = zhanghb.getZhanghxz();
				String khh = zhanghb.getKehh();
				String zhjgh = zhanghb.getJigh();
				String khrq = zhanghb.getKaihrq();
				String bz = (null == zhanghb.getBeiz() || "" == zhanghb.getBeiz() || "".equals( zhanghb.getBeiz())) ? "" : zhanghb.getBeiz();
				String zhzt = zhanghb.getZhanghzt();
				String zhshzt = zhanghb.getZhanghshzt();
				String yinjshzt = zhanghb.getYinjshzt();
				response.setContentType("text/xml");
				response.setLocale(Locale.SIMPLIFIED_CHINESE);
				response.setCharacterEncoding("GBK");
				out = response.getWriter();
				String accountinfo = zh + "," + zzh + "," + hm + "," + zhlb + "," + khh + "," + zhjgh + "," + khrq + "," + bz + "," + zhzt+","+zhshzt+","+yinjshzt;
				Map<String,String> accmap = new HashMap<String, String>();
				accmap.put("zh", zh);
				out.println(accountinfo);
				out.close();
				return null;
			} catch (BusinessException e) {
				 try {
					out = response.getWriter();
					out.println(",");
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				 return null;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
			
	}
	
	/*
	 * ��֤�����Ƿ���ں����޲���Ȩ��
	 */
	public ActionForward validateJigh(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String jigh = request.getParameter("jigh");
			PrintWriter out;
			boolean flag=true;
			boolean bool=true;
			try {
				//��֤�˻������Ƿ��������ӡϵͳ��
				Org o = orgService.getOrgByCode(jigh);
				if("".equals(o)||o==null){
					flag=false;
				}else{
					//��֤��ǰ��Ա����������Ȩ��
					bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),jigh);
					/*if(!bool)
					{
						
						//return super.showMessageJSP(actionMapping, request, "accountinfo.net.view.success", "û��Ȩ����:["+jigh+"]�½���");
					}*/
				}
				response.setContentType("text/xml");
				response.setLocale(Locale.SIMPLIFIED_CHINESE);
				response.setCharacterEncoding("GBK");
				out = response.getWriter();
				if(flag){
					if(bool){
						out.println(flag+","+o.getName());
					}else{
						out.println(flag+","+bool);
					}
				}else{
					out.println(flag);
				}
				out.close();
				return null;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
			
	}
	
	/*
	 * ��ѯ�˻���Ϣ������˻�Ϊ���˻����������˻��б�
	 */
	public ActionForward getAccountInfoWithSubAccounts(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String zhangh = request.getParameter("zh");
			Zhanghb zhanghb;
			PrintWriter out;
			try {
				zhanghb = ZhanghbService.getZhanghb(zhangh);
				//��֤��ǰ��Ա�����˺�Ȩ��
				boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
				if(!bool)
				{
					return super.showMessageJSP(actionMapping, request, "accountinfo.net.view.success", "û��Ȩ�޲鿴�˺�:["+zhanghb.getZhangh()+"]");
				}
				request.setAttribute("Zhanghb", zhanghb);
				String zh = zhanghb.getZhangh();
				String zzh = zhanghb.getZhuzh();
				String hm = zhanghb.getHum();
				String zhlb = zhanghb.getZhanghxz();
				String khh = zhanghb.getKehh();
				String zhjgh = zhanghb.getJigh();
				String khrq = zhanghb.getKaihrq();
				String bz = (null == zhanghb.getBeiz() || "" == zhanghb.getBeiz() || "".equals( zhanghb.getBeiz())) ? "" : zhanghb.getZhanghzt();
				String zhzt = zhanghb.getZhanghzt();
				String zhshzt = zhanghb.getZhanghshzt();
				List<Zhanghb> zzhlist = null;
				String zzh_str = "";
				String accountinfo = "";
				
				//��������˻����������˻��б�
				if("".equals(zzh) || zzh == null){
					zzhlist = this.ZhanghbService.getzzhlist(zh);
				}
				
				//ƴ�����˺��ַ���
				if(zzhlist.size() >0){
					for(int i=0;i<zzhlist.size();i++){
						zzh_str += zzhlist.get(i).getZhangh() + ",";
					}
					zzh_str = zzh_str.substring(0,zzh_str.length()-1);
					//ƴ�ӷ����ַ������˻���Ϣ+���˺��ַ�����
					accountinfo = zh + "," + zzh + "," + hm + "," + zhlb + "," + khh + "," + zhjgh + "," + khrq + "," + bz + "," + zhzt + "," +zzh_str+","+zhshzt;
				}else{
					accountinfo = zh + "," + zzh + "," + hm + "," + zhlb + "," + khh + "," + zhjgh + "," + khrq + "," + bz + "," + zhzt+","+zhshzt;
				}
				
				response.setContentType("text/xml");
				response.setLocale(Locale.SIMPLIFIED_CHINESE);
				response.setCharacterEncoding("GBK");
				out = response.getWriter();
				out.println(accountinfo);
				out.close();
				return null;
			} catch (BusinessException e) {
				 try {
					out = response.getWriter();
					out.println(",");
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				 return null;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return null;
	}
	//ӡ����Ϣ�鿴ҳ����ת
	public ActionForward yinjxxck(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			
			return actionMapping.findForward("accountinfo.yinjxxck");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.yinjxxck");
		}
	}
}
