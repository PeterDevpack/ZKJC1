package com.unitop.sysmgr.action;


import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.form.SealchecklogForm;
import com.unitop.sysmgr.service.OrgService;
import com.unitop.sysmgr.service.impl.QueryServiceImpl;
/**
 * ������Ʊ��ӡ��־��ѯ----���汾  ������ϸ����
 * @author Owner
 */
@Controller("/voucherchecklog_huif")
public class VoucherCheckAction_huif extends ExDispatchAction {		
	private final static String SUCCESS = "success";


	@Resource
	private OrgService orgService;
	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {
 
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			SealchecklogForm logForm = (SealchecklogForm) form;
			
			String beginDate = logForm.getBegindate();
			String endDate = logForm.getEnddate();
			String jigh = logForm.getJigh();
			String sequence=logForm.getSequence();//��ˮ��	
			

		
			if(jigh==null||"".equals(jigh)){
				return this.showMessageJSP(mapping, request, "success","�����Ų�����Ϊ�գ�");		
			}else{
				//�жϻ���Ȩ��							
				String res=orgService.CanOperDesOrg(clerk.getOrgcode(), jigh);
				if(res.equals("2")){
					return this.showMessageJSP(mapping, request, "success","û��Ȩ�޲鿴�˻�����");					
				}else if(res.equals("1")){
					return this.showMessageJSP(mapping, request, "success","�����Ų����ڣ�");		
				}
				
			}


/*			boolean canOperAcc = false;
			String canOperAccRetMsg = "";
			
			if (account!=null&&!account.equals("")){
				//����Ա�ܷ�����˻�
				CanOperAccReturn coar = this.getSystemMgrService().ProCanOperAcc(clerk.getOrgcode().toString(),account.toString());
				canOperAcc = coar.getReturnValue();
				canOperAccRetMsg = coar.getReturnMessage();
			}
			if (!canOperAcc && account!=null && account.trim().length()>0) {
				return this.showMessageJSPforcx(mapping,request,"success",canOperAccRetMsg+" !");
			}*/
			
			
			
			
			String xls=request.getParameter("ec_ev");		
			//��������-�����һ��������
			if("xls".equals(xls)){
				String[] begin=beginDate.split("-");
				String[] end = endDate.split("-");
				int year=Integer.valueOf(end[0])-Integer.valueOf(begin[0]);
				int month=Integer.valueOf(end[1])-Integer.valueOf(begin[1]);
				int date=Integer.valueOf(end[2])-Integer.valueOf(begin[2]);
				if(year==0){//�����ͬ
					if(month==1&&date>1){//���������µ�����30�죬�����һ����01����ǰ��
						beginDate=end[0]+"-"+(end[1])+"-01";
					}if(month>1){//����һ���°����һ����01����ǰ��
						beginDate=end[0]+"-"+(end[1])+"-01";
					}
				}else if(year==1){//����
					if(Integer.valueOf(begin[1])==12&&Integer.valueOf(end[1])==1){//�����������ȥ���12�·ݺͽ����1�·�
						if(date>0){//������ʱ���Ƿ�С��1����
							beginDate=end[0]+"-"+(end[1])+"-01";	
						}
					}else{
						beginDate=end[0]+"-"+(end[1])+"-01";
					}
				}else{
					return this.showMessageJSPforcx(mapping,request,"success","����ʱ�䲻��ȷ !");
				}
				
			}
			
			TabsBo TabsBo = this.createTabsBo(request);
			QueryServiceImpl queryServiceImpl = (QueryServiceImpl) this.getQueryService();
			queryServiceImpl.setTabsService(TabsBo);
			TabsBo tabsBo = this.getQueryService().pingzhengyanyinlog(sequence,null,null, null, null, null, beginDate,endDate,jigh , null);
//			this.showTabsModel(request, tabsBo);
			request.setAttribute("list", tabsBo.getList());
			request.setAttribute("totalRows_cs", tabsBo.getCounts());
			//logForm.setCheckmode(checkMode);
			//logForm.setCheckresult(checkResult);
			return super.showMessageJSPForFeny(mapping,request,tabsBo,SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, SUCCESS);
		}
	}
	
	public ActionForward getAccountInfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		
		return null;
	}
}