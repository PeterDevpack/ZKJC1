package com.unitop.sysmgr.action;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.framework.util.StringUtil;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.form.ClerkChangeCheckForm;
import com.unitop.sysmgr.service.ClerkManageService;
import com.unitop.sysmgr.service.impl.QueryServiceImpl;

@Controller("/clerkChangeCheck")
public class ClerkChangeCheckAction extends ExDispatchAction {
	/*
	 * �°���ʺ���ת
	 */
	@Resource
	private OrgDao orgDao;
	@Resource
	private ClerkManageService clerkService;

	public ActionForward forward(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		String code = clerk.getOrgcode();
		JSONArray jsonArray = new JSONArray();
		List<Org> orgList = orgDao.getAllOrg(code);
		for (Org orgltem : orgList) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("id", orgltem.getCode());
			jsonObject.put("pId", orgltem.getParentCode());
			jsonObject.put("name", orgltem.getName());
			jsonObject.put("wdflag", orgltem.getWdflag());
			if (code.equals(orgltem.getCode())) {
				jsonObject.put("open", "true");
				jsonObject.put("nocheck", false);
			}
			jsonArray.add(jsonObject);
			if ("1".equals(orgltem.getWdflag())
					|| "2".equals(orgltem.getWdflag())
					|| "3".equals(orgltem.getWdflag())) {
				jsonObject.put("id", "banb" + orgltem.getCode());
				jsonObject.put("pId", orgltem.getCode());
				jsonObject.put("name", orgltem.getName() + "(����)");
				jsonArray.add(jsonObject);
			}
		}
		String str = jsonArray.toString();
		ClerkChangeCheckForm form = (ClerkChangeCheckForm)actionForm;
		Date rightNow = Calendar.getInstance().getTime();
		SimpleDateFormat sdf_date = new SimpleDateFormat("yyyy-MM-dd");
		form.setBegindate(sdf_date.format(rightNow));
		form.setEnddate(sdf_date.format(rightNow));
		request.setAttribute("Jsonstr", str);
		// request.setAttribute("youqjgstr",code);
		// return mapping.findForward("success");
		return actionMapping.findForward("clerkChangeChech.login");
	}

	public ActionForward clerkChangeCheckDo(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			// Clerk clerk =(Clerk) request.getSession().getAttribute("clerk");
			ClerkChangeCheckForm clerkChangeForm = (ClerkChangeCheckForm) actionForm;
			request.setAttribute("totalRows", new Integer(0));
			Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
			String code2 = clerk2.getOrgcode();
			String clerknum = clerkChangeForm.getGuiyuanh();
			//�ж�����Ĺ�Ա���Ƿ�Ϊ�գ��յĻ����õ�½��Ա���
			Clerk clerk_target = null;
			if(StringUtils.isEmpty(clerknum)){
				clerk_target = clerk2;
			}else{
				clerk_target = clerkService.getClerkByCode(clerknum);
				if (StringUtil.isEmpty(clerk_target.getCode())) {
					return this.showMessageJSP(mapping, request, "success", "��Ա������");
				} else {

					boolean bool = this.getSystemMgrService().CanOperDesOrg(
							clerk2.getOrgcode(), clerk_target.getOrgcode());
					if (!bool) {
						return this.showMessageJSP(mapping, request, "success",
								"û��Ȩ�޲鿴�ù�Ա");
					}
				}
			}
			//������֤
			String startdata = clerkChangeForm.getBegindate().replace("-","");
			String enddata = clerkChangeForm.getEnddate().replace("-","");
			SimpleDateFormat sm = new SimpleDateFormat("yyyyMMdd");
			String rightdate = sm.format(new Date());
			
			Date end = sm.parse(enddata);
			if(Integer.valueOf(startdata)>Integer.valueOf(enddata)){
				return this.showMessageJSP(mapping, request, "success",
						"��ʼʱ��ҪС�ڽ���ʱ��");
			}else if(Integer.valueOf(enddata)>Integer.valueOf(rightdate)){
				return this.showMessageJSP(mapping, request, "success",
						"�������ڲ��ܴ��ڽ���");
			}
			JSONArray jsonArray = new JSONArray();
			List<Org> orgList = orgDao.getAllOrg(code2);
			for (Org orgltem : orgList) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("id", orgltem.getCode());
				jsonObject.put("pId", orgltem.getParentCode());
				jsonObject.put("name", orgltem.getName());
				if (code2.equals(orgltem.getCode())) {
					jsonObject.put("open", "true");
					jsonObject.put("nocheck", false);
				}
				jsonArray.add(jsonObject);
				if ("1".equals(orgltem.getWdflag())
						|| "2".equals(orgltem.getWdflag())
						|| "3".equals(orgltem.getWdflag())) {
					jsonObject.put("id", "banb" + orgltem.getCode());
					jsonObject.put("pId", orgltem.getCode());
					jsonObject.put("name", orgltem.getName() + "(����)");
					jsonArray.add(jsonObject);
				}
			}
			String str = jsonArray.toString();
			// ��ҳ��ѯ
			TabsBo TabsBo = this.createTabsBo(request);
			QueryServiceImpl queryServiceImpl = (QueryServiceImpl) this
					.getQueryService();
			queryServiceImpl.setTabsService(TabsBo);

			TabsBo tabsBo = null;
			/*if (StringUtil.isEmpty(clerk_target.getCode())) {
				tabsBo = this.getQueryService().findClerkChangeCheck(
						clerkChangeForm.getBegindate(),
						clerkChangeForm.getEnddate(), clerk2.getCode());
			} else {*/
				tabsBo = this.getQueryService().findClerkChangeCheck(
						clerkChangeForm.getBegindate(),
						clerkChangeForm.getEnddate(), clerk_target.getCode());
//				}
			this.showTabsModel(request, tabsBo);
			List industrycharacterlist = getQueryService().getHuobh();
			request.setAttribute("Jsonstr", str);
			// request.setAttribute("youqjgstr",newjigh);
			request.setAttribute("industrycharacterlist", industrycharacterlist);
			return super.showMessageJSPForFeny(mapping, request, tabsBo,"success");

		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "success");
		}
	}
}