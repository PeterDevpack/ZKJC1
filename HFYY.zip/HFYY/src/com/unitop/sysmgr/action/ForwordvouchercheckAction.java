package com.unitop.sysmgr.action;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.dao.OrgDao;

@Controller("/forwordvoucherchecklog")
public class ForwordvouchercheckAction extends ExDispatchAction{

	@Resource
	private OrgDao orgDao;
	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response){

		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");										
		String code=clerk.getOrgcode();	
		JSONArray jsonArray = new JSONArray();	
		List<Org> orgList=orgDao.getAllOrg(code);			
		for(Org orgltem:orgList){											
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("id", orgltem.getCode());
				jsonObject.put("pId", orgltem.getParentCode());
				jsonObject.put("name", orgltem.getName());
				jsonObject.put("wdflag", orgltem.getWdflag());
				if(code.equals(orgltem.getCode())){
					jsonObject.put("open", "true");					
					jsonObject.put("nocheck", false);
				}
				jsonArray.add(jsonObject);
				if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
					jsonObject.put("id","banb"+orgltem.getCode());
					jsonObject.put("pId", orgltem.getCode());
					jsonObject.put("name", orgltem.getName()+"(����)");
					jsonArray.add(jsonObject);
				}
		}	
		String str=jsonArray.toString();
		request.setAttribute("Jsonstr",str);
//		request.setAttribute("youqjgstr",code);			
		return mapping.findForward("success");					
	}
}
