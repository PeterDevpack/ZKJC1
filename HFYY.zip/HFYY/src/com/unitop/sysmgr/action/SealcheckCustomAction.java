package com.unitop.sysmgr.action;

import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Controller;

import com.unitop.bank.DataSourceFactory;
import com.unitop.framework.util.DateTool;
import com.unitop.sysmgr.bo.CanOperAccReturn;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Zhanghb;
import com.unitop.sysmgr.form.SealchecklogForm;
import com.unitop.sysmgr.service.ClerkManageService;
import com.unitop.sysmgr.service.YanyinLogService;
import com.unitop.sysmgr.service.ZhanghbService;

@Controller("/sealcheckcustom")
public class SealcheckCustomAction extends ExDispatchAction {
	@Resource
	private ZhanghbService zhanghbService;
	@Resource
	private YanyinLogService YanyinLogService;
	@Resource
	private ClerkManageService clerkManageService;
	
	public boolean CanOperDesOrg(String OperOrg, String DesOrg) {
		return getSystemMgrService().CanOperDesOrg(OperOrg, DesOrg);
	}

	public ActionForward list(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		
		try {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			List list = new ArrayList();
			list = this.getQueryService().getCustomSealcheckList(clerk.getCode());
			request.setAttribute("list", list);
			return actionMapping.findForward("list");
		} catch (Exception e) {
			request.setAttribute("list", new ArrayList());
			return this.errrForLogAndException(e, actionMapping, request,
		 			"list");
		}
	}

	public ActionForward add(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			request.setAttribute("time",DateTool.getDataTime("yyyyMMddHHmmss"));
			return actionMapping.findForward("add");
		} catch (Exception e) {
			request.setAttribute("time",DateTool.getDataTime("yyyyMMddHHmmss"));
			return this.errrForLogAndException(e, actionMapping, request, "list");
		}
	}
	

	public ActionForward save(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			SealchecklogForm sealchecklogForm = (SealchecklogForm) actionForm;
		try {
			String zhangh = sealchecklogForm.getAccount();
			String clerknum = sealchecklogForm.getClerknum();
			if((zhangh==null||"".equals(zhangh))&&(clerknum==null||"".equals(clerknum)))
			{
				return this.showMessageJSP(actionMapping, request, "add","��Ա������˺Ų���ͬʱΪ�գ�");
			}
			Clerk clerk_ = clerkManageService.getClerkByCode(sealchecklogForm.getClerknum());
			if(sealchecklogForm.getAccount()==null||"".equals(sealchecklogForm.getAccount()))
			{
				if(clerk_==null)
				{
					return this.showMessageJSP(actionMapping, request, "add","��Ա���벻���ڣ�");
				}
			}else{
				Zhanghb accountinfo = zhanghbService.getZhanghb(sealchecklogForm.getAccount());
				if(accountinfo==null)
				{
					return this.showMessageJSP(actionMapping, request, "add","�˺Ż��Ա���벻���ڣ�");
				}
				else if(sealchecklogForm.getClerknum()!=null&&!"".equals(sealchecklogForm.getClerknum())&&clerk_==null)
				{
					return this.showMessageJSP(actionMapping, request, "add","��Ա���벻���ڣ�");
				}
			}
			if(!"".equals(sealchecklogForm.getChecknum())&&sealchecklogForm.getChecknum()!=null){
				if (YanyinLogService.validatePjhForZhengp(sealchecklogForm.getChecknum()))
				{
					return this.showMessageJSP(actionMapping, request, "add", "������Ч,ƾ֤�Ų����ڣ�");
				}
			}
			if(clerk_!=null&&!"".equals(clerk_.getCode()))
			{		
				if (!CanOperDesOrg(clerk.getOrgcode(), clerk_.getOrgcode()))
				{
					return this.showMessageJSP(actionMapping,request,"add","������Ч,û��Ȩ�޲�ѯ�˹�Ա!");
				}
			}
			boolean canOperAcc = false;
			String canOperAccRetMsg = "";
			if (sealchecklogForm.getAccount()!= null && !sealchecklogForm.getAccount().equals("")) 
			{ 
				CanOperAccReturn coar = this.getSystemMgrService().ProCanOperAcc(clerk.getOrgcode(),sealchecklogForm.getAccount());
				canOperAcc = coar.getReturnValue();
				canOperAccRetMsg = coar.getReturnMessage();
			} 
			if(zhangh!=null&&!"".equals(zhangh))
			{
				if (!canOperAcc)
				{
					return this.showMessageJSP(actionMapping,request,"add",canOperAccRetMsg);
				}
			}
			
			String begindate = sealchecklogForm.getBegindate();
			String enddate = sealchecklogForm.getEnddate();
			if ((begindate != null && begindate.trim().length() > 0) && (enddate != null && enddate.trim().length() > 0))
			{
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date begin = null;
				try {
					begin = format.parse(begindate);
					Date end = format.parse(enddate);
					if (end.compareTo(begin) < 1 && !begin.equals(end))
					{
						return this.showMessageJSP(actionMapping,request,"add","�������ڲ���С�ڿ�ʼ���ڣ�");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			String TaskFlag = (String) request.getParameter("TaskFlag");
			this.getQueryService().CreateCustomaQuery_SealCheckLog(TaskFlag, clerk.getCode(), sealchecklogForm);
			return actionMapping.findForward("save.ok");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "add");
		}
	}

	public ActionForward delete(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String id = request.getParameter("id");
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		try {
			this.getQueryService().DeleteCustomaQuery(id, clerk.getCode());
			return actionMapping.findForward("delete.ok");
		} catch (Exception e) {
			return this.showMessageJSP(actionMapping,request,"delete.ok","д���ݿ�ʱ��������!");
		}
	}

	public ActionForward download(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			String id = request.getParameter("id");
			Connection con = null;
			Statement st = null;
			ResultSet rs = null; 
			
		try {
			con = DataSourceUtils.getConnection(DataSourceFactory.getDataSourceByPool());
			con.setAutoCommit(false);
			st = con.createStatement();
			rs = st.executeQuery("select fileinfo from dzcxinfo where id='"+id+"'");
			if (rs.next()) {
				Blob blob = rs.getBlob(1);
				InputStream ins = blob.getBinaryStream();
				response.setContentType("application/unknown");
				response.addHeader("Content-Disposition","attachment;  filename=" + id+".xls");
				OutputStream outStream = response.getOutputStream();
				byte[] bytes = new byte[1024];
				int len = 0;
				while ((len = ins.read(bytes)) != -1) {
					outStream.write(bytes, 0, len);
				}
				ins.close();
				outStream.close();
				outStream = null;
				st.execute("update dzcxinfo set xz_time =to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') where id ='"+id+"'");
				con.commit();
				con.setAutoCommit(true);
		}
			return null;
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request,"download.error");
		}finally{
			if(st!=null)
			{
				try {
					st.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(con!=null)
			{
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
