package com.unitop.sysmgr.action;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;
import org.springframework.stereotype.Controller;

import com.unitop.config.Privilege;
import com.unitop.config.PrivilegeConfig;
import com.unitop.config.SystemConfig;
import com.unitop.exception.BusinessException;
import com.unitop.framework.util.ExpOrImp;
import com.unitop.sysmgr.action.project.SendHX;
import com.unitop.sysmgr.bo.CanOperAccReturn;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.Role;
import com.unitop.sysmgr.bo.Usermanage;
import com.unitop.sysmgr.dao.ClerkDao;
import com.unitop.sysmgr.form.ClerkForm;
import com.unitop.sysmgr.service.ChanpcdService;
import com.unitop.sysmgr.service.ClerkManageService;
import com.unitop.sysmgr.service.Logservice;
import com.unitop.sysmgr.service.OrgService;
import com.unitop.sysmgr.service.PrivilegeService;
import com.unitop.sysmgr.service.RoleService;
import com.unitop.sysmgr.service.SystemMgrService;
import com.unitop.sysmgr.service.impl.ControlRights;

@Controller("/clerkManage")
public class ClerkManageAction extends ExDispatchAction {
	@Resource
	private OrgService OrgService;
	@Resource
	private ClerkManageService clerkService;
	@Resource
	private ControlRights controlRights;
	@Resource
	private ChanpcdService ChanpcdService;
	@Resource
	public ClerkDao clerkDao = null;
	@Resource
	private SystemMgrService systemMgrService;
	@Resource
	private RoleService roleService;
	@Resource
	private PrivilegeService privilegeService;
	@Resource
	private Logservice logservice;

	private Properties Properities;


	public ActionForward loadtree(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = request.getParameter("id"); // autoparam
		String clerkOrgNum = request.getParameter("clerkOrgNum"); // otherparam
		List list = OrgService.getOrgChildrenByCode(code);
		PrintWriter writer = null;
		try {
			JSONArray jsonArray = new JSONArray();
			JSONObject jsonObject = new JSONObject();
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			// ��ȡĬ�����л�����
			String rootCode = SystemConfig.getInstance().getRootCode();
			// ��ȡ��Ա����ģʽ:1:���й���;2:���й���
			String clerk_guanlms = SystemConfig.getInstance().getValue("clerk_guanlms");
			if ((!rootCode.equalsIgnoreCase(clerkOrgNum))|| "1".equalsIgnoreCase(clerk_guanlms)) {
				if (code == null || "".equals(code)) { // �״μ���
					if (clerk != null) {
						String orgcode = clerk.getOrgcode(); // ���ص�ǰ����
						jsonObject.put("id", orgcode);
						jsonObject.put("name", clerk.getOrgname());
						jsonObject.put("url", request.getContextPath()+ "/clerkManage.do?method=load&orgcode="+ orgcode);
						jsonObject.put("target", "mainF");
						// �ж��Ƿ����ӽڵ�
						List children = OrgService.getOrgChildrenByCode(orgcode);
						if (children == null || children.size() == 0) {
							jsonObject.put("isParent", "false");
							jsonArray.add(jsonObject);
						} else { // ������һ���������ӽڵ㡿
							jsonObject.put("open", "true");
							jsonArray.add(jsonObject);
							for (int i = 0; i < children.size(); i++) {
								Org org = (Org) children.get(i);
								if (org.getName().contains("(")) {
									continue;
								}
								jsonObject.put("id", org.getCode());
								jsonObject.put("name", org.getName());
								jsonObject.put("pId", orgcode);
								jsonObject.put("url",request.getContextPath()+ "/clerkManage.do?method=load&orgcode="+ org.getCode());
								jsonObject.put("target", "mainF");
								// �ж��Ƿ����ӽڵ� //�����ӽڵ��Ƿ����չ��
								List subChildren = OrgService.getOrgChildrenByCode(org.getCode());
								if (subChildren == null|| subChildren.size() == 0) {
									jsonObject.put("isParent", "false");
								} else {
									jsonObject.put("isParent", "true");
								}
								jsonArray.add(jsonObject);
							}
						}
					} else {
						return this.showMessageJSP(actionMapping, request,"timeout", "��¼��ʱ�������µ�¼!");
					}
				} else { // �������
					List children = OrgService.getOrgChildrenByCode(code);
					for (int i = 0; i < children.size(); i++) { // ����ָ���������ӻ���
						Org org = (Org) children.get(i);
						if (org.getName().contains("(")) {
							continue;
						}
						jsonObject.put("id", org.getCode());
						jsonObject.put("name", org.getName());
						jsonObject.put("url",request.getContextPath()+ "/clerkManage.do?method=load&orgcode="+ org.getCode());
						jsonObject.put("target", "mainF");
						// �ж��Ƿ����ӽڵ�
						List subChildren = OrgService.getOrgChildrenByCode(org.getCode());
						if (subChildren == null || subChildren.size() == 0) {
							jsonObject.put("isParent", "false");
						} else {
							jsonObject.put("isParent", "true");
						}
						jsonArray.add(jsonObject);
					}
					System.out.println(jsonArray.toString());
				}
			} else {
				if (clerk != null) {
					jsonObject.put("id", clerk.getOrgcode());
					jsonObject.put("name", clerk.getOrgname());
					jsonObject.put("isParent", "false");
					jsonArray.add(jsonObject);
				} else {
					return this.showMessageJSP(actionMapping, request,"timeout", "��¼��ʱ�������µ�¼!");
				}
			}
			response.setContentType("text/json;charset=UTF-8");
			writer = null;
			writer = response.getWriter();
			writer.print(jsonArray.toString());
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request, null);
		} finally {
			writer.close();
		}
		return null;
	}

	// �����������Ӹ��������Ա��ѯ
	public ActionForward loadByclerk(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			boolean addflag = true;
			ClerkForm form = (ClerkForm) actionForm;
			String orgcode = request.getParameter("orgnum");
			String include = request.getParameter("include");
			String guiyh = request.getParameter("guiyh");
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			List<Clerk> list = new ArrayList<Clerk>();
			if (!(guiyh == null || "".equals(guiyh))) {
				Clerk c = clerkDao.getClerkByCode(guiyh);

				if (c != null) {
					List<Org> listorg = OrgService.getOrgList(clerk
							.getOrgcode());
					String quanx = "false";
					for (Org o : listorg) {
						if (c.getOrgcode().equals(o.getCode())) {
							quanx = "ture";
						}
					}
					if ("false".equals(quanx)) {
						request.setAttribute("list", list);
						request.setAttribute("error", "��Ȩ�޲鿴�˹�Ա");
					} else {
						list.add(c);
					}

				} else {
					request.setAttribute("list", list);
					request.setAttribute("error", "���޴˹�Ա");
					// return actionMapping.findForward("list.success");
				}

			} else {
				if ("0".equals(include)) {
					list = clerkDao.getAllClerkByOrgcode(orgcode);
				} else {
					list = this.clerkService.getClerkByOrgcode(orgcode);
				}
			}
			Privilege privilege = ChanpcdService
					.getPostCollectionByName("��Ա����");
			if (clerk.getOrgcode().equals(orgcode)) {
				addflag = true;
			}
			// ���ƹ�Ա�����ӡ���ť����ʾ
			int nowwdflag = Integer.parseInt(OrgService.getOrgByCode(orgcode)
					.getWdflag());
			int lastWdflag = OrgService.getLastWdflag();
			boolean b = nowwdflag > lastWdflag;
			if (b) {
				addflag = false;
			}
			if (addflag)
				request.setAttribute("addflag", "1");
			else
				request.setAttribute("addflag", "0");
			form.setOrgcode(orgcode);
			String errorpasswordtimes = SystemConfig.getInstance().getValue(
					"errorpasswordtimes");
			request.setAttribute("errorpasswordtimes", errorpasswordtimes);
			request.setAttribute("list", list);
			request.setAttribute("orgcode", orgcode);
			request.setAttribute("include", include);
			return actionMapping.findForward("list.success");
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request,
					"list.success");
		}
	}

	/**
	 * ���ع�Ա��Ϣ�б�
	 * 
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward load(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			boolean addflag = true;
			ClerkForm form = (ClerkForm) actionForm;
			String orgcode = request.getParameter("orgcode");
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			List list = this.clerkService.getClerkByOrgcode_(orgcode);
			Privilege privilege = ChanpcdService.getPostCollectionByName("��Ա����");
			if (clerk.getOrgcode().equals(orgcode)) {
				addflag = true;
			} else {
				/*
				 * for (Iterator iter = list.iterator(); iter.hasNext();) {
				 * Clerk element = (Clerk) iter.next(); String postpodeom =
				 * element.getPostpopedom(); int value = new
				 * Integer(privilege.getValue()).intValue(); if (postpodeom ==
				 * null || postpodeom.equals("")) ; else if
				 * (PrivilegeConfig.CheckPrivilege(postpodeom,value)) { addflag
				 * = false; break; } }
				 */
			}
			// ���ƹ�Ա�����ӡ���ť����ʾ
			int nowwdflag = Integer.parseInt(OrgService.getOrgByCode(orgcode).getWdflag());
			int lastWdflag = OrgService.getLastWdflag() + 1;
			boolean b = nowwdflag > lastWdflag;
			if (b) {
				addflag = false;
			}
			if (addflag){
				request.setAttribute("addflag", "1");
			}else{
				request.setAttribute("addflag", "0");
			}
			form.setOrgcode(orgcode);
			String errorpasswordtimes = SystemConfig.getInstance().getValue("errorpasswordtimes");
			request.setAttribute("errorpasswordtimes", errorpasswordtimes);
			request.setAttribute("list", list);
			request.setAttribute("orgcode", orgcode);
			return actionMapping.findForward("list.success");
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request,
					"list.success");
		}
	}

	private ActionForward loadForMessage(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response, String orgCode, String Message) {
		try {
			boolean addflag = true;
			ClerkForm form = (ClerkForm) actionForm;
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			List list = this.clerkService.getClerkByOrgcode(orgCode);
			Privilege privilege = ChanpcdService
					.getPostCollectionByName("��Ա����");
			for (Iterator iter = list.iterator(); iter.hasNext();) {
				Clerk element = (Clerk) iter.next();
				String postpodeom = element.getPostpopedom();
				int value = new Integer(privilege.getValue()).intValue();
				if (postpodeom == null || postpodeom.equals(""))
					;
				else if (PrivilegeConfig.CheckPrivilege(postpodeom, value)) {
					addflag = false;
					break;
				}
			}
			// ���ƹ�Ա�����ӡ���ť����ʾ
			int nowwdflag = Integer.parseInt(OrgService.getOrgByCode(orgCode).getWdflag());
			int lastWdflag = OrgService.getLastWdflag();
			if ((nowwdflag > lastWdflag)) {
				addflag = false;
			}
			if (addflag)
				request.setAttribute("addflag", "1");
			else
				request.setAttribute("addflag", "0");
			form.setOrgcode(orgCode);
			String errorpasswordtimes = SystemConfig.getInstance().getValue("errorpasswordtimes");
			request.setAttribute("errorpasswordtimes", errorpasswordtimes);
			request.setAttribute("list", list);
			return this.showMessageJSP(actionMapping, request, "list.success",Message);
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request,"list.success");
		}
	}

	/**
	 * ɾ����Ա
	 * 
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */

	public ActionForward delete(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = "";
		String orgcode = "";
		Clerk delclerk = null;
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		try {
			code = request.getParameter("code");
			delclerk = clerkService.getClerkByCode(code);
			orgcode = delclerk.getOrgcode();
			String deleteSingle = SystemConfig.getInstance().getValue("deleteSingle");
			request.setAttribute("delclerkpostnum", delclerk.getPostCode());
			// ZZ 10/22 ������Ա����ɾ������
			if ("no".equals(deleteSingle)) {// if("yes".equals(deleteSingle))
				// Ϊ��yes����ʱ���Ƿ����Ϻ���
				// ���ͺ���
				SendHX sendMsg = new SendHX();
				Map<String, String> back_map = sendMsg.sendMessage(request,code, "delClerk");
				if (back_map == null) {
					return this.loadForMessage(actionMapping, actionForm,request, response, orgcode, "ɾ����Աʧ�ܣ�ͳһƽ̨δ������Ϣ");
				}
				if (!"0000".equals(back_map.get("msgcode"))) {
					return this.loadForMessage(actionMapping, actionForm,request, response, orgcode, "ɾ����Աʧ��:ͳһƽ̨��ѯʧ��");
				}
			}
			// ɾ����Ա+��Ա��ɫ��ϵ
			List roleSelectList = clerkService.getRoleByClerk(code);// ��ȡ�ù�Ա�Ľ�ɫ
			clerkService.deleteRoleByClerk(code);
			addlog(clerk, delclerk,roleSelectList, "[ɾ���ɹ�]��Ա��" + delclerk.getName() + "[" + code+ "]", "ɾ����Ա");
			if (delclerk != null) {
				this.createManageLog(clerk.getCode(),"[ɾ���ɹ�]��Ա��" + delclerk.getName() + "[" + code + "]");
			}
		} catch (BusinessException e) {
			return this.errrForLogAndException(e, actionMapping, request, null);
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request, null);
		} finally {
			request.setAttribute("orgcode", delclerk.getOrgcode());
		}
		return this.loadForMessage(actionMapping, actionForm, request,response, orgcode, "[ɾ���ɹ�]��Ա��" + delclerk.getName() + "["+ code + "]");
	}

	public ActionForward unlock(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			String code = request.getParameter("code");
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			Clerk jsclerk = clerkService.getClerkByCode(code);
			if (jsclerk != null) {
				jsclerk.setErrortime(new Integer(0));
				try {
					clerkService.updateClerk(jsclerk);
					String content = "[�����ɹ�]��Ա��" + jsclerk.getName() + "["+ code + "]";
					this.createManageLog(clerk.getCode(), content);
				} catch (BusinessException e) {
					return this.showMessageJSP(actionMapping, request,"list.success", "ϵͳ�쳣������ʧ�ܣ�");
				}
			}
			return this.loadForMessage(actionMapping, actionForm, request,
					response, clerk.getOrgcode(),"[�����ɹ�]��Ա��" + jsclerk.getName() + "[" + code + "]");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request,"list.success");
		}
	}

	/**
	 * ��ת����Ա����ģ��
	 * 
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward forwardCreate(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {

		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		try {
			String orgcode = request.getParameter("orgcode");
			Org org = OrgService.getOrgByCode(orgcode);
			List roleList = this.clerkService.getAllRoleByWDfalg(clerk);
			ClerkForm clerkForm = (ClerkForm) actionForm;
			clerkForm.setOrgcode(orgcode);
			clerkForm.setPostlist(roleList);
			request.setAttribute("rolelist", roleList);
			if (org != null)
				clerkForm.setOrgname(org.getName());
			return actionMapping.findForward("forward.create");
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request,"list.success");
		}
	}

	/**
	 * ������Ա
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * 
	 *            ���Ӳ�����¼��־
	 * @return
	 */
	public ActionForward createClerk(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			// ��ɫ�б�
			String[] selected = request.getParameterValues("s2");
			if (selected == null || selected.length == 0) {
				List roleList = this.clerkService.getAllRoleByClerk(clerk);
				request.setAttribute("rolelist", roleList);
				return this.showMessageJSP(mapping, request, "create.input","�����ӹ�Ա��ɫ��");
			}

			// ����ϵͳ��Ա����
			if (!controlRights.clerkNumControl()) {
				List roleList = this.clerkService.getAllRoleByClerk(clerk);
				request.setAttribute("rolelist", roleList);
				return this.showMessageJSP(mapping, request, "create.input","�����Ĺ�Ա���Ѵ����ޣ�");
			}

			ClerkForm clerkForm = (ClerkForm) form;
			Clerk bo = new Clerk();
			bo.setCode(clerkForm.getCode());
			bo.setName(clerkForm.getName());
			bo.setOrgcode(clerkForm.getOrgcode());
			if (clerkForm.getPassword() == null|| clerkForm.getPassword().length() == 0) {
				SystemConfig systemConfig = SystemConfig.getInstance();
				bo.setPassword(systemConfig.getAdminPassword());
			} else {
				bo.setPassword(clerkForm.getPassword());
			}

			bo.setPostCode(clerkForm.getPostCode());
			String date = this.getSystemMgrService().getSystetemNowDate();
			bo.setUpdateDate(date.substring(0, 10));
			bo.setCreator(clerk.getCode());
			bo.setShOrgCode(clerk.getShOrgCode());
			Org org = OrgService.getOrgByCode(clerkForm.getOrgcode());
			bo.setWdFlag(org.getWdflag());
			boolean flag = false;
			try {
				Clerk clerk_temp = clerkService.getClerkByCode(clerkForm.getCode());
				if (clerk_temp.getCode() != "") {
					List roleList = this.clerkService.getAllRoleByClerk(clerk);
					request.setAttribute("rolelist", roleList);
					return this.showMessageJSP(mapping, request,"create.input", "��Ա�����Ѵ���!");
				}
				String addSingle = SystemConfig.getInstance().getValue("addSingle");
				if ("yes".equals(addSingle)) {// ����ͳһ��¼ƽ̨
					// ����ͨ�ſ�ʼ--------------------------begin
					SendHX sendMsg = new SendHX();
					Map<String, String> back_map = sendMsg.sendMessage(request,
							clerkForm.getCode(), "addUser");
					if (back_map == null) {
						return this.showMessageJSP(mapping, request,"create.input", "����ʧ�ܣ�ͳһƽ̨δ������Ϣ");
					}
					if (!"0000".equals(back_map.get("msgcode"))) {
						return this.showMessageJSP(mapping, request,"create.input", "����ʧ�ܣ�ͳһƽ̨��ѯʧ��");
					}
					// ռ��postnum�ֶδ洢ͳһƽ̨���Խ�����ӡϵͳ�ĵ�¼��ʽ��0���� 1ָ��
					bo.setPostCode(request.getParameter("zcfs"));
					// ����ͨ�Ž���--------------------------end
				}

				// �����Ա+��Ա��ɫ
				clerkService.save(bo, selected);
				flag = true;
			} catch (BusinessException e) {
				processBusinessException(mapping, request, e);
				return mapping.findForward("create.input");
			}
			String admincode = ((Clerk) request.getSession().getAttribute("clerk")).getCode();
			String content = "[����ɹ�]��Ա��" + bo.getName() + "[" + bo.getCode()+ "]";
			this.createManageLog(admincode, content);

			// ��Ա�����ɹ�ʱ ������־
			// ��Ҫ�������У������ţ��������ƣ�����ѯ�˹�Ա�� ��ѯ�˹����֣���ѯ���� ����ѯʱ�� ���������ͣ� ��ע
			List roleSelectList = clerkService.getRoleByClerk( bo.getCode());// ��ȡ�ù�Ա�Ľ�ɫ 
			addlog(clerk, bo,roleSelectList , content, "������Ա");
			if (flag) {
				clerkForm.clear();
				return this.showMessageJSP(mapping, request, "load", content);
			}
			ActionForward forward = mapping.findForward("load");
			String path = forward.getPath();
			path = path + "&orgcode=" + bo.getOrgcode();
			return forward;
		} catch (Exception e) {
			return this.errrForLogAndException(e, mapping, request,
					"create.input");
		}
	}

	// ��¼������־
	private void addlog(Clerk clerk1, Clerk clerk2 , List rolelist, String content,String caozuo) {
		Calendar calendar = Calendar.getInstance(); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat dateFormat_ = new SimpleDateFormat("hh:mm:ss");
		String chaxrq = dateFormat.format(calendar.getTime());
		String chaxtime = dateFormat_.format(calendar.getTime());
		Usermanage usermanage = new Usermanage();
		usermanage.setBeiz(content);
		usermanage.setChaxrq(chaxrq);
		usermanage.setChaxtime(chaxtime);
		usermanage.setJigouhao(clerk1.getOrgcode());
		usermanage.setJigouname(clerk1.getOrgname());
		usermanage.setMaintenance(caozuo);
		String jues = "";
		for (Object object : rolelist) {
			jues = "["+((Role)object).getJuesmc()+"] " + jues;
		}
		usermanage.setUserjues(jues);
		usermanage.setUserid(clerk2.getCode());
		usermanage.setUsername(clerk2.getName());
		usermanage.setClerkcode(clerk1.getCode());
		usermanage.setClerkname(clerk1.getName());
		logservice.addusermanage(usermanage);
	}

	/**
	 * ��ת���޸Ĺ�Ա��Ϣģ��
	 * 
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward forwardupdate(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			String admincode = ((Clerk) request.getSession().getAttribute("clerk")).getCode();
			String code = request.getParameter("code");
			Clerk clerk = clerkService.getClerkByCode(code);
			List roleList = clerkService.getElseRoleByClerk(admincode, code);// ��ȡ�����ڸù�Ա�Ľ�ɫ
			List roleSelectList = clerkService.getRoleByClerk(code);// ��ȡ�ù�Ա�Ľ�ɫ
			ClerkForm clerkForm = (ClerkForm) actionForm;
			clerkForm.setCode(clerk.getCode());
			clerkForm.setName(clerk.getName());
			clerkForm.setPostCode(clerk.getPostCode());
			clerkForm.setPostlist(roleList);
			clerkForm.setOldcode(clerk.getCode());
			clerkForm.setOrgcode(clerk.getOrgcode());
			clerkForm.setPassword(clerk.getPassword());
			clerkForm.setPassword1(clerk.getPassword());
			request.setAttribute("rolelist", roleList);
			request.setAttribute("roleselectlist", roleSelectList);
			return actionMapping.findForward("forward.update");
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request,"list.success");
		}
	}

	/**
	 * �޸Ĺ�Ա��Ϣ
	 * 
	 * @param mapping
	 * @param actionform
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward updateClerk(ActionMapping mapping,
			ActionForm actionform, HttpServletRequest request,
			HttpServletResponse response) {
		ClerkForm form = (ClerkForm) actionform;
		try {
			// ��ɫ�б�
			String[] selected = request.getParameterValues("s2");
			String orgcode = form.getOrgcode();
			Org org = OrgService.getOrgByCode(orgcode);
			if (org == null) {
				return this.showMessageJSP(mapping, request, "update.error","�����Ų����ڣ�");
			}
			if (selected == null || selected.length == 0) {
				Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
				List roleList = this.clerkService.getAllRoleByClerk(clerk);
				request.setAttribute("rolelist", roleList);
				return this.showMessageJSP(mapping, request, "update.error","�����ӹ�Ա��ɫ��");
			}

			if (!form.getPassword().equals(form.getPassword1())) {
				return this.showMessageJSP(mapping, request, "update.error","�����������벻һ��!");
			}

			Clerk clerk = clerkService.getClerkByCode(form.getOldcode());
			clerk.setOrgcode(orgcode);
			clerk.setCode(form.getCode());
			clerk.setName(form.getName());
			clerk.setPassword(form.getPassword());
			clerk.setWdFlag(org.getWdflag());
			// clerk.setPostCode(form.getPostCode());
			boolean flag = clerkService.updateClerkRoles(clerk, selected);
			String content = "";
			String admincode = ((Clerk) request.getSession().getAttribute("clerk")).getCode();
			if (flag) {
				form.setOldcode(clerk.getCode());
				content = "[�޸ĳɹ�]��Ա��" + clerk.getName() + "[" + clerk.getCode()+ "]";
				this.createManageLog(admincode, content);
				List roleList = clerkService.getElseRoleByClerk(admincode,form.getCode());// ��ȡ�����ڸù�Ա�Ľ�ɫ
				List roleSelectList = clerkService.getRoleByClerk(form.getCode());// ��ȡ�ù�Ա�Ľ�ɫ
				request.setAttribute("rolelist", roleList);
				request.setAttribute("roleselectlist", roleSelectList);
				addlog(((Clerk) request.getSession().getAttribute("clerk")),clerk , roleSelectList, content, "�޸Ĺ�Ա");
				return this.showMessageJSP(mapping, request, "load", content);
			} else {
				content = "[�޸�ʧ��]��Ա��" + clerk.getName() + "[" + clerk.getCode()+ "]";
				List roleSelectList = clerkService.getRoleByClerk( clerk.getCode());// ��ȡ�ù�Ա�Ľ�ɫ
				addlog(((Clerk) request.getSession().getAttribute("clerk")),clerk,roleSelectList, content, "�޸Ĺ�Ա");
				this.createManageLog(admincode, content);
				return this.showMessageJSP(mapping, request, "update.error",content);
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request,"update.error");
		}
	}

	/**
	 * ��д download������������Ա��Ϣ
	 */
	public ActionForward download(ActionMapping mapping, ActionForm actionForm,
			HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, BusinessException {
		String file = "clerk.xls";
		String orgcode = request.getParameter("orgcode");
		String include = request.getParameter("include");
		Map map = new HashMap();
		List list = null;
		try {
			list = clerkService.exportClerk(orgcode, include);

			if (list.size() > 0) {
				HSSFWorkbook wb = ExpOrImp.exportExcel("clerk", list, 7);
				response.setHeader("Content-disposition",
						"attachment;filename=" + file);
				response.setContentType("application/rar");
				response.setContentLength(wb.getSheetIndex(file));
				ServletOutputStream out = response.getOutputStream();
				wb.write(out);
				out.flush();
			} else {
				throw new BusinessException("����ļ������ڣ�");
			}
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return this.showMessageJSP(mapping, request, "load",
					getPromptService().getPromptMsg("YYA-export-error", map));
		}
	}

	/**
	 * �����Ա��Ϣ
	 */
	@SuppressWarnings("unchecked")
	public ActionForward importClerk(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		ClerkForm form = (ClerkForm) actionForm;
		FormFile file = (FormFile) form.getFile();
		Map map = new HashMap();
		InputStream input = null;
		try {
			input = file.getInputStream();
			int size = input.available();
			if (size <= 0) {
				return this.showMessageJSP(mapping, request, "load",
						"�ϴ��ļ�Ϊ����Ϊ��!");
			}
			input = file.getInputStream();
			POIFSFileSystem fs = new POIFSFileSystem(input);
			HSSFWorkbook wb = new HSSFWorkbook(fs);
			HSSFSheet sheet = wb.getSheetAt(0);
			boolean isImport = false;
			isImport = clerkService.importClerk(sheet);
			if (isImport) {
				return this.showMessageJSP(mapping, request, "load",
						getPromptService().getPromptMsg("YYA-import-ok", map));
			} else {
				return this.showMessageJSP(mapping, request, "load",
						getPromptService()
								.getPromptMsg("YYA-import-error", map));
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, mapping, request, "load");
		} finally {
			request.setAttribute("orgcode", request.getParameter("orgcode"));
		}
	}

	// ˫�˻�ǩ
	public ActionForward shuangrhq(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String clerkCode = request.getParameter("clerknum");
		String clerkPwd = request.getParameter("password");
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		String titleName = "";
		// String account = request.getParameter("account");
		try {
			// ajax���󴫹���������Ҫ����
			titleName = URLDecoder.decode(request.getParameter("titleName"),"utf-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		PrintWriter out = null;
		try {
			out = response.getWriter();
			response.setContentType("text/xml");
			response.setLocale(Locale.SIMPLIFIED_CHINESE);
			Clerk clerk_ = (Clerk) clerkService.getClerkByCode(clerkCode);
			if ("".equals(clerk_.getCode())) {
				out.println("0");// ��Ա������
				return null;
			}
			if (clerk_.getCode().equals(clerk.getCode())) {
				out.println("4");// ��ǩ��Ա�����ǵ�¼��Ա
				return null;
			}
			if (clerk.getOrgcode().endsWith(clerk_.getOrgcode())) { // ͬһ����
				boolean flag = false;
				// �ж���Ȩ��Ա�Ƿ�����ȨȨ��
				SystemConfig systemConfig = SystemConfig.getInstance();
				if (clerk_.getCode().equals(systemConfig.getAdminCode())) { // ��è����Ȩ���ж�
					flag = true;
				} else {
					List<Role> roles = clerkService.getAllRoleByClerk(clerk_);
					for (Role role : roles) {
						List<com.unitop.sysmgr.bo.Privilege> privileges = privilegeService
								.getPrivilegeList(role.getJuesid());
						for (com.unitop.sysmgr.bo.Privilege privilege : privileges) {
							if (privilege.getChecked()
									&& "��ȨȨ��".equals(privilege.getName())) { // ����ȨȨ��
								flag = true;
							}
						}
					}
				}
				if (flag) {
					if (clerkPwd.equals(clerk_.getPassword())) {
						// �ж��Ƿ�ǿ���޸�����
						if ("0".equals(clerk_.getClerkstatus())) { // ��Ȩ��Աû���޸�����
																	// //�жϹ�Ա�Ƿ���������
							if ("1".equals(SystemConfig.getInstance().getValue(
									"clerk_firstlogincpw"))) {
								out.println("5");
								return null;
							}
						}
						out.println("1");// ˫ǩ�ɹ�
						// ˫ǩ��־��¼�������������
						/*
						 * if(account!=null) {
						 * this.createAccountManageLog(account
						 * ,"��ǩ",titleName+"��ǩ", clerk_); }
						 */
					} else {
						out.println("2");// �������
					}
				} else {
					out.println("6");// û����ȨȨ��
				}

				return null;
			} else {
				out.println("3");// ������ͬһ����
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			// return this.errrForLogAndException(e, mapping, request, null);
		} finally {
			if (out != null) {
				out.close();
			}
		}
		return null;
	}

	/*
	 * �жϵ�¼��Ա�������Ա��ɫ�����С
	 */
	public ActionForward validateClerks(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String denglguiy = request.getParameter("denglguiy");
		String caozguiy = request.getParameter("caozguiy");
		PrintWriter out = null;
		try {
			out = response.getWriter();
			String denglguiyJuesJB = clerkService.getClerkJusjb(denglguiy);
			String caozguiyJuesJB = clerkService.getClerkJusjb(caozguiy);
			if (Integer.valueOf(denglguiyJuesJB) >= Integer
					.valueOf(caozguiyJuesJB)) {
				out.write("1");
			} else {
				out.write("0");
			}
			return null;
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, null);
		} finally {
			if (out != null) {
				out.close();
			}
			return null;
		}
	}

	// ���ӹ�Ա�������ù���

	/**
	 * ��ת����Ա��������
	 * 
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward forwardReset(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {

		return actionMapping.findForward("forward.reset");
	}

	/**
	 * ��������
	 * 
	 * @param mapping
	 * @param actionform
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward resetPassword(ActionMapping mapping,
			ActionForm actionform, HttpServletRequest request,
			HttpServletResponse response) {
		ClerkForm form = (ClerkForm) actionform;
		Clerk clerk1 = (Clerk) request.getSession().getAttribute("clerk");
		try {
			Clerk clerk = new Clerk();
			clerk = clerkService.getClerkByCode(form.getCode());
			if (clerk.getCode() != null && !"".equals(clerk.getCode())) {
				clerk.setIp(null);
				clerk.setErrortime(0);
				String password = SystemConfig.getInstance().getValue(
						"adminPassword");
				clerk.setPassword(password);
				clerkService.updateClerk(clerk);
				String content = "";
				String admincode = ((Clerk) request.getSession().getAttribute(
						"clerk")).getCode();
				content = "��Ա" + clerk1.getName() + "��" + clerk1.getCode()
						+ "�������˹�Ա" + clerk.getName() + "��" + clerk.getCode()
						+ "�������룬��ʼ����Ϊ��" + password;
				this.createManageLog(admincode, content);
				return this.showMessageJSP(mapping, request, "forward.reset",
						content);
			} else {
				return this.showMessageJSP(mapping, request, "forward.reset",
						"��Ա������!");
			}
		} catch (BusinessException e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "");
		}
	}

	/**
	 * ��ȡ��Ա��Ϣ
	 * 
	 * @param mapping
	 * @param actionform
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward getClerkName(ActionMapping mapping,
			ActionForm actionform, HttpServletRequest request,
			HttpServletResponse response) {
		PrintWriter out;
		response.setContentType("text/xml");
		response.setLocale(Locale.SIMPLIFIED_CHINESE);
		response.setCharacterEncoding("GBK");
		String clerkinfo = "";
		try {
			out = response.getWriter();

			String code = request.getParameter("code"); // Ҫ�����õĹ�Ա��
			Clerk currentClerk = (Clerk) request.getSession().getAttribute(
					"clerk");
			Clerk resetClerk = clerkService.getClerkByCode(code);
			if (resetClerk.getCode() == null || "".equals(resetClerk.getCode())) {
				clerkinfo = "2";
			} else {
				CanOperAccReturn proCanOperTel = systemMgrService
						.ProCanOperTel(currentClerk.getOrgcode(), code);

				if (proCanOperTel.getReturnValue()) {
					clerkinfo = "1," + resetClerk.getName();
				} else {
					clerkinfo = "0," + proCanOperTel.getReturnMessage();
				}
			}
			out.print(clerkinfo);
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}