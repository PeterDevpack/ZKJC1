package com.unitop.sysmgr.action;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.config.Rights;
import com.unitop.config.SystemConfig;
import com.unitop.framework.util.IPTool;
import com.unitop.framework.util.PasswordUtil;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.SystemControlParameter;
import com.unitop.sysmgr.form.LoginForm;
import com.unitop.sysmgr.service.BusinessService;
import com.unitop.sysmgr.service.ClerkManageService;
import com.unitop.sysmgr.service.InitSystem;
import com.unitop.sysmgr.service.OrgService;
import com.unitop.sysmgr.service.PrivilegeService;
import com.unitop.sysmgr.service.ZhanghxzService;
import com.unitop.sysmgr.service.impl.ControlRights;

@Controller("/login")
public class LoginAction extends ExDispatchAction {
	@Resource
	private ControlRights controlRights;	
	@Resource
	private BusinessService businessService;
	@Resource
	private ClerkManageService clerkManageService;
	@Resource
	private PrivilegeService privilegeService;
	@Resource
	private OrgService OrgService;
	@Resource
	private InitSystem InitSystem;
	@Resource
	private ZhanghxzService zhanghxzService;
	/*
	 * ��Ա��¼ �߼�
	 */
	public ActionForward loginsys(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response){
		//��ʼ��
		LoginForm loginForm = (LoginForm) form;
		String clerkCode = null;
		boolean manageFlag=false;
		InitSystem.synchronousSystemParameters();
		SystemConfig systemConfig = SystemConfig.getInstance();
		Date rightNow = Calendar.getInstance().getTime();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String date = format.format(rightNow);
		SystemControlParameter scp = this.getQueryService().findSystemControlParameterById("datasync");
		if("t".equals(scp.getValue())){
			businessService.getYewgzRules();
			getPromptService().getTisxxMap();
			try {
				controlRights.control();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else{
			businessService.getBusinessRules();//����ҵ�������Ϣ���ڴ�
			getPromptService().getPromptMap();//���ؽ�����ʾ��Ϣ
		}
		try {
			//�汾����
			String state = controlRights.control();
			clerkCode = loginForm.getCode();
			Clerk clerk = clerkManageService.getClerkByCode(clerkCode);
			System.out.println("+++++++clerk"+clerk);
		  /*String juesjb = clerkManageService.getClerkJusjb(clerkCode);
			List rolelist = clerkManageService.getRoleByClerk(clerkCode);
			for(int i=0;i<rolelist.size();i++){
				Role role = (Role)rolelist.get(i);
				String juesid = role.getJuesid();
			}*/
			if("��������".equals(state))
			{
				return this.showMessageJSP(mapping,request,"login.error","��ϵͳΪ���ð棬���������ѹ���");
			}else if("�ն�����".equals(state))
			{
				return this.showMessageJSP(mapping, request, "login.error", "ͬʱ�������������ޣ�");
			}else if("�汾����".equals(state))
			{
				return this.showMessageJSP(mapping, request, "login.error", "û��Ȩ��ʹ�ô�ϵͳ");
			}
			if("shiyong".equals(controlRights.getControlMap().get("version")))
			{
				String product_period = "�����ڣ�"+ controlRights.getControlMap().get("productperiod")+"  �汾�ţ�"+controlRights.getControlMap().get("versionnum");
				request.getSession().setAttribute("product_period",product_period);
			}else{
				request.setAttribute("orgCode", clerk.getOrgcode());
				request.getSession().setAttribute("product_period","��ʽ��   �汾�ţ�"+controlRights.getControlMap().get("versionnum"));
			}
			 // ���жϹ�Ա�Ƿ����
			if (clerk == null||"".equals(clerk.getCode()))
			{
				return this.showMessageJSP(mapping,request,"login.error","��Ա������!");
			}else{
				//��ù�Ա��Ϣ
				String update = clerk.getUpdateDate();
				Integer errorTime = clerk.getErrortime()==null?new Integer(0):clerk.getErrortime();
				Org parent_org = OrgService.getOrgByCode(clerk.getShOrgCode());
				clerk.setShOrgName(parent_org.getName());
				Org org = OrgService.getOrgByCode(clerk.getOrgcode());
				clerk.setOrgname(org.getName());
				clerk.setZhiszh(org.getZhiszh());
				
				//���ù�ԱȨ�ޱ�ʶ ���ݻ����㼶��1��ʼ
				if("1".equals(org.getWdflag())||"2".equals(org.getWdflag()))
				{
					manageFlag =true;
				}
				
				/*
				 * �жϵ�½�����Ƿ���ȷ
				 */ 
				if (clerk.getPassword().equals(loginForm.getPassword()))
				{
					//������ȷ���жϵ�½��������Ƿ񳬹�6��
					if (errorTime.intValue() > (Integer.valueOf(systemConfig.getValue("errorpasswordtimes"))-1))  
					{
						return this.showMessageJSP(mapping,request,"login.error","��������������࣬�û���������");
					}
					clerk.setErrortime(0);
					clerkManageService.setErrorNum(clerk.getCode(), "0");//���������ȷ���������������
					
					if(clerk.getPassword().equals("888888")){
						request.getSession().setAttribute("clerk", clerk);
						return super.showMessageJSP(mapping, request, "changepwd.success", "�޸�����");
					}
					
					//�жϵ�½IP�Ƿ�����
					String ipaddress = IPTool.getIpAddr(request);
					Clerk ip_clerk = clerkManageService.getClerkCountByIp(ipaddress);
					
					//�жϹ�Աip�Ƿ��Ǳ�����ip��������ǣ�����ʾ��
					if (clerk.getIp() != null&&!ipaddress.equals(clerk.getIp()))
					{   
						Map<String, String> map = new HashMap<String, String>();
						map.put("clerknum", clerk.getCode());
						map.put("clerkip", clerk.getIp());
						return this.showMessageJSP(mapping,request,"login.error",getPromptService().getPromptMsg("YYA-ip_err1", map));						
					}
					
					//�����ԱipΪ�գ���ͳ�Ʊ������Ѿ���¼�Ĺ�Ա�����������0��˵����������Ա�ڱ�����¼��������ʾ
					if(ip_clerk!=null&&!ipaddress.equals(clerk.getIp()))
					{
						Map<String, String> map = new HashMap<String, String>();
						map.put("clerknum", ip_clerk.getCode());
						return this.showMessageJSP(mapping,request,"login.error",getPromptService().getPromptMsg("YYA-ip_err2", map));
					}
					
					//�жϵ�½��ԱȨ��
					if (manageFlag&&systemConfig.getAdminCode().equals(loginForm.getCode()))
					{
						//��ʶ�˹�ԱΪ��ϵͳ����Ա��
						clerk.setSysManager("administrator");
					}
					//�жϵ�½��ԱȨ��
					if (manageFlag&&(clerk.getOrgcode()+systemConfig.getSuperManager()).equals(loginForm.getCode()))
					{
						//��ʶ�˹�ԱΪ��ϵͳ����Ա��
						clerk.setSysManager("administrator");
					}
					
					if (clerk.getIp() == null)
					{//20170517 sun
						//clerk.setIp(ipaddress);
						clerkManageService.updateClerk(clerk);
						clerk.setIp(ipaddress);
						clerk.setPassword(PasswordUtil.decodePwd(clerk.getPassword()));
					}
					
					//�ж�����ʹ�������Ƿ�>7��
					if (update != null && !"".equals(update))
					{
						Date updatedate = format.parse(update);
						long mm=rightNow.getTime()-updatedate.getTime();
						long day=mm/(24*60*60*1000);
						if(day> (Integer.valueOf(systemConfig.getValue("changpassworddays"))))
						{
							request.getSession().setAttribute("clerk", clerk);
							request.setAttribute("flag", "1");
							this.showMessageJSP(mapping,request,"login.error","����ʹ������>"+systemConfig.getValue("changpassworddays")+"�죡���޸���������µ�½");
							return mapping.findForward("changepwd.success");
						}						
					}
					
					/*
					 * ��ȡ��Ա��ɫȨ�޼���
					 */
					Map juesMap =  privilegeService.getPrivilegeForMenue(clerkCode);
					//��è������ɫ�ǿ��ж�   JZ
					if(!systemConfig.getAdminCode().equals(loginForm.getCode())&&juesMap.isEmpty()){
						return this.showMessageJSP(mapping,request,"login.error","��ǰ��Աû�з����ɫ,���ҹ���Ա�����ɫ���ٵ�½!");
					}
					clerk.setJuesMap(juesMap);
					String roleName = clerkManageService.getClerkByOrgClerkName(clerkCode);
					String juesid = clerkManageService.getClerkByOrgClerkJues(clerkCode);
					clerk.setPostCode(juesid);
					clerk.setPostName(roleName);
				}else{	
					//��Сè�����û�����
					if (!(manageFlag&&systemConfig.getSuperManager().equals(loginForm.getCode()))) 
					{	
						if (errorTime.intValue() > (Integer.valueOf(systemConfig.getValue("errorpasswordtimes"))-2))  
						{
							clerkManageService.setErrorNum(clerk.getCode(),"6");
							return this.showMessageJSP(mapping,request,"login.error","��������������࣬�û�������!");
						}
						if (clerk.getLogDate() == null || "".equals(clerk.getLogDate()))
						{
							clerk.setLogDate(date);
						}
						if (date.equals(clerk.getLogDate()))
						{
							if(clerk.getErrortime()==null || "".equals(clerk.getErrortime()))
							{
								clerk.setErrortime(0);
							}
							clerk.setErrortime(new Integer(clerk.getErrortime().intValue() + 1));
						} else if (errorTime.intValue() < (Integer.valueOf(systemConfig.getValue("errorpasswordtimes"))-1))
						{
							clerk.setErrortime(new Integer(1));
							clerk.setLogDate(date);
						}
						clerkManageService.updateClerk(clerk);
						Map<String,String> map = new HashMap<String,String>();
						map.put("clerknum",clerk.getCode());
						map.put("n_error",""+clerk.getErrortime());
						map.put("leavetimes",""+(Integer.valueOf(systemConfig.getValue("errorpasswordtimes"))-clerk.getErrortime()));
						return this.showMessageJSP(mapping,request,"login.error",getPromptService().getPromptMsg("YYA-pwdError", map));
					}
					request.setAttribute("orgCode", clerk.getOrgcode());
					Map<String,String> errormap = new HashMap<String,String>();
					return this.showMessageJSP(mapping,request,"login.error",getPromptService().getPromptMsg("YYA-pwdErrorCat", errormap));
				}
			}
			
			HttpSession session = request.getSession();
			session.setMaxInactiveInterval(Integer.valueOf(systemConfig.getValue("outtime")));
			
			//��¼��Ա��¼����
			clerk.setLoginDate(date);
			session.setAttribute("clerk",clerk);
			//Cookie orgcode = new Cookie("orgcodecookie",loginForm.getOrgCode());
			Cookie orgcode = new Cookie("orgcodecookie",clerk.getOrgcode());			
			orgcode.setMaxAge(60 * 60 * 24 * 90);
			response.addCookie(orgcode);
			this.createManageLog(clerkCode,"��½",clerk);		
			clerkManageService.setErrorNum(clerk.getCode(),"0");
			Rights.getInstance().setNowonline(Rights.getInstance().getNowonline()+1);//������������
			
			//�ض���
			ActionForward forward = mapping.findForward("login.success");
			forward = new ActionForward(forward);
			forward.setRedirect(true);
			return forward;
			
//			return mapping.findForward("login.success");
		} catch (Exception e) {
			e.printStackTrace();
			logString.append("(" + getClass() + ") ���룺��Ա�� " + clerkCode);
			return this.errrForLogAndException(e, mapping, request,"login.error");
		}finally{
			loginForm.setPassword(null);
		}
	}
	
	/*
	 * ǿ��ǩ��
	 * 	
	 */
	public ActionForward forcedtosign(ActionMapping mapping, ActionForm form,
			HttpServletRequest request,HttpServletResponse response){
			LoginForm loginForm = (LoginForm) form;
			try {
				String clerkCode = loginForm.getCode();
				Clerk clerk = clerkManageService.getClerkByCode(clerkCode);
				if (clerk == null)
				{
					return this.showMessageJSP(mapping,request,"forcedtosign.error","��Ա������!");
				}else{
					
					if(clerk.getIp()==null)
					{
						return this.showMessageJSP(mapping,request,"forcedtosign.error","��Աû������,����Ҫǩ��!");
					}else{
						if(!clerk.getPassword().equals(loginForm.getPassword()))
						{
							return this.showMessageJSP(mapping,request,"forcedtosign.error","�������!");
						}
						clerk.setIp(null);
						clerkManageService.updateClerk(clerk);
						this.showMessageJSP(mapping,request,"login.error","��Ա��:["+clerk.getCode()+"],ǩ�˳ɹ�!");
						return mapping.findForward("login.error");
					}
				}
			} catch (Exception e){
				return this.errrForLogAndException(e, mapping, request,"forcedtosign.error");
			}finally{
				loginForm.setPassword(null);
			}
	}
}
