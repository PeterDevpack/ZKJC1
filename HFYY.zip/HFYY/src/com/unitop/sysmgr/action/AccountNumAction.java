package com.unitop.sysmgr.action;


import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.sysmgr.bo.AccountNum;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.form.AccountnumForm;
import com.unitop.sysmgr.service.ZhanghbService;

@Controller("/accountnum")
public class AccountNumAction extends ExDispatchAction {
	@Resource
	ZhanghbService ZhanghbService;

	public ActionForward show(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			AccountnumForm aform = (AccountnumForm) actionForm;
			aform.setNetpointflag("");
			request.setAttribute("orgNum", "");
			request.setAttribute("AccountNum", null);
			return actionMapping.findForward("accountnum.show");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountnum.show");
		}
	}
	
	/*
	 * �°�NETocx �˻�����ͳ�� �鿴
	 */
	public ActionForward showForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			AccountnumForm aform = (AccountnumForm) actionForm;
			//������ػ�����
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			//��Ա����������
			aform.setNetpointflag( clerk.getOrgcode());
			return actionMapping.findForward("accountnum.show.net");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountnum.show.net");
		}
	}
	
	//1226 �˻�ͳ��
	/*public ActionForward view(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		
			//���
			ZhanghForm zhanghform = (ZhanghForm)actionForm;
			//ȡ�õ�½��Ա
			Clerk clerk2 = (Clerk)request.getSession().getAttribute("clerk");
			try{								
				//��ȡJsonstr
				//��ȡ��¼��Ա������
				String code2=clerk2.getOrgcode();	
				String include=zhanghform.getInclude();
				JSONArray jsonArray = new JSONArray();	
				//ȡ�õ�½��ԱȨ���µĻ���
				List<Org> orgList=orgDao.getAllOrg(code2);
				for(Org orgltem:orgList){											
							JSONObject jsonObject = new JSONObject();
							jsonObject.put("id", orgltem.getCode());
							jsonObject.put("pId", orgltem.getParentCode());
							jsonObject.put("name", orgltem.getName());
							jsonObject.put("wdflag", orgltem.getWdflag());
							if(code2.equals(orgltem.getCode())){
								jsonObject.put("open", "true");					
								jsonObject.put("nocheck", false);
							}
							jsonArray.add(jsonObject);
							//���ӱ���
							if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
								jsonObject.put("id","banb"+orgltem.getCode());
								jsonObject.put("pId", orgltem.getCode());
								jsonObject.put("name", orgltem.getName()+"(����)");
								jsonArray.add(jsonObject);
							}
					}
					String str=jsonArray.toString();
					request.setAttribute("Jsonstr",str);
					String zhanghxz=zhanghform.getZhanghxz().replace("'", "");
					String shenhzt=zhanghform.getZhanghshzt().replace("'", "");
					String zhanghzt=zhanghform.getZhanghzt().replace("'", "");
//					if("".equals(zhanghxc)||null==zhanghxc){zhanghxc="ȫ��";}
//					if("".equals(shenhzt)||null==shenhzt){shenhzt="ȫ��";}
//					if("".equals(zhanghzt)||null==zhanghzt){zhanghzt="ȫ��";}
					request.setAttribute("leib",zhanghxz);
					request.setAttribute("shzt",shenhzt);
					request.setAttribute("zhzt",zhanghzt);
					
					//��ȡ����Ļ�����
					String jigh2= zhanghform.getJigh2();  //request.getParameter("jigh2");
					if(!(jigh2==null||"".equals(jigh2))){
						if(clerk2!=null){
							boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk2.getOrgcode(),jigh2);
							if(!bool){
								return super.showMessageJSPforcx(actionMapping, request, "accountnum", "��û��Ȩ�޲鿴:["+jigh2+"]�µ��˺�");
							}
						}
						//�жϻ����Ƿ����
						Org org = this.OrgService.getOrgByCode(jigh2);					
						if(org==null){
							return super.showMessageJSPforcx(actionMapping, request, "accountnum", "������Ļ����Ų����ڣ�����������");
						}
						zhanghform.setJigh1(jigh2);
					}else {

						return super.showMessageJSPforcx(actionMapping, request, "accountnum", "����������ţ�");
					}
					
				TabsBo TabsBo = this.createTabsBo(request);   
				ZhanghbServiceImpl ZhanghbServiceImpl =  (ZhanghbServiceImpl) ZhanghbService;
				ZhanghbServiceImpl.setTabsService(TabsBo);
				TabsBo tabsBo = ZhanghbService.searchZhanghInfo(zhanghform);
				this.showTabsModel(request, tabsBo);
//				request.setAttribute("list", tabsBo.getList());
				
				return super.showMessageJSPForFeny(actionMapping,request,tabsBo,"accountnum");
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request, "error");
			}
		}*/
		
	
	/*
	 * �°�NETocx �˻�����ͳ�� ��ѯ
	 */
	public ActionForward accountnumForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountnumForm accountnumform = (AccountnumForm) actionForm;
			String orgnum = accountnumform.getNetpointflag();
			String huobh = accountnumform.getIndustrycharacter();
			String shifbhxj = accountnumform.getRemark();
			/*if (this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),orgnum))
			{
				AccountNum accountnum = ZhanghbService.zhanghNumber(orgnum,huobh,shifbhxj);
				request.setAttribute("AccountNum", accountnum);
			} else {
				return this.showMessageJSP(actionMapping,request,"accountnum.show.net","���������Ч����Ȩ�޲鿴�øĻ�����Ϣ!");
			}*/
			AccountNum accountnum = ZhanghbService.zhanghNumber(orgnum,huobh,shifbhxj);
			request.setAttribute("AccountNum", accountnum);
			accountnumform.setIndustrycharacter(accountnumform.getIndustrycharacter());
			accountnumform.setNetpointflag(accountnumform.getNetpointflag());
			return actionMapping.findForward("accountnum.show.net");
		} catch (Exception e) {
			request.setAttribute("AccountNum", new AccountNum());
			return this.errrForLogAndException(e, actionMapping, request, "accountnum.show.net");
		}
		
	}
}
