package com.unitop.sysmgr.action;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.framework.util.DateTool;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.dao.PassRateDao;
import com.unitop.sysmgr.form.PassRateForm;
import com.unitop.sysmgr.service.OrgService;

//�˻�ͨ����
@Controller("/accountPassRate")
public class AccountPassRateAction extends ExDispatchAction {
	@Resource
	private OrgService orgService;
	
	@Resource
	private OrgDao orgDao;
	
	@Resource
	private PassRateDao passRateDao;

	public ActionForward view(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {	
			
//			Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
//			String code2=clerk2.getOrgcode();	
//			JSONArray jsonArray = new JSONArray();	
//			List<Org> orgList=orgDao.getAllOrg(code2);	
													
//			for(Org orgltem:orgList){											
//					JSONObject jsonObject = new JSONObject();
//					jsonObject.put("id", orgltem.getCode());
//					jsonObject.put("pId", orgltem.getParentCode());
//					jsonObject.put("name", orgltem.getName());
//					jsonObject.put("wdflag", orgltem.getWdflag());
//					if(code2.equals(orgltem.getCode())){
//						jsonObject.put("open", "true");					
//						jsonObject.put("nocheck", false);
//					}
//					jsonArray.add(jsonObject);
//					
//					if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
//						jsonObject.put("id","banb"+orgltem.getCode());
//						jsonObject.put("pId", orgltem.getCode());
//						jsonObject.put("name", orgltem.getName()+"(����)");
//						jsonArray.add(jsonObject);
//					}
//					
//					
//			}	
//			String str=jsonArray.toString();
//			request.setAttribute("Jsonstr",str);
//			request.setAttribute("youqjgstr",code2);	
			
			request.setAttribute("totalRows", new Integer(0));
			//���ڻ���
			String begindate = DateTool.getNowDayForYYYMMDD().substring(0,7)+"-01";
			String enddate = DateTool.getNowDayForYYYMMDD();					
			request.setAttribute("riqfw", begindate);
			request.setAttribute("riqend", enddate);
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "view");
		}
		return mapping.findForward("view");
	}

	public ActionForward select(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
			PassRateForm passRateForm = (PassRateForm) form;
		try {
			//���ڻ���			
			String riqfw=passRateForm.getRiqfw();
			String riqend=passRateForm.getRiqend();										
			request.setAttribute("riqfw", riqfw);
			request.setAttribute("riqend", riqend);
//			String jigh=request.getParameter("orgCode1");
//			String neworg=jigh;
			String jigh=request.getParameter("jigh");
			Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
//			String code2=clerk2.getOrgcode();	
			
//			JSONArray jsonArray = new JSONArray();
//			List<Org> orgList=orgDao.getAllOrg(code2);			
//			for(Org orgltem:orgList){											
//					JSONObject jsonObject = new JSONObject();
//					jsonObject.put("id", orgltem.getCode());
//					jsonObject.put("pId", orgltem.getParentCode());
//					jsonObject.put("name", orgltem.getName());
//					jsonObject.put("wdflag", orgltem.getWdflag());
//					if(code2.equals(orgltem.getCode())){
//						jsonObject.put("open", "true");					
//						jsonObject.put("nocheck", false);
//					}
//					jsonArray.add(jsonObject);
//					//���ӱ���
//					if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
//						jsonObject.put("id","banb"+orgltem.getCode());
//						jsonObject.put("pId", orgltem.getCode());
//						jsonObject.put("name", orgltem.getName()+"(����)");
//						jsonArray.add(jsonObject);
//					}
//			}	
//			String str=jsonArray.toString();								
//			request.setAttribute("totalRows", new Integer(0));	
			if(!(jigh==null||jigh.equals(""))){
				//�жϻ���Ȩ��			
				String res=orgService.CanOperDesOrg(clerk2.getOrgcode(), jigh);
				if(res.equals("2")){
					return this.showMessageJSPforcx(mapping, request, "success","��û��Ȩ�޲鿴:["+jigh+"]�µ��˺ţ�");					
				}else if(res.equals("1")){
					return this.showMessageJSPforcx(mapping, request, "success","���������ڣ�");
				}
			}else{
				return this.showMessageJSPforcx(mapping, request, "success","����������Ϊ�գ�");
			}
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			 Date date = format.parse(riqfw);
			 Date date2 = format.parse(riqend);
			 int days = (int) ((date2.getTime() - date.getTime()) / (1000*3600*24));
			if(riqfw==null||riqfw.equals("")||riqend==null||riqend.equals("")){
				return this.showMessageJSPforcx(mapping, request, "success","��ӡʱ�䲻��Ϊ�գ�");
			}else if(days>90){
				return this.showMessageJSPforcx(mapping, request, "success","��ӡʱ��β��ܳ���90�죡");
			}
			String newjg="";	
//			if(!(jigh==null||"".equals(jigh))){
//				String[] guanljg=jigh.split(",");
//				for(int i =0;i<guanljg.length;i++){
//					Pattern pattern=Pattern.compile("[0-9]*");
//					if(!(pattern.matcher(guanljg[i]).matches())){
//						if("".equals(newjg)){						
//							newjg+=guanljg[i].replaceAll("[a-zA-Z]", "");
//						}else{
//							newjg+=","+guanljg[i].replaceAll("[a-zA-Z]", "");
//						}
//					}else{
//						
//						if("".equals(newjg)){
//							newjg+=guanljg[i];
//						}else{
//							newjg+=","+guanljg[i];
//						}
////							Org o = orgDao.getOrgByCode(guanljg[i]);
////							if(o==null){
////								return this.showMessageJSPforcx(mapping, request, "success", "���������ڣ�");
////							}
////								if(!(o.getGuanljg()==null||"".equals(o.getGuanljg()))){					
////									newjg+=(","+o.getGuanljg());			
////							}
//						}
//					jigh=newjg;
//				}
//			}else{
//				jigh=clerk2.getOrgcode();
//			}
			TabsBo TabsBo = this.createTabsBo(request);  
			TabsBo tabsBo = passRateDao.getAccPassRate(riqfw,riqend,jigh,"",TabsBo);
			this.showTabsModel(request, tabsBo);
			request.setAttribute("totalRows", tabsBo.getCounts());
//			request.setAttribute("Jsonstr",str);
//			request.setAttribute("youqjgstr",neworg);	
//			request.setAttribute("list", list);
//			request.setAttribute("totalRows", list.size());
			if(tabsBo.getCounts()==0)
			{
				return this.showMessageJSPforcx(mapping, request, "success","�޲�ѯ�����");
			}else{
				return mapping.findForward("success");
			}
		} catch (Exception e){
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "view");
		}
	}
}

