package com.unitop.sysmgr.action;

import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.config.SystemConfig;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.form.SealchecklogForm;
import com.unitop.sysmgr.service.OrgService;
import com.unitop.sysmgr.service.YanyinLogService;
import com.unitop.sysmgr.service.impl.QueryServiceImpl;



@Controller("/orgCheckLog_huif")
public class OrgCheckLogAction_huif extends ExDispatchAction {
	@Resource
	private OrgDao orgDao;
	
	@Resource
	private YanyinLogService YanyinLogService;
	@Resource
	private OrgService orgService;
	
	public ActionForward forward(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {			
			Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
			String code2=clerk2.getOrgcode();	
			JSONArray jsonArray = new JSONArray();	
			List<Org> orgList=orgDao.getAllOrg(code2);			
			for(Org orgltem:orgList){											
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("id", orgltem.getCode());
					jsonObject.put("pId", orgltem.getParentCode());
					jsonObject.put("name", orgltem.getName());	
					jsonObject.put("wdflag", orgltem.getWdflag());
					if(code2.equals(orgltem.getCode())){
						jsonObject.put("open", "true");					
						jsonObject.put("nocheck", false);
					}
					jsonArray.add(jsonObject);
					if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
						jsonObject.put("id","banb"+orgltem.getCode());
						jsonObject.put("pId", orgltem.getCode());
						jsonObject.put("name", orgltem.getName()+"(����)");
						jsonArray.add(jsonObject);
					}
			}	
			String str=jsonArray.toString();
			request.setAttribute("Jsonstr",str);
//2017-4-25 sun			
			SystemConfig systemConfig = SystemConfig.getInstance();
			String yanyinLogType =  systemConfig.getValue("yanyinlogType");
			String[] yanyinlogs = yanyinLogType.split("\\|");
			request.setAttribute("yanyinlogs",yanyinlogs);
//			request.setAttribute("youqjgstr",code2);						
			
		} catch (Exception e) {
			return this.errrForLogAndException(e, mapping, request, "list");
		}
		return mapping.findForward("list");
	}

	
	public ActionForward selectRange(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			//��ȡ������Ա
			Clerk clerk =(Clerk) request.getSession().getAttribute("clerk");
			//��ȡ��������
			SealchecklogForm sealchecklogForm = (SealchecklogForm) form;
			request.setAttribute("totalRows", new Integer(0));
			//ѡ������
			String jigh=request.getParameter("orgCode1");			
			//��������
			String jigh1=request.getParameter("jigh1");
			//��ȡ������Ա
			Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
			String code2=clerk2.getOrgcode();	
			JSONArray jsonArray = new JSONArray();	
			List<Org> orgList=orgDao.getAllOrg(code2);			
			for(Org orgltem:orgList){											
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("id", orgltem.getCode());
					jsonObject.put("pId", orgltem.getParentCode());
					jsonObject.put("name", orgltem.getName());	
					jsonObject.put("wdflag", orgltem.getWdflag());
					if(code2.equals(orgltem.getCode())){
						jsonObject.put("open", "true");					
						jsonObject.put("nocheck", false);
					}
					jsonArray.add(jsonObject);
					if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
						jsonObject.put("id","banb"+orgltem.getCode());
						jsonObject.put("pId", orgltem.getCode());
						jsonObject.put("name", orgltem.getName()+"(����)");
						jsonArray.add(jsonObject);
					}
			}	
			String str=jsonArray.toString();
			request.setAttribute("Jsonstr",str);
			
			if(!(jigh1==null||jigh1.equals(""))){		
				//�жϻ���Ȩ��			
				String res=orgService.CanOperDesOrg(clerk.getOrgcode(), jigh1);
				if(res.equals("1")){
					return this.showMessageJSPforcx(mapping, request, "success","���������ڣ�");
				}
				if(res.equals("2")){
					return this.showMessageJSPforcx(mapping, request, "success","û��Ȩ�޲鿴�˻�����");
				}
					jigh=jigh1;
				
				
			}
			String newjigh=jigh;
			String neworg="";
			if(!(jigh==null||"".equals(jigh))){
				String[] guanljg=jigh.split(",");
				for(int i =0;i<guanljg.length;i++){
					Pattern pattern=Pattern.compile("[0-9]*");
					if(!(pattern.matcher(guanljg[i]).matches())){
						if("".equals(neworg)){					
							neworg+=guanljg[i].replaceAll("[a-zA-Z]", "");
						}else{
							neworg+=","+guanljg[i].replaceAll("[a-zA-Z]", "");
						}
					}else{
						if("".equals(neworg)){
							neworg+=guanljg[i];
						}else{
							neworg+=","+guanljg[i];
						}
							Org o = orgDao.getOrgByCode(guanljg[i]);
							if(o==null){
								return this.showMessageJSPforcx(mapping, request, "success", "���������ڣ�");				
							}
							if(!(o.getGuanljg()==null||"".equals(o.getGuanljg()))){					
								neworg+=(","+o.getGuanljg());					
							}
						}
					}
			}
			
			//��ҳ��ѯ
			TabsBo TabsBo = this.createTabsBo(request);
			QueryServiceImpl queryServiceImpl = (QueryServiceImpl) this.getQueryService();
			queryServiceImpl.setTabsService(TabsBo);
			TabsBo tabsBo =null;
			tabsBo = this.getQueryService().finusermanmage(sealchecklogForm.getBegindate(),sealchecklogForm.getEnddate(), neworg);
			this.showTabsModel(request, tabsBo);
			return super.showMessageJSPForFeny(mapping,request,tabsBo,"success");
			
		} catch (Exception e){
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "list");
		}
	}
}
