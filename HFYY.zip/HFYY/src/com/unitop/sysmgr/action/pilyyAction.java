package com.unitop.sysmgr.action;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.sysmgr.bo.Pilyy;

//������ӡ
@Controller("/pilyy")
public class pilyyAction extends ExDispatchAction {	
	public ActionForward view(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {													
			
		} catch (Exception e) {
			return this.errrForLogAndException(e, mapping, request, "view");
		}
		return mapping.findForward("view");
	}	
	
		public ActionForward OCR(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response) {
			try {
				String jsonStr=request.getParameter("OCRJsonStr");
				String jsonStr1=request.getParameter("OCRJsonStr1");
				//��ӡ�������
		        JSONArray jsonarray = JSONArray.fromObject(jsonStr);
		        List<Pilyy> list = (List)JSONArray.toList(jsonarray,Pilyy.class); 
		        //δʶ�𷵻�
		        JSONArray jsonarray1 = JSONArray.fromObject(jsonStr1);	        
		        List<Pilyy> list1 = (List)JSONArray.toList(jsonarray1,Pilyy.class); 
		        int size=list1.size();
				request.setAttribute("list", list);
				request.setAttribute("list1", list1);
				request.setAttribute("size", size);
				
			} catch (Exception e) {
				e.printStackTrace();
				return this.errrForLogAndException(e, mapping, request, "view");
			}
			return mapping.findForward("view");
		}
		//�˹���ӡ
		public ActionForward rengyy(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response) {
			try {
				String zhangh=request.getParameter("zhangh");
				String jine=request.getParameter("jine");
				System.out.println("�˹���ӡ"+zhangh+jine);
				String jsonStr=request.getParameter("OCRJsonStr");
				String jsonStr1=request.getParameter("OCRJsonStr1");
				//��ӡ�������
		        JSONArray jsonarray = JSONArray.fromObject(jsonStr);
		        List<Pilyy> list = (List)JSONArray.toList(jsonarray,Pilyy.class); 
		        //δʶ�𷵻�
		        JSONArray jsonarray1 = JSONArray.fromObject(jsonStr1);	        
		        List<Pilyy> list1 = (List)JSONArray.toList(jsonarray1,Pilyy.class); 
			
				request.setAttribute("list", list);
				request.setAttribute("list1", list1);
				
			} catch (Exception e) {
				e.printStackTrace();
				return this.errrForLogAndException(e, mapping, request, "view");
			}
			return mapping.findForward("view");
		}		
}

