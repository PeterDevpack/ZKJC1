package com.unitop.sysmgr.action;

import java.io.PrintWriter;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.JiejrBo;
import com.unitop.sysmgr.service.AjaxService;
import com.unitop.sysmgr.service.JiejrService;

//ajax �첽����
@Controller("/ajax")
public class AjaxAction extends ExDispatchAction {
	
	@Resource
	private AjaxService ajaxServicel;
	@Resource
	private JiejrService jiejrService;
	
	public ActionForward getMessage(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request,HttpServletResponse response) {
		String sql = request.getParameter("sql");
		String message = request.getParameter("message");
		try {
			message = ajaxServicel.ajax(sql,message);
			response.setContentType("text/xml");
			response.setLocale(Locale.SIMPLIFIED_CHINESE);
			response.setCharacterEncoding("GBK");
			PrintWriter out = response.getWriter();
			out.println(message);
			out.close();
			return null;
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, null);
		}
	}
	
	
	//��ȡ�ڼ��չ���
	public ActionForward getJiejrgl(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request,HttpServletResponse response) {
		String year = request.getParameter("year");
		try {
			JiejrBo jiejrBo = jiejrService.getJiejr(year);
			response.setContentType("text/xml");
			response.setLocale(Locale.SIMPLIFIED_CHINESE);
			PrintWriter out = response.getWriter();
			out.println(jiejrBo.getMonthString());
			out.close();
			return null;
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, null);
		}
	}
	
	//���� �ڼ��չ���
	public ActionForward saveJiejrgl(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request,HttpServletResponse response) {
		String year = request.getParameter("year");
		String monthString = request.getParameter("monthString");
		response.setContentType("text/xml");
		response.setLocale(Locale.SIMPLIFIED_CHINESE);
		PrintWriter out = null;
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		try {
			JiejrBo JiejrBo = new JiejrBo();
			JiejrBo.setYear(year);
			String[] monthStrings = monthString.split(",");
			JiejrBo.setMonth_01(monthStrings[0]);
			JiejrBo.setMonth_02(monthStrings[1]);
			JiejrBo.setMonth_03(monthStrings[2]);
			JiejrBo.setMonth_04(monthStrings[3]);
			JiejrBo.setMonth_05(monthStrings[4]);
			JiejrBo.setMonth_06(monthStrings[5]);
			JiejrBo.setMonth_07(monthStrings[6]);
			JiejrBo.setMonth_08(monthStrings[7]);
			JiejrBo.setMonth_09(monthStrings[8]);
			JiejrBo.setMonth_10(monthStrings[9]);
			JiejrBo.setMonth_11(monthStrings[10]);
			JiejrBo.setMonth_12(monthStrings[11]);
			jiejrService.updateOrSaveJiejr(JiejrBo);
			String content = "����["+year+"]�ڼ�������";
			this.createManageLog(clerk.getCode(), content);
			out = response.getWriter();
			out.println("1");
			return null;
		} catch (Exception e) {
			if(out!=null)
			out.println("0");
			return this.errrForLogAndException(e, actionMapping, request, null);
		}finally{
			if(out!=null)
			out.close();
		}
	}
	
	//ɾ�� �ڼ��չ���
	public ActionForward deletJiejrgl(ActionMapping actionMapping, ActionForm actionForm, HttpServletRequest request,HttpServletResponse response) {
		String year = request.getParameter("year");
		response.setContentType("text/xml");
		response.setLocale(Locale.SIMPLIFIED_CHINESE);
		PrintWriter out = null;
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		try {
			jiejrService.deletJiejr(year);
			String content = "ɾ��["+year+"]�ڼ�������";
			this.createManageLog(clerk.getCode(), content);
			out = response.getWriter();
			out.println("1");
			return null;
		} catch (Exception e) {
			if(out!=null)
			out.println("0");
			return this.errrForLogAndException(e, actionMapping, request, null);
		}finally{
			if(out!=null)
			out.close();
		}
	}
}
