package com.unitop.sysmgr.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.actions.DispatchAction;

import com.unitop.exception.BusinessException;
import com.unitop.sysmgr.bo.AccountManageLog;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.SystemManageLog;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.bo.sys.OrgDj;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.service.ClerkManageService;
import com.unitop.sysmgr.service.PromptService;
import com.unitop.sysmgr.service.QueryService;
import com.unitop.sysmgr.service.SystemMgrService;
public class ExDispatchAction extends DispatchAction {
	
	@Resource
	private OrgDao orgDao;
	@Resource
	private SystemMgrService systemMgrService;
	
	@Resource
	private ClerkManageService clerkService;
	
	@Resource
	private QueryService queryService;
	
	@Resource
	private PromptService prompteService;
	
	protected StringBuffer logString = new StringBuffer();

	protected static Log log = LogFactory.getLog(ExDispatchAction.class);
	
	protected SystemMgrService getSystemMgrService(){
		return this.systemMgrService;
	}

	protected QueryService getQueryService(){
		return this.queryService;
	}
	protected PromptService getPromptService(){
		return this.prompteService;
	}
	
	protected void processBusinessException(ActionMapping actionMapping,
			HttpServletRequest request, BusinessException e){
		ActionMessages errors = new ActionMessages();
		errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("errors.detail", e.getMessage()));
		this.saveErrors(request, errors);
	}
	
	protected void processBusinessException(ActionMapping actionMapping,
			HttpServletRequest request, String message){
		ActionMessages errors = new ActionMessages();
		errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("errors.detail",message));
		this.saveErrors(request, errors);
	}
	
	protected ActionForward showMessageJSPforcx(ActionMapping actionMapping,
			HttpServletRequest request,String Forward,String message){
		ActionMessages errors = new ActionMessages();
		errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("errors.detail",message));
		Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");		
		if(clerk2 != null){
			JSONArray jsonArray = new JSONArray();
			String code2=clerk2.getOrgcode();
			List<Org> orgList=orgDao.getAllOrg(code2);

				for(Org orgltem:orgList){											
						JSONObject jsonObject = new JSONObject();
						jsonObject.put("id", orgltem.getCode());
						jsonObject.put("pId", orgltem.getParentCode());
						jsonObject.put("name", orgltem.getName());
						jsonObject.put("wdflag", orgltem.getWdflag());
						if(code2.equals(orgltem.getCode())){
							jsonObject.put("open", "true");					
							jsonObject.put("nocheck", false);
						}
						jsonArray.add(jsonObject);
						//���ӱ���
						if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
							jsonObject.put("id","banb"+orgltem.getCode());
							jsonObject.put("pId", orgltem.getCode());
							jsonObject.put("name", orgltem.getName()+"(����)");
							jsonArray.add(jsonObject);
						}
				}
				String str=jsonArray.toString();
				request.setAttribute("Jsonstr",str);
				List<OrgDj> orgdjlist=orgDao.getAlldj(clerk2.getWdFlag());
				request.setAttribute("orgdjlist", orgdjlist);
		}
		
		this.saveErrors(request, errors);
		return actionMapping.findForward(Forward);
	}
	protected ActionForward showMessageJSPforjgtgl(ActionMapping actionMapping,
			HttpServletRequest request,String Forward,String message){
		ActionMessages errors = new ActionMessages();
		errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("errors.detail",message));
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");		
		if(clerk != null){
			JSONArray jsonArray = new JSONArray();
			String code1=clerk.getOrgcode();
			List<Org> orgList=orgDao.getAllOrg(code1);

			for(Org orgltem:orgList){	
				if(Integer.valueOf(clerk.getWdFlag())<Integer.valueOf(orgltem.getWdflag())){continue;}
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("id", orgltem.getCode());
					jsonObject.put("pId", orgltem.getParentCode());
					jsonObject.put("name", orgltem.getName());
					jsonObject.put("wdflag", orgltem.getWdflag());
					if(code1.equals(orgltem.getCode())){
						jsonObject.put("open", "true");					
						jsonObject.put("nocheck", false);
					}
					jsonArray.add(jsonObject);
					if(Integer.valueOf(clerk.getWdFlag())>Integer.valueOf(orgltem.getWdflag())){
						if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
							jsonObject.put("id","banb"+orgltem.getCode());
							jsonObject.put("pId", orgltem.getCode());
//							jsonObject.put("wdflag", String.valueOf((Integer.valueOf(orgltem.getWdflag())+1)));
							jsonObject.put("name", orgltem.getName()+"(����)");
							jsonArray.add(jsonObject);
						}
					}
			
				}
				String str=jsonArray.toString();
				request.setAttribute("Jsonstr",str);
				List<OrgDj> orgdjlist=orgDao.getAlldj(clerk.getWdFlag());
				request.setAttribute("orgdjlist", orgdjlist);
		}
		
		this.saveErrors(request, errors);
		return actionMapping.findForward(Forward);
	}
	protected ActionForward showMessageJSP(ActionMapping actionMapping,
			HttpServletRequest request,String Forward,String message){
		ActionMessages errors = new ActionMessages();
		errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("errors.detail",message));		
		this.saveErrors(request, errors);
		return actionMapping.findForward(Forward);
	}
	
	protected ActionForward errrForLogAndException(Exception e,
			ActionMapping mapping, HttpServletRequest request, String forward){
		
		String admincode = "";
		String warn = null;
		String error = null;
		
		if (request.getSession().getAttribute("clerk") != null)
		{
			admincode = "��Ա��" + ((Clerk) request.getSession().getAttribute("clerk")).getCode();
		}
		
		warn = admincode + " IP:" + request.getRemoteAddr() + " " + e.getMessage() + logString.toString();
	    error = admincode + " IP:" + request.getRemoteAddr() + logString.toString();
		
		logString.delete(0, logString.length());
		
		if (e != null && e.getClass().getName().equals("com.unitop.exception.BusinessException"))
		{
			log.warn(warn);
			processBusinessException(mapping, request, new BusinessException(e.getMessage()));
			return mapping.findForward(forward);
		} else {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			log.error(sw.toString()+"["+error+"]");
			try {
				sw.close();
				pw.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			return processException(mapping, request, e, forward);
		}
	}

	protected ActionForward processBusinessException(ActionMapping actionMapping, HttpServletRequest request,
			BusinessException e, String Forward){
		ActionMessages errors = new ActionMessages();
		errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("errors.detail", e.getMessage()));
		this.saveErrors(request, errors);
		return actionMapping.findForward(Forward);
	}

	protected ActionForward processException(ActionMapping actionMapping,
			HttpServletRequest request, Exception e, String Forward){
		ActionMessages errors = new ActionMessages();
		errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("errors.detail", "����ʧ��!"));
		this.saveErrors(request, errors);
		return actionMapping.findForward(Forward);
	}
	
	protected void createManageLog(String admincode, String content)
			throws BusinessException{
		try {
			String strdate=this.getSystemMgrService().getSystetemNowDate();
			SystemManageLog mlog = new SystemManageLog();
			mlog.setAdmincode(admincode);
			mlog.setOperdate(strdate);
			mlog.setContent(content);
			//���ù�ԱIP
			Clerk clerk = clerkService.getClerkByCode(admincode);
			mlog.setIp(clerk.getIp());
			this.getSystemMgrService().createSystemManageLog(mlog);
			log.info("��Ա��" + admincode +" ������"+ content);
		} catch (Exception e) {
			throw new BusinessException(e);
		}
	}
	//��������Ա������IP��������־��ҪIP
	protected void createManageLog(String admincode, String content,Clerk clerk)
			throws BusinessException{
		try {
			String strdate=this.getSystemMgrService().getSystetemNowDate();
			SystemManageLog mlog = new SystemManageLog();
			mlog.setAdmincode(admincode);
			mlog.setOperdate(strdate);
			mlog.setContent(content);
			//���ù�ԱIP
		//	Clerk clerk = clerkService.getClerkByCode(admincode);
			mlog.setIp(clerk.getIp());
			this.getSystemMgrService().createSystemManageLog(mlog);
			log.info("��Ա��" + admincode +" ������"+ content);
		} catch (Exception e) {
			throw new BusinessException(e);
		}
	}
	public String  getSystemContolParameter(String number) throws Exception{
		return getSystemMgrService().getSystemContolParameter(number);
	}
	
	public void createAccountManageLog(String account, String managetype,String content, Clerk clerk){
		AccountManageLog bo = new AccountManageLog();
		String strdate=this.getSystemMgrService().getSystetemNowDate();
		bo.setAccount(account);
		bo.setManagedate(strdate.substring(0, 10));
		bo.setManagetime(strdate.substring(11,19));
		bo.setManagetype(managetype);
		bo.setManagecontent(content);
		bo.setClerkname(clerk.getName());
		bo.setClerknum(clerk.getCode());
		bo.setIp(clerk.getIp());
		bo.setUpflag("δ�ϴ�");
		bo.setStr1(clerk.getOrgcode());	
		bo.setShuangqy(clerk.getShuangqy());
		getSystemMgrService().createAccountmanagelog(bo);
	}
	
	//��ҳ��ѯ (�ύ����)
	public TabsBo createTabsBo(HttpServletRequest request){
		TabsBo TabsBo = new TabsBo();
		String ec_p = request.getParameter("ec_p");
		String ec_rd = request.getParameter("ec_rd");
		ServletContext servletContext = request.getSession().getServletContext();
		String ec_yemjlts = (String) servletContext.getAttribute("ec_yemjlts");
		if(ec_rd==null)ec_rd=ec_yemjlts;
		if(ec_p==null)ec_p="1";
		TabsBo.setDangqym(Integer.valueOf(ec_p));
		TabsBo.setFenysl(Integer.valueOf(ec_rd));
		return TabsBo;
	}
	
	//��ҳ��ѯ (��ѯչʾ)
	public void showTabsModel(HttpServletRequest request,TabsBo tabsBo){
		request.setAttribute("list", tabsBo.getList());
		request.setAttribute("totalRows_cs", new Integer(tabsBo.getCounts()));
	}
	
	//��ҳ��ѯ ��תչʾ
	public ActionForward showMessageJSPForFeny(ActionMapping actionMapping,HttpServletRequest request,TabsBo tabsBo,String Forward){
		if(tabsBo.getList().size()==0)
		{
			return this.showMessageJSP(actionMapping, request, Forward,"�޲�ѯ�����");
		}else{
			return actionMapping.findForward(Forward);
		}
	}
}