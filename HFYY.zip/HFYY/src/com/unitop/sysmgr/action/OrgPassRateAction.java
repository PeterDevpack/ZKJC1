package com.unitop.sysmgr.action;



import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.framework.util.DateTool;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Jigtgl;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.sys.OrgDj;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.dao.PassRateDao;
import com.unitop.sysmgr.form.PassRateForm;
import com.unitop.sysmgr.service.OrgService;


//����ͨ����
@Controller("/orgPassRate")
public class OrgPassRateAction extends ExDispatchAction {
	@Resource
	private OrgService orgService;
	
	@Resource
	private PassRateDao passRateDao;
	
	@Resource
	private OrgDao orgDao;
	
	public ActionForward view(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {													
			//request.setAttribute("totalRows", new Integer(0));
			
			String riqhx = request.getParameter("riqfw");
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			List<OrgDj> orgdjlist=new ArrayList<OrgDj>();
			String wdf= request.getParameter("orgdj");
//					if(wdf==null){
//						wdf=clerk.getWdFlag();
//					}			
//			if("zszh".equals(clerk.getZhiszh())){
//				List<OrgDj> zszh=orgDao.getAlldj("2");
//				for(OrgDj dj:zszh){
//					if(!("2".equals(dj.getId()))){
//						if("3".equals(dj.getId())){
//							dj.setName("����");
//						}
//					orgdjlist.add(dj);
//					}
//				}
//			}else{
//				 orgdjlist=orgDao.getAlldj(clerk.getWdFlag());
//			}	
					
		
//			String code1=clerk.getOrgcode();
//			JSONArray jsonArray = new JSONArray();	
//			List<Org> orgList=orgDao.getAllOrg(code1);			
//			for(Org orgltem:orgList){
//				if("zszh".equals(orgltem.getZhiszh())){
//					if("2".equals(wdf)){
//						orgltem.setWdflag(String.valueOf(Integer.valueOf(orgltem.getWdflag())-1));
//					}
//				}
//				if(Integer.valueOf(clerk.getWdFlag())<Integer.valueOf(orgltem.getWdflag())){continue;}
//					JSONObject jsonObject = new JSONObject();
//					jsonObject.put("id", orgltem.getCode());
//					jsonObject.put("pId", orgltem.getParentCode());
//					jsonObject.put("name", orgltem.getName());
//					jsonObject.put("wdflag", orgltem.getWdflag());
//					if(code1.equals(orgltem.getCode())){
//						jsonObject.put("open", "true");					
//						jsonObject.put("nocheck", false);
//					}
//					jsonArray.add(jsonObject);
//					if(Integer.valueOf(clerk.getWdFlag())>Integer.valueOf(orgltem.getWdflag())){
//						if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
//							jsonObject.put("id","banb"+orgltem.getCode());
//							jsonObject.put("pId", orgltem.getCode());
////							jsonObject.put("wdflag", String.valueOf((Integer.valueOf(orgltem.getWdflag())+1)));
//							jsonObject.put("name", orgltem.getName()+"(����)");
//							jsonArray.add(jsonObject);
//						}
//					}
//			}	
//			String str=jsonArray.toString();
//			request.setAttribute("Jsonstr",str);
//			request.setAttribute("youqjgstr",code1);		
			
			

		
			request.setAttribute("orgdj", wdf);	
			request.setAttribute("orgdjlist", orgdjlist);
			String begindate = DateTool.getNowDayForYYYMMDD().substring(0,7)+"-01";
			String enddate = DateTool.getNowDayForYYYMMDD();
			if(riqhx==null){
				request.setAttribute("riqfw", begindate);
				}else{request.setAttribute("riqfw", riqhx);}
			request.setAttribute("riqend", enddate);
			
		} catch (Exception e) {
			return this.errrForLogAndException(e, mapping, request, "view");
		}
		return mapping.findForward("view");
	}	
	public ActionForward select(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			Clerk clerk =(Clerk) request.getSession().getAttribute("clerk");
			PassRateForm passRateForm = (PassRateForm) form;
			String orgnum = request.getParameter("orgCode1");		
			String jigh = passRateForm.getJigh();
			String orgdj=request.getParameter("orgdj");
//�¼�xitlx
			String xitlx=passRateForm.getXitlx();
			String code1=clerk.getOrgcode();
			JSONArray jsonArray = new JSONArray();	
			List<Org> orgList=orgDao.getAllOrg(code1);	
			for(Org orgltem:orgList){	
				if("zszh".equals(orgltem.getZhiszh())){
					if("2".equals(orgdj)){
						orgltem.setWdflag(String.valueOf(Integer.valueOf(orgltem.getWdflag())-1));
					}
				}
				if(Integer.valueOf(orgdj)<Integer.valueOf(orgltem.getWdflag())){continue;}
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("id", orgltem.getCode());
					jsonObject.put("pId", orgltem.getParentCode());
					jsonObject.put("name", orgltem.getName());
					jsonObject.put("wdflag", orgltem.getWdflag());
					if(code1.equals(orgltem.getCode())){
						jsonObject.put("open", "true");					
						jsonObject.put("nocheck", false);
					}
					jsonArray.add(jsonObject);
					if("zszh".equals(orgltem.getZhiszh())){//��ֹѡ��3��ʱֱ��֧�л��������
						orgltem.setWdflag(String.valueOf(Integer.valueOf(orgltem.getWdflag())+1));
					}
					if(Integer.valueOf(orgdj)>Integer.valueOf(orgltem.getWdflag())){
						if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
							jsonObject.put("id","banb"+orgltem.getCode());
							jsonObject.put("pId", orgltem.getCode());
//							jsonObject.put("wdflag", String.valueOf((Integer.valueOf(orgltem.getWdflag())+1)));
							jsonObject.put("name", orgltem.getName()+"(����)");
							jsonArray.add(jsonObject);
						}
					}
			}	
			String str=jsonArray.toString();
			request.setAttribute("Jsonstr",str);
//			request.setAttribute("youqjgstr",orgnum);	
								
			if(!(jigh==null||"".equals(jigh))){
				
				
				orgnum=jigh;
			}
			
				String[] guanljg=orgnum.split(",");	
				String benb="";
			if(!(orgnum==null||"".equals(orgnum))){						
				for(int i =0;i<guanljg.length;i++){	
					Pattern pattern=Pattern.compile("[0-9]*");
					if(!(pattern.matcher(guanljg[i]).matches())){
						if("".equals(benb)){
							benb+=guanljg[i];
						}else{
							benb+=","+guanljg[i];
						}
					}else{
						//��ѯ�Ƿ��й�������
						Org o = orgDao.getOrgByCode(guanljg[i]);			
						if(o==null){
							return this.showMessageJSPforjgtgl(mapping, request, "success", "���������ڣ�");
						}
						if(!(o.getGuanljg()==null||"".equals(o.getGuanljg()))){	
							if(clerk.getShOrgCode().equals(o.getCode())){
								orgnum+=(","+o.getGuanljg());			
							}
						}
					}
				}
			}
	
			//�жϻ���Ȩ��			
			if(!("".equals(jigh)||null==jigh)){
				String res=orgService.CanOperDesOrg(clerk.getOrgcode(), jigh);
				if(res.equals("2")){
					return this.showMessageJSPforjgtgl(mapping, request, "success","��û��Ȩ�޲鿴:["+jigh+"]�µ��˺ţ�");
				}
			}
			
			String orgcode=clerk.getOrgcode();
			List<OrgDj> orgdjlist=orgDao.getAlldj(clerk.getWdFlag());	
			if("zszh".equals(clerk.getZhiszh())){
				for(OrgDj d:orgdjlist){
					if("3".equals(d.getId())){
						d.setName("����");
					}
				}
			}
			request.setAttribute("totalRows", new Integer(0));
			//���ڻ���				
			String riqfw=passRateForm.getRiqfw();
			String riqend=passRateForm.getRiqend();	
//			String jig=passRateForm.getJigh();
			request.setAttribute("riqfw", riqfw);
			request.setAttribute("riqend", riqend);
			List<Jigtgl> list = new ArrayList<Jigtgl>();
			Jigtgl jg =null;
			Jigtgl hej =null;				
			if(jigh==null||"".equals(jigh)){				
				if(orgnum==null||"".equals(orgnum)){//�м���ѯ	
//					��ѯ���еȼ����ϱ���ͨ����		
					return this.showMessageJSPforjgtgl(mapping, request, "success","����������ţ�");
					/*if(Integer.valueOf(orgdj)>1){
						List<Org> erjOrg=orgDao.getOrgBywdf("1",orgcode);
						for(Org o:erjOrg){
							jg=passRateDao.queryJgBy(o.getCode(),riqfw,riqend,orgdj);
								if(!(jg.getYanyzs()==null)){
									 jg.setJigmc(jg.getJigmc()+"(����)");
									 list.add(jg);	
									 jg.setParentOrg("zongh");								
									
							}
						}
					}	
					if(Integer.valueOf(orgdj)>2){
						List<Org> erjOrg=orgDao.getOrgBywdf("2",orgcode);
						for(Org o:erjOrg){
							jg=passRateDao.queryJgBy(o.getCode(),riqfw,riqend,orgdj);
								if(!(jg.getYanyzs()==null)){
									 jg.setJigmc(jg.getJigmc()+"(����)");
									 list.add(jg);	
									
							}
						}
					}
					if(Integer.valueOf(orgdj)>3){
						List<Org> sanjOrg=orgDao.getOrgBywdf("3",orgcode);
						for(Org o:sanjOrg){
							jg=passRateDao.queryJgBy(o.getCode(),riqfw,riqend,orgdj);
							 if(!(jg.getYanyzs()==null)){
								 jg.setJigmc(jg.getJigmc()+"(����)");
								 list.add(jg);	
								
							}
						}
					}
					//��ѯֱ��֧��
					if("2".equals(orgdj)&&"1".equals(clerk.getWdFlag())){
						List<Org> zhiszh=orgDao.getAllOrg2();
						for(Org zszh:zhiszh){							
							if("zszh".equals(zszh.getZhiszh())){
								 jg = passRateDao.queryAllJgBy(zszh.getCode(),riqfw,riqend ,orgdj);
								 list.add(jg);
							}
						}
					}
					//��ѯ����ͬһ�û���¼��ͬһ�ȼ��µĻ���
					List<Org> allOrg=orgDao.getOrgBywdf(orgdj,orgcode);
					for(Org o:allOrg){
						 jg = passRateDao.queryAllJgBy(o.getCode(),riqfw,riqend ,orgdj);
						 if(!(jg.getYanyzs()==null)){
							 list.add(jg);
							 if("01001".equals(jg.getJigh())){
								 jg.setParentOrg("zongh");
							 }
							
						}
					}
					//�ܼ�
					int yanyzs=0; int fuztgzs=0; int zidtgzs=0; int rengtgzs=0;	int xitzs=0;
					for(Jigtgl jig:list){
						 if(!(jig.getYanyzs()==null||"".equals(jig.getYanyzs()))){
							 yanyzs+=Integer.valueOf(jig.getYanyzs());
							 fuztgzs+=Integer.valueOf(jig.getFuztgzs());
							 zidtgzs+=Integer.valueOf(jig.getZidtgzs());
							 rengtgzs+=Integer.valueOf(jig.getRengtgzs());
							 xitzs+=Integer.valueOf(jig.getXittgzs());
							 }
						
					}
						Jigtgl total = new Jigtgl();
						if(yanyzs!=0){
							float zidtgl=(float)zidtgzs*100/yanyzs; 
							float rengtgl= (float)rengtgzs*100/yanyzs; 
							float fuztgl=(float)fuztgzs*100/yanyzs;
							float xittgl=(float)xitzs*100/yanyzs;
							DecimalFormat df = new DecimalFormat("0.00");
							total.setYanyzs(Integer.toString(yanyzs));
							total.setFuztgzs(Integer.toString(fuztgzs));
							total.setRengtgzs(Integer.toString(rengtgzs));
							total.setZidtgzs(Integer.toString(zidtgzs));
							total.setXittgzs(Integer.toString(xitzs));
							total.setFuztgl(df.format(fuztgl));
							total.setRengtgl(df.format(rengtgl));
							total.setZidtgl(df.format(zidtgl));	
							total.setXittgl(df.format(xittgl));
						}
						total.setJigmc("�ϼ�");
						list.add(total);
						hej=total;
					*/
				}else{
					//��������ѯ					
					int yanyzs=0; int fuztgzs=0; int zidtgzs=0; int rengtgzs=0;		int xitzs=0;													
					String[] alljigh=orgnum.split(",");										
					for(int i=0;i<alljigh.length;i++){						
						String orgnu = alljigh[i].replaceAll("[a-zA-Z]", "");
							Org sahnggorg=orgDao.getOrgByCode(orgnu);//��ѯѡ�л����ȼ�					
							if("2".equals(orgdj)){//���м�Ϊ2ʱ��ֱ��֧�еȼ���3��Ϊ2
								if("zszh".equals(sahnggorg.getZhiszh())){
									sahnggorg.setWdflag("2");								
								}
							}														
							 if(sahnggorg.getWdflag().equals(orgdj)){
								jg = passRateDao.queryAllJgBy(orgnu,riqfw,riqend,orgdj,xitlx);							
								if(!(jg.getYanyzs()==null)){							
									list.add(jg);
								} 	
							 }else{
								 jg=passRateDao.queryJgBy(orgnu,riqfw,riqend,orgdj);
									if(jg.getYanyzs()!=null){
										 jg.setJigmc(jg.getJigmc()+"(����)");
										 list.add(jg);										 
									}
							 }			
						 if(!(jg.getYanyzs()==null||"".equals(jg.getYanyzs()))){
						 yanyzs+=Integer.valueOf(jg.getYanyzs());
						 fuztgzs+=Integer.valueOf(jg.getFuztgzs());
						 zidtgzs+=Integer.valueOf(jg.getZidtgzs());
						 rengtgzs+=Integer.valueOf(jg.getRengtgzs());
						 xitzs+=Integer.valueOf(jg.getXittgzs());
						 
						 }
					}
					
					Jigtgl total = new Jigtgl();
					if(yanyzs!=0){
						float zidtgl=(float)zidtgzs*100/yanyzs; 
						float rengtgl= (float)rengtgzs*100/yanyzs; 
						float fuztgl=(float)fuztgzs*100/yanyzs;
						float xittgl=(float)xitzs*100/yanyzs;
						DecimalFormat df = new DecimalFormat("0.00");
						total.setYanyzs(Integer.toString(yanyzs));
						total.setFuztgzs(Integer.toString(fuztgzs));
						total.setRengtgzs(Integer.toString(rengtgzs));
						total.setZidtgzs(Integer.toString(zidtgzs));
						total.setXittgzs(Integer.toString(xitzs));
						total.setFuztgl(df.format(fuztgl));
						total.setRengtgl(df.format(rengtgl));
						total.setZidtgl(df.format(zidtgl));	
						total.setXittgl(df.format(xittgl));
					}
					total.setJigmc("�ϼ�");
		//			list.add(total);
					hej=total;
					
			}
			}else{
				//��������Ų�ѯ
				jg=passRateDao.queryJgBy(jigh,riqfw,riqend,orgdj);
				Org o = orgDao.getOrgByOrgCode(jigh);
				if(jg.getYanyzs()==null){jg.setJigmc(o.getName());}
				if("1".equals(o.getWdflag())||"2".equals(o.getWdflag())||"3".equals(o.getWdflag())){
					jg.setJigmc(o.getName()+"(����)");
				}
				list.add(jg);
			}
				//���������				
				List<Jigtgl> orgs = new ArrayList<Jigtgl>();	
				orglist(orgs,orgList,list);
				if(hej!=null){orgs.add(hej);}				
				request.setAttribute("list", orgs);
				request.setAttribute("totalRows", orgs.size());
				request.setAttribute("orgdjlist", orgdjlist);
				request.setAttribute("orgdj", orgdj);
						
				if(list.size()==0)
				{
					return this.showMessageJSPforcx(mapping, request, "success","�޲�ѯ�����");
				}else{
					return mapping.findForward("success");
				}
			
		} catch (Exception e){
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "view");
		}
	}
	public void selectOrg(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response){	
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		PrintWriter out;
		String wdf= request.getParameter("orgdj");
				if(wdf==null){
					wdf=clerk.getWdFlag();
				}
		String code1=clerk.getOrgcode();
		JSONArray jsonArray = new JSONArray();	
		List<Org> orgList= orgDao.getAllOrg(code1);

		for(Org orgltem:orgList){
			if("zszh".equals(orgltem.getZhiszh())){
					if("2".equals(wdf)){
						orgltem.setWdflag(String.valueOf(Integer.valueOf(orgltem.getWdflag())-1));
					}
				}
			if(Integer.valueOf(wdf)<Integer.valueOf(orgltem.getWdflag())){continue;}
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("id", orgltem.getCode());
				jsonObject.put("pId", orgltem.getParentCode());
				jsonObject.put("name", orgltem.getName());
				jsonObject.put("wdflag", orgltem.getWdflag());
				if(code1.equals(orgltem.getCode())){
					jsonObject.put("open", "true");					
					jsonObject.put("nocheck", false);
				}
				jsonArray.add(jsonObject);
				if(Integer.valueOf(wdf)>Integer.valueOf(orgltem.getWdflag())){
					if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
						jsonObject.put("id","banb"+orgltem.getCode());
						jsonObject.put("pId", orgltem.getCode());
//						jsonObject.put("wdflag", String.valueOf((Integer.valueOf(orgltem.getWdflag())+1)));
						jsonObject.put("name", orgltem.getName()+"(����)");
						jsonArray.add(jsonObject);
					}
				}
		}	
		String str=jsonArray.toString();				
		try{
			response.setContentType("text/xml");
			response.setLocale(Locale.SIMPLIFIED_CHINESE);
			response.setCharacterEncoding("GBK");
			out = response.getWriter();
			out.print(str);
			out.close();
		}catch(IOException e){
			 try {
					out = response.getWriter();
					out.print("false");
					out.close();
			 }catch (IOException e1) {
					e1.printStackTrace();
				}
		}
	}
	/**
	 * ��������ר��	��ָ��������Ŀ¼�����������ڡ�����ͨ���ʰ�Ŀ¼�����򡿹���
	 * @param _jigtgls	Ҫ����Ļ�������
	 * @param rootOrgNum Ҫ����Ļ������ϵĸ�����
	 * @param jigtgls   �����Ļ�������
	 * @return
	 */
	private List<Org> sortOrg(List<Org> _jigtgls,String rootOrgNum,List<Org> duiborg){
		for(Org jigtgl:_jigtgls){
			if(rootOrgNum.equals(jigtgl.getParentCode())){
				duiborg.add(jigtgl);
				sortOrg(_jigtgls,jigtgl.getCode(),duiborg);
			}
		}
		return duiborg;
	}
	
	private List<Jigtgl> orglist(List<Jigtgl> newjiglist,List<Org> orgList,List<Jigtgl> oldjiglist){
		for(Org org:orgList){
			for(Jigtgl jig:oldjiglist){
				if(org.getCode().equals(jig.getJigh())){
					newjiglist.add(jig);
				}
			}
		}
		return newjiglist;
	}
	public ActionForward selectForJigtgl(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			Clerk clerk =(Clerk) request.getSession().getAttribute("clerk");
			PassRateForm passRateForm = (PassRateForm) form;
//			String orgnum = request.getParameter("orgCode1");		
			String jigh = passRateForm.getJigh();
			String orgdj=request.getParameter("orgdj");
//�¼�xitlx			
			String xitlx=passRateForm.getXitlx();
			
			//���ڻ���				
			String riqfw=passRateForm.getRiqfw();
			String riqend=passRateForm.getRiqend();	
//			String jig=passRateForm.getJigh();
			request.setAttribute("riqfw", riqfw);
			request.setAttribute("riqend", riqend);
			String code1=clerk.getOrgcode();
			//�жϻ���Ȩ��			
			if(!(jigh==null||jigh.equals(""))){
				//�жϻ���Ȩ��			
				String res=orgService.CanOperDesOrg(clerk.getOrgcode(), jigh);
				if(res.equals("2")){
					return this.showMessageJSP(mapping, request, "success","��û��Ȩ�޲鿴:["+jigh+"]�µ��˺ţ�");					
				}else if(res.equals("1")){
					return this.showMessageJSP(mapping, request, "success","���������ڣ�");
				}
			}else{
				return this.showMessageJSP(mapping, request, "success","����������Ϊ�գ�");
			}
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date date = format.parse(riqfw);
			Date date2 = format.parse(riqend);
			int days = (int) ((date2.getTime() - date.getTime()) / (1000*3600*24));
			if(riqfw==null||riqfw.equals("")||riqend==null||riqend.equals("")){
				return this.showMessageJSP(mapping, request, "success","��ӡʱ�䲻��Ϊ�գ�");
			}else if(days>90){
				return this.showMessageJSP(mapping, request, "success","��ӡʱ��β��ܳ���90�죡");
			}
			Org rootOrg= orgDao.getOrgByCode(jigh);
			if(rootOrg==null){
				return this.showMessageJSP(mapping, request, "success","���������ڣ�");
			}
//			JSONArray jsonArray = new JSONArray();	
			List<Jigtgl> list = new ArrayList<Jigtgl>();
			Jigtgl jg =null;
			Jigtgl hej =null;
			List<Org> orgList =null;
			//List<Jigtgl> orgs = new ArrayList<Jigtgl>();//���ܷ��صĻ�������
			if(rootOrg.getWdflag().equals(orgdj)){
				jg = passRateDao.queryAllJgBy(jigh,riqfw,riqend ,orgdj,xitlx);	
				if(!(jg.getYanyzs()==null)){							
					list.add(jg);
				}
				request.setAttribute("list", list);
				request.setAttribute("totalRows", list.size());
			}else{
				list = passRateDao.queryDJJgBy(jigh, riqfw,riqend ,orgdj, xitlx);	
			
			request.setAttribute("list", list);
			request.setAttribute("totalRows", list.size());
			}
			List<OrgDj> orgdjlist=orgDao.getAlldj(rootOrg.getWdflag());	
			
			request.setAttribute("orgdjlist", orgdjlist);
			request.setAttribute("orgdj", orgdj);
					
			if(list.size()==0)
			{
				return this.showMessageJSP(mapping, request, "success","�޲�ѯ�����");
			}else{
				return mapping.findForward("success");
			}
//			String orgcode=clerk.getOrgcode();
//			
//			 
//			Org oroot= orgDao.getOrgByCode(clerk.getOrgcode());
//			String rootOrgNum=oroot.getParentCode();
//
//			for(Org orgltem:orgList){
//				if("zszh".equals(orgltem.getZhiszh())){
//						if("2".equals(orgdj)){
//							orgltem.setWdflag(String.valueOf(Integer.valueOf(orgltem.getWdflag())-1));
//						}
//					}
//				if(Integer.valueOf(orgdj)<Integer.valueOf(orgltem.getWdflag())){continue;}
//					JSONObject jsonObject = new JSONObject();
//					jsonObject.put("id", orgltem.getCode());
//					jsonObject.put("pId", orgltem.getParentCode());
//					jsonObject.put("name", orgltem.getName());
//					jsonObject.put("wdflag", orgltem.getWdflag());
//					if(code1.equals(orgltem.getCode())){
//						jsonObject.put("open", "true");					
//						jsonObject.put("nocheck", false);
//					}
//					jsonArray.add(jsonObject);
//					if(Integer.valueOf(orgdj)>Integer.valueOf(orgltem.getWdflag())){
//						if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
//							jsonObject.put("id","banb"+orgltem.getCode());
//							jsonObject.put("pId", orgltem.getCode());
////							jsonObject.put("wdflag", String.valueOf((Integer.valueOf(orgltem.getWdflag())+1)));
//							jsonObject.put("name", orgltem.getName()+"(����)");
//							jsonArray.add(jsonObject);
//						}
//					}
//			}	
//			String str=jsonArray.toString();
//			request.setAttribute("Jsonstr",str);
//			request.setAttribute("youqjgstr",orgnum);	
			
			
					
//			if(!(jigh==null||"".equals(jigh))){								
//				orgnum=jigh;
//			}
//			
//				String[] guanljg=orgnum.split(",");	
//				String benb="";
//				String nobenb="";
//			if(!(orgnum==null||"".equals(orgnum))){						
//				for(int i =0;i<guanljg.length;i++){	
//					Pattern pattern=Pattern.compile("[0-9]*");
//					if(!(pattern.matcher(guanljg[i]).matches())){//�Ѵ�benb�Ļ����ó���
//						String orgnum1 = guanljg[i].replaceAll("banb", "");
//						if("".equals(benb)){
//							benb+=orgnum1;
//						}else{
//							benb+=","+orgnum1;
//						}
//					}else{
//						if("".equals(nobenb)){
//							nobenb+=guanljg[i];
//						}else{
//							nobenb+=","+guanljg[i];
//						}
//						
//					}
//				}
//			}			
			
//			List<OrgDj> orgdjlist=orgDao.getAlldj(clerk.getWdFlag());	
//			if("zszh".equals(clerk.getZhiszh())){
//				for(OrgDj d:orgdjlist){
//					if("3".equals(d.getId())){
//						d.setName("����");
//					}
//				}
//			}
//			request.setAttribute("totalRows", new Integer(0));

							
//			if(jigh==null||"".equals(jigh)){				
//				if(orgnum==null||"".equals(orgnum)){		
//					return this.showMessageJSPforjgtgl(mapping, request, "success","����������ţ�");			
//				}else{
//					//��������ѯ	
//					if("4".equals(orgdj)){//��ѡ��4��ʱȫ����getOrgPassRate������ѯ
//						benb+=","+nobenb;
//						nobenb="";
//					}
//					int yanyzs=0; int fuztgzs=0; int zidtgzs=0; int rengtgzs=0;		int xitzs=0;													
//					List<Jigtgl> listb=passRateDao.getOrgPassRate(riqfw,riqend,benb);//ȡ�����б���������ͨ����										
//						for(Jigtgl jgt:listb){
//							if("4".equals(orgdj)){//��ѡ��4��ʱ1��2��3���ӱ���
//								if(!"4".equals(jgt.getOrgflag())){
//									jgt.setJigmc(jgt.getJigmc()+("��������"));
//								}
//							}else{
//								jgt.setJigmc(jgt.getJigmc()+("��������"));
//							}
//							
//							list.add(jgt);
//							 yanyzs+=Integer.valueOf(jgt.getYanyzs());
//							 fuztgzs+=Integer.valueOf(jgt.getFuztgzs());
//							 zidtgzs+=Integer.valueOf(jgt.getZidtgzs());
//							 rengtgzs+=Integer.valueOf(jgt.getRengtgzs());
//							 xitzs+=Integer.valueOf(jgt.getXittgzs());
//						}							
//					if(!"".equals(nobenb)){//��ѯ�����ӻ�����ӡ����
//						String[] childorg = nobenb.split(",");
//						for(int i=0;i<childorg.length;i++){
//							jg = passRateDao.queryAllJgBy(childorg[i],riqfw,riqend ,orgdj);							
//							if(!(jg.getYanyzs()==null)){							
//								list.add(jg);
//								yanyzs+=Integer.valueOf(jg.getYanyzs());
//								 fuztgzs+=Integer.valueOf(jg.getFuztgzs());
//								 zidtgzs+=Integer.valueOf(jg.getZidtgzs());
//								 rengtgzs+=Integer.valueOf(jg.getRengtgzs());
//								 xitzs+=Integer.valueOf(jg.getXittgzs());
//							}
//						}
//					}						 										
//		//---------------------------------------------------------------------			
//					Jigtgl total = new Jigtgl();
//					if(yanyzs!=0){
//						float zidtgl=(float)zidtgzs*100/yanyzs; 
//						float rengtgl= (float)rengtgzs*100/yanyzs; 
//						float fuztgl=(float)fuztgzs*100/yanyzs;
//						float xittgl=(float)xitzs*100/yanyzs;
//						DecimalFormat df = new DecimalFormat("0.00");
//						total.setYanyzs(Integer.toString(yanyzs));
//						total.setFuztgzs(Integer.toString(fuztgzs));
//						total.setRengtgzs(Integer.toString(rengtgzs));
//						total.setZidtgzs(Integer.toString(zidtgzs));
//						total.setXittgzs(Integer.toString(xitzs));
//						total.setFuztgl(df.format(fuztgl));
//						total.setRengtgl(df.format(rengtgl));
//						total.setZidtgl(df.format(zidtgl));	
//						total.setXittgl(df.format(xittgl));
//					}
//					total.setJigmc("�ϼ�");
//					list.add(total);
//					hej=total;
//					
//			}else{
				//��������Ų�ѯ
//				jg=passRateDao.queryJgBy(jigh,riqfw,riqend,orgdj);
//				Org o = orgDao.getOrgByOrgCode(jigh);
//				if(jg.getYanyzs()==null){jg.setJigmc(o.getName());}
//				if("1".equals(o.getWdflag())||"2".equals(o.getWdflag())||"3".equals(o.getWdflag())){
//					jg.setJigmc(o.getName()+"(����)");
//				}
//				list.add(jg);
//			}
//				//���������				
//				List<Jigtgl> orgs = new ArrayList<Jigtgl>();//���ܷ��صĻ�������
//				List<Org> duiborgs = new ArrayList<Org>();//������ջ���
//							
//				sortOrg(orgList,jigh,duiborgs);
//				orglist(orgs,duiborgs,list);//����
////				if(hej!=null){orgs.add(hej);}	
//				request.setAttribute("list", orgs);
//				request.setAttribute("totalRows", orgs.size());
//				request.setAttribute("orgdjlist", orgdjlist);
//				request.setAttribute("orgdj", orgdj);
//						
//				if(list.size()==0)
//				{
//					return this.showMessageJSPforcx(mapping, request, "success","�޲�ѯ�����");
//				}else{
//					return mapping.findForward("success");
//				}
			
		} catch (Exception e){
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "view");
		}
	}

}

