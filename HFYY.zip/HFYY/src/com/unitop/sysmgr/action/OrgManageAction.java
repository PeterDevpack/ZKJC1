package com.unitop.sysmgr.action;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.upload.FormFile;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Controller;

import com.unitop.config.SystemConfig;
import com.unitop.exception.BusinessException;
import com.unitop.framework.util.ExpOrImp;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.OrgLog;
import com.unitop.sysmgr.dao.ClerkDao;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.dao.ZhanghbDao;
import com.unitop.sysmgr.form.OrgForm;
import com.unitop.sysmgr.service.ClerkManageService;
import com.unitop.sysmgr.service.OrgService;
import com.unitop.sysmgr.service.PromptService;

@Controller("/orgManage")
public class OrgManageAction extends ExDispatchAction {
	@Resource
	private ClerkDao clerkDao;
	
	@Resource
	private ZhanghbDao zhanghbDao;
	@Resource
	private ClerkManageService clerkService;
	
	@Resource
	private OrgService OrgService;
	
	@Resource  
	private OrgDao orgDao; 
	
	@Resource
	SessionFactory sessionFactory;

	List<String> list = new ArrayList<String>();

	public ActionForward loadtree(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String id = request.getParameter("id");
		String name =request.getParameter("name");
		
//		System.out.println("id="+id);
//		System.out.println("name="+name);
		
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		
		if(id==null || "".equals(id)){									//�״μ���
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			if(clerk!=null){
				String orgcode = clerk.getOrgcode();			//���ص�ǰ����
				jsonObject.put("id", orgcode);
				jsonObject.put("name", clerk.getOrgname());
				jsonObject.put("url", request.getContextPath()+"/orgManage.do?method=load&parentcode="+orgcode);
				jsonObject.put("target", "mainF");
				//�ж��Ƿ����ӽڵ�
				List children = OrgService.getOrgChildrenByCode(orgcode);
				if(children==null || children.size()==0){
					jsonObject.put("isParent", "false");
					jsonArray.add(jsonObject);
				}else{														//������һ���������ӽڵ㡿
					jsonObject.put("open", "true");
					jsonArray.add(jsonObject);
					
					for(int i=0;i<children.size();i++){
						Org org = (Org)children.get(i);
						if(org.getName().contains("(")){
							continue;
						}
						jsonObject.put("id", org.getCode());
						jsonObject.put("name", org.getName());
						jsonObject.put("pId", orgcode);
						jsonObject.put("url", request.getContextPath()+"/orgManage.do?method=load&parentcode="+org.getCode());
						jsonObject.put("target", "mainF");
						//�ж��Ƿ����ӽڵ�							//�����ӽڵ��Ƿ����չ��
						List subChildren = OrgService.getOrgChildrenByCode(org.getCode());
						if(subChildren==null || subChildren.size()==0){
							jsonObject.put("isParent", "false");
						}else{
							jsonObject.put("isParent", "true");
						}
						jsonArray.add(jsonObject);
					}
				}
			}else{
				return this.showMessageJSP(actionMapping, request, "timeout","��¼��ʱ�������µ�¼!");
			}
		}else{																	//�������
			List children = OrgService.getOrgChildrenByCode(id);
			for(int i=0;i<children.size();i++){						//����ָ���������ӻ���
				Org org = (Org)children.get(i);
				if(org.getName().contains("(")){
					continue;
				}
				jsonObject.put("id", org.getCode());
				jsonObject.put("name", org.getName());
				jsonObject.put("url", request.getContextPath()+"/orgManage.do?method=load&parentcode="+org.getCode());
				jsonObject.put("target", "mainF");
				//�ж��Ƿ����ӽڵ�
				List subChildren = OrgService.getOrgChildrenByCode(org.getCode());
				if(subChildren==null || subChildren.size()==0){
					jsonObject.put("isParent", "false");
				}else{
					jsonObject.put("isParent", "true");
				}
				jsonArray.add(jsonObject);
			}
//			System.out.println(jsonArray.toString());
		}
		
		response.setContentType("text/json;charset=UTF-8");
		PrintWriter writer = null;
		try {
			writer = response.getWriter();
			writer.print(jsonArray.toString());
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			writer.close();
		}
		return null;
	}

	public ActionForward load(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = null;
		if (request.getParameter("parentcode") != null)
			code = request.getParameter("parentcode");
		else if (request.getAttribute("parentcode") != null)
			code = request.getAttribute("parentcode").toString();
		try {
			Org org = OrgService.getOrgByCode(code);
			//��ȡĬ�����л�����
			String rootCode = SystemConfig.getInstance().getRootCode();
			//��ȡ��������ģʽ:1:���й���;2:���й���
			String org_guanlms = SystemConfig.getInstance().getValue("org_guanlms");
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String pcode = org.getCode();
			if (pcode == null)pcode = "0";
			String wdflag = org.getWdflag();
			if (wdflag == null)wdflag = "0";
			//�ж��Ƿ���ʾ��������"����"��"����"��"����"��"�޸�"��"����"�Ȱ�ť
			int lastWdflag = OrgService.getLastWdflag();
			if(clerk.getOrgcode().equals(rootCode)&&(!pcode.equals(rootCode))||(Integer.parseInt(wdflag)>=lastWdflag))
			{
				if("1".equals(org_guanlms))
					request.setAttribute("guanlms", "1");
				else
					request.setAttribute("guanlms", "0");
			} else {
				request.setAttribute("guanlms", "1");
			}
			request.setAttribute("lastWdflag", OrgService.getLastWdflag());
			List list = OrgService.getOrgChildrenByCode(code);
			List count = OrgService.getOrgCount(code);
			request.setAttribute("org",count.get(0));//�¼���������
			request.setAttribute("all",count.get(1));//�����¼���������
			request.setAttribute("list",list);
			request.setAttribute("parentcode",code);
			request.setAttribute("rootcode",rootCode);
			return actionMapping.findForward("list.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request,"list.success");
		}
	}

	public ActionForward add(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = request.getParameter("parentcode");
		try {
			Org parentorg = OrgService.getOrgByCode(code);
			OrgForm orgForm = (OrgForm) actionForm;
			orgForm.setParentcode(parentorg.getCode());
			orgForm.setParentname(parentorg.getName());
			orgForm.setParentwdflag(parentorg.getWdflag());
			int wdflag = Integer.parseInt(parentorg.getWdflag()) + 1;
			String wdflag1 = "" + wdflag;
			request.setAttribute("wdflag", wdflag1);
			request.setAttribute("list", null);
			request.setAttribute("rootCode", SystemConfig.getInstance().getRootCode());
			return actionMapping.findForward("add.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request,"list.success");
		}
	}

	public ActionForward forwardupdate(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = request.getParameter("code");
		try {
			Org org = OrgService.getOrgByCode(code);
			Org parentorg = OrgService.getOrgByCode(org.getParentCode());
			OrgForm orgForm = (OrgForm) actionForm;
			orgForm.setCode(org.getCode());
			orgForm.setName(org.getName());
			orgForm.setParentcode(parentorg.getCode());
			orgForm.setParentname(parentorg.getName());
			//modify  by bin ���ε�����֧���к�
			//orgForm.setPaymentCode(org.getPaymentCode().toString().trim());
			request.setAttribute("rootCode", SystemConfig.getInstance().getRootCode());
			return actionMapping.findForward("updateforward.success");
		} catch (Exception e) {
			request.setAttribute("rootCode", SystemConfig.getInstance().getRootCode());
			return this.errrForLogAndException(e, actionMapping, request,"updateforward.success");
		}
	}

	public ActionForward changerelation(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = request.getParameter("code");
		OrgForm orgForm = (OrgForm) actionForm;
		try {
			Org org = OrgService.getOrgByCode(code);
			Org parentorg = OrgService.getOrgByCode(org.getParentCode());
			orgForm.setCode(org.getCode());
			orgForm.setName(org.getName());
			orgForm.setParentcode(parentorg.getCode());
			orgForm.setParentname(parentorg.getName());
			//modify by bin ��������֧���к�
			//orgForm.setPaymentCode(org.getPaymentCode());
			orgForm.setWdflag(org.getWdflag());
			request.setAttribute("code", code);
			return actionMapping.findForward("changerelation.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e,actionMapping,request,"changerelation.success");
		}
	}
//����Ǩ����ת
	public ActionForward move(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = request.getParameter("code");
		OrgForm orgForm = (OrgForm) actionForm;
		try {
			Org org = OrgService.getOrgByCode(code);
			Org parentorg = OrgService.getOrgByCode(org.getParentCode());
			orgForm.setCode(org.getCode());
			orgForm.setName(org.getName());
			orgForm.setParentcode(parentorg.getCode());
			orgForm.setParentname(parentorg.getName());
			//modify by bin ��������֧���к�
			//orgForm.setPaymentCode(org.getPaymentCode());
			orgForm.setWdflag(org.getWdflag());
			request.setAttribute("code", code);
			return actionMapping.findForward("move.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e,actionMapping,request,"changerelation.success");
		}
	}

	public ActionForward delete(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = request.getParameter("code");//��ȡJSPҳ��Ļ�����
		
		try {
			Org bo = OrgService.getOrgByCode(code);
			request.setAttribute("parentcode", bo.getParentCode());
			if(bo==null)
			{
				return this.showMessageJSP(actionMapping, request, "load","ɾ������������!");
			}
			List list = this.OrgService.getOrgChildrenByCode(code);
			if (list != null && list.size() > 0)
			{
				throw new BusinessException("�û���������ڻ���������ɾ���¼�����!");
			}
			this.OrgService.deleteOrg(bo);
			String admincode = ((Clerk) request.getSession().getAttribute("clerk")).getCode();
			String content = "ɾ��������"+bo.getName()+"["+bo.getCode()+"]";
			
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			OrgLog orglog= new OrgLog();//��������䶯��־
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
			String now = sdf.format(date);
			orglog.setOperateDate(now);
			orglog.setClerkOrg(clerk.getOrgcode());
			orglog.setOperateContent(content);
			orglog.setOldOrgnum(code);
			orglog.setClerkNum(clerk.getCode());
			orglog.setClerkName(clerk.getName());
			orglog.setOperateType("ɾ������");
			orgDao.createOrgLog(orglog);	//���������䶯��־
			
			this.createManageLog(admincode, content);
			request.setAttribute("reloadflag", content);
			return this.showMessageJSP(actionMapping, request, "load","[ɾ���ɹ�] " + content);
		} catch (BusinessException e) {
			return this.errrForLogAndException(e, actionMapping, request,"load");
		}
	}

	public ActionForward merge(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String oldcode = request.getParameter("code");
		String newcode = request.getParameter("newcode");
		Org org = null;
		try {
			org = OrgService.getOrgByCode(oldcode);
			OrgService.mergeOrg(oldcode, newcode);

			String admincode = ((Clerk) request.getSession().getAttribute("clerk")).getCode();
			String content = "��������(������" + oldcode + "������" + newcode + ")";
			this.createManageLog(admincode, content);

			request.setAttribute("parentcode", org.getParentCode());
			request.setAttribute("reloadflag", content);
			return actionMapping.findForward("load");
		} catch (BusinessException e) {
			request.setAttribute("parentcode", org.getParentCode());
			return this.errrForLogAndException(e, actionMapping, request,"load");
		}
	}
	/**
	 * ��ת����������ҳ��
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward forwardmerge(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = "";
		OrgForm form = (OrgForm) actionForm;
		try {
			if (request.getParameter("code") != null)
				code = request.getParameter("code");
			else
				code = (String) request.getAttribute("code");
			List list=OrgService.getOrgList(code);
			Org org = OrgService.getOrgByCode(code);
			form.setCode(code);
			form.setName(org.getName());
			if(list!=null&&list.size()>1){
				String content = "�����������ܰ����¼����� ";
				request.setAttribute("parentcode", org.getParentCode());
				request.setAttribute("reloadflag", content);
				return this.showMessageJSP(actionMapping, request, "load","[����ʧ��] " + content);
			}else{
				request.setAttribute("code", code);
				return actionMapping.findForward("merge.success");
			}
			
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request,"merge.success");
		}
	}
	
	/*
	 * ���룺code��������
	 * Ajax��ʽ��ȡ�������� 
	 * ����������ƴ��ڷ��أ�������������ڷ��ؿ�
	 */
	public ActionForward getOrgname(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String code = request.getParameter("code");
		String orgname = "";
		try {
			Org org = OrgService.getOrgByCode(code);
			if(org != null)orgname = org.getName();
			response.setContentType("text/xml");
			response.setLocale(Locale.SIMPLIFIED_CHINESE);
			response.setCharacterEncoding("GBK");
			PrintWriter out = response.getWriter();
			out.print(orgname);
			out.close();
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, null);
		}
		return null;
	}

	/**
	 * �½�����
	 * @param mapping
	 * @param actionform
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward createOrg(ActionMapping mapping,
			ActionForm actionform, HttpServletRequest request,
			HttpServletResponse response) {
		OrgForm form = (OrgForm) actionform;
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		String admincode = clerk.getCode();
		String zhishu=request.getParameter("zhishu");
		try {
			if("".equals(form.getCode())||form.getCode()==null){
				return this.showMessageJSP(mapping, request, "load", "�����������");
			}
			Org bo = new Org();
			bo.setCode(form.getCode());
			bo.setName(form.getName());
			bo.setParentCode(form.getParentcode());
			bo.setTctd("��");
			//�������������Ӧ�ڵ�ʡ�л�����
			if ("2".equals(form.getWdflag())||"3".equals(form.getWdflag())){	//���л���֧��
				bo.setShOrgCode(form.getParentcode());		//���л��߷���
			}else{					//֧�����½��������»����ŵ�ʡ��Ϊ֧�еĸ�����
				Org zhOrg = OrgService.getOrgByCode(form.getParentcode());
				bo.setShOrgCode(zhOrg.getParentCode());
			}
			if (form.getWdflag() != null)
				if("��".equals(zhishu)){
					bo.setWdflag("3");
					bo.setZhiszh("zszh");
				}else{
					bo.setWdflag(form.getWdflag());
				}
			else
				return this.showMessageJSP(mapping, request, "load", "wdflag����Ϊ��");
			request.setAttribute("wdflag", form.getWdflag());//�쳣��ת��Ҫ����Wdflag�ֶΣ������´����ӻ����ᶪʧWdflag
			request.setAttribute("parentcode", bo.getParentCode());
/*			if (form.getWdflag().equals("1"))
				bo.setShOrgCode(form.getCode());
			else
				bo.setShOrgCode(clerk.getShOrgCode());
			if (form.getWdflag() != null)
				bo.setWdflag(form.getWdflag());
			else
				bo.setWdflag("0");
			
			Clerk orgManagerClerk = OrgService.createOrg(bo,clerk);
			String orgManagerClerkStr = ",�Զ������������Ա["+orgManagerClerk.getCode()+"]";
			
			SystemConfig systemConfig = SystemConfig.getInstance();
			String content = "";
			if("2".equals(systemConfig.getValue("clerk_guanlms")))
				if(systemConfig.getRootCode().equals(clerk.getOrgcode()))
				{
					content = bo.getName()+"["+bo.getCode()+"]";
				}else{
					content = bo.getName()+"["+bo.getCode()+"]";
				}
*/			
			String content = "���ӻ���:"+bo.getName()+"["+bo.getCode()+"]";
			OrgService.createOrgWithOutCreateManager(bo);
			this.createManageLog(admincode, content);

			OrgLog orglog= new OrgLog();//��������䶯��־
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
			String now = sdf.format(date);
			orglog.setOperateDate(now);
			orglog.setClerkOrg(clerk.getOrgcode());
			orglog.setOperateContent(content);
			orglog.setNewOrgnum(form.getCode());
			orglog.setClerkNum(clerk.getCode());
			orglog.setClerkName(clerk.getName());
			orglog.setOperateType("���ӻ���");
			orgDao.createOrgLog(orglog);	//���������䶯��־
			
			request.setAttribute("reloadflag", "����ɹ�");
			return this.showMessageJSP(mapping, request, "load", "���� "+bo.getName()+"["+bo.getCode()+"]���ӳɹ�");
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "add.success");
		}
	}

	public ActionForward updateOrg(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		OrgForm form = (OrgForm) actionForm;
		
		String oldCode=form.getCode();//ԭ������
		String oldName=form.getName();//ԭ������
		String newName=request.getParameter("newName");//�»�����
		String newCode=request.getParameter("newCode");//�»�����
		try {
			Org bo = OrgService.getOrgByCode(form.getCode());
			Org newBo = OrgService.getOrgByCode(newCode);
				if(StringUtils.isEmpty(newCode)){
					newCode = oldCode;
					if(newName==null||StringUtils.isEmpty(newName)){								
						return this.showMessageJSP(mapping, request, "updateforward.success", "[����ѡ��һ���޸���] ");			
					}
				}
				if(newBo != null){
					return this.showMessageJSP(mapping, request, "updateforward.success", "�Ѵ��ڻ�����["+newCode+"],�����޸� ");
				}

				if(oldName.equals(newName)&&oldCode.equals(newCode)){
					return this.showMessageJSP(mapping, request, "updateforward.success", "[������ͬ������Ҫ����] ");	
				}
				
				if(oldCode.equals(newCode)){
					
				}else{
					bo.setCode(newCode);
				}
				if(StringUtils.isEmpty(newName)){
					newName = oldName;
				}else{
					bo.setName(newName);
				}
				this.OrgService.updateOrg(bo);
				if(!(newCode.equals(oldCode))){									
					//�����¼��޸Ļ�����	
 					this.OrgService.updateForParentCode(newCode, oldCode);
						clerkService.updateOrg(newCode, oldCode);					
					//�ͻ�Ǩ�Ƶ��»�����
						zhanghbDao.updateOrgAndGuiYJGH(newCode, oldCode);
					//�޸���־����
						zhanghbDao.updateRizb(newCode, oldCode);					
						Org bo1 = OrgService.getOrgByCode(form.getCode());					
						this.OrgService.deleteOrgBycode(bo1);
				}
				String admincode = ((Clerk) request.getSession().getAttribute("clerk")).getCode();				
				String content = "�޸Ļ���[ԭ������:"+oldCode+",������:"+oldName+"],�޸ĺ�[������:"+newCode+",������:"+newName+"]";
				this.createManageLog(admincode, content);
				Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
				OrgLog orglog= new OrgLog();//��������䶯��־
				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
				String now = sdf.format(date);
				orglog.setOperateDate(now);
				orglog.setClerkOrg(clerk.getOrgcode());
				orglog.setOldOrgnum(oldCode);
				orglog.setOperateContent(content);
				orglog.setNewOrgnum(newCode);
				orglog.setClerkNum(clerk.getCode());
				orglog.setClerkName(clerk.getName());
				orglog.setOperateType("�޸Ļ���");
				orgDao.createOrgLog(orglog);	//���������䶯��־
				
				request.setAttribute("parentcode", bo.getParentCode());
				request.setAttribute("reloadflag", content);
				return this.showMessageJSP(mapping, request, "load", "[�޸ĳɹ�] " + content);
			
		} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("rootCode", SystemConfig.getInstance().getRootCode());
					return this.errrForLogAndException(e, mapping, request, "load");
		}
	}

	public ActionForward mergeOrg(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		OrgForm orgForm = (OrgForm) form;
		String code = request.getParameter("code");
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		ActionMessages errors = new ActionMessages();
		try {
			Org org = OrgService.getOrgByCode(orgForm.getCode());
			if (this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),orgForm.getNewcode()))
			{
				OrgService.mergeOrg(orgForm.getCode(),orgForm.getNewcode());
				String admincode = clerk.getCode();
				String content = "��������(������" + orgForm.getCode() + "������" + orgForm.getNewcode() + ")";
				this.createManageLog(admincode, content);
				request.setAttribute("parentcode", org.getParentCode());
				errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("errors.detail", "[�����ɹ�] " + content));
				this.saveErrors(request, errors);
			} else {
				errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("errors.detail", "[����ʧ��]����Ȩ�޲���:���ܿ��������!"));
				this.saveErrors(request, errors);
			}
			Org org_ = OrgService .getOrgByCode(code);
			if (org_ != null)
			{
				request.setAttribute("parentcode", org_.getParentCode());
			}
			return mapping.findForward("load");
		} catch (Exception e) {
			request.setAttribute("code", code);
			return this.errrForLogAndException(e, mapping, request,"merge.error");
		}finally{
			
		}
	}
	/**
	 * ��������
	 * @param mapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	//��������
	//�ı������ϵ 20170515 sun
	public ActionForward changeOrg(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			OrgForm form = (OrgForm) actionForm;
			String targetParentOrgCode = form.getParentcode();	//������Ŀ�������
			String oldOrgCode=form.getCode();					//ԭ������
			
			/*String newOrgCode = request.getParameter("newOrgCode");*/		//�»�����
			/*String newOrgName = request.getParameter("newOrgName");*/	
			String shengjlx = request.getParameter("shengjlx");			//�Ƿ�����Ϊֱ��֧��
			
			/*if(newOrgCode==null||"".equals(newOrgCode)){
				return this.showMessageJSP(mapping, request, "change.error", "�������»�����");
			}else{
				Org neworg = OrgService.getOrgByCode(newOrgCode);			
				if(neworg!=null){
					return this.showMessageJSP(mapping, request, "change.error", "����["+newOrgCode+"]�Ѵ��ڣ�");				
				}
			}*/
			
			
			/*if(newOrgName==null||"".equals(newOrgName)){
				newOrgName = oldOrgName;
			}*/
			Org targetParentOrg = OrgService.getOrgByCode(targetParentOrgCode);
			Org oldOrg = OrgService.getOrgByCode(oldOrgCode);
			//�ж�Ŀ���ϼ������Ƿ����
			if(oldOrg == null){
				return this.showMessageJSP(mapping, request, "change.error", "����["+oldOrgCode+"]������!");
			}
			if(targetParentOrg == null){
				request.setAttribute("code", oldOrgCode);
				return this.showMessageJSP(mapping, request, "change.error", "�ϼ�����["+form.getParentcode()+"]������!");
			}
			if(oldOrgCode.equals(targetParentOrg.getCode())){
				request.setAttribute("code", oldOrgCode);
				return this.showMessageJSP(mapping, request, "change.error", "�ϼ������Ų�����ԭ������");
			}
			Integer targetWdflag = Integer.valueOf(targetParentOrg.getWdflag())+1;
			Integer oldwdflag  = 	Integer.valueOf(oldOrg.getWdflag());
			//һ��֧�в���������ֱ��֧��
			if("��".equals(shengjlx)){
				if(!"3".equals(oldOrg.getWdflag())){
					return this.showMessageJSP(mapping, request, "change.error", "һ��֧�в���������ֱ��֧��");
				}
			}
			String s = SystemConfig.getInstance().getValue("org_ranking");
			if(targetWdflag>Integer.valueOf(s)){
				request.setAttribute("code", oldOrgCode);
				return this.showMessageJSP(mapping, request, "change.error", "�ı����֮�󳬳������ȼ���Χ");
			}
			//�µȼ��Ŵ�����ǰ�ȼ���
			Integer flag = 0;
			Integer i= targetWdflag-oldwdflag;
			if(targetWdflag>oldwdflag){
				List list = OrgService.getOrgList(oldOrgCode);
				if(list.size()>0){
					for(Object o:list){
						Org o1 = (Org)o;
						Org child = OrgService.getOrgByCode(o1.getCode());
						if(!StringUtils.isEmpty(child.getWdflag())){
							Integer target =Integer.valueOf(child.getWdflag())+i;
							if(target>flag){
								flag = target;
							}
						}else{
						}
						
					}
				}
				if(Integer.valueOf(s)<flag){
					request.setAttribute("code", oldOrgCode);
					return this.showMessageJSP(mapping, request, "change.error", "�ı����֮���ӻ������������ȼ���Χ");
				}
			}
			//�ж��Ƿ���������
			/*if(!(targetParentOrg.getWdflag().equals(targetWdflag))){
				return this.showMessageJSP(mapping, request, "change.error", "����["+oldOrg.getName()+"]ֻ�����������ڵ���һ����");
			}*/
				
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String content = "�ı��������ǰ[������:"+oldOrg.getCode()+",������:"+oldOrg.getName()+",�ϼ������ţ�"+oldOrg.getParentCode()+"],�ı����������[�ϼ�������:"+targetParentOrg.getCode()+"]";
			
			OrgLog orglog= new OrgLog();//��������䶯��־
			orglog.setOperateContent(content);
			orglog.setOldOrgnum(oldOrg.getCode());
			orglog.setClerkNum(clerk.getCode());
			orglog.setClerkName(clerk.getName());
			orglog.setClerkOrg(clerk.getOrgcode());
			orglog.setOperateType("�ı������ϵ");
			
			OrgService.changeRelation(oldOrg,targetParentOrg,shengjlx, orglog);
			this.createManageLog(clerk.getCode(), "�ı������ϵ:"+content);
			
			request.setAttribute("parentcode", targetParentOrgCode);
			request.setAttribute("reloadflag", "����ɹ�");
			return this.showMessageJSP(mapping, request, "load","�ı������ϵ�ɹ�:"+content);			
		} catch (Exception e) {			
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "load");
		}
	}
//����Ǩ��
	public ActionForward moveOrg(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			OrgForm form = (OrgForm) actionForm;
			//String newOrgCode = form.getNewcode();	//Ǩ�Ƶ�Ŀ�������
			String newOrgCode = request.getParameter("newOrgCode");
			String oldOrgCode=form.getCode();					//ԭ������
			String oldOrgName = form.getName();
			//Ŀ�����������ԭ����
			if(oldOrgCode.equals(newOrgCode)){
				return this.showMessageJSP(mapping, request, "move.error", "Ŀ�����������ԭ����");
			}
			if(newOrgCode == null || oldOrgName == null || oldOrgCode == null){
				return this.showMessageJSP(mapping, request, "move.error", "����д��Ϣ");
			}
			//Ǩ�ƻ����������¼�
			@SuppressWarnings("unchecked")
			List<Org> oldOrglist = OrgService.getOrgChildrenByCode(oldOrgCode);
			if(oldOrglist.size()>1){
				return this.showMessageJSP(mapping, request, "move.error", "Ǩ�ƻ����������¼�");
			}
			//�ж�Ŀ���ϼ������Ƿ����
			Org newOrg = OrgService.getOrgByCode(newOrgCode);
			if(newOrg == null){
				request.setAttribute("code", oldOrgCode);
				return this.showMessageJSP(mapping, request, "move.error", "����["+form.getNewcode()+"]������!");
			}	
			Org oldOrg = OrgService.getOrgByCode(oldOrgCode);
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String content = "Ǩ��ǰ�˺�[������:"+oldOrg.getCode()+",������:"+oldOrg.getName()+"],Ǩ�ƺ��˺�[������:"+newOrg.getCode()+",������:"+newOrg.getName()+"]";
			
			OrgLog orglog= new OrgLog();//��������䶯��־
			orglog.setOperateContent(content);
			orglog.setNewOrgnum(newOrgCode);
			orglog.setOldOrgnum(oldOrg.getCode());
			orglog.setClerkNum(clerk.getCode());
			orglog.setClerkName(clerk.getName());
			orglog.setClerkOrg(clerk.getOrgcode());
			orglog.setOperateType("����Ǩ��");
			
			OrgService.moveOrg_(oldOrg,newOrg,orglog);
			this.createManageLog(clerk.getCode(), "����Ǩ��:"+content,clerk);
			
			request.setAttribute("parentcode", newOrg.getParentCode());
			request.setAttribute("reloadflag", "����ɹ�");
			return this.showMessageJSP(mapping, request, "load","����Ǩ�Ƴɹ�:"+content);			
		} catch (Exception e) {			
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "load");
		}
	}
//��������
	public ActionForward orgAddtoOther(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try{
			OrgForm form = (OrgForm)actionForm;
			String newOrgCode = form.getNewcode();//�»�����					
			String oldOrgCode= form.getCode();//ԭ������		
			Org neworg =null;
			if(oldOrgCode.equals(newOrgCode)){
				return this.showMessageJSP(mapping, request, "merge.error", "���������Ų�����ԭ������");
			}
			if(newOrgCode==null||"".equals(newOrgCode)){//�жϻ������Ƿ�Ϊ��
				return this.showMessageJSP(mapping, request, "merge.error", "�������»�����");
			}else{
				 neworg = OrgService.getOrgByCode(newOrgCode);//�жϻ����Ƿ����
				if(neworg==null){
					return this.showMessageJSP(mapping, request, "merge.error", "����["+neworg.getName()+"]�����ڣ�");
				}
			}
				
			Org oldOrg = OrgService.getOrgByCode(oldOrgCode);//��ȡԭ������Ϣ
			String targetWdflag = (String.valueOf(Integer.valueOf(oldOrg.getWdflag())));//��λԭ����Ҫ�������ĵȼ�Wdflag
			//�ж��Ƿ�Ϊͬһ�ȼ�����
			/*if(!(neworg.getWdflag().equals(targetWdflag))){
				return this.showMessageJSP(mapping, request, "merge.error", "����["+oldOrgCode+"]ֻ�ܳ�����ͬһ�ȼ������£�");
			}*/
			//�ж��Ƿ�Ϊ�������»���
			if(Integer.valueOf(oldOrg.getWdflag())<3){
				return this.showMessageJSP(mapping, request, "merge.error", "���м����ϻ������ܳ��� ��");
			}
			
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String content = "����ǰ[������:"+oldOrg.getCode()+",������:"+oldOrg.getName()+"],������[������:"+newOrgCode+",������:"+neworg.getName()+"]";
			

			OrgLog orglog= new OrgLog();//��������䶯��־
			orglog.setOperateContent(content);
			orglog.setNewOrgnum(newOrgCode);
			orglog.setOldOrgnum(oldOrg.getCode());
			orglog.setClerkNum(clerk.getCode());
			orglog.setClerkName(clerk.getName());
			orglog.setClerkOrg(clerk.getOrgcode());
			orglog.setOperateType("��������");
			
			OrgService.addtoOther(oldOrg,neworg,orglog);
			this.createManageLog(clerk.getCode(), "��������:"+content);
			
			request.setAttribute("parentcode", neworg.getParentCode());
			request.setAttribute("reloadflag", "����ɹ�");
			return this.showMessageJSP(mapping, request, "load","���������ɹ�:"+content);			
		} catch (Exception e) {			
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "load");
		}
	
	}

	
	/**
	 * ��д download����,����������Ϣ
	 */

	public ActionForward download(ActionMapping mapping, ActionForm actionForm,
			HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, BusinessException {
		String file = "org.xls";
		String orgcode = request.getParameter("parentcode");
		String include = request.getParameter("include");
		Map map = new HashMap();
		List list;
		try {
			list = OrgService.exportOrg(orgcode, include);
			if (list.size() > 0) {
				HSSFWorkbook wb = ExpOrImp
						.exportExcel("organarchives", list, 6);
				response.setHeader("Content-disposition",
						"attachment;filename=" + file);
				response.setContentType("application/rar");
				response.setContentLength(wb.getSheetIndex(file));
				ServletOutputStream out = response.getOutputStream();
				wb.write(out);
				out.flush();
			} else {
				throw new BusinessException("����ļ������ڣ�");
			}
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return this.showMessageJSP(mapping, request, "load",
					getPromptService().getPromptMsg("YYA-export-error", map));
		}
	}

	/**
	 * ���������Ϣ
	 * (������ʣ�excle)
	 */
	public ActionForward importOrg(ActionMapping mapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		request.setAttribute("parentcode", request.getParameter("parentcode"));
		PromptService promptService = getPromptService();
		OrgForm orgForm = (OrgForm) actionForm;
		FormFile file = (FormFile) orgForm.getFile();
		InputStream input = null;
		try {
			input = file.getInputStream();
			int size = input.available();
			if (size<=0)
			{
				return this.showMessageJSP(mapping, request, "load","�ϴ��ļ�Ϊ����Ϊ��!");
			}
			POIFSFileSystem fs = new POIFSFileSystem(input);
			HSSFWorkbook wb = new HSSFWorkbook(fs);
			HSSFSheet sheet = wb.getSheetAt(0);
			boolean isImport = false;
			isImport = OrgService.importOrg(sheet);
			if (isImport)
			{
				return this.showMessageJSP(mapping, request, "load", promptService.getPromptMsg("YYA-import-ok", new HashMap()));
			} else {
				return this.showMessageJSP(mapping, request, "load",promptService.getPromptMsg("YYA-import-error", new HashMap()));
			}
		} catch (Exception e) {
			e.printStackTrace();
			return this.showMessageJSP(mapping, request, "load",promptService.getPromptMsg("YYA-import-error", new HashMap()));
		}
	}

}
