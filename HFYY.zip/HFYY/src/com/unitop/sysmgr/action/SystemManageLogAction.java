package com.unitop.sysmgr.action;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.form.SystemManageLogForm;
import com.unitop.sysmgr.service.ClerkManageService;
import com.unitop.sysmgr.service.OrgService;
import com.unitop.sysmgr.service.impl.QueryServiceImpl;
/*
 * ����Ա��־��ѯ
 */
@Controller("/managelog")
public class SystemManageLogAction extends ExDispatchAction {

	private final static String SUCCESS = "success";
	@Resource
	private ClerkManageService clerkManageService;
	@Resource
	private OrgService OrgService;
	
	public boolean CanOperDesOrg(String OperOrg, String DesOrg) {
		return this.getSystemMgrService().CanOperDesOrg(OperOrg, DesOrg);
	}

	public ActionForward execute(ActionMapping mapping, ActionForm actionform,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			SystemManageLogForm form = (SystemManageLogForm) actionform;
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			Clerk managerclerk = clerkManageService.getClerkByCode(form.getAdmincode());
			String netpointfiag = managerclerk.getOrgcode();
			if (!OrgService.validateOrg(clerk.getOrgcode(),netpointfiag))
			{
				return this.showMessageJSP(mapping,request,SUCCESS,"������Ч������Ա�����ڻ�û��Ȩ�޲鿴�ù�Ա��");
			}else{
				TabsBo TabsBo = this.createTabsBo(request);
				QueryServiceImpl queryServiceImpl = (QueryServiceImpl) this.getQueryService();
				queryServiceImpl.setTabsService(TabsBo);
				TabsBo tabsBo = this.getQueryService().findSystemManageLog(form.getAdmincode(),form.getBegindate(),form.getEnddate());
				this.showTabsModel(request, tabsBo);
				return super.showMessageJSPForFeny(mapping,request,tabsBo,SUCCESS);
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, mapping, request, "error");
		}
	}
	//public ActionForward log(ActionMapping mapping, ActionForm actionform,
	//		HttpServletRequest request, HttpServletResponse response) {
	//	return mapping.findForward("success");
	//}
}