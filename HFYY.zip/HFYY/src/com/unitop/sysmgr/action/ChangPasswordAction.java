package com.unitop.sysmgr.action;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.exception.BusinessException;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.form.PasswordForm;
import com.unitop.sysmgr.service.ClerkManageService;

/*
 * ��Ա�����޸ķ���
 * 
 */
@Controller("/changepwd")
public class ChangPasswordAction extends ExDispatchAction {
	@Resource
	private ClerkManageService clerkManageService;
	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		String flag = request.getParameter("flag");
		PasswordForm passwordform = (PasswordForm) form;
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		try {
			if (!clerk.getPassword().equals(passwordform.getPassword()))
			{
				return this.showMessageJSP(mapping,request,"changepwd.error","��������벻��ȷ!");
			}
			//��Ա��һ�ε�¼�Ѿ�ǿ���޸Ĺ�����
			clerk.setClerkstatus("1");
			clerkManageService.changePassword(clerk,passwordform.getNewpassword());
			
			clerk.setPassword(passwordform.getNewpassword());
			
			if ("�������".equals(clerk.clerkMotion)||"ǿ���޸�����".equals(clerk.clerkMotion))
			{
				//��Աǿ���޸�����
				request.getSession().removeValue("clerk");
				return super.showMessageJSP(mapping, request, "changepwd.sucess", "�޸�����ɹ�!");
			}else{
				//��Ա�������� �����޸�����
				/*PrintWriter out;
				out = response.getWriter();
				out.print(0);
				out.close();
				return null;*/
				request.setAttribute("changepwdtisxx", "�޸�����ɹ�!");
				return super.showMessageJSP(mapping, request, "changepwd.loginout", "�޸�����ɹ�!");
			}
		} catch (Exception e) {
			logString.append("(" + getClass() + ") ���룺������ " + passwordform.getPassword()).append(" ������ " + passwordform.getNewpassword());
			return this.errrForLogAndException(e, mapping, request,"changepwd.error");
		}finally{
			passwordform.setNewpassword(null);
			passwordform.setNewpassword1(null);
			passwordform.setPassword(null);
		}
	}
	
	public ActionForward changePassWord(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) {
			PasswordForm passwordform = (PasswordForm) form;
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			PrintWriter out;
			try {
				if (!clerk.getPassword().equals(passwordform.getPassword()))
				{
					return this.showMessageJSP(mapping,request,"changepwd.error","��������벻��ȷ!");
				}
				//��Ա��һ�ε�¼�Ѿ�ǿ���޸Ĺ�����
				clerk.setClerkstatus("1");
				clerkManageService.changePassword(clerk,passwordform.getNewpassword());
				
				clerk.setPassword(passwordform.getNewpassword());
				
				response.setContentType("text/xml");
				response.setLocale(Locale.SIMPLIFIED_CHINESE);
				response.setCharacterEncoding("GBK");
				out = response.getWriter();
				out.println(0);
				out.close();
				return null;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			} catch (BusinessException e) {
				logString.append("(" + getClass() + ") ���룺������ " + passwordform.getPassword()).append(" ������ " + passwordform.getNewpassword());
				return this.errrForLogAndException(e, mapping, request,"changepwd.error");
			}finally{
				passwordform.setNewpassword(null);
				passwordform.setNewpassword1(null);
				passwordform.setPassword(null);
			}
			
	}
}