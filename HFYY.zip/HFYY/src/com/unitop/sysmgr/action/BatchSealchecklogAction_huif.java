package com.unitop.sysmgr.action;


import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.config.SystemConfig;
import com.unitop.framework.util.JsonSystemTool;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.form.SealchecklogForm;
import com.unitop.sysmgr.service.impl.QueryServiceImpl;

/**
 * ���   �����������ܱ���   ���յ�����ӡ��־��ѯ
 * @author BBBBBBao
 *
 */

@Controller("/batchsealchecklog_huif")
public class BatchSealchecklogAction_huif extends ExDispatchAction {
	
	
	@Resource
	private OrgDao orgDao;
	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {			
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			//��Ա��Ϣ��ʽת��Ϊjson
			String jsonClerkrStr = JsonSystemTool.toJsonForClerkForZhang(clerk);
			request.setAttribute("jsonClerkrStr", jsonClerkrStr);
			SealchecklogForm logForm = (SealchecklogForm) form;
			String beginDate = logForm.getBegindate();
			String endDate = logForm.getEnddate();

			TabsBo TabsBo = this.createTabsBo(request);
			QueryServiceImpl queryServiceImpl = (QueryServiceImpl) this.getQueryService();
			queryServiceImpl.setTabsService(TabsBo);
			//����			
			TabsBo tabsBo = this.getQueryService().findSealCheckLog(null,null,null, null, null, null, beginDate,endDate);
			this.showTabsModel(request, tabsBo);
			return super.showMessageJSPForFeny(mapping,request,tabsBo,"success");
		} catch (Exception e) {
			e.getStackTrace();
			return this.errrForLogAndException(e, mapping, request, "success");
		}
	}
	
}