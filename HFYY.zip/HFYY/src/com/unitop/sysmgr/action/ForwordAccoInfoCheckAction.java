package com.unitop.sysmgr.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

@Controller("/forwardAccInfoCheck")
public class ForwordAccoInfoCheckAction extends ExDispatchAction{

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response){
		String zhangh = request.getParameter("zhangh");
		String hum = request.getParameter("hum");
		String zhanghxz = request.getParameter("zhanghxz");
		String kehh = request.getParameter("kehh");
		String jigh = request.getParameter("jigh");
		String qiyrq = request.getParameter("qiyrq");
		String beiz = request.getParameter("beiz");
		
		String lianxr = request.getParameter("lianxr");
		String dianh = request.getParameter("dianh");
		String diz = request.getParameter("diz");
		String jiesywsqr = request.getParameter("jiesywsqr");
		String jiesywsqrdh = request.getParameter("jiesywsqrdh");
		
		//ZZ1221
		String tongctd=request.getParameter("tongctd");
		String shefzid=request.getParameter("shefzid");
		String youzbm=request.getParameter("youzbm");
		String kaihrq=request.getParameter("kaihrq");
		
		request.setAttribute("tongctd", tongctd);
		request.setAttribute("shefzid", shefzid);
		request.setAttribute("youzbm", youzbm);
		request.setAttribute("kaihrq", kaihrq);
		
		request.setAttribute("zhangh", zhangh);
		request.setAttribute("hum", hum);
		request.setAttribute("zhanghxz", zhanghxz);
		request.setAttribute("kehh", kehh);
		request.setAttribute("jigh", jigh);
		request.setAttribute("qiyrq", qiyrq);
		request.setAttribute("beiz", beiz);
		
		request.setAttribute("lianxr", lianxr);
		request.setAttribute("dianh", dianh);
		request.setAttribute("diz", diz);
		request.setAttribute("jiesywsqr", jiesywsqr);
		request.setAttribute("jiesywsqrdh", jiesywsqrdh);
		
		
		return mapping.findForward("success");					
	}
}
