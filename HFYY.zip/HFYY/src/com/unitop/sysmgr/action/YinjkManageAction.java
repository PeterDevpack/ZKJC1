package com.unitop.sysmgr.action;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.form.YinjkForm;
import com.unitop.sysmgr.service.KagService;
import com.unitop.sysmgr.service.impl.KagServiceImpl;

@Controller("/yinjkOperate")
public class YinjkManageAction extends ExDispatchAction{
	
	@Resource
	private KagService kagService;
	
	//��ת����ѯ�͹黹�������
	public ActionForward toApply(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("toApply");
		return actionMapping.findForward("toApply");
	}
	public ActionForward getYinjk(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		YinjkForm yinjkForm = (YinjkForm) actionForm;
		try {
			TabsBo TabsBo = this.createTabsBo(request);
			KagServiceImpl kagServiceImpl = (KagServiceImpl) kagService;
			kagServiceImpl.setTabsService(TabsBo);
			TabsBo tabsBo = kagService.getYinjk(yinjkForm);
			this.showTabsModel(request, tabsBo);
			return super.showMessageJSPForFeny(actionMapping,request,tabsBo,"toApply");
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request, "toputandgetcard");
		}
	}
}
