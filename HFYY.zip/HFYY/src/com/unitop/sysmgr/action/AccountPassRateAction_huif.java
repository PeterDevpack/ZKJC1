package com.unitop.sysmgr.action;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.framework.util.DateTool;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.dao.PassRateDao;
import com.unitop.sysmgr.form.PassRateForm;
import com.unitop.sysmgr.service.OrgService;

//�˻�ͨ����
@Controller("/accountPassRate_huif")
public class AccountPassRateAction_huif extends ExDispatchAction {
	@Resource
	private OrgService orgService;
	
	
	@Resource
	private PassRateDao passRateDao;

	public ActionForward view(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {	
			request.setAttribute("totalRows", new Integer(0));
			//���ڻ���
			String begindate = DateTool.getNowDayForYYYMMDD().substring(0,7)+"-01";
			String enddate = DateTool.getNowDayForYYYMMDD();					
			request.setAttribute("riqfw", begindate);
			request.setAttribute("riqend", enddate);
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "view");
		}
		return mapping.findForward("view");
	}

	public ActionForward select(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
			PassRateForm passRateForm = (PassRateForm) form;
		try {
			//���ڻ���			
			String riqfw=passRateForm.getRiqfw();
			String riqend=passRateForm.getRiqend();										
			request.setAttribute("riqfw", riqfw);
			request.setAttribute("riqend", riqend);
			String jigh=request.getParameter("jigh");
			Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
			if(!(jigh==null||jigh.equals(""))){
				//�жϻ���Ȩ��			
				String res=orgService.CanOperDesOrg(clerk2.getOrgcode(), jigh);
				if(res.equals("2")){
					return this.showMessageJSPforcx(mapping, request, "success","��û��Ȩ�޲鿴:["+jigh+"]�µ��˺ţ�");					
				}else if(res.equals("1")){
					return this.showMessageJSPforcx(mapping, request, "success","���������ڣ�");
				}
			}else{
				return this.showMessageJSPforcx(mapping, request, "success","����������Ϊ�գ�");
			}
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			 Date date = format.parse(riqfw);
			 Date date2 = format.parse(riqend);
			 int days = (int) ((date2.getTime() - date.getTime()) / (1000*3600*24));
			if(riqfw==null||riqfw.equals("")||riqend==null||riqend.equals("")){
				return this.showMessageJSPforcx(mapping, request, "success","��ӡʱ�䲻��Ϊ�գ�");
			}else if(days>90){
				return this.showMessageJSPforcx(mapping, request, "success","��ӡʱ��β��ܳ���90�죡");
			}
			TabsBo TabsBo = this.createTabsBo(request);  
			TabsBo tabsBo = passRateDao.getAccPassRate(riqfw,riqend,jigh,"",TabsBo);
			this.showTabsModel(request, tabsBo);
			request.setAttribute("totalRows", tabsBo.getCounts());
			if(tabsBo.getCounts()==0)
			{
				return this.showMessageJSPforcx(mapping, request, "success","�޲�ѯ�����");
			}else{
				return mapping.findForward("success");
			}
		} catch (Exception e){
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "view");
		}
	}
}

