package com.unitop.sysmgr.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Controller;

import com.unitop.bank.DataSourceFactory;
import com.unitop.sysmgr.service.DanbwhService;
@Controller("/operDB")
public class OperDBAction extends ExDispatchAction {
	
	//��ѯ����[MAX]����
	private int  PAGE_COUNTS=500;
	private String SQL = null;
	private int lX = 0;
	private int UPDATE_COUNTS;
	private String RMESSAGE = "";
	
	@Resource
	private DanbwhService DanbwhService;
	/*
	 * ���� ��ת
	 */
	public ActionForward list(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response){
			try{
				return actionMapping.findForward("list");
			}catch(Exception e){
				return this.processException(actionMapping, request, e, "list");
			}
	}
	/*
	 * ���� �ύ����
	 */
	public ActionForward doWork(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response){
			String temp1 = request.getParameter("sql");
			SQL  = request.getParameter("sql");
			request.setAttribute("sql", temp1);
			
		try{
			this.paseSQL();
			this.exeDDL();
			this.exeMessage();
			this.processBusinessException(actionMapping, request, RMESSAGE);
			
			if(lX==1)
			{
				List<Map> DataList = DanbwhService.page(SQL,0, PAGE_COUNTS);
				if(DataList.size()==1) return this.showMessageJSP(actionMapping, request, "list", "û�в�ѯ����¼!");;
				List  titleList = new ArrayList();
				//���ݴ���
				{		
						Map MapTemp =(Map) DataList.get(1);
						Iterator it = MapTemp.entrySet().iterator();
						while(it.hasNext())
						{
							Map.Entry entry = (Map.Entry) it.next();
					        String title = (String) entry.getKey();
					        Map  temp = new HashMap();
					        temp.put("TITLE",title);
							titleList.add(temp);
						}
						DataList.remove(0);
				}
				request.setAttribute("titleList", titleList);
				request.setAttribute("dataList", DataList);
			}
				return actionMapping.findForward("list");
			}catch(Exception e){
				e.printStackTrace();
				return this.processException(actionMapping, request, e, "list");
			}
	}
	//SQL ����[simple]
	private void  paseSQL(){
		if(SQL.equals(null)||SQL.equals(""))
		{
			lX = 0;
		}
		if(SQL.indexOf("select ")!=-1)
		{
			lX = 1;
		}
		if(SQL.indexOf("insert ")!=-1)
		{
			lX = 2;
		}
		if(SQL.indexOf("update ")!=-1)
		{
			lX = 3;
		}
		if(SQL.indexOf("delete ")!=-1)
		{
			lX = 4;
		}
		
	}
	//DDL ����
	private void  exeDDL() throws Exception{
		
		Connection conn = null;
		PreparedStatement pre = null;
		
		try{
			conn = DataSourceUtils.getConnection(DataSourceFactory.getDataSourceByPool());
			pre = conn.prepareStatement(SQL);
			switch(lX)
			{
				case 2: pre.execute();break;
				case 3:	UPDATE_COUNTS = pre.executeUpdate();break;
				case 4: pre.execute();break;
			}
		}catch(Exception e){
			throw new Exception(e);
		}finally{
			if(conn!=null)
			{
				conn.close();
			}
			if(pre!=null)
			{
				pre.close();
			}
		}
	}
	//DDL ����
	private void  exeMessage() {
		if(lX == 0)
		{
			RMESSAGE ="SQL�����Ч!";
		}
		if(lX == 1)
		{
			RMESSAGE ="��ѯ�ɹ�";
		}
		if(lX == 2)
		{
			RMESSAGE ="����ɹ�";
		}
		if(lX == 3)
		{
			RMESSAGE ="���³ɹ� [����������:"+UPDATE_COUNTS+"]";
		}
		if(lX == 4)
		{
			RMESSAGE ="ɾ���ɹ�";
		}
	}
}