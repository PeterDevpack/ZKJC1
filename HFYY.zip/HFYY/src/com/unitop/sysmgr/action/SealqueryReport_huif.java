package com.unitop.sysmgr.action;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.form.SealchecklogForm;
import com.unitop.sysmgr.service.impl.QueryServiceImpl;

@Controller("/sealqueryReport_huif")
public class SealqueryReport_huif extends ExDispatchAction{
	@Resource
	private OrgDao orgDao;
	
	
	public ActionForward showlist(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		
		try {
			//��ȡ������Ա
			Clerk clerk =(Clerk) request.getSession().getAttribute("clerk");
			//��ȡ��������
			SealchecklogForm sealchecklogForm = (SealchecklogForm) form;
			request.setAttribute("totalRows", new Integer(0));
			//ѡ������
			String jigh=request.getParameter("orgCode1");	
			
			
			System.out.println(jigh);
			//��ȡʱ��
			String beginDate = sealchecklogForm.getBegindate();
			String endDate = sealchecklogForm.getEnddate();
			
			//��ȡ������Ա
			Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
			String code2=clerk2.getOrgcode();	
			JSONArray jsonArray = new JSONArray();	
			List<Org> orgList=orgDao.getAllOrg(code2);			
			for(Org orgltem:orgList){											
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("id", orgltem.getCode());
					jsonObject.put("pId", orgltem.getParentCode());
					jsonObject.put("name", orgltem.getName());	
					jsonObject.put("wdflag", orgltem.getWdflag());
					if(code2.equals(orgltem.getCode())){
						jsonObject.put("open", "true");					
						jsonObject.put("nocheck", false);
					}
					jsonArray.add(jsonObject);
					if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
						jsonObject.put("id","banb"+orgltem.getCode());
						jsonObject.put("pId", orgltem.getCode());
						jsonObject.put("name", orgltem.getName()+"(����)");
						jsonArray.add(jsonObject);
					}
			}	
			String str=jsonArray.toString();
			request.setAttribute("Jsonstr",str);
			
			//��ҳ��ѯ
			TabsBo TabsBo = this.createTabsBo(request);
			QueryServiceImpl queryServiceImpl = (QueryServiceImpl) this.getQueryService();
			queryServiceImpl.setTabsService(TabsBo);
			TabsBo tabsBo =null;

			tabsBo = this.getQueryService().finyinjrz(beginDate,endDate,jigh);
			System.out.println("��ҳ����********"+tabsBo.toString());

			this.showTabsModel(request, tabsBo);
			return super.showMessageJSPForFeny(mapping,request,tabsBo,"list");
			
		} catch (Exception e){
			e.printStackTrace();
			return this.errrForLogAndException(e, mapping, request, "success");
		}
	}
	
	
	public ActionForward view(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		try {			
			Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
			String code2=clerk2.getOrgcode();	
			JSONArray jsonArray = new JSONArray();	
			List<Org> orgList=orgDao.getAllOrg(code2);			
			for(Org orgltem:orgList){											
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("id", orgltem.getCode());
					jsonObject.put("pId", orgltem.getParentCode());
					jsonObject.put("name", orgltem.getName());	
					jsonObject.put("wdflag", orgltem.getWdflag());
					if(code2.equals(orgltem.getCode())){
						jsonObject.put("open", "true");					
						jsonObject.put("nocheck", false);
					}
					jsonArray.add(jsonObject);
					if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
						jsonObject.put("id","banb"+orgltem.getCode());
						jsonObject.put("pId", orgltem.getCode());
						jsonObject.put("name", orgltem.getName()+"(����)");
						jsonArray.add(jsonObject);
					}
			}	
			String str=jsonArray.toString();
			request.setAttribute("Jsonstr",str);						
		} catch (Exception e) {
			return this.errrForLogAndException(e, mapping, request, "success");
		}
		return mapping.findForward("show");
	}
}
