package com.unitop.sysmgr.action;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URLDecoder;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import net.sf.json.JSONArray;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.bank.CommonUtil;
import com.unitop.config.SystemConfig;
import com.unitop.exception.BusinessException;
import com.unitop.framework.util.JsonSystemTool;
import com.unitop.framework.util.StringUtil;
import com.unitop.sysmgr.action.project.AddZero;
import com.unitop.sysmgr.action.project.SendHX;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.PiaojyxwjbId;
import com.unitop.sysmgr.bo.ScData;
import com.unitop.sysmgr.bo.Yinjb;
import com.unitop.sysmgr.bo.Yinjcyrzb;
import com.unitop.sysmgr.bo.Zhanghb;
import com.unitop.sysmgr.bo.Zhanghxz;
import com.unitop.sysmgr.dao.YinjkDao;
import com.unitop.sysmgr.dao.ZhanghbDao;
import com.unitop.sysmgr.form.AccountinfoForm;
import com.unitop.sysmgr.service.AccountImageServcie;
import com.unitop.sysmgr.service.ClerkManageService;
import com.unitop.sysmgr.service.Logservice;
import com.unitop.sysmgr.service.OrgService;
import com.unitop.sysmgr.service.ZhanghbService;
import com.unitop.sysmgr.service.ZhanghxzService;
import com.unitop.sysmgr.service.impl.VoucherMgrServiceImpl;
import com.unitop.util.SocketConnect;
@Controller("/accountinfo")
public class AccountinfoAction extends ExDispatchAction {
	@Resource
	private ZhanghbDao ZhanghbDao;
	@Resource
	private ZhanghbService ZhanghbService;
	@Resource
	private AccountImageServcie AccountImageServcie;
	@Resource
	private ZhanghxzService zhanghxzService;
	@Resource
	private OrgService orgService;
	
	@Resource
	private ClerkManageService clerService;
	@Resource
	private YinjkDao yinjkDao;
	@Resource
	private VoucherMgrServiceImpl voucherMgrServiceImpl;
	@Resource
	private Logservice logservice;
	protected DataInputStream in;
	

	
	/*
	 * �Ӻ���ȡֵ
	 */
	private static int count = 0;

	public boolean CanOperDesOrg(String DesOrg, String OperOrg)
	{
		return this.getSystemMgrService().CanOperDesOrg(OperOrg, DesOrg);
	}
	
	/*
	 * �°���ʺ���ת
	 */
	public ActionForward net_view(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			//����Ա��Ϣ��ʽ��>json
			String jsonClerkrStr = JsonSystemTool.toJsonForClerkForZhang(clerk);
			request.setAttribute("jsonClerkrStr", jsonClerkrStr);
			return actionMapping.findForward("accountinfo.net.view.success");
	}
	
	/*
	 * �°���ʺŲ�ѯ
	 */
	public ActionForward net_select(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String zhangh = request.getParameter("zhangh");
		try{
			Zhanghb zhanghb = ZhanghbService.getZhanghb(zhangh);
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.view.success", "û��Ȩ�޲鿴�˺�:["+zhanghb.getZhangh()+"]");
			}
			request.setAttribute("Zhanghb", zhanghb);
			} catch (Exception e) {
				return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.view.success");
			}finally{
				//����Ա��Ϣ��ʽ��>json
				String jsonClerkrStr = JsonSystemTool.toJsonForClerkForZhang(clerk);
				request.setAttribute("jsonClerkrStr", jsonClerkrStr);
			}
			return actionMapping.findForward("accountinfo.net.view.success");
	}
	
	/*
	 * �°���˺Ų�ѯ excel����
	 */
	public ActionForward net_excel(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			String zhangh = request.getParameter("zhangh");
			try{
					Zhanghb Zhanghb = ZhanghbService.getZhanghb(zhangh);
					response.setHeader("Content-Type", "application/octet-stream");
					response.setHeader("Content-Disposition", "attachment;   filename=\"log.csv\"");
					WritableWorkbook book;
					book = Workbook.createWorkbook(response.getOutputStream());
					
					WritableSheet sheet = book.createSheet("Accountinfo", 0);
					
					Label name = new Label(0, 0, "�˺�");
					sheet.addCell(name);
					name = new Label(0, 1, Zhanghb.getZhangh());
					sheet.addCell(name);
					
					name = new Label(1, 0, "������");
					sheet.addCell(name);
					name = new Label(1, 1, Zhanghb.getJigh());
					sheet.addCell(name);
					
					name = new Label(2, 0, "����");
					sheet.addCell(name);
					name = new Label(2, 1, Zhanghb.getHum());
					sheet.addCell(name);
					
					name = new Label(3, 0, "��ַ");
					sheet.addCell(name);
					name = new Label(3, 1, Zhanghb.getDiz());
					sheet.addCell(name);
					
					name = new Label(4, 0, "��������");
					sheet.addCell(name);
					name = new Label(4, 1, Zhanghb.getYouzbm());
					sheet.addCell(name);
					
					name = new Label(5, 0, "��������");
					sheet.addCell(name);
					name = new Label(5, 1, Zhanghb.getKaihrq());
					sheet.addCell(name);
					
//					name = new Label(6, 0, "��������");
//					sheet.addCell(name);
//					name = new Label(6, 1, Zhanghb.getQiyrq());
//					sheet.addCell(name);
					
					name = new Label(6, 0, "�ͻ���");
					sheet.addCell(name);
					name = new Label(6, 1, Zhanghb.getKehh());
					sheet.addCell(name);
					
					name = new Label(7, 0, "���Һ�");
					sheet.addCell(name);
					name = new Label(7, 1, Zhanghb.getHuobh());
					sheet.addCell(name);
					
					name = new Label(8, 0, "�Ƿ�ͨ��ͨ�һ�");
					sheet.addCell(name);
					name = new Label(8, 1, Zhanghb.getTongctd());
					sheet.addCell(name);
					
					name = new Label(9, 0, "�Ƿ���ӡ��");
					sheet.addCell(name);
					name = new Label(9, 1, Zhanghb.getYouwyj());
					sheet.addCell(name);
					
					name = new Label(10, 0, "�Ƿ���ӡ�����");
					sheet.addCell(name);
					name = new Label(10, 1, Zhanghb.getYouwzh());
					sheet.addCell(name);
					
					name = new Label(11, 0, "�˻�״̬");
					sheet.addCell(name);
					name = new Label(11, 1, Zhanghb.getZhanghshzt());
					sheet.addCell(name);
					
					name = new Label(12, 0, "ӡ��״̬");
					sheet.addCell(name);
					name = new Label(12, 1, Zhanghb.getYinjshzt());
					sheet.addCell(name);
					
					name = new Label(13, 0, "���״̬");
					sheet.addCell(name);
					name = new Label(13, 1, Zhanghb.getZuhshzt());
					sheet.addCell(name);
					
					name = new Label(14, 0, "��ע");
					sheet.addCell(name);
					name = new Label(14, 1, Zhanghb.getBeiz());
					sheet.addCell(name);
					
					book.write();
					book.close();
					request.getRequestDispatcher("").forward(request, response);
			} catch (Exception e) {
				return this.errrForLogAndException(e, actionMapping, request, null);
			}
			return null;
	}

	
	/*
	 * �˺���ϸ��ѯ .net
	 */
	public ActionForward scanAccountinfo(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		try {
			String zhangh = request.getParameter("zhangh");
			Zhanghb Zhanghb = ZhanghbService.getZhanghb(zhangh);
			request.setAttribute("Zhanghb", Zhanghb);
			return actionMapping.findForward("accountinfo.net.scan.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request,"accountinfo.net.scan.success");
		}finally{
			//����Ա��Ϣ��ʽ��>json
			String jsonClerkrStr = JsonSystemTool.toJsonForClerkForZhang(clerk);
			request.setAttribute("jsonClerkrStr", jsonClerkrStr);
		}
	}

	//�����ָ� ��ת
	public ActionForward recoverAccountForNetView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.resume.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.resume.success");
		}
	}
	
	//�����ָ�
	public ActionForward recoverAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu", "�˺ţ�["+accountinfoform.getAccount()+"]������");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			/*	boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu", "û��Ȩ�������ָ����˺�:["+accountinfoform.getAccount()+"]");
			}*/
			
			String accountOrg = zhanghb.getJigh();		
			String clerkOrg = clerk.getOrgcode();
			String clerkOrgRank = clerk.getWdFlag();
			if(!hasOperatePrivilege(accountOrg,clerkOrg,clerkOrgRank)){
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu", "�˺�["+accountinfoform.getAccount()+"]ֻ���ڿ�������["+accountOrg+"]�»ָ�");
			}
			
			//��֤�˻�״̬
			if("����".equals(zhanghb.getZhanghzt())){
				ZhanghbService.recoverAccount(zhanghb.getZhangh());
				String content1 = "�����ָ�(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
				this.createManageLog(clerk.getCode(), content1);
				
				String shuangqgy = request.getParameter("shuangqgy");
				String content2 = "�����ָ�";
				if(shuangqgy!=null && !"".equals(shuangqgy)){
					content2 += (",��Ȩ��Ա:"+shuangqgy);
				}
				this.createAccountManageLog(zhanghb.getZhangh() ,"�����ָ�", content2, clerk);
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu","�˺�["+accountinfoform.getAccount()+"]�����ָ��ɹ�!");
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu","�˺�["+zhanghb.getZhangh()+"]��ǰ״̬Ϊ["+zhanghb.getZhanghzt()+"],���ܽ��������ָ�");
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.xiaohu");
		}
	}
	
	//���� ��ת
	public ActionForward coverAccountForNetView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.xiaohu");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.xiaohu");
		}
	}
	/**
	 * ����  �жϵ�ǰ��Ա�Ƿ�������ҵ���Ȩ��
	 * @return
	 */
	private boolean hasOperatePrivilege(String accountOrg,String clerkOrg,String clerkOrgRank){
		boolean boo = this.getSystemMgrService().CanOperDesOrg(clerkOrg,accountOrg);
		if(boo) return true;
		if("1".equals(clerkOrgRank) && clerkOrg.equals(accountOrg)){		//����
			return true;
		}else if("2".equals(clerkOrgRank) && clerkOrg.equals(accountOrg)){	//����
			return true;
		}else if("3".equals(clerkOrgRank)){									//֧��
			if(clerkOrg.equals(accountOrg)){								//֧�в���֧�б���
				return true;
			}else{															//֧�в�������
				return this.getSystemMgrService().CanOperDesOrg(clerkOrg,accountOrg);
			}
		}else if("4".equals(clerkOrgRank) && clerkOrg.equals(accountOrg)){
			return true;
		}else
			return false;
		
	}
	
	/**
	 * �������ָ�����ʧ����ҡ�����ɾ��˫ǩǰУ��	ajax
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward validateBeforeShuangq(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		PrintWriter out = null;
		response.setContentType("text/xml");
		response.setLocale(Locale.SIMPLIFIED_CHINESE);
		response.setCharacterEncoding("GBK");
		
		try {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String accountNum = request.getParameter("accountNum");
			String _operateType = request.getParameter("operateType");
			String operateType = URLDecoder.decode(_operateType,"UTF-8");
				out = response.getWriter();
				Zhanghb zhanghb = ZhanghbDao.getZhanghb(accountNum);
				//��֤�˻��Ƿ����
				if(zhanghb==null){
					out.print("0|�˺�["+accountNum+"]������");
				}else{
					zhanghb = ZhanghbService.getZhanghb(accountNum);
					//��֤��ǰ��Ա�����˺�Ȩ��	�������ָ�����ʧ����ҡ�����ɾ��ֻ�����˻��Ŀ�����
					String accountOrg = zhanghb.getGuiyjgh();	
					String clerkOrg = clerk.getOrgcode();
					String clerkOrgRank = clerk.getWdFlag();
					if(!hasOperatePrivilege(accountOrg,clerkOrg,clerkOrgRank)){
						out.print("0|�˺�["+accountNum+"]ֻ���ڿ�������["+accountOrg+"]��"+operateType);
					}else{
						//��֤�˻�״̬
						if("�ָ�".equals(operateType) && "����".equals(zhanghb.getZhanghzt())){
							out.print("1");						
						}else if("���".equals(operateType) && "��ʧ".equals(zhanghb.getZhanghzt())){
							out.print("1");
						}else if("����ɾ��".equals(operateType)){
							out.print("1");
						}else{
							if(!"��Ч".equals(zhanghb.getZhanghzt())){
								out.print("1");
							}else{
								out.print("1");
							}
						}
					}
				}
			}catch(Exception e) {
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				log.error(sw.toString());
				out.print("2|"+sw.toString());
			}finally{
				out.close();
			}
			return null;
	}
	
	//����
	public ActionForward coverAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu", "�˺�["+accountinfoform.getAccount()+"]������");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu", "û��Ȩ���������˺�:["+accountinfoform.getAccount()+"]��");
			}
			//����ֻ�����˻��Ŀ�����
			String accountOrg = zhanghb.getJigh();		
			String clerkOrg = clerk.getOrgcode();
			String clerkOrgRank = clerk.getWdFlag();
			if(!hasOperatePrivilege(accountOrg,clerkOrg,clerkOrgRank)){
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu", "�˺�["+accountinfoform.getAccount()+"]ֻ���ڿ�������["+accountOrg+"]������!");
			}
			
			//��֤�˻�״̬
			if("��Ч".equals(zhanghb.getZhanghzt())){
				boolean flag = ZhanghbService.closeAccount(zhanghb.getZhangh());
				if(!flag){
					return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu","ϵͳæ���˺�["+zhanghb.getZhangh()+"]����ʧ��!");
				}
				String content1 = "����(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
				this.createManageLog(clerk.getCode(), content1);
				
				String shuangqgy = request.getParameter("shuangqgy");
				String content2 = "�˻�����";
				if(shuangqgy!=null && !"".equals(shuangqgy)){
					content2 += (",��Ȩ��Ա:"+shuangqgy);
				}
				this.createAccountManageLog(zhanghb.getZhangh() ,"�˻�����", content2, clerk);
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu","�˺�["+zhanghb.getZhangh()+"]�����ɹ�!");
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.xiaohu","�˺�["+zhanghb.getZhangh()+"]��ǰ״̬Ϊ["+zhanghb.getZhanghzt()+"]���ܽ�������");
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.xiaohu");
		}
	}
	
	//�˺Ž�� ��ת
	public ActionForward jiegAccountForNetView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.zhanghjg.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghjg.success");
		}
	}
	
	//�˺Ž��
	public ActionForward jiegAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			/*boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "û��Ȩ�޽���˺�:["+accountinfoform.getAccount()+"]");
			}*/
			//���ֻ���ڿ�����
			String accountOrg = zhanghb.getJigh();		
			String clerkOrg = clerk.getOrgcode();
			String clerkOrgRank = clerk.getWdFlag();
			//if(!hasOperatePrivilege(accountOrg,clerkOrg,clerkOrgRank)){
			//	return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "�˺�["+accountinfoform.getAccount()+"]ֻ���ڿ�������["+accountOrg+"]�½��");
			//}
			if(!clerkOrg.equals(accountOrg)){
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "�˺�["+accountinfoform.getAccount()+"]ֻ���ڿ�������["+accountOrg+"]�½��");
			}
			//��֤�˻�״̬
			if("��ʧ".equals(zhanghb.getZhanghzt()))
			{	
				//ZhanghbService.recoverAccount(zhanghb.getZhangh());
				boolean flag = ZhanghbService.recoverAccountAndYinjbAndYinjzhb(zhanghb.getZhangh());
				if(!flag){
					throw new Exception("ϵͳæ�����ʧ��");
				}
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success","�˺�["+zhanghb.getZhangh()+"]��ǰ״̬Ϊ["+zhanghb.getZhanghzt()+"],���ܽ��н��");
			}
			String content = "��ҳɹ�(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
			this.createManageLog(clerk.getCode(), content);
			
			String shuangqgy = request.getParameter("shuangqgy");
			String content2 = "�˻����";
			if(shuangqgy!=null && !"".equals(shuangqgy)){
				content2 += (",��Ȩ��Ա:"+shuangqgy);
			}
			this.createAccountManageLog(zhanghb.getZhangh() ,"�˻����", content2, clerk);
			return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghgs.success","�˺�["+zhanghb.getZhangh()+"]��ҳɹ�!");		
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghjg.success");
		}
	}
	
	//�˺Žⶳ ��ת
	public ActionForward jiedAccountForNetView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.zhanghjd.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghjd.success");
		}
	}
	
	//�˺Žⶳ
	public ActionForward jiedAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success", "û��Ȩ�������˺�:["+accountinfoform.getAccount()+"]");
			}
			//��֤�˻�״̬
			if("����".equals(zhanghb.getZhanghzt()))
			{	
				ZhanghbService.recoverAccount(zhanghb.getZhangh());
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success","�˺ţ�["+zhanghb.getZhangh()+"]���ɽ��нⶳ,��ǰ״̬Ϊ��["+zhanghb.getZhanghzt()+"]");
			}
			String content = "�ⶳ�ɹ�(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
			this.createManageLog(clerk.getCode(), content);
			this.createAccountManageLog(zhanghb.getZhangh() , "�˻��ⶳ","�˻��ⶳ", clerk);
			return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success","�˺Žⶳ�ɹ�!");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghdj.success");
		}
	}
	
	//����ɾ�� ��ת
	public ActionForward physicsDeleteForNetForView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.physicsdelete.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.physicsdelete.success");
		}
	}
	
	//�°�����ɾ��
	public ActionForward physicsDeleteForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success", "�˻�������");
			}
			//��֤�˻��Ƿ�Ϊ���˻������˻����ܽ�������ɾ��        by wp
			List list = ZhanghbService.getzzhlist(accountinfoform.getAccount());
			if(list.size()>0){
				return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success", "��ǰ�˻�["+accountinfoform.getAccount()+"]Ϊ���˻�������ִ������ɾ������");	
			}
			//��֤��ǰ��Ա�����˺�Ȩ�� ɾ��
/*			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.physicsdelete.success", "û��Ȩ��ɾ���˺�:["+accountinfoform.getAccount()+"]");
			}*/
			
			//����ɾ��ֻ�����˻��Ŀ�����
			String accountOrg = zhanghb.getJigh();		
			String clerkOrg = clerk.getOrgcode();
			String clerkOrgRank = clerk.getWdFlag();
			if(!hasOperatePrivilege(accountOrg,clerkOrg,clerkOrgRank)){
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "�˺�["+accountinfoform.getAccount()+"]ֻ���ڿ�������["+accountOrg+"]�½�������ɾ��");
			}
			
			ZhanghbService.physicsdelete(zhanghb.getZhangh());
			String content1 = "�˻�����ɾ��(�˺�Ϊ"+zhanghb.getZhangh()+";��Ա��:"+clerk.getCode()+")";
			this.createManageLog(clerk.getCode(), content1);
			
			String shuangqgy = request.getParameter("shuangqgy");
			String content2 = "�˻�����ɾ��";
			if(shuangqgy!=null && !"".equals(shuangqgy)){
				content2 += (",��Ȩ��Ա:"+shuangqgy);
			}
			this.createAccountManageLog(zhanghb.getZhangh(),"�˻�����ɾ��",content2,clerk);
			return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success","�˻�["+accountinfoform.getAccount()+"]����ɾ�������ɹ�");
		} catch (Exception e) {
			return this.errrForLogAndException(e,actionMapping,request,"accountinfo.net.physicsdelete.success");
		}
	}
	//20170427 �˻�����
		public ActionForward accountDiable(ActionMapping actionMapping,
				ActionForm actionForm, HttpServletRequest request,
				HttpServletResponse response) {
				Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
				AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
			try {
				Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
				//��֤�˻��Ƿ����
				if(zhanghb==null)
				{
					return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success", "�˻�������");
				}
				//��֤�˻��Ƿ�Ϊ���˻������˻����ܽ�������        by wp
				List list = ZhanghbService.getzzhlist(accountinfoform.getAccount());
				if(list.size()>0){
					return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success", "��ǰ�˻�["+accountinfoform.getAccount()+"]Ϊ���˻��������������˻�");	
				}
				//��֤��ǰ��Ա�����˺�Ȩ�� ����
				boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
				if(!bool)
				{
					return super.showMessageJSP(actionMapping, request, "accountinfo.net.physicsdelete.success", "û��Ȩ�������˺�:["+accountinfoform.getAccount()+"]");
				}
				
				//����ֻ�����˻��Ŀ�����
				String accountOrg = zhanghb.getJigh();		
				String clerkOrg = clerk.getOrgcode();
				String clerkOrgRank = clerk.getWdFlag();
				/*if(!hasOperatePrivilege(accountOrg,clerkOrg,clerkOrgRank)){
					return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "�˺�["+accountinfoform.getAccount()+"]ֻ���ڿ�������["+accountOrg+"]�½������ϲ���");
				}*/
				
				boolean flag = ZhanghbService.disable(zhanghb.getZhangh());
				if(!flag){
					return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success","���ݿ�æ,�˻�["+accountinfoform.getAccount()+"]���ϲ���ʧ��");
				}
				String content1 = "�˻�����(�˺�Ϊ"+zhanghb.getZhangh()+";��Ա��:"+clerk.getCode()+")";
				this.createManageLog(clerk.getCode(), content1);
				
				String shuangqgy = request.getParameter("shuangqgy");
				String content2 = "�˻�����";
				if(shuangqgy!=null && !"".equals(shuangqgy)){
					content2 += (",��Ȩ��Ա:"+shuangqgy);
				}
				this.createAccountManageLog(zhanghb.getZhangh(),"�˺�����",content2,clerk);
				return super.showMessageJSP(actionMapping, request,"accountinfo.net.physicsdelete.success","�˻�["+accountinfoform.getAccount()+"]���ϲ����ɹ�");
			} catch (Exception e) {
				return this.errrForLogAndException(e,actionMapping,request,"accountinfo.net.physicsdelete.success");
			}
		}
	/**
	 * 
	 * <dl>
	 * <dt><b>getAccountForNet:��.net���˻����л�ȡ�˻�����</b></dt>
	 * <dd></dd>
	 * </dl>
	 */
	public ActionForward getAccountForNet(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		String account = request.getParameter("account");
		String accountname = "";
		String allexchange = "";
		String englishname = "";
		String accountstate = "";
		String zhanghzt="��Ч";
		String isZhuzh = "0";//0:�������˻���1�����˻�
		String zhuzhzt="";
		try {
			Zhanghb accountinfo = ZhanghbService.getZhanghb(account);
			if (accountinfo != null)
			{
				accountname = accountinfo.getHum();
				allexchange = accountinfo.getTongctd();
				englishname = accountinfo.getKehh()==null?"":accountinfo.getKehh();
				accountstate = accountinfo.getZhanghzt();
				List<Zhanghb> zlist  = ZhanghbService.getzzhlist(account);//���˻��б�
				//�ж��˻��Ƿ�������˻�
				if(zlist!=null&&zlist.size()>=1)isZhuzh="1";
				for(Zhanghb z:zlist){					
					if(!("��Ч".equals(z.getZhanghzt()))){
						zhanghzt=z.getZhanghzt();
					}
				}
				//�ж����˺ŵ�״̬
				if(!("".equals(accountinfo.getZhuzh()))&&accountinfo.getZhuzh()!=null){
					Zhanghb accountinfo1 = ZhanghbService.getZhanghb(accountinfo.getZhuzh());
					if(accountinfo1 != null){
						zhuzhzt=accountinfo1.getZhanghzt();
					}
				}
			}
			response.setContentType("text/xml");
			response.setLocale(Locale.SIMPLIFIED_CHINESE);
			response.setCharacterEncoding("GBK");
			PrintWriter out = response.getWriter();
			String accountin = accountname + "," + allexchange + "," + englishname + "," + accountstate+","+isZhuzh+","+zhanghzt+","+zhuzhzt;
			out.println(accountin);
			out.close();
			return null;
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, null);
		}

	}
	
	/*
	 * ����Ʊ��Ӱ��
	 */
	public ActionForward getBillImage(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			String zhangh = request.getParameter("zhangh");
			String wenjbh = request.getParameter("wenjbh");
			try {
				ServletOutputStream out = response.getOutputStream();
				PiaojyxwjbId id = new PiaojyxwjbId();
				id.setZhangh(zhangh);
				id.setWenjbh(wenjbh);
				AccountImageServcie.downloadBillImage(id,out);
				out.close();
				out=null;
				return null;
			} catch (Exception e) {
				return this.errrForLogAndException(e, actionMapping, request, null);
			}
	}
	
	/*
	 * �����˻�ӡ����Ӱ��
	 */
	public ActionForward downloadYinjkImage(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			String zhangh=request.getParameter("zhangh");
			String yinjkh=request.getParameter("yinjkh");
			String billcm=request.getParameter("billcm");
			try {
				ServletOutputStream out = response.getOutputStream();
				AccountImageServcie.downloadYinjkImage(zhangh, yinjkh, billcm, out);
				out.close();
				out=null;
				return null;
			} catch (Exception e) {
				return this.errrForLogAndException(e, actionMapping, request, null);
			}
	}
	
	/*
	 * ��ȡ�˺�ӡ������Ϣ
	 */
	public ActionForward getAcccountYjkImageList(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
				String account = request.getParameter("account");
			try {
				List list = AccountImageServcie.getZhanghYjkList(account);
				if(list ==null||list.size()==0)
				{
					return this.showMessageJSP(actionMapping, request, "accountinfo.image", "û���ҵ����˺ŵ�Ԥ��ӡ������");
				}
				request.setAttribute("accountList", list);
				return actionMapping.findForward("accountinfo.image");
			} catch (Exception e) {
				e.printStackTrace();
				return this.errrForLogAndException(e, actionMapping, request, "accountinfo.image");
			}
	}
	
	/*
	 * ��ȡ�˺�ӡ������Ϣ
	 */
	public ActionForward getYinjkListByQiyrq(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
				String zhangh = request.getParameter("zhangh");
				String qiyrq = request.getParameter("qiyrq");
			try {
				List list = AccountImageServcie.getYinjkByQiyrq(zhangh, qiyrq);
				if(list ==null||list.size()==0)
				{
					return this.showMessageJSP(actionMapping, request, "accountinfo.image", "û���ҵ����˺ŵ�Ԥ��ӡ������");
				}
				request.setAttribute("accountList", list);
				return actionMapping.findForward("accountinfo.image");
			} catch (Exception e) {
				e.printStackTrace();
				return this.errrForLogAndException(e, actionMapping, request, "accountinfo.image");
			}
	}
	
	/*
	 * ��ȡƱ����Ϣ
	 */
	public ActionForward getPiaojImageList(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
				String zhangh = request.getParameter("zhangh");
				String pingzbsm = request.getParameter("pingzbsm");
			try {
				List list = AccountImageServcie.getBillImgList(zhangh,pingzbsm);
				if(list ==null||list.size()==0)
				{
					return this.showMessageJSP(actionMapping, request, "accountinfo.image", "û���ҵ���Ʊ�ݣ�");
				}
				request.setAttribute("accountList", list);
				return actionMapping.findForward("accountinfo.bill");
			} catch (Exception e) {
				e.printStackTrace();
				return this.errrForLogAndException(e, actionMapping, request, "accountinfo.bill");
			}
	}

	//�˻�������תҳ��
	public ActionForward zhanghdjView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.zhanghdj.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghdj.success");
		}
	}
	
	//����
	public ActionForward zhanghdj(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success", "û��Ȩ�޶��ᣬ�˺�:["+accountinfoform.getAccount()+"]��");
			}
			//��֤�˻�״̬
			if("��Ч".equals(zhanghb.getZhanghzt())){
				ZhanghbService.dongjAccount(zhanghb.getZhangh());
				String content = "����(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
				this.createManageLog(clerk.getCode(), content);
				this.createAccountManageLog(zhanghb.getZhangh() ,"����", "����", clerk);
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success","�˻�����ɹ�!");
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghdj.success","�˺ţ�["+zhanghb.getZhangh()+"]���ɽ����˻�����,��ǰ״̬Ϊ��["+zhanghb.getZhanghzt()+"]��");
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghdj.success");
		}
	}
	
	//�˻���ʧ��תҳ��
	public ActionForward zhanghgsView(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			return actionMapping.findForward("accountinfo.net.zhanghgs.success");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghgs.success");
		}
	}
	

	//��ʧ
	public ActionForward zhanghgs(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			AccountinfoForm accountinfoform = (AccountinfoForm) actionForm;
		try {
			Zhanghb zhanghb = ZhanghbService.getZhanghb(accountinfoform.getAccount());
			//��֤�˻��Ƿ����
			if(zhanghb==null)
			{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghgs.success", "�˺ţ�["+accountinfoform.getAccount()+"]������!");
			}
			//��֤��ǰ��Ա�����˺�Ȩ��
			boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
			if(!bool)
			{	
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghgs.success", "û��Ȩ�޹�ʧ���˺�:["+accountinfoform.getAccount()+"]��");
			}
			
			//��ʧֻ�����˻��Ŀ�����
			String accountOrg = zhanghb.getJigh();		
			String clerkOrg = clerk.getOrgcode();
			String clerkOrgRank = clerk.getWdFlag();
			/*if(!hasOperatePrivilege(accountOrg,clerkOrg,clerkOrgRank)){
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "�˺�["+accountinfoform.getAccount()+"]ֻ���ڿ�������["+accountOrg+"]�¹�ʧ");
			}*/
			if(!clerkOrg.equals(accountOrg)){
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "�˺�["+accountinfoform.getAccount()+"]ֻ���ڿ�������["+accountOrg+"]�¹�ʧ");
			}
			if("����".equals(zhanghb.getZhanghzt())||"��ʧ".equals(zhanghb.getZhanghzt())){
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "["+zhanghb.getZhanghzt()+"]�˺Ų��ܹ�ʧ");
			}
			if("δ��".equals(zhanghb.getZhanghshzt())||"δ��".equals(zhanghb.getZhanghshzt())){
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "["+zhanghb.getZhanghshzt()+"]�˺Ų��ܹ�ʧ");
			}
			if("δ��".equals(zhanghb.getYinjshzt())||"δ��".equals(zhanghb.getYinjshzt())){
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "["+zhanghb.getYinjshzt()+"]ӡ������˺Ų��ܹ�ʧ");
			}
			if(!StringUtil.isEmpty(zhanghb.getZhuzh())){
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "���˺Ų��ܹ�ʧ");
			}
			Date d =Calendar.getInstance().getTime();
			SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd"); 
			String date = sf.format(d).replaceAll("-","");
			String d1 = zhanghb.getQiyrq().replace("-","");
			if(Integer.parseInt(date)<=Integer.parseInt(d1)){
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghjg.success", "��ʧʧ�ܣ���ʧʱ��ֻ�ܴ���ӡ����������");
			}
			//��֤�˻�״̬
			if("��Ч".equals(zhanghb.getZhanghzt())){
				//ZhanghbService.guasAccount(zhanghb.getZhangh());
				boolean flag = ZhanghbService.guasAccountAndYingjbAndYinjzhb(zhanghb.getZhangh());
				if(!flag){
					throw new Exception("ϵͳæ����ʧʧ��");
				}
				String content1 = "��ʧ�˻�(�˺�Ϊ" + zhanghb.getZhangh() + ";��Ա����:"+clerk.getCode()+")";
				this.createManageLog(clerk.getCode(), content1);
				
				String shuangqgy = request.getParameter("shuangqgy");
				String content2 = "�˻���ʧ";
				if(shuangqgy!=null && !"".equals(shuangqgy)){
					content2 += (",��Ȩ��Ա:"+shuangqgy);
				}
				this.createAccountManageLog(zhanghb.getZhangh() ,"�˻���ʧ", content2, clerk);
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghgs.success","�˺�["+zhanghb.getZhangh()+"]��ʧ�ɹ�!");
			}else{
				return super.showMessageJSP(actionMapping, request, "accountinfo.net.zhanghgs.success","�˺�["+zhanghb.getZhangh()+"]��ǰ״̬Ϊ["+zhanghb.getZhanghzt()+"],���ܽ����˻���ʧ");
			}
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.net.zhanghgs.success");
		}
	}
	
	//ӡ��������תҳ��
	public ActionForward openAccount(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			return actionMapping.findForward("accountinfo.openaccount");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.openaccount");
		}
	}
	
	//ӡ�������ӡ��תҳ��
		public ActionForward changeForword(ActionMapping actionMapping,
				ActionForm actionForm, HttpServletRequest request,
				HttpServletResponse response) {
			try {
				//�����˻�������ʣ��б�
//				List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
//				request.setAttribute("zhanghxzList", zhanghxzList);			
				return actionMapping.findForward("forword.shenhyy");
			} catch (Exception e) {
				return this.errrForLogAndException(e, actionMapping, request, "forword.shenhyy");
			}
		}
	
	//ӡ�������תҳ��
	public ActionForward changeSeals(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			String zhangh=request.getParameter("zh");
			String biangsm=request.getParameter("biangsm");
			request.setAttribute("zh", zhangh);
			request.setAttribute("biangsm", biangsm);		
			return actionMapping.findForward("accountinfo.changeseals");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.changeseals");
		}
	}
	
	//�����޸���תҳ��
	public ActionForward changeAccountInfo(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			
			return actionMapping.findForward("accountinfo.changeaccountinfo");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.changeaccountinfo");
		}
	}
	
	//ӡ�������תҳ��
	public ActionForward accInfoCheck(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);	
			return actionMapping.findForward("accountinfo.accinfocheck");
			
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.accinfocheck");
		}
	}
	
	//�˺Ź�����תҳ��
	public ActionForward accountLink(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);			
			return actionMapping.findForward("accountinfo.accountlink");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.accountlink");
		}
	}
	
	
	public ActionForward insertLink(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			//1221 �޸�����
			String glkhh=request.getParameter("khh");
			String hum=request.getParameter("hm");//hum1
			String glzhjgh=request.getParameter("zhjgh");
			
			//String glkhh=request.getParameter("glkhh");
			String khh=request.getParameter("khh");
			String zhangh=request.getParameter("zh");
			String glzh=request.getParameter("glzh");
			//String hum=request.getParameter("glhm");
			String jgh=request.getParameter("zhjgh");
			//String glzhjgh=request.getParameter("glzhjgh");
			String kaihrq=request.getParameter("glkhrq");
			String shuangqy=request.getParameter("shuangqy");
			String glzhlb=request.getParameter("zhlb");
			if("".equals(glzhlb)||glzhlb==null){
				glzhlb="����";
			}
//			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			Zhanghb zhanghb = ZhanghbDao.getZhanghb(glzh);
			if(!glkhh.equals(khh)){
				request.setAttribute("zh", zhangh);
				request.setAttribute("message", "�����ͻ��������˺ſͻ��Ų�һ�� ��");
				return actionMapping.findForward("accountinfo.accountlink");
			}
			if(!glzhjgh.equals(jgh)){
				request.setAttribute("zh", zhangh);
				request.setAttribute("message", "���������������˺Ż����Ų�һ�� ��");
				return actionMapping.findForward("accountinfo.accountlink");
			}
			if(zhanghb!=null){
				request.setAttribute("zh", zhangh);
				request.setAttribute("message", "�����˺�"+glzh+"�Ѵ��ڣ�");
				return actionMapping.findForward("accountinfo.accountlink");
			}
			if(glzh!=null&&glzh!=""){
				zhanghxzService.insertLink(zhangh,glzh,hum,glzhjgh,glkhh,kaihrq,glzhlb);
			}
			
			request.setAttribute("zh", zhangh);
			request.setAttribute("message", "�˺�"+glzh+"���ӳɹ���");
			String content = "�˻�����(�����˺ţ�" + zhangh + ";�������˻�:"+glzh+")";
			Clerk shuangq=clerService.getClerkByCode(shuangqy);
			clerk.setShuangqy(shuangq.getName());
			this.createAccountManageLog(glzh ,"�˻�����", content, clerk);
			return actionMapping.findForward("accountinfo.accountlink");
		} catch (Exception e) {
			request.setAttribute("message", "����ʧ��");
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.accountlink");
		}
	}
	
	//�������
	public ActionForward updateLink(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String zzh=request.getParameter("zh");
			String glzh=request.getParameter("glzzh");
			String shuangqy=request.getParameter("shuangqy");
			zhanghxzService.updateLink(glzh);				
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			request.setAttribute("message", "�˺�"+glzh+"��������ɹ�");
			String content = "�˻������(�����˺ţ�" + zzh + ";�������˻�:"+glzh+")";
			Clerk shuangq=clerService.getClerkByCode(shuangqy);
			clerk.setShuangqy(shuangq.getName());
			this.createAccountManageLog(glzh ,"�����", content, clerk);
			return actionMapping.findForward("accountinfo.accountlink");
		} catch (Exception e) {
			request.setAttribute("message", "����ʧ��");
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.accountlink");
		}
	}
	public ActionForward getAccountInfomation(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
		String zhangh = request.getParameter("zh");
		Zhanghb zhanghb;
		PrintWriter out;
		try {
			//zhanghb = ZhanghbService.getZhanghb(zhangh);
			zhanghb = ZhanghbDao.getZhanghb(zhangh);
			//����ӡ���� ��֤��ǰ��Ա�����˺�Ȩ��
			if(zhanghb == null ){
				new NullPointerException("�˺�Ϊ��");
			}
			if(!"��ʧ".equals(zhanghb.getZhanghzt())||"" == zhanghb.getZhanghzt()||null == zhanghb.getZhanghzt()){
				new NullPointerException("�˺Ų���Ҫ��ʧ�����˺�״̬������");
			}else{
				zhanghb.setZhanghzt("��Ч");
				ZhanghbDao.updateZhanghb(zhanghb);
			}
			out = response.getWriter();
			out.print(zhangh+",");
			out.close();
			return null;
		} catch(NullPointerException e){
			System.out.println(e.getMessage());
			try {
				out = response.getWriter();
				out.print("a");
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			return null;
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/*
	 * ��ѯ�˻���Ϣ
	 */
	public ActionForward getAccountInfo(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String zhangh = request.getParameter("zh");
			String operateType = request.getParameter("operate");		//��������  �Ƿ�����ӡ
			Zhanghb zhanghb;
			PrintWriter out;
			try {
				zhanghb = ZhanghbService.getZhanghb(zhangh);
				
				
				//���汾  ������ӡ�����Ĺ��ܵ���־    ʹ�ù��ܵ����
				//��Ҫ�������У������ţ��������ƣ��˻���    zhangh����ѯ�����֣���Ա��clerk����ѯ�˹�Ա��   clerk����ѯ����   date����ѯʱ��   time����ע
				Calendar calendar = Calendar.getInstance();
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat dateFormat_ = new SimpleDateFormat("hh:mm:ss");
				String chaxrq = dateFormat.format(calendar.getTime());
				String chaxtime = dateFormat_.format(calendar.getTime());
				Yinjcyrzb yin = new Yinjcyrzb();
				yin.setBeiz("");
				yin.setChaxrq(chaxrq);
				yin.setChaxtime(chaxtime);
				yin.setGuiyh(clerk.getCode());
				yin.setGuiymz(clerk.getName());
				yin.setJigouhao(clerk.getOrgcode());
				yin.setJigoumc(clerk.getOrgname());
				yin.setYinjbh(zhangh);
				//clerk.getOrgcode(), clerk.getOrgname(), zhangh, clerk.getName(), clerk.getCode(), chaxrq, chaxtime, null
				//yinjcyrzbservice.insertyinjrzb(yin);//���ӵ�����
				logservice.addyinjrz(yin);
				
				if("sealCheck".equals(operateType)){		//��ӡ����
					if("��".equals(zhanghb.getTongctd())){	//����ͨ��ͨ���ж����¼�Ȩ��
						boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
						//boolean bool  = clerk.getOrgcode().equals(zhanghb.getJigh());
						if(!bool){
							response.setContentType("text/xml");
							response.setLocale(Locale.SIMPLIFIED_CHINESE);
							response.setCharacterEncoding("GBK");
							out = response.getWriter();
							String accountinfo = "false";
							out.println(accountinfo);
							out.close();
							return null;
						}else{
							return findAccountInfoInner(request, response,zhanghb);
						}
					}else if("ʡ".equals(zhanghb.getTongctd())){	

						boolean bool = this.getSystemMgrService().CanOperDesSHOrg(clerk.getOrgcode(),zhanghb.getJigh());
						//boolean bool  = clerk.getOrgcode().equals(zhanghb.getJigh());
						if(!bool){
							response.setContentType("text/xml");
							response.setLocale(Locale.SIMPLIFIED_CHINESE);
							response.setCharacterEncoding("GBK");
							out = response.getWriter();
							String accountinfo = "false";
							out.println(accountinfo);
							out.close();
							return null;
						}else{
							return findAccountInfoInner(request, response,zhanghb);
						}
					}
					else{
					//ͨ��ͨ��ֱ�Ӳ���
						return findAccountInfoInner(request, response, zhanghb);
					}										
				}else{										//����ӡ���� ��֤��ǰ��Ա�����˺�Ȩ��
					boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
					if(!bool){
						response.setContentType("text/xml");
						response.setLocale(Locale.SIMPLIFIED_CHINESE);
						response.setCharacterEncoding("GBK");
						out = response.getWriter();
						String accountinfo = "false";
						out.println(accountinfo);
						out.close();
						return null;
					}
				}
				return findAccountInfoInner(request, response, zhanghb);
			} catch (BusinessException e) {
				 try {
					out = response.getWriter();
					out.print("a");
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				 return null;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
			
	}
	/**
	 * ajax��ȡ�˻���Ϣ  �ڲ���ȡ����
	 * @param request
	 * @param response
	 * @param zhanghb
	 * @return
	 * @throws IOException
	 */
	private ActionForward findAccountInfoInner(HttpServletRequest request,
			HttpServletResponse response, Zhanghb zhanghb) throws IOException {
		PrintWriter out;
		request.setAttribute("Zhanghb", zhanghb);
		String zh = zhanghb.getZhangh();
		String zzh = zhanghb.getZhuzh();
		String zhzt = zhanghb.getZhanghzt();
		String ywlx = request.getParameter("ywlx");
		Clerk clerknum=null;
		String yinjshzt="";
		if(!("".equals(zzh))&&zzh!=null){//�ж��Ƿ�������˺�
			 clerknum=ZhanghbService.findClerkNUm(zzh);	
				 try {
					 Zhanghb zzhangh= ZhanghbService.getZhanghb(zzh);
					// zhzt=zzhangh.getZhanghzt();
					
					 //������ӡ�����ҵ��
					 if("shenhe".equals(ywlx)){
						yinjshzt =zzhangh.getYinjshzt();
					 }else{
						//�жϵ�ǰ����ʹ�õ�ӡ���Ƿ�Ϊ����״̬
						Yinjb yinjb=ZhanghbService.getYinjb(zzh);
						yinjshzt = yinjb.getYinjshzt();
					 }
				} catch (BusinessException e) {
					e.printStackTrace();
				}
		}else{		
			 clerknum=ZhanghbService.findClerkNUm(zh);
			 //������ӡ�����ҵ��
			 if("shenhe".equals(ywlx)){
				yinjshzt =zhanghb.getYinjshzt();
			 }else{
				//�жϵ�ǰ����ʹ�õ�ӡ���Ƿ�Ϊ����״̬
				Yinjb yinjb=ZhanghbService.getYinjb(zh);
				yinjshzt = yinjb.getYinjshzt();
			 }
		}
		String clerkcode="false";
		String clerkOrg=zhanghb.getGuiyjgh();
		if(clerknum!=null){
			clerkcode=clerknum.getCode();
			
		}
		
		String hm = zhanghb.getHum();
		String zhlb = zhanghb.getZhanghxz();
		String khh = zhanghb.getKehh();
		String zhjgh = zhanghb.getJigh();
		String kaihrq = zhanghb.getKaihrq();
		String bz = (null == zhanghb.getBeiz() || "" == zhanghb.getBeiz() || "".equals( zhanghb.getBeiz())) ? "" : zhanghb.getBeiz();		
		String zhshzt = zhanghb.getZhanghshzt();		
		String tongctd=zhanghb.getTongctd();
		
		//181221ZZ 
		String shefzid=zhanghb.getShefzid();
		String youzbm=zhanghb.getYouzbm();
	
		
		String lianxr=(null == zhanghb.getLianxr())?"": zhanghb.getLianxr();
		String dianh=(null == zhanghb.getDianh())?"":zhanghb.getDianh();
		String dz=(null == zhanghb.getDiz())?"":zhanghb.getDiz();
		/*String sqr=(null == zhanghb.getJiesywsqrdh())?"":zhanghb.getJiesywsqrdh();
		String sqrdh=(null == zhanghb.getJiesywsqr())?"":zhanghb.getJiesywsqr();*/
		String sqr=(null == zhanghb.getJiesywsqr())?"":zhanghb.getJiesywsqr();
		String sqrdh=(null == zhanghb.getJiesywsqrdh())?"":zhanghb.getJiesywsqrdh();
		
		
		String qiyrq = zhanghb.getQiyrq();
		String ys_qiyrq = zhanghb.getYs_qiyrq();
		String guiyjgh = zhanghb.getGuiyjgh();//csq add
		response.setContentType("text/xml");
		response.setLocale(Locale.SIMPLIFIED_CHINESE);
		response.setCharacterEncoding("GBK");
		out = response.getWriter();
		String accountinfo = zh + "," + zzh + "," + hm + "," + zhlb + "," + khh + "," + zhjgh + "," + kaihrq + "," + bz + "," + zhzt+","+zhshzt+","+yinjshzt+","+tongctd+","+clerkcode+","+clerkOrg+","+qiyrq+","+guiyjgh+","+ys_qiyrq+","+lianxr+"," +dianh+"," +dz+"," +sqr+"," +sqrdh+","+shefzid+","+youzbm;				
		Map<String,String> accmap = new HashMap<String, String>();
		accmap.put("zh", zh);
		out.print(accountinfo);
		out.close();
		return null;
	}
	
	/*
	 * ��ѯ�����˻���Ϣ
	 */
	public ActionForward getAccountInfoFromSC(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String zhangh = request.getParameter("zh");
			ScData scdata;			
			PrintWriter out;
			try {
				scdata = ZhanghbService.getZhanghInfoFromSC(zhangh);			
				//��֤��ǰ��Ա�����˺�Ȩ��								
				String zh = scdata.getZhangh();				
				String hm = scdata.getHum();			
				String khh = scdata.getKehh();
				String zhjgh = clerk.getOrgcode();
				String khrq = scdata.getKaihrq();
				String bz = "";
				String zhzt = scdata.getZhanghzt();
				String zhshzt = scdata.getZhanghshzt();
				String yinjshzt = scdata.getYinjshzt();	
				String zhanghxz=scdata.getZhanghxz();
				//
				
				
				
				response.setContentType("text/xml");
				response.setLocale(Locale.SIMPLIFIED_CHINESE);
				response.setCharacterEncoding("GBK");
				out = response.getWriter();
				String accountinfo = zh + "," + hm + "," + khh + "," + zhjgh + "," + khrq + "," + bz + "," + zhzt+","+zhshzt+","+yinjshzt+","+zhanghxz;//+","+diz+","+lianxr+","+dianh+","+jiesywsqr+","+jiesywsqrdh;								
				Map<String,String> accmap = new HashMap<String, String>();
				accmap.put("zh", zh);
				out.println(accountinfo);
				out.close();
				return null;
			} catch (BusinessException e) {
				 try {
					out = response.getWriter();
					out.print("a");
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				 return null;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
			
	}
	
	public ActionForward getAccountInfoFromESB(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
				PrintWriter out = null;
				String zhanghMsg = null;
				
				try{
					//msgid
					Date rightNow = Calendar.getInstance().getTime();
					SimpleDateFormat msg_id_date = new SimpleDateFormat("yyyyMMdd");
					SimpleDateFormat mag_id_time = new SimpleDateFormat("HHmmssSSS");
					if(count>999){
						count = 0;
					}
					String msgId = "0098"+msg_id_date.format(rightNow)+mag_id_time.format(rightNow)+new AddZero().addzero(count++,4);
					System.out.println("msgId===================="+msgId);
					String zhangh = request.getParameter("zh");
					if(StringUtils.isEmpty(zhangh)){
						out = response.getWriter();
						out.print("a");
						return null;
					}
					Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
				//	String HXIP  = GetWeishu.getBcodeMesage("HXIP");
//					String ip = "32.114.67.1:8888";
					/*sendXML.append("<?xml version='1.0' encoding='UTF-8'?>")
							.append("<Transaction>") 
								.append("<Header>") 
									.append("<sysHeader>")
										.append("<msgId>"+msgId+"</msgId>") 
										.append("<msgDate>"+msgDate+"</msgDate>")
										.append("<msgTime>"+msgTime+"</msgTime>")
										.append("<serviceCd>P00001000260</serviceCd>")
										.append("<operation>qracct</operation>")
										.append("<clientCd>060</clientCd>") 
										.append("<serverCd>001</serverCd>")
										.append("<bizId></bizId>") 
										.append("<bizType></bizType>")
										.append("<orgCode></orgCode>") 
										.append("<resCode></resCode>")
										.append("<resText></resText>") 
										.append("<bizResCode></bizResCode>")
										.append("<bizResText></bizResText>") 
										.append("<version></version>")
										.append("<authId></authId>") 
										.append("<authPara></authPara>")
										.append("<authContext></authContext>") 
										.append("<pinIndex></pinIndex>")
										.append("<pinValue></pinValue>") 
									.append("</sysHeader>") 
								.append("</Header>")
								.append("<Body>") 
									.append("<request>") 
										.append("<bizHeader>")
											.append("<userid>"+clerk.getCode()+"</userid>") 
											.append("<brchno></brchno>")
											.append("<servtp>ESVS</servtp>") 
											.append("<prcscd>qracct</prcscd>")
											.append("<csbxno></csbxno>") 
											.append("<winame/>")
											.append("<mutrcd/>") 
											.append("<authsq/>")
											.append("<sunfront></sunfront>")
											.append("<node_id></node_id>")
											.append("<tmnlip></tmnlip>")
										.append("</bizHeader>") 
										.append("<bizBody>")
											.append("<acctno>"+zhangh+"</acctno>") 
											.append("<subsac></subsac>")
											.append("<winame></winame>")
											.append("<brchno>"+clerk.getOrgcode()+"</brchno>") 
											.append("<custno></custno>")
										.append("</bizBody>") 
									.append("</request>") 
								.append("</Body>") 
							.append("</Transaction>");*/
					//��װXML����
					StringBuffer sendXML = new StringBuffer();
					SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
					SimpleDateFormat time = new SimpleDateFormat("HH:mm:ss.SSS");
					sendXML.append("<?xml version='1.0' encoding='UTF-8'?>")
						    .append("<Transaction>")
						    .append("<Header>")
						      .append("<sysHeader>")
						        .append("<msgId>"+msgId+"</msgId>")
						        .append("<msgDate>"+date.format(rightNow)+"</msgDate>")
						        .append("<msgTime>"+time.format(rightNow)+"</msgTime>")
						        .append("<serviceCd>P00002007284</serviceCd>")
						        .append("<operation>OrderTurnAccReg</operation>")
						        .append("<clientCd>060</clientCd>")
						        .append("<serverCd>111</serverCd>")
						        .append("<bizId>3</bizId>")
						        .append("<bizType>1</bizType>")
						        .append("<orgCd/>")
						        .append("<resCode/>")
						        .append("<resText/>")
						        .append("<bizResCode/>")
						        .append("<bizResText/>")
						        .append("<authId/>")
						        .append("<authPara/>")
						        .append("<authContext/>")
						        .append("<pinIndex/>")
						        .append("<pinValue/>")
						        .append("<ver>100100100</ver>")
						      .append("</sysHeader>")
						    .append("</Header>")
						    .append("<Body>")
						      .append("<request>")
						        .append("<bizHeader>")
						          .append("<qudaohao>060</qudaohao>")
						          .append("<fqxtbios>060</fqxtbios>")
						          .append("<waibclma>ib1253</waibclma>")
						          .append("<waibjymc>1253</waibjymc>")
						          .append("<farendma></farendma>")
						          .append("<quanjuls/>")
						          .append("<jiaoyijg>"+clerk.getOrgcode()+"</jiaoyijg>")
						          .append("<jiaoyigy>"+clerk.getCode()+"</jiaoyigy>")
						          .append("<jiaoyima>ib1253</jiaoyima>")
						          /*.append("<waiblius/>")
						          .append("<waibriqi/>")
						          .append("<waibshij/>")
						          .append("<qudaoflm/>")
						          .append("<shoqxinx_ARRAY>")
						            .append("<Map>")
						              .append("<jgaoxinx/>")
						              .append("<shoqxinx/>")
						              .append("<tishxinx/>")
						            .append("</Map>")
						          .append("</shoqxinx_ARRAY>")
						          .append("<querenbz/>")
						          .append("<shoqbzhi/>")
						          .append("<shoqlius/>")
						          .append("<shoqguiy/>")
						          .append("<shoqjibe/>")
						          .append("<shoqfshi/>")
						          .append("<shoqjigo/>")
						          .append("<shoqjgjb/>")
						          .append("<ycsqbzhi/>")
						          .append("<sqqrenbz/>")
						          .append("<shoqqrgy/>")
						          .append("<bendsqcs/>")
						          .append("<hejijine/>")
						          .append("<zhidsfje/>")
						          .append("<cjsfsvrlst_ARRAY>")
						            .append("<Map>")
						              .append("<changjdm/>")
						              .append("<changjms/>")
						              .append("<shoufdma/>")
						              .append("<shouflxm/>")
						              .append("<shisjine/>")
						              .append("<yingsfje/>")
						              .append("<zuizyhbl/>")
						              .append("<feiyysje/>")
						              .append("<yonhjine/>")
						              .append("<kehuzhao>"+zhangh+"</kehuzhao>")
						              .append("<shuxuhao/>")
						              .append("<shuliang/>")
						              .append("<zhidsfje/>")
						            .append("</Map>")
						          .append("</cjsfsvrlst_ARRAY>")
						          .append("<feiyqrbz/>")
						          .append("<cplfyxinx_ARRAY>")
						            .append("<Map>")
						              .append("<xianzhbz/>")
						              .append("<shoufbzh/>")
						              .append("<kehuzhao>"+zhangh+"</kehuzhao>")
						              .append("<chaohubz/>")
						              .append("<shuxuhao/>")
						              .append("<xjinxmdm/>")
						              .append("<zhidsfje/>")
						            .append("</Map>")
						          .append("</cplfyxinx_ARRAY>")
						          .append("<ldbiaozi/>")
						          .append("<ldjioyma/>")
						          .append("<jiamixxlst_ARRAY>")
						            .append("<Map>")
						              .append("<jiamizdm/>")
						              .append("<shoufbzh/>")
						            .append("</Map>")
						          .append("</jiamixxlst_ARRAY>")
						          .append("<dalrinfo/>")
						          .append("<zongbshu/>")
						          .append("<mimajmbs/>")
						          .append("<mmmysyin/>")
						          .append("<ipdizhii/>")
						          .append("<chkouhao/>")
						          .append("<jiaoyilx/>")
						          .append("<dpdizhii/>")
						          .append("<macdizhi/>")*/
						        .append("</bizHeader>")
						        .append("<bizBody>")
						          .append("<kehuzhao>"+zhangh+"</kehuzhao>")
						          .append("<zhhaoxuh/>")
						          .append("<shifoubz/>")
						          .append("<chaxmima/>")
						          .append("<mimazlei/>")
						          .append("<rengbhao/>")
						        .append("</bizBody>")
						      .append("</request>")
						    .append("</Body>")
						  .append("</Transaction>");
					
					//ƴ�ӳ���
					String length = new AddZero().addzero(sendXML.length(),8);
					System.out.println(length+sendXML.toString());
					Map<String,String> map =null;
					response.setContentType("text/xml");
					response.setLocale(Locale.SIMPLIFIED_CHINESE);
					response.setCharacterEncoding("GBK");
					out = response.getWriter();
					map = new SendHX().getESB(length+sendXML.toString());
					/*	map = new HashMap();
					map.put("kehuzhao", "2017");
					map.put("zhhuzwmc","2018");
					map.put("kehuhaoo","2019");
					map.put("zhujigoh","80999");
					map.put("jigoumch","2020");
					map.put("zhhuztai","B");
					map.put("dghushux","0");
					map.put("tduibzhi", "1");*/
					if(map != null && map.size()>0){
						/*String orgName = map.get("epbkna");
						String zh = map.get("acctno"); 
						String huming = map.get("acctna");
						String cusNum = map.get("custno");
						String orgNum = map.get("acctbr");
						String acctst = map.get("acctst");
						//String acctst = "0";
						//�˺�����
						String spectp = map.get("spectp");
						//ͨ���־
						String daabtg = map.get("daabtg");*/
						//�˺�
						String zh = map.get("kehuzhao");
						//����
						String huming = map.get("zhhuzwmc");
						//�ͻ���
						String cusNum = map.get("kehuhaoo");
						//������
						String orgNum = map.get("zhkhjigo");
						String orgName = map.get("bumenmch");
						//�˺�״̬
						String acctst = map.get("zhhuztai");
						//String acctst = "0";
						//�˺�����
						String spectp = map.get("dghushux");
						//ͨ���־
						String daabtg = map.get("tduibzhi");
						zhanghMsg = zh+","+huming+","+cusNum+","+orgNum+","+orgName+","+acctst+","+spectp+","+daabtg;
						out.println(zhanghMsg);
					}else{
						System.out.println("ͨ��ESB��ȡ�����˻���Ϣ���̳���");
						throw new Exception("ͨ��ESB��ȡ�����˻���Ϣ���̳���");
					}
					
					return null;
				}catch(Exception e){
					e.printStackTrace();
					if(out != null){
						out.print("b");
					}else{
						try {
							out = response.getWriter();
							out.print("b");
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					return null;
				}finally{
					if(out != null){
						out.close();
					}
				}
				
	}
	/*
	 * ��֤�����Ƿ���ں����޲���Ȩ��
	 */
	public ActionForward validateJigh(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String jigh = request.getParameter("jigh");
			PrintWriter out;
			boolean flag=true;
			boolean bool=true;
			try {
				//��֤�˻������Ƿ��������ӡϵͳ��
				Org o = orgService.getOrgByCode(jigh);
				if("".equals(o)||o==null){
					flag=false;
					
				}else{
					//��֤��ǰ��Ա����������Ȩ��
					bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),jigh);
				}
					
					
					/*if(!bool)
					{
						
						//return super.showMessageJSP(actionMapping, request, "accountinfo.net.view.success", "û��Ȩ����:["+jigh+"]�½���");
					}*/
				
				response.setContentType("text/xml");
				response.setLocale(Locale.SIMPLIFIED_CHINESE);
				response.setCharacterEncoding("GBK");
				out = response.getWriter();
				if(flag){
					if(bool){
						out.println(flag+","+o.getName()+","+o.getWdflag()+","+bool);
					}else{
						out.println(flag+","+bool);
					}
				}else{
					out.println(flag);
				}
				out.close();
				return null;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
			
	}
	
	/*
	 * ��ѯ�˻���Ϣ������˻�Ϊ���˻����������˻��б�
	 */
	public ActionForward getAccountInfoWithSubAccounts(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			String zhangh = request.getParameter("zh");
			Zhanghb zhanghb;
			String accountinfo = "";
			PrintWriter out;
			try {
				zhanghb = ZhanghbService.getZhanghb(zhangh);
				//��֤��ǰ��Ա�����˺�Ȩ��
				boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghb.getJigh());
				if(!bool){						
					accountinfo ="false";					
				}else{
					request.setAttribute("Zhanghb", zhanghb);
					String zh = zhanghb.getZhangh();
					//����clerk
					Clerk clerknum=ZhanghbService.findClerkNUm(zh);
					String clerkcode="false";
					String clerkOrg=zhanghb.getGuiyjgh();
					if(clerknum!=null){
						clerkcode=clerknum.getCode();
					}
					String zzh = zhanghb.getZhuzh();
					String hm = zhanghb.getHum();
					String zhlb = zhanghb.getZhanghxz();
					String khh = zhanghb.getKehh();
					String zhjgh = zhanghb.getJigh();			
					String khrq = zhanghb.getKaihrq();
					String bz = (null == zhanghb.getBeiz() || "" == zhanghb.getBeiz() || "".equals( zhanghb.getBeiz())) ? "" : zhanghb.getZhanghzt();
					String zhzt = zhanghb.getZhanghzt();
					String zhshzt = zhanghb.getZhanghshzt();
					String yinjshzt=zhanghb.getYinjshzt();
					String lianxr=zhanghb.getLianxr();
					String dianh=zhanghb.getDianh();
					String dz=zhanghb.getDiz();
					//String sqr=zhanghb.getJiesywsqrdh();//zhanghb.getJiesywsqr()
					//String sqrdh=zhanghb.getJiesywsqr();//zhanghb.getJiesywsqrdh()
					String sqr=zhanghb.getJiesywsqr();
					String sqrdh=zhanghb.getJiesywsqrdh();
					String zzh_str="";
					try {
						List<Zhanghb> zzhlist=ZhanghbService.getzzhlist(zhangh);
						for (int i = 0; i < zzhlist.size(); i++) {
							zzh_str=zzh_str+","+	zzhlist.get(i).getZhangh();
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					/*List<Zhanghb> zzhlist = null;
					String zzh_str = "";*/
					/*//��������˻����������˻��б�
					if("".equals(zzh) || zzh == null){
						zzhlist = this.ZhanghbService.getzzhlist(zh);
					}*/
					
					/*//ƴ�����˺��ַ���
					if(zzhlist!=null&&zzhlist.size() >0){
						for(int i=0;i<zzhlist.size();i++){
							zzh_str += zzhlist.get(i).getZhangh() + ",";
						}
						zzh_str = zzh_str.substring(0,zzh_str.length()-1);
						//ƴ�ӷ����ַ������˻���Ϣ+���˺��ַ�����
						accountinfo = zh + "," + zzh + "," + hm + "," + zhlb + "," + khh + "," + zhjgh + "," + khrq + "," + bz + "," + zhzt+","+yinjshzt + ","  +clerkOrg+","+lianxr+"," +dianh+"," +dz+"," +sqr+"," +sqrdh+","+zzh_str+",";					
					}else{
						accountinfo = zh + "," + zzh + "," + hm + "," + zhlb + "," + khh + "," + zhjgh + "," + khrq + "," + bz + "," + zhzt+","+yinjshzt+ ","  +clerkOrg+"," +lianxr+"," +dianh+"," +dz+"," +sqr+"," +sqrdh+",";
					}*/
					accountinfo = zh + "," + zzh + "," + hm + "," + zhlb + "," + khh + "," + zhjgh + "," + khrq + "," + bz + "," + zhzt+","+yinjshzt+ ","  +clerkOrg+"," +lianxr+"," +dianh+"," +dz+"," +sqr+"," +sqrdh +zzh_str+",";
				}
				response.setContentType("text/xml");
				response.setLocale(Locale.SIMPLIFIED_CHINESE);
				response.setCharacterEncoding("GBK");
				out = response.getWriter();
				out.println(accountinfo);
				out.close();
				return null;
			} catch (BusinessException e) {
				 try {
					out = response.getWriter();
					out.println(",");
					out.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				 return null;
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
	}
	//ӡ����Ϣ�鿴ҳ����ת
	public ActionForward yinjxxck(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			//�����˻�������ʣ��б�
			List<Zhanghxz> zhanghxzList = this.zhanghxzService.getZhanghxzList();
			request.setAttribute("zhanghxzList", zhanghxzList);
			
			return actionMapping.findForward("accountinfo.yinjxxck");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "accountinfo.yinjxxck");
		}
	}
	
	
	/**
	 * 
	 * ��ȡ�����˻���Ϣ
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	public String getAccountInfoFromHX(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response){
	
		StringBuffer sBuffer = new StringBuffer();
		String mc="HUBEIBANK|00000056|";
		sBuffer.append(mc);
		String jiaoydm="702";
		sBuffer.append(jiaoydm);
		PrintWriter out = null;
		int jydmlen=jiaoydm.length();
		for (int i = 0; i < 6-jydmlen; i++) {
			sBuffer.append(" ");
		}
		String account = request.getParameter("zh");
		sBuffer.append(account);
		int accountlen=account.length();
		for (int i = 0; i < 50-accountlen; i++) {
			sBuffer.append(" ");
		}
		SocketConnect socket = new SocketConnect();
		response.setLocale(Locale.SIMPLIFIED_CHINESE);
		response.setCharacterEncoding("GBK");
		response.setContentType("text/xml;charset=GBK");
		try {
			
			String respon = socket.SendMessage(sBuffer.toString(), SystemConfig.getInstance().getValue("core_ip"), Integer.valueOf(SystemConfig.getInstance().getValue("core_port")),Integer.valueOf(SystemConfig.getInstance().getValue("core_outtime")));
			System.out.println("respon:"+respon);
			System.out.println("����respon:"+respon);
			
			out = response.getWriter();
			
			out.printf(respon);
			out.close();
			return null;
		} catch(Exception e){
			try {
				CommonUtil.error(e.getMessage());
				e.printStackTrace();
				out = response.getWriter();
				out.println("b,"+e.getMessage());
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			 return null;
		}
	}
	
	public static void main(String[] args){
		StringBuffer sBuffer = new StringBuffer();
		String respon;
		String str = "sfsfsf|aaaaaaa|123456789011111111111111111111111111111111111111111111111111112345678901111111111111111111111111111111111111111111111111k";
		try {
			String[] strList = str.split("\\|");
			System.out.println(str.length());
			String lenth = strList[1];
			String baot = strList[2];
			String str_60 = baot.substring(0,1);
			System.out.println("str_60:"+str_60);
			String str_2 = baot.substring(1,60);
			System.out.println(str_2+"|"+str_2.length());
			String hm=baot.substring(61,121);
			System.out.println(hm);
//			java.lang.StringIndexOutOfBoundsException:
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	/**
	 * ��ȡ��ǰ��Ա�Ĵ�������
	 * @param actionMapping
	 * @param actionForm
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward getUnCheckTasks(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		try {
			/*TabsBo TabsBo = this.createTabsBo(request);   
			ZhanghbServiceImpl ZhanghbServiceImpl = (ZhanghbServiceImpl) zhanghbService;
			ZhanghbServiceImpl.setTabsService(TabsBo);
			TabsBo tabsBo = zhanghbService.searchZhanghInfo(zhanghform);
			this.showTabsModel(request, tabsBo);*/
			
			Clerk clerk = (Clerk) request.getSession().getAttribute("clerk");
			Org org = orgService.getOrgByCode(clerk.getOrgcode());
			List<Zhanghb> uncheckTaskList = this.zhanghxzService.getUncheckTasks(org.getCode(), org.getWdflag(), clerk.getCode());
			
			request.setAttribute("list", uncheckTaskList);
			return actionMapping.findForward("accountinfo.unchecktasks");
		} catch (Exception e) {
			return this.errrForLogAndException(e, actionMapping, request, "unchecktasks");
		}
	}
	
	
	/*
	 * 
	 * ��ȡ�˺���Ϣ
	 */
	public ActionForward getAccount(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		PrintWriter out;
		response.setContentType("text/xml");
		response.setLocale(Locale.SIMPLIFIED_CHINESE);
		response.setCharacterEncoding("GBK");
		try {
			String account = request.getParameter("zh");
			Zhanghb zhangh = ZhanghbDao.getZhanghb(account);
			if(zhangh == null)
			{
				out = response.getWriter();
				out.println();
				out.close();
				return null;
			}
			out = response.getWriter();
			out.println(zhangh.getZhangh()+",");
			out.close();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	/*
	 * 
	 * ��ȡƾ֤�б�    lixiangxiang 20181108
	 */
	public ActionForward getVoucherList(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		PrintWriter out;
		response.setContentType("text/xml");
		response.setLocale(Locale.SIMPLIFIED_CHINESE);
		response.setCharacterEncoding("GBK");
		try {
			List list = voucherMgrServiceImpl.getVoucherList();
			if(list.size() == 0)
			{
				out = response.getWriter();
				out.println();
				out.close();
				return null;
			}
			JSONArray jsonArray=JSONArray.fromObject(list);
			out = response.getWriter();
			out.println(jsonArray);
			out.close();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}