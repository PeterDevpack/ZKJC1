package com.unitop.sysmgr.action.project;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	/**
	 * @param args
	 */
	private static int count = 0;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocket server = null;
		try{
			server =  new ServerSocket(60600);
			while(true){
				Socket s = server.accept();
				new Server().new SimpleProcessor(s,count++).start();
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	class SimpleProcessor extends Thread{
		private int id;
		private Socket socket;
		private PrintWriter out;
		private BufferedReader in;
		private volatile boolean running = true;
		
		public SimpleProcessor(Socket s,int id)throws IOException{
			this.id = id;
			this.socket = s;
			in = new BufferedReader(new InputStreamReader(s.getInputStream()));
			out = new PrintWriter(s.getOutputStream());
		}
		public void run(){
			while(running){
				try {
					if(in.ready()){
						String tmp = in.readLine();
						System.out.println("sssssssss=============="+tmp);
						out.print(tmp);
						out.flush();
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
}
