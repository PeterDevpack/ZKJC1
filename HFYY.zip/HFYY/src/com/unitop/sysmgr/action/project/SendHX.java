package com.unitop.sysmgr.action.project;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.xml.sax.InputSource;

import com.unitop.bank.CommonUtil;
import com.unitop.framework.util.IPTool;
import com.unitop.util.sequence.GetWeishu;

public class SendHX {
	// �����IP(serverip)��Socket�˿�(socketport)��ƾ֤��(ticket)�������WEB�˿�(urlport)�������WEBĿ¼(urlpath)��ϵͳ���(appid)
	// socketIP
	private static int COUNT_NUMBER = 0;
	private static int COUNT_NUMBER2 = 0;
	private static String serverip = null;
	// socket�˿�
	private static String socketport = null;
	// ��Աƾ֤��
	private String ticket = null;
	// web�˿�
	private static String urlport = null;
	// �����webĿ¼
	private static String urlpath = null;
	// ��ӡϵͳ���
	private static String appid = null;
	// ��ԱIP
	private String ipaddress = null;

	private static String ESBIP = null;
	private static String ESBPORT = null;

	// get���ղ���
	public void getArgsGet(HttpServletRequest request)
			throws UnsupportedEncodingException {
		String args = request.getQueryString();
		if (args.isEmpty()) {
			return;
		}
		if(SendHX.serverip == null){
			SendHX.serverip = request.getParameter("serverip");
		}
		if(SendHX.socketport ==null){
			SendHX.socketport = request.getParameter("socketport");
		}
		this.ticket = request.getParameter("ticket");
		if(SendHX.urlpath == null){
			SendHX.urlpath = request.getParameter("urlpath");
		}
		if(SendHX.urlport == null){
			SendHX.urlport = request.getParameter("urlport");
		}
		if(SendHX.appid == null){
			SendHX.appid = request.getParameter("appid");
		}
		this.ipaddress = IPTool.getIpAddr(request);
		CommonUtil.info("������ڲ���GBK==========================="
				+ args);
		HttpSession session = request.getSession();
		session.setAttribute("ipaddress", ipaddress);
		session.setAttribute("ticket", ticket);
	}

	// post���ղ���
	/*
	 * public void getArgsPost(HttpServletRequest request) throws
	 * UnsupportedEncodingException { request.setCharacterEncoding("GBK");
	 * 
	 * @SuppressWarnings("unchecked") Map<String, String[]> params =
	 * request.getParameterMap();
	 * CommonUtil.info("������ڲ���===========================" + params.toString());
	 * if (params.isEmpty()) { return; } Map<String, String> map = new
	 * HashMap<String, String>(); for (String key : params.keySet()) { String[]
	 * values = params.get(key); for (String value : values) { if
	 * (value.length() > 0) { map.put(key, value); } else { map.put(key, null);
	 * } } } this.appid = map.get("appid"); this.ipaddress =
	 * IPTool.getIpAddr(request); this.serverip = map.get("serverip");
	 * this.ticket = map.get("ticket"); this.socketport = map.get("socketport");
	 * this.urlpath = map.get("urlpath"); this.urlport = map.get("urlport"); }
	 */

	public Map<String, String> sendMessage(HttpServletRequest request,
			String clerkCode, String type) {
		++COUNT_NUMBER;
		CommonUtil.info("��½ �ӿ�ʹ�ô�����"+COUNT_NUMBER);
		Socket socket = null;
		PrintWriter print = null;
		InputStream in = null;
		Map<String, String> back_map = null;
		HttpSession session = request.getSession();
		try {
			socket = new Socket(SendHX.serverip, Integer.parseInt(SendHX.socketport));
			print = new PrintWriter(socket.getOutputStream());
			in = new BufferedInputStream(socket.getInputStream());

			if ("login".equals(type)) {
				StringBuffer sb = new StringBuffer();
				// ��װ�����
				sb.append("prcscd=getuser|");
				sb.append("clerkip=").append(session.getAttribute("ipaddress"))
						.append("|");
				sb.append("ticket=").append(session.getAttribute("ticket"))
						.append("|");
				String out = new AddZero().addzero(String.valueOf(sb.length()))
						+ sb.toString();
				CommonUtil.info("socket����ͳһƽ̨��ʼ=========================="
						+ out);
				print.println(out);
				print.flush();

			} else if ("addUser".equals(type)) {
				StringBuffer sb = new StringBuffer();
				// ��װ�����
				sb.append("prcscd=adduser|");
				sb.append("ip=").append(session.getAttribute("ipaddress"))
						.append("|");
				sb.append("userid=").append(clerkCode).append("|");
				sb.append("appid=")
						.append(transString(SendHX.appid)).append("|");
				// ��ӡҳ��Ĭ��0���� 1ָ��
				// ����0����1ָ��
				String zcfs = request.getParameter("zcfs");
				if ("1".equals(zcfs)) {
					sb.append("certtp=1").append("|");
				} else {
					sb.append("certtp=0").append("|");
				}

				String out = new AddZero().addzero(String.valueOf(sb.length()))
						+ sb.toString();
				CommonUtil.info("socket����ͳһƽ̨��ʼ=========================="
						+ out);
				print.println(out);
				print.flush();

			} else if ("delClerk".equals(type)) {
				StringBuffer sb = new StringBuffer();
				// ��װ�����
				sb.append("prcscd=deluser|");
				sb.append("ip=").append(session.getAttribute("ipaddress"))
						.append("|");
				sb.append("userid=").append(clerkCode).append("|");
				sb.append("appid=")
						.append(transString(SendHX.appid)).append("|");
				sb.append("certtp=")
						.append(request.getAttribute("delclerkpostnum"))
						.append("|");
				String out = new AddZero().addzero(String.valueOf(sb.length()))
						+ sb.toString();
				CommonUtil.info("socket����ͳһƽ̨��ʼ=========================="+ out);
				print.println(out);
				print.flush();
			}
			String back_str = backMsg(in);
			back_map = transMap(back_str);
			return back_map;
		} catch (NumberFormatException e) {
			e.printStackTrace();
			return null;
		} catch (UnknownHostException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			close(print, in, socket);
		}

	}

	// ȡ��appid��Ӧ��ֵ����һ���ո�֮ǰ����%֮ǰ��ֵ
	public String transString(String s) {
		int space = s.indexOf(" ");
		int other = s.indexOf("%");
		if (space != -1 && other == -1) {
			s = s.substring(0, space);
		} else if (space == -1 && other != -1) {
			s = s.substring(0, other);
		} else {

		}
		return s;
	}

	// �������ķ���ֵ��String ת Map
	public Map<String, String> transMap(String params) {
		if (StringUtils.isEmpty(params))
			return null;
		Map<String, String> back_para = new HashMap<String, String>();
		String[] para = params.split("\\|");
		for (String s : para) {
			String[] s1 = s.split("=");
			if (s1.length > 1) {
				back_para.put(s1[0], s1[1]);
			} else {
				back_para.put(s1[0], null);
			}

		}
		return back_para;
	}

	public String backMsg(InputStream in) {
		// ���ķ���ֵ
		String back_message = null;
		try {
			byte[] msg_length = new byte[4];
			in.read(msg_length);
			String str_len = new String(msg_length);
			str_len = str_len.replaceAll(" ", "");
			if (str_len == null || "".equals(str_len.trim())) {
				return null;
			} else {
				byte[] msg = new byte[Integer.valueOf(str_len)];
				int count = Integer.valueOf(str_len);
				int readCount = 0; // �Ѿ��ɹ���ȡ���ֽڵĸ���
				while (readCount < count) {
					readCount += in.read(msg, readCount, count - readCount);
				}
				back_message = new String(msg, "GBK");
				CommonUtil.info("ͳһƽ̨���ص��ַ���" + back_message);
			}
		} catch (Exception e) {
			e.printStackTrace();
			CommonUtil.info("socket���ӳ���==========================ͳһƽ̨���ط���");
			return null;
		}
		return back_message;
	}

	// �ر�����socket
	public void close(PrintWriter out, InputStream in, Socket socket) {
		try {
			if (in != null) {in.close();}
		} catch (Exception e) {
			e.printStackTrace();
			CommonUtil.info("socketͳһƽ̨�ر�ʱ���ӳ���=========================="+e.getMessage());
		}
		try {	
			if (out != null) {out.close();}
		} catch (Exception e) {
			e.printStackTrace();
			CommonUtil.info("socketͳһƽ̨�ر�ʱ���ӳ���=========================="+e.getMessage());
		}
		try {	
			if (socket != null) {socket.close();}
		} catch (Exception e) {
			e.printStackTrace();
			CommonUtil.info("socketͳһƽ̨�ر�ʱ���ӳ���=========================="+e.getMessage());
		}
		CommonUtil.info("socketͳһƽ̨�ر�");
	}

	// ����ͨ��ESBȡ�����˺���Ϣ
	public Map<String, String> getESB(String sendMsg)
			throws NumberFormatException, UnknownHostException, IOException,
			JDOMException {
		++COUNT_NUMBER2;
		CommonUtil.info("��ȡ�����˺Ŵ�����-----------��"+COUNT_NUMBER2);
		String back_message = null;
		Socket socket = null;
		PrintWriter out = null;
		InputStream in = null;
		// String ip = "32.114.67.1";
		Map<String, String> map = null;
		// String port = "6000";
		if (SendHX.ESBIP == null || StringUtils.isEmpty(SendHX.ESBIP)) {
			SendHX.ESBIP = GetWeishu.getBcodeMesage("ESBIP");
		}
		if (SendHX.ESBPORT == null || StringUtils.isEmpty(SendHX.ESBPORT)) {
			SendHX.ESBPORT = GetWeishu.getBcodeMesage("ESBPORT");
		}

		try {
			socket = new Socket(SendHX.ESBIP, Integer.valueOf(SendHX.ESBPORT));
			out = new PrintWriter(socket.getOutputStream());
			in = new BufferedInputStream(socket.getInputStream());

			// ���շ���ֵ
			// ƴ�ӳ���
			out.println(sendMsg);
			out.flush();
			CommonUtil.info("����ESB���ͷ��ر���==========================" + sendMsg);
			// ��ȡǰ��λ�õ��ܹ���λ��
			byte[] msg_length = new byte[8];
			in.read(msg_length);
			String str_len = new String(msg_length);
			if (str_len == null || "".equals(str_len.trim())) {
				return null;
			} else {
				byte[] msg = new byte[Integer.valueOf(str_len)];
				int count = Integer.valueOf(str_len);
				int readCount = 0; // �Ѿ��ɹ���ȡ���ֽڵĸ���
				while (readCount < count) {
					readCount += in.read(msg, readCount, count - readCount);
				}
				back_message = new String(msg, "GBK");
				CommonUtil.info("socketESB�ѷ��ر���=========================="
						+ back_message);
			}
			Map<String, String> back_map = null;
			if (!StringUtils.isEmpty(back_message)) {
				back_map = transXML(back_message);
			} else {
				return null;
			}
			return back_map;
		} catch (IOException e) {
			CommonUtil.info("��ȡ�����˺���Ϣ�����г���"+e.getMessage());
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (in != null) {in.close();}
			} catch (Exception e) {
				e.printStackTrace();
				CommonUtil.info("��ȡ�����˺���Ϣ�����г���"+e.getMessage());
			}
			try {
				if (out != null) {out.close();}
			} catch (Exception e) {
				e.printStackTrace();
				CommonUtil.info("��ȡ�����˺���Ϣ�����г���"+e.getMessage());
			}
			try {
				if (socket != null) {socket.close();}
			} catch (Exception e) {
				e.printStackTrace();
				CommonUtil.info("��ȡ�����˺���Ϣ�����г���"+e.getMessage());
			}
			CommonUtil.info("socketESB�ر�==========================");
		}
		// this.close(out, in, socket);
	}

	// ����XML������
	public Map<String, String> transXML(String message) throws JDOMException,
			IOException {
		StringReader read = new StringReader(message);
		InputSource source = new InputSource(read);
		SAXBuilder saxb = new SAXBuilder();
		Document doc = null;
		doc = saxb.build(source);
		Element root = doc.getRootElement();
		// System.out.println(root.getName());
		Map<String, String> map = new HashMap<String, String>();
		parseXML(root, map);
		return map;
	}

	// ѭ������
	@SuppressWarnings("unchecked")
	public void parseXML(Element root, Map<String, String> map) {
		List<Element> root0 = (List<Element>) root.getChildren();
		if (root0.size() <= 0) {
			return;
		}
		for (int i = 0; i < root0.size(); i++) {
			Element et = (Element) root0.get(i);
			parseXML(et, map);
			map.put(et.getName(), et.getText());
			// System.out.println(et.getName());
			// System.out.println(et.getText());

		}
	}
}
