package com.unitop.sysmgr.action.project;

import com.unitop.framework.util.StringUtil;

public class AddZero {
	public String addzero(String in){
		if("".equals(in)||StringUtil.isEmpty(in)){
			return null;
		}else if(in.length() >= 4){
			return in;
		}else{
				if(in.length()==1){
					in = "000"+in;
				return in;
				}else if(in.length()==2){
					in ="00"+in;
					return in;
				}else{
					in = "0"+in;
					return in;
				}
		}
	}
	/*
	 * in= xx.length();
	 * ��in�ĸ�ʽ���000XX
	 * n-in.length() �� 0
	 * xx��in.length()
	 */
	public String addzero(Object obj,int n){
		String in = null;
		if (obj instanceof Integer) {
			in = String.valueOf(obj);
		}else if(obj instanceof String){
			in = (String)obj;
		}else{
			return (String)obj;
		}
		if( n<=0 || in.length()>=n){
			return null;
		}else if("".equals(in)||in == null){
			return null;
		}else{
			while(in.length()<n){
				in = "0"+in;
			}
		}
		return in;
	}
}
