package com.unitop.sysmgr.action;


import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.stereotype.Controller;

import com.unitop.framework.util.StringUtil;
import com.unitop.sysmgr.bo.Clerk;
import com.unitop.sysmgr.bo.Org;
import com.unitop.sysmgr.bo.TabsBo;
import com.unitop.sysmgr.dao.OrgDao;
import com.unitop.sysmgr.form.ZhanghForm;
import com.unitop.sysmgr.service.OrgService;
import com.unitop.sysmgr.service.ZhanghbService;
import com.unitop.sysmgr.service.impl.ZhanghbServiceImpl;
/**
 * @author binbin
 *�˻��߼���ѯ�ñ���������weblogic92�²���ʾ
 */
@Controller("/zhanghgjcx")
public class ZhanghgjcxAction  extends ExDispatchAction {
	@Resource
	private OrgDao orgDao;
	
	private final static String SUCCESS = "success";
	@Resource
	private ZhanghbService zhanghbService;
	@Resource
	private OrgService OrgService;
	
	public ActionForward enter(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		
		try {
			//��ȡJsonstr
			Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
			String code2=clerk2.getOrgcode();	
			JSONArray jsonArray = new JSONArray();		
			List<Org> orgList=orgDao.getAllOrg(code2);

				for(Org orgltem:orgList){											
						JSONObject jsonObject = new JSONObject();
						jsonObject.put("id", orgltem.getCode());
						jsonObject.put("pId", orgltem.getParentCode());
						jsonObject.put("name", orgltem.getName());
						jsonObject.put("wdflag", orgltem.getWdflag());
						if(code2.equals(orgltem.getCode())){
							jsonObject.put("open", "true");					
							jsonObject.put("nocheck", false);
						}
						jsonArray.add(jsonObject);
						//���ӱ���
						if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
							jsonObject.put("id","banb"+orgltem.getCode());
							jsonObject.put("pId", orgltem.getCode());
							jsonObject.put("name", orgltem.getName()+"(����)");
							jsonArray.add(jsonObject);
						}
				}	
				String str=jsonArray.toString();				
			request.setAttribute("Jsonstr",str);
//			request.setAttribute("youqjgstr",code2);
			return mapping.findForward("zhanghgjcx");
		} catch (Exception e) {
			return this.errrForLogAndException(e, mapping, request, "error");
		}
	}
	
	public ActionForward searchZhanghForgj(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
		//���
			ZhanghForm zhanghform = (ZhanghForm)actionForm;
		//ѡ��Ļ���
			//String newjigh=zhanghform.getJigh1();
			
		//ȡ�õ�½��Ա
			Clerk clerk2 = (Clerk)request.getSession().getAttribute("clerk");
			try{								
				//��ȡJsonstr
				//��ȡ��¼��Ա������
				String code2=clerk2.getOrgcode();	
				String include=zhanghform.getInclude();
				JSONArray jsonArray = new JSONArray();	
				//ȡ�õ�½��ԱȨ���µĻ���
				List<Org> orgList=orgDao.getAllOrg(code2);
				
			
				
				for(Org orgltem:orgList){											
							JSONObject jsonObject = new JSONObject();
							jsonObject.put("id", orgltem.getCode());
							jsonObject.put("pId", orgltem.getParentCode());
							jsonObject.put("name", orgltem.getName());
							jsonObject.put("wdflag", orgltem.getWdflag());
							if(code2.equals(orgltem.getCode())){
								jsonObject.put("open", "true");					
								jsonObject.put("nocheck", false);
							}
							jsonArray.add(jsonObject);
							//���ӱ���
							if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
								jsonObject.put("id","banb"+orgltem.getCode());
								jsonObject.put("pId", orgltem.getCode());
								jsonObject.put("name", orgltem.getName()+"(����)");
								jsonArray.add(jsonObject);
							}
					}
					String str=jsonArray.toString();
					request.setAttribute("Jsonstr",str);
					String zhanghxz=zhanghform.getZhanghxz().replace("'", "");
					String shenhzt=zhanghform.getZhanghshzt().replace("'", "");
					String zhanghzt=zhanghform.getZhanghzt().replace("'", "");
//					if("".equals(zhanghxc)||null==zhanghxc){zhanghxc="ȫ��";}
//					if("".equals(shenhzt)||null==shenhzt){shenhzt="ȫ��";}
//					if("".equals(zhanghzt)||null==zhanghzt){zhanghzt="ȫ��";}
					request.setAttribute("leib",zhanghxz);
					request.setAttribute("shzt",shenhzt);
					request.setAttribute("zhzt",zhanghzt);
					//������˺�
					String account = zhanghform.getAccount();
					if(!StringUtil.isEmpty(account)){
						request.setAttribute("account",account);
					}
					//��ȡ����Ļ�����
					String jigh2= zhanghform.getJigh2();  //request.getParameter("jigh2");
					if(!(jigh2==null||"".equals(jigh2))){
						if(clerk2!=null){
							boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk2.getOrgcode(),jigh2);
							if(!bool){
								return super.showMessageJSPforcx(actionMapping, request, "zhanghgjcx", "��û��Ȩ�޲鿴:["+jigh2+"]�µ��˺�");
							}
						}
						//�жϻ����Ƿ����
						Org org = this.OrgService.getOrgByCode(jigh2);					
						if(org==null){
							return super.showMessageJSPforcx(actionMapping, request, "zhanghgjcx", "������Ļ����Ų����ڣ�����������");
						}
						zhanghform.setJigh1(jigh2);
					}else {

						return super.showMessageJSPforcx(actionMapping, request, "zhanghgjcx", "����������ţ�");
					}
					
					
					/*String neworg="";
					//ȡ��ѡ�������ӦID
					String guanl=zhanghform.getJigh1();
					if(!(guanl==null||"".equals(guanl))){
						String[] guanljg=guanl.split(",");					
						for(int i =0;i<guanljg.length;i++){
							Pattern pattern=Pattern.compile("[0-9]*");
							if(!(pattern.matcher(guanljg[i]).matches())){							
								if("".equals(neworg)){								
									neworg+=guanljg[i].replaceAll("[a-zA-Z]", "");
								}else{
									neworg+=","+guanljg[i].replaceAll("[a-zA-Z]", "");
								}							
							}else{
								if("".equals(neworg)){								
									neworg+=guanljg[i];
								}else{
									neworg+=","+guanljg[i];
								}
								Org o = orgDao.getOrgByCode(guanljg[i]);			
								if(!(o.getGuanljg()==null||"".equals(o.getGuanljg()))){							
									neworg+=(","+o.getGuanljg());						
								}
							}
						}
					}*/
					//��ԭѡ������ID
					/*zhanghform.setJigh1(neworg);
					if((zhanghform.getJigh1().indexOf(",")!=-1)&&zhanghform.getInclude().equals("��")){
						return super.showMessageJSPforcx(actionMapping, request, "zhanghgjcx", "ֻ��ѡ��һ�����������Ƿ�����¼���ѡ�񡰷�");
					}*/
					
//					request.setAttribute("youqjgstr",newjigh);
					
					/*if(zhanghform.getJigh1().equals("")||zhanghform.getJigh1()==null){
						return super.showMessageJSPforcx(actionMapping, request, "zhanghgjcx", "����������ţ�");
					}*/
					
					/*if(zhanghform.getZhanghxz().equals("")||zhanghform.getZhanghxz()==null){
						return super.showMessageJSPforcx(actionMapping, request, "zhanghgjcx", "�������˻����");
					}
					if(zhanghform.getZhanghshzt().equals("")||zhanghform.getZhanghshzt()==null){
						return super.showMessageJSPforcx(actionMapping, request, "zhanghgjcx", "��ѡ���˻����״̬��");
					}	
					if(zhanghform.getZhanghzt().equals("")||zhanghform.getZhanghzt()==null){
						return super.showMessageJSPforcx(actionMapping, request, "zhanghgjcx", "�������˻�״̬��");
					}*/
				TabsBo TabsBo = this.createTabsBo(request);   
				ZhanghbServiceImpl ZhanghbServiceImpl = (ZhanghbServiceImpl) zhanghbService;
				ZhanghbServiceImpl.setTabsService(TabsBo);
				TabsBo tabsBo = zhanghbService.searchZhanghInfo(zhanghform);
				this.showTabsModel(request, tabsBo);
//				request.setAttribute("list", tabsBo.getList());
				
				return super.showMessageJSPForFeny(actionMapping,request,tabsBo,"zhanghgjcx");
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request, "error");
		}
		
	}
	
	public ActionForward selectShenhwg(ActionMapping actionMapping,
			ActionForm actionForm, HttpServletRequest request,
			HttpServletResponse response) {
			@SuppressWarnings("unused")
			ZhanghForm zhanghform1 = (ZhanghForm)actionForm;
			ZhanghForm zhanghform = (ZhanghForm)actionForm;	
			zhanghform.setZhanghshzt("���δ��");
			try{			
				//��ȡJsonstr
				Clerk clerk2 = (Clerk) request.getSession().getAttribute("clerk");
				String code2=clerk2.getOrgcode();	
				JSONArray jsonArray = new JSONArray();		
				List<Org> orgList=orgDao.getAllOrg(code2);

					for(Org orgltem:orgList){											
							JSONObject jsonObject = new JSONObject();
							jsonObject.put("id", orgltem.getCode());
							jsonObject.put("pId", orgltem.getParentCode());
							jsonObject.put("name", orgltem.getName());	
							jsonObject.put("wdflag", orgltem.getWdflag());
							if(code2.equals(orgltem.getCode())){
								jsonObject.put("open", "true");					
								jsonObject.put("nocheck", false);
							}
							jsonArray.add(jsonObject);
							//���ӱ���
							if("1".equals(orgltem.getWdflag())||"2".equals(orgltem.getWdflag())||"3".equals(orgltem.getWdflag())){
								jsonObject.put("id","banb"+orgltem.getCode());
								jsonObject.put("pId", orgltem.getCode());
								jsonObject.put("name", orgltem.getName()+"(����)");
								jsonArray.add(jsonObject);
							}
					}	
					String str=jsonArray.toString();						
					//�жϻ����Ƿ����
					Org org = this.OrgService.getOrgByCode(zhanghform.getJigh());
					if(org==null){
						return super.showMessageJSPforcx(actionMapping, request, "zhanghgjcx", "������Ļ����Ų����ڣ�����������");
					}
					request.setAttribute("Jsonstr",str);
					request.setAttribute("youqjgstr",zhanghform.getJigh());
//				boolean bool = this.getSystemMgrService().CanOperDesOrg(clerk.getOrgcode(),zhanghform.getJigh());
//				if(!bool)
//				{
//					return super.showMessageJSP(actionMapping, request, "zhanghgjcx", "��û��Ȩ�޲鿴:["+zhanghform.getJigh()+"]�µ��˺�");
//				}
				TabsBo TabsBo = this.createTabsBo(request);   
				ZhanghbServiceImpl ZhanghbServiceImpl = (ZhanghbServiceImpl) zhanghbService;
				ZhanghbServiceImpl.setTabsService(TabsBo);
				TabsBo tabsBo = zhanghbService.searchZhanghInfo(zhanghform);
				this.showTabsModel(request, tabsBo);
				request.setAttribute("list", tabsBo.getList());
				return super.showMessageJSPForFeny(actionMapping,request,tabsBo,"zhanghgjcx");
		} catch (Exception e) {
			e.printStackTrace();
			return this.errrForLogAndException(e, actionMapping, request, "error");
		}
	}
}
