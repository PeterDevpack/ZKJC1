package com.unitop.sysmgr.service.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.unitop.config.SystemConfig;
import com.unitop.framework.util.FileServerClient;
import com.unitop.sysmgr.bo.Ocxkongzcsb;
import com.unitop.sysmgr.bo.Piaojyxwjb;
import com.unitop.sysmgr.bo.PiaojyxwjbId;
import com.unitop.sysmgr.bo.Yinjk;
import com.unitop.sysmgr.dao.OcxkongzcsbDao;
import com.unitop.sysmgr.dao.PiaojyxwjbDao;
import com.unitop.sysmgr.dao.impl.YinjkDaoImpl;
import com.unitop.sysmgr.service.AccountImageServcie;

@Service("AccountImageServcieImpl")
public class AccountImageServcieImpl implements AccountImageServcie {
	
	@Resource
	private PiaojyxwjbDao piaojyxwjbDao =null;
	@Resource
	private YinjkDaoImpl yinjkDaoImpl =null;
	@Resource
	private OcxkongzcsbDao ocxkongzcsbDao =null;
	
	public List getZhanghYjkList(String zhangh) {
		List list  = yinjkDaoImpl.getYinjkByZhangh(zhangh);
		return list;
	}
	
	public List getBillImgList(String zhangh,String wenjbh) {
		List list  = piaojyxwjbDao.getPiaojyxwjb(zhangh,wenjbh);
		return list;
	}

	public Piaojyxwjb getAccountImageInfo(PiaojyxwjbId id) {
		return piaojyxwjbDao.getPiaojyxwjb(id);
	}
	
	public void downloadBillImage(PiaojyxwjbId id, OutputStream out) {
		Piaojyxwjb zTemp =  piaojyxwjbDao.getPiaojyxwjb(id);
		String wenjdz = zTemp.getWenjfwdz();
		String ip = wenjdz.substring(0,wenjdz.indexOf(":"));
		int port = Integer.valueOf(wenjdz.substring(wenjdz.indexOf(":")+1));
		//ͨѶ��ȡ�ļ�
		try {
				FileServerClient fService = new FileServerClient();
				fService.GetFile(ip, port, 10000, out, zTemp.getPiaojyxdz());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	public void downloadYinjkImage(String zhangh,String yinjkh,String billcm,OutputStream out) {
		Yinjk yinjk = yinjkDaoImpl.getYinjkByZhangh(zhangh, yinjkh);
		//ͨѶ��ȡ�ļ�
		try {
				SystemConfig systemConfig = SystemConfig.getInstance();
				FileServerClient fService = new FileServerClient();
//				String file_address_ip = systemConfig.getValue("file_address_ip");
//				int file_address_port = Integer.valueOf(systemConfig.getValue("file_address_port"));
				int file_address_outtime = Integer.valueOf(systemConfig.getValue("file_address_port"));
				
				Ocxkongzcsb ocxkongzcsb = ocxkongzcsbDao.getocxkongzcs("jkFileSeverIp");
				String wenjdz = ocxkongzcsb.getValue();
				String file_address_ip = wenjdz.substring(0,wenjdz.indexOf(":"));
				int file_address_port = Integer.valueOf(wenjdz.substring(wenjdz.indexOf(":")+1));
				
				//billcm=1 ��ȡ����ͼ��billcm=2 ��ȡ����ͼ��
				if("1".equals(billcm))
					fService.GetFile(file_address_ip,file_address_port,file_address_outtime,out,yinjk.getZhengmwjm());
				if("2".equals(billcm))
					fService.GetFile(file_address_ip,file_address_port,file_address_outtime,out,yinjk.getFanmwjm());
			} catch (IOException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	public List<Yinjk> getYinjkByQiyrq(String zhangh,String qiyrq){
		List list  = yinjkDaoImpl.getYinjkByQiyrq(zhangh, qiyrq);
		return list;
	}
	
	public void downloadFromYinxpt(String wenjsy,OutputStream out){
		//��Ӱ��ƽ̨���� Ԥ���ӿ�
	}
}