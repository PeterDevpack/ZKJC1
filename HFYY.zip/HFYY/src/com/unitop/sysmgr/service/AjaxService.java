package com.unitop.sysmgr.service;

public interface AjaxService {
	/*
	 * ajax���
	 */
	public String ajax(String id,String message) throws Exception ;
	
}
