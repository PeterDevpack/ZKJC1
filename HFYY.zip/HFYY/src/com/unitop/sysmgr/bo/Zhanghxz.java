package com.unitop.sysmgr.bo;
/**
 * �˻����ʱ�
 * @author guodx
 */
public class Zhanghxz {
	private String zhanghxzbh; //�˻����ʱ��
	private String zhanghxz;   //�˻�����
	private String beiz;	   //��ע
	
	public String getZhanghxzbh() {
		return zhanghxzbh;
	}
	public void setZhanghxzbh(String zhanghxzbh) {
		this.zhanghxzbh = zhanghxzbh;
	}
	public String getZhanghxz() {
		return zhanghxz;
	}
	public void setZhanghxz(String zhanghxz) {
		this.zhanghxz = zhanghxz;
	}
	public String getBeiz() {
		return beiz;
	}
	public void setBeiz(String beiz) {
		this.beiz = beiz;
	}
	
}
