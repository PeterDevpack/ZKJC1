package com.unitop.sysmgr.bo;

/***********************************************************************
 * Module:  Chout.java
 * Author:  Administrator
 * Purpose: Defines the Class Chout
 ***********************************************************************/


public class Chout {

	private ChoutId choutid;
	private int shengykj;
	private int zongkj;
	private int shiykj;
	private String jigh;
	private String choutzt;

	public String getChoutzt() {
		return choutzt;
	}
	public void setChoutzt(String choutzt) {
		this.choutzt = choutzt;
	}
	public ChoutId getChoutid() {
		return choutid;
	}
	public void setChoutid(ChoutId choutid) {
		this.choutid = choutid;
	}
	public int getShengykj() {
		return shengykj;
	}
	public void setShengykj(int shengykj) {
		this.shengykj = shengykj;
	}
	public int getZongkj() {
		return zongkj;
	}
	public void setZongkj(int zongkj) {
		this.zongkj = zongkj;
	}
	public int getShiykj() {
		return shiykj;
	}
	public void setShiykj(int shiykj) {
		this.shiykj = shiykj;
	}
	public String getJigh() {
		return jigh;
	}
	public void setJigh(String jigh) {
		this.jigh = jigh;
	}


}