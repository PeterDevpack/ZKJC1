package com.unitop.sysmgr.bo;


public class Jigtgl {
	
	private String jigmc;//������
	private String yanyzs;//��ӡ����
	private String tonggzs;//ͨ������
	private String tonggl;//ͨ��������
	private String zidtgzs; //�Զ�ͨ������
	private String zidtgl;//�Զ�ͨ����
	private String rengtgzs;//�˹�ͨ������
	private String rengtgl;//�˹�ͨ����
	
	//private String xitbs;
	
	
	//����
	private String jigh;	
	private String fuztgzs;
	private String fuztgl;
	private String hum;
	private String zhangh;
	private String parentOrg;
	private String orgflag;
	private String xittgzs;
	private String xittgl;
	private String xitlx;//ҵ������
	
	public String getXittgzs() {
		return xittgzs;
	}
	public void setXittgzs(String xittgzs) {
		this.xittgzs = xittgzs;
	}
	public String getXittgl() {
		return xittgl;
	}
	public void setXittgl(String xittgl) {
		this.xittgl = xittgl;
	}
	public String getOrgflag() {
		return orgflag;
	}
	public void setOrgflag(String orgflag) {
		this.orgflag = orgflag;
	}
	public String getParentOrg() {
		return parentOrg;
	}
	public void setParentOrg(String parentOrg) {
		this.parentOrg = parentOrg;
	}
	public String getHum() {
		return hum;
	}
	public void setHum(String hum) {
		this.hum = hum;
	}
	public String getZhangh() {
		return zhangh;
	}
	public void setZhangh(String zhangh) {
		this.zhangh = zhangh;
	}
	public String getFuztgzs() {
		return fuztgzs;
	}
	public void setFuztgzs(String fuztgzs) {
		this.fuztgzs = fuztgzs;
	}
	public String getFuztgl() {
		return fuztgl;
	}
	public void setFuztgl(String fuztgl) {
		this.fuztgl = fuztgl;
	}
	public String getJigh() {
		return jigh;
	}
	public void setJigh(String jigh) {
		this.jigh = jigh;
	}
	public String getJigmc() {
		return jigmc;
	}
	public void setJigmc(String jigmc) {
		this.jigmc = jigmc;
	}
	public String getYanyzs() {
		return yanyzs;
	}
	public void setYanyzs(String yanyzs) {
		this.yanyzs = yanyzs;
	}
	public String getTonggzs() {
		return tonggzs;
	}
	public void setTonggzs(String tonggzs) {
		this.tonggzs = tonggzs;
	}
	public String getTonggl() {
		return tonggl;
	}
	public void setTonggl(String tonggl) {
		this.tonggl = tonggl;
	}
	public String getZidtgzs() {
		return zidtgzs;
	}
	public void setZidtgzs(String zidtgzs) {
		this.zidtgzs = zidtgzs;
	}
	public String getZidtgl() {
		return zidtgl;
	}
	public void setZidtgl(String zidtgl) {
		this.zidtgl = zidtgl;
	}
	public String getRengtgzs() {
		return rengtgzs;
	}
	public void setRengtgzs(String rengtgzs) {
		this.rengtgzs = rengtgzs;
	}
	public String getRengtgl() {
		return rengtgl;
	}
	public void setRengtgl(String rengtgl) {
		this.rengtgl = rengtgl;
	}

	public String getXitlx() {
		return xitlx;
	}
	public void setXitlx(String xitlx) {
		this.xitlx = xitlx;
	}
	@Override
	public String toString() {
		return "Jigtgl [jigmc=" + jigmc + ", yanyzs=" + yanyzs + ", tonggzs="
				+ tonggzs + ", tonggl=" + tonggl + ", zidtgzs=" + zidtgzs
				+ ", zidtgl=" + zidtgl + ", rengtgzs=" + rengtgzs
				+ ", rengtgl=" + rengtgl + ", jigh=" + jigh + ", fuztgzs="
				+ fuztgzs + ", fuztgl=" + fuztgl + ", hum=" + hum + ", zhangh="
				+ zhangh + ", parentOrg=" + parentOrg + ", orgflag=" + orgflag
				+ ", xittgzs=" + xittgzs + ", xittgl=" + xittgl + ", xitlx="
				+ xitlx + "]";
	}
	
}
