package com.unitop.sysmgr.bo;

/**
 * Pingzxtlxgxb entity. @author MyEclipse Persistence Tools
 */

public class Pingzxtlxgxb implements java.io.Serializable {

	// Fields

	private PingzxtlxgxbId id;

	// Constructors

	/** default constructor */
	public Pingzxtlxgxb() {
	}

	/** full constructor */
	public Pingzxtlxgxb(PingzxtlxgxbId id) {
		this.id = id;
	}

	// Property accessors

	public PingzxtlxgxbId getId() {
		return this.id;
	}

	public void setId(PingzxtlxgxbId id) {
		this.id = id;
	}

}