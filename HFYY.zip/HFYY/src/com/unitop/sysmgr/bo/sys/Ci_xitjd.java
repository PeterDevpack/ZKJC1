package com.unitop.sysmgr.bo.sys;

import java.io.Serializable;

public class Ci_xitjd implements Serializable{

	private static final long serialVersionUID = -2657270050823052645L;
	private String jiedbs;
	private String jiedmc;
	
	
	public String getJiedbs() {
		return jiedbs;
	}
	public void setJiedbs(String jiedbs) {
		this.jiedbs = jiedbs;
	}
	public String getJiedmc() {
		return jiedmc;
	}
	public void setJiedmc(String jiedmc) {
		this.jiedmc = jiedmc;
	}
	
}
