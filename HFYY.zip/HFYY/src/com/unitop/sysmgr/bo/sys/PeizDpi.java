package com.unitop.sysmgr.bo.sys;

import java.io.Serializable;

public class PeizDpi implements Serializable{

	private static final long serialVersionUID = 2009958253449052512L;
	private String dpiid;
	private String diqh;
	private String wangdh;
	private String yewlx;
	private String secbz;
	private String dpi;
	private String tiaoycs;
	
	
	public String getDpiid() {
		return dpiid;
	}
	public void setDpiid(String dpiid) {
		this.dpiid = dpiid;
	}
	public String getDiqh() {
		return diqh;
	}
	public void setDiqh(String diqh) {
		this.diqh = diqh;
	}
	public String getWangdh() {
		return wangdh;
	}
	public void setWangdh(String wangdh) {
		this.wangdh = wangdh;
	}
	public String getYewlx() {
		return yewlx;
	}
	public void setYewlx(String yewlx) {
		this.yewlx = yewlx;
	}

	public String getSecbz() {
		return secbz;
	}
	public void setSecbz(String secbz) {
		this.secbz = secbz;
	}
	public String getDpi() {
		return dpi;
	}
	public void setDpi(String dpi) {
		this.dpi = dpi;
	}
	public String getTiaoycs() {
		return tiaoycs;
	}
	public void setTiaoycs(String tiaoycs) {
		this.tiaoycs = tiaoycs;
	}
	
	
}
