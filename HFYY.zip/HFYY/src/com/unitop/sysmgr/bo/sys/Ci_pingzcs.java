package com.unitop.sysmgr.bo.sys;

import java.io.Serializable;

public class Ci_pingzcs implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7423444545159383735L;
	private UnionPingzcs unionPingzcs;
	private String pingzmc;
	private String zhaozq;
	private String fazq;
	private int yanyjb;
	private int xfenbl;
	private int yfenbl;
	private int xsuof ;
	private int ysuof;
	
	
	

	public UnionPingzcs getUnionPingzcs() {
		return unionPingzcs;
	}
	public void setUnionPingzcs(UnionPingzcs unionPingzcs) {
		this.unionPingzcs = unionPingzcs;
	}
	public String getPingzmc() {
		return pingzmc;
	}
	public void setPingzmc(String pingzmc) {
		this.pingzmc = pingzmc;
	}
	public String getZhaozq() {
		return zhaozq;
	}
	public void setZhaozq(String zhaozq) {
		this.zhaozq = zhaozq;
	}
	public String getFazq() {
		return fazq;
	}
	public void setFazq(String fazq) {
		this.fazq = fazq;
	}
	public int getYanyjb() {
		return yanyjb;
	}
	public void setYanyjb(int yanyjb) {
		this.yanyjb = yanyjb;
	}
	public int getXfenbl() {
		return xfenbl;
	}
	public void setXfenbl(int xfenbl) {
		this.xfenbl = xfenbl;
	}
	public int getYfenbl() {
		return yfenbl;
	}
	public void setYfenbl(int yfenbl) {
		this.yfenbl = yfenbl;
	}
	public int getXsuof() {
		return xsuof;
	}
	public void setXsuof(int xsuof) {
		this.xsuof = xsuof;
	}
	public int getYsuof() {
		return ysuof;
	}
	public void setYsuof(int ysuof) {
		this.ysuof = ysuof;
	}
	
	
}
