package com.unitop.sysmgr.bo.sys;

import java.io.Serializable;

public class Ci_yewxt implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262021223417501450L;
	private String xitbs;
	private String xitmc;
	private String yanzxx;
	
	
	
	public String getXitbs() {
		return xitbs;
	}
	public void setXitbs(String xitbs) {
		this.xitbs = xitbs;
	}
	public String getXitmc() {
		return xitmc;
	}
	public void setXitmc(String xitmc) {
		this.xitmc = xitmc;
	}
	public String getYanzxx() {
		return yanzxx;
	}
	public void setYanzxx(String yanzxx) {
		this.yanzxx = yanzxx;
	}
	
	
}
