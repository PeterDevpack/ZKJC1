package com.unitop.sysmgr.bo.sys;

import java.io.Serializable;

public class UnionXitcs implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7641213383159573542L;
	
	private String xitbs="";
	private String cansbs="";
	
	
	public String getXitbs() {
		return xitbs;
	}
	public void setXitbs(String xitbs) {
		this.xitbs = xitbs;
	}
	public String getCansbs() {
		return cansbs;
	}
	public void setCansbs(String cansbs) {
		this.cansbs = cansbs;
	}
	
	
	
}
