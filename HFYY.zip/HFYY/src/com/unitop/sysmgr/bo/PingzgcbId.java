package com.unitop.sysmgr.bo;

import java.io.Serializable;

public class PingzgcbId implements Serializable{
	
	private String pingzh;
	private String pingzlx;
	
	public void setPingzh(String pingzh) {
		this.pingzh = pingzh;
	}
	public String getPingzh() {
		return pingzh;
	}
	public void setPingzlx(String pingzlx) {
		this.pingzlx = pingzlx;
	}
	public String getPingzlx() {
		return pingzlx;
	}
	
	
	


}
