package com.unitop.sysmgr.bo;

import java.io.Serializable;

public class AccountNum implements Serializable {

	private static final long serialVersionUID = 1L;

	private String zhanghzs = "";
	private String youyj_zhanghzs ="";
	private String youyj_zhanghzs_you_youx = "";
	private String youyj_zhanghzs_you_xiaoh = "";
	private String youyj_zhanghzs_you_dongj = "";
	private String youyj_zhanghzs_you_guas = "";
	private String youyj_zhanghzs_you_weiss = "";
	private String youyj_zhanghzs_you_shenhwg = "";
	
	public String getYouyj_zhanghzs_you_shenhwg() {
		return youyj_zhanghzs_you_shenhwg;
	}

	public void setYouyj_zhanghzs_you_shenhwg(String youyj_zhanghzs_you_shenhwg) {
		this.youyj_zhanghzs_you_shenhwg = youyj_zhanghzs_you_shenhwg;
	}

	public String getYouyj_zhanghzs_you_weiss() {
		return youyj_zhanghzs_you_weiss;
	}

	public void setYouyj_zhanghzs_you_weiss(String youyj_zhanghzs_you_weiss) {
		this.youyj_zhanghzs_you_weiss = youyj_zhanghzs_you_weiss;
	}

	private String wuyj_zhanghzs= "";
	private String youyj_zhanghzs_wu_youx ="";
	private String youyj_zhanghzs_wu_xiaoh ="";
	private String youyj_zhanghzs_wu_dongj ="";
	private String youyj_zhanghzs_wu_guas ="";
	
	
	

	public String getYouyj_zhanghzs_you_guas() {
		return youyj_zhanghzs_you_guas;
	}

	public void setYouyj_zhanghzs_you_guas(String youyjZhanghzsYouGuas) {
		youyj_zhanghzs_you_guas = youyjZhanghzsYouGuas;
	}

	public String getYouyj_zhanghzs_wu_guas() {
		return youyj_zhanghzs_wu_guas;
	}

	public void setYouyj_zhanghzs_wu_guas(String youyjZhanghzsWuGuas) {
		youyj_zhanghzs_wu_guas = youyjZhanghzsWuGuas;
	}

	public String getZhanghzs() {
		return zhanghzs;
	}

	public void setZhanghzs(String zhanghzs) {
		this.zhanghzs = zhanghzs;
	}

	public String getYouyj_zhanghzs() {
		return youyj_zhanghzs;
	}

	public void setYouyj_zhanghzs(String youyjZhanghzs) {
		youyj_zhanghzs = youyjZhanghzs;
	}

	public String getYouyj_zhanghzs_you_youx() {
		return youyj_zhanghzs_you_youx;
	}

	public void setYouyj_zhanghzs_you_youx(String youyjZhanghzsYouYoux) {
		youyj_zhanghzs_you_youx = youyjZhanghzsYouYoux;
	}

	public String getYouyj_zhanghzs_you_xiaoh() {
		return youyj_zhanghzs_you_xiaoh;
	}

	public void setYouyj_zhanghzs_you_xiaoh(String youyjZhanghzsYouXiaoh) {
		youyj_zhanghzs_you_xiaoh = youyjZhanghzsYouXiaoh;
	}

	public String getYouyj_zhanghzs_you_dongj() {
		return youyj_zhanghzs_you_dongj;
	}

	public void setYouyj_zhanghzs_you_dongj(String youyjZhanghzsYouDongj) {
		youyj_zhanghzs_you_dongj = youyjZhanghzsYouDongj;
	}

	public String getWuyj_zhanghzs() {
		return wuyj_zhanghzs;
	}

	public void setWuyj_zhanghzs(String wuyjZhanghzs) {
		wuyj_zhanghzs = wuyjZhanghzs;
	}

	public String getYouyj_zhanghzs_wu_youx() {
		return youyj_zhanghzs_wu_youx;
	}

	public void setYouyj_zhanghzs_wu_youx(String youyjZhanghzsWuYoux) {
		youyj_zhanghzs_wu_youx = youyjZhanghzsWuYoux;
	}

	public String getYouyj_zhanghzs_wu_xiaoh() {
		return youyj_zhanghzs_wu_xiaoh;
	}

	public void setYouyj_zhanghzs_wu_xiaoh(String youyjZhanghzsWuXiaoh) {
		youyj_zhanghzs_wu_xiaoh = youyjZhanghzsWuXiaoh;
	}

	public String getYouyj_zhanghzs_wu_dongj() {
		return youyj_zhanghzs_wu_dongj;
	}

	public void setYouyj_zhanghzs_wu_dongj(String youyjZhanghzsWuDongj) {
		youyj_zhanghzs_wu_dongj = youyjZhanghzsWuDongj;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


}
