package com.unitop.sysmgr.bo;

public class Menu {
	private String gongnid;
	
	private String zignid;

	private String gongnmc;
	
	private String gongnlx;
	
	private String gongnurl;
	
	private int gongnsx;

	private String shangjgn;
	
	private String quanxwz;
	
	private String zhuangt;
	
	private String beiz;
	
	private String caidlx;
	
	private String classid;
	
	

	public String getClassid() {
		return classid;
	}

	public void setClassid(String classid) {
		this.classid = classid;
	}

	public String getCaidlx() {
		return caidlx;
	}

	public void setCaidlx(String caidlx) {
		this.caidlx = caidlx;
	}

	public String getGongnid() {
		return gongnid;
	}

	public void setGongnid(String gongnid) {
		this.gongnid = gongnid;
	}

	public String getZignid() {
		return zignid;
	}

	public void setZignid(String zignid) {
		this.zignid = zignid;
	}

	public String getGongnlx() {
		return gongnlx;
	}

	public void setGongnlx(String gongnlx) {
		this.gongnlx = gongnlx;
	}

	public String getGongnmc() {
		return gongnmc;
	}

	public void setGongnmc(String gongnmc) {
		this.gongnmc = gongnmc;
	}

	public String getGongnurl() {
		return gongnurl;
	}

	public void setGongnurl(String gongnurl) {
		this.gongnurl = gongnurl;
	}

	public int getGongnsx() {
		return gongnsx;
	}

	public void setGongnsx(int gongnsx) {
		this.gongnsx = gongnsx;
	}

	public String getShangjgn() {
		return shangjgn;
	}

	public void setShangjgn(String shangjgn) {
		this.shangjgn = shangjgn;
	}

	public String getQuanxwz() {
		return quanxwz;
	}

	public void setQuanxwz(String quanxwz) {
		this.quanxwz = quanxwz;
	}


	public String getZhuangt() {
		return zhuangt;
	}

	public void setZhuangt(String zhuangt) {
		this.zhuangt = zhuangt;
	}

	public String getBeiz() {
		return beiz;
	}

	public void setBeiz(String beiz) {
		this.beiz = beiz;
	}

}
