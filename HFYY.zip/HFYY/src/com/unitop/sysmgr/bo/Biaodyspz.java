package com.unitop.sysmgr.bo;

public class Biaodyspz {
	private String baobbs = null;
	private String yaosbs = null;
	private String yaosmc = null;
	private String yaosbt = null;
	private String yaoslx = null;
	private String shifbt = null;
	private String yaoscd = null;
	private String moyz = null;
	private String xianssx = null;
	private String zhidbs = null;
	
	public String getBaobbs() {
		return baobbs;
	}
	public void setBaobbs(String baobbs) {
		this.baobbs = baobbs;
	}
	public String getMoyz() {
		return moyz;
	}
	public void setMoyz(String moyz) {
		this.moyz = moyz;
	}
	public String getShifbt() {
		return shifbt;
	}
	public void setShifbt(String shifbt) {
		this.shifbt = shifbt;
	}
	public String getXianssx() {
		return xianssx;
	}
	public void setXianssx(String xianssx) {
		this.xianssx = xianssx;
	}
	public String getYaosbs() {
		return yaosbs;
	}
	public void setYaosbs(String yaosbs) {
		this.yaosbs = yaosbs;
	}
	public String getYaosbt() {
		return yaosbt;
	}
	public void setYaosbt(String yaosbt) {
		this.yaosbt = yaosbt;
	}
	public String getYaoscd() {
		return yaoscd;
	}
	public void setYaoscd(String yaoscd) {
		this.yaoscd = yaoscd;
	}
	public String getYaoslx() {
		return yaoslx;
	}
	public void setYaoslx(String yaoslx) {
		this.yaoslx = yaoslx;
	}
	public String getYaosmc() {
		return yaosmc;
	}
	public void setYaosmc(String yaosmc) {
		this.yaosmc = yaosmc;
	}
	public String getZhidbs() {
		return zhidbs;
	}
	public void setZhidbs(String zhidbs) {
		this.zhidbs = zhidbs;
	}
	
}
