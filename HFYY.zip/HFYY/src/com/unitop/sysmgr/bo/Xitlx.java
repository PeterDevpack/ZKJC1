package com.unitop.sysmgr.bo;

public class Xitlx {
	
	private String xitlx = "";
	private String beiz = "";
	private String shifqy = "";

	public String getXitlx() {
		return xitlx;
	}

	public void setXitlx(String xitlx) {
		this.xitlx = xitlx;
	}

	public String getBeiz() {
		return beiz;
	}

	public void setBeiz(String beiz) {
		this.beiz = beiz;
	}

	public String getShifqy() {
		return shifqy;
	}

	public void setShifqy(String shifqy) {
		this.shifqy = shifqy;
	}
}
