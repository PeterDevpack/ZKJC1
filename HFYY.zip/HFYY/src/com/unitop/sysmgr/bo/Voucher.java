package com.unitop.sysmgr.bo;

public class Voucher implements java.io.Serializable{

	private String pingzbs;
	private String pingzmc;
	private String yanyjb;
	private String shifqy;
	private String pingzhqz;
	private Integer meibzs;
	private String shifzk;
	private String jigh;

	public String getPingzbs() {
		return this.pingzbs;
	}

	public void setPingzbs(String pingzbs) {
		this.pingzbs = pingzbs;
	}

	public String getPingzmc() {
		return this.pingzmc;
	}

	public void setPingzmc(String pingzmc) {
		this.pingzmc = pingzmc;
	}

	public String getYanyjb() {
		return this.yanyjb;
	}

	public void setYanyjb(String yanyjb) {
		this.yanyjb = yanyjb;
	}

	public String getShifqy() {
		return this.shifqy;
	}

	public void setShifqy(String shifqy) {
		this.shifqy = shifqy;
	}

	public String getPingzhqz() {
		return this.pingzhqz;
	}

	public void setPingzhqz(String pingzhqz) {
		this.pingzhqz = pingzhqz;
	}

	public Integer getMeibzs() {
		return this.meibzs;
	}

	public void setMeibzs(Integer meibzs) {
		this.meibzs = meibzs;
	}

	public String getShifzk() {
		return this.shifzk;
	}

	public void setShifzk(String shifzk) {
		this.shifzk = shifzk;
	}

	public String getJigh() {
		return this.jigh;
	}

	public void setJigh(String jigh) {
		this.jigh = jigh;
	}
}
