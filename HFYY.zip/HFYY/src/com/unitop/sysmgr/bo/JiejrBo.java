package com.unitop.sysmgr.bo;

//�ڼ��չ��� ʵ��
public class JiejrBo {
	
	private String year="";//���
	private String month_01 = "";//1��
	private String month_02 = "";//2��
	private String month_03 = "";//3��
	private String month_04 = "";//4��
	private String month_05 = "";//5��
	private String month_06 = "";//6��
	private String month_07 = "";//7��
	private String month_08 = "";//8��
	private String month_09 = "";//9��
	private String month_10 = "";//10��
	private String month_11 = "";//11��
	private String month_12 = "";//12��
	
	public String getMonthString(){
		return month_01+","+month_02+","+month_03+","+month_04+","+month_05+","+month_06+","+month_07+","+month_08+","+month_09+","+month_10+","+month_11+","+month_12;
	}
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth_01() {
		return month_01;
	}
	public void setMonth_01(String month_01) {
		this.month_01 = month_01;
	}
	public String getMonth_02() {
		return month_02;
	}
	public void setMonth_02(String month_02) {
		this.month_02 = month_02;
	}
	public String getMonth_03() {
		return month_03;
	}
	public void setMonth_03(String month_03) {
		this.month_03 = month_03;
	}
	public String getMonth_04() {
		return month_04;
	}
	public void setMonth_04(String month_04) {
		this.month_04 = month_04;
	}
	public String getMonth_05() {
		return month_05;
	}
	public void setMonth_05(String month_05) {
		this.month_05 = month_05;
	}
	public String getMonth_06() {
		return month_06;
	}
	public void setMonth_06(String month_06) {
		this.month_06 = month_06;
	}
	public String getMonth_07() {
		return month_07;
	}
	public void setMonth_07(String month_07) {
		this.month_07 = month_07;
	}
	public String getMonth_08() {
		return month_08;
	}
	public void setMonth_08(String month_08) {
		this.month_08 = month_08;
	}
	public String getMonth_09() {
		return month_09;
	}
	public void setMonth_09(String month_09) {
		this.month_09 = month_09;
	}
	public String getMonth_10() {
		return month_10;
	}
	public void setMonth_10(String month_10) {
		this.month_10 = month_10;
	}
	public String getMonth_11() {
		return month_11;
	}
	public void setMonth_11(String month_11) {
		this.month_11 = month_11;
	}
	public String getMonth_12() {
		return month_12;
	}
	public void setMonth_12(String month_12) {
		this.month_12 = month_12;
	}
}
