package com.unitop.sysmgr.bo;

public class LogTgl {
	private int  index;
	private String zhangh;
	private String jigh;
	private String leix;
	private String time;
	private String zongs;
	private String zid;
	private String fuz;
	private String reng;
	private String wux;
	private String tonggl;
	
	public String getFuz() {
		return fuz;
	}
	public void setFuz(String fuz) {
		this.fuz = fuz;
	}
	public String getJigh() {
		return jigh;
	}
	public void setJigh(String jigh) {
		this.jigh = jigh;
	}
	public String getLeix() {
		return leix;
	}
	public void setLeix(String leix) {
		this.leix = leix;
	}
	public String getReng() {
		return reng;
	}
	public void setReng(String reng) {
		this.reng = reng;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTonggl() {
		return tonggl;
	}
	public void setTonggl(String tonggl) {
		this.tonggl = tonggl;
	}
	public String getWux() {
		return wux;
	}
	public void setWux(String wux) {
		this.wux = wux;
	}
	public String getZhangh() {
		return zhangh;
	}
	public void setZhangh(String zhangh) {
		this.zhangh = zhangh;
	}
	public String getZid() {
		return zid;
	}
	public void setZid(String zid) {
		this.zid = zid;
	}
	public String getZongs() {
		return zongs;
	}
	public void setZongs(String zongs) {
		this.zongs = zongs;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	 
}
