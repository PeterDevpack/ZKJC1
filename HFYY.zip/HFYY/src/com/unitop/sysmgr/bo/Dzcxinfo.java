package com.unitop.sysmgr.bo;

public class Dzcxinfo {

	private String id="";
	private String sql="";
	private String statue="";
	private String isdownload="";
	private String cj_time="";
	private String error="";
	private String clerknum="";
	private String wc_time="";
	private String xz_time="";
	private String description ="";
	public String getCj_time() {
		return cj_time;
	}
	public void setCj_time(String cj_time) {
		this.cj_time = cj_time;
	}
	public String getClerknum() {
		return clerknum;
	}
	public void setClerknum(String clerknum) {
		this.clerknum = clerknum;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIsdownload() {
		return isdownload;
	}
	public void setIsdownload(String isdownload) {
		this.isdownload = isdownload;
	}
	public String getSql() {
		return sql;
	}
	public void setSql(String sql) {
		this.sql = sql;
	}
	public String getStatue() {
		return statue;
	}
	public void setStatue(String statue) {
		this.statue = statue;
	}
	public String getWc_time() {
		return wc_time;
	}
	public void setWc_time(String wc_time) {
		this.wc_time = wc_time;
	}
	public String getXz_time() {
		return xz_time;
	}
	public void setXz_time(String xz_time) {
		this.xz_time = xz_time;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
