package com.unitop.sysmgr.bo;

public class Pilyy {
	private String tuplj;
	private String zhangh;
	private String	weitgyy;
	private String jieg;
	private String id;
	private String jine;
	private String riq;
	private String pingzh;
	private String pingzlx;
	
	
	public String getRiq() {
		return riq;
	}
	public void setRiq(String riq) {
		this.riq = riq;
	}
	public String getPingzh() {
		return pingzh;
	}
	public void setPingzh(String pingzh) {
		this.pingzh = pingzh;
	}
	public String getPingzlx() {
		return pingzlx;
	}
	public void setPingzlx(String pingzlx) {
		this.pingzlx = pingzlx;
	}
	public String getJine() {
		return jine;
	}
	public void setJine(String jine) {
		this.jine = jine;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getJieg() {
		return jieg;
	}
	public void setJieg(String jieg) {
		this.jieg = jieg;
	}
	public String getTuplj() {
		return tuplj;
	}
	public void setTuplj(String tuplj) {
		this.tuplj = tuplj;
	}
	public String getZhangh() {
		return zhangh;
	}
	public void setZhangh(String zhangh) {
		this.zhangh = zhangh;
	}
	public String getWeitgyy() {
		return weitgyy;
	}
	public void setWeitgyy(String weitgyy) {
		this.weitgyy = weitgyy;
	}
	
	
	
}
