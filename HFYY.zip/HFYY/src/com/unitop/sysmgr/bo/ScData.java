package com.unitop.sysmgr.bo;

public class ScData {
	private String zhangh;//�ʺ�	
	private String zhangh_;//h��ȡӡ����Ϣ�ʺ�
	private String kehh;
	private String hum;
	private String jigh;
	private String diz;
	private String youzbm;
	private String lianxr;
	private String dianh;
	private String kaihrq;
	private String tongctd;
	private String huobh;
	private String youwyj;
	private String youwzh;
	private String yinjshzt;
	private String zhanghshzt;
	private String zuhshzt;
	private String zhanghzt;
	private String beiz;
	private String zhanghxz;
	
	public String getZhanghxz() {
		return zhanghxz;
	}
	public void setZhanghxz(String zhanghxz) {
		this.zhanghxz = zhanghxz;
	}
	public String getZhangh() {
		return zhangh;
	}
	public void setZhangh(String zhangh) {
		this.zhangh = zhangh;
	}
	public String getZhangh_() {
		return zhangh_;
	}
	public void setZhangh_(String zhangh_) {
		this.zhangh_ = zhangh_;
	}
	public String getKehh() {
		return kehh;
	}
	public void setKehh(String kehh) {
		this.kehh = kehh;
	}
	public String getHum() {
		return hum;
	}
	public void setHum(String hum) {
		this.hum = hum;
	}
	public String getJigh() {
		return jigh;
	}
	public void setJigh(String jigh) {
		this.jigh = jigh;
	}
	public String getDiz() {
		return diz;
	}
	public void setDiz(String diz) {
		this.diz = diz;
	}
	public String getYouzbm() {
		return youzbm;
	}
	public void setYouzbm(String youzbm) {
		this.youzbm = youzbm;
	}
	public String getLianxr() {
		return lianxr;
	}
	public void setLianxr(String lianxr) {
		this.lianxr = lianxr;
	}
	public String getDianh() {
		return dianh;
	}
	public void setDianh(String dianh) {
		this.dianh = dianh;
	}
	public String getKaihrq() {
		return kaihrq;
	}
	public void setKaihrq(String kaihrq) {
		this.kaihrq = kaihrq;
	}
	public String getTongctd() {
		return tongctd;
	}
	public void setTongctd(String tongctd) {
		this.tongctd = tongctd;
	}
	public String getHuobh() {
		return huobh;
	}
	public void setHuobh(String huobh) {
		this.huobh = huobh;
	}
	public String getYouwyj() {
		return youwyj;
	}
	public void setYouwyj(String youwyj) {
		this.youwyj = youwyj;
	}
	public String getYouwzh() {
		return youwzh;
	}
	public void setYouwzh(String youwzh) {
		this.youwzh = youwzh;
	}
	public String getYinjshzt() {
		return yinjshzt;
	}
	public void setYinjshzt(String yinjshzt) {
		this.yinjshzt = yinjshzt;
	}
	public String getZhanghshzt() {
		return zhanghshzt;
	}
	public void setZhanghshzt(String zhanghshzt) {
		this.zhanghshzt = zhanghshzt;
	}
	public String getZuhshzt() {
		return zuhshzt;
	}
	public void setZuhshzt(String zuhshzt) {
		this.zuhshzt = zuhshzt;
	}
	public String getZhanghzt() {
		return zhanghzt;
	}
	public void setZhanghzt(String zhanghzt) {
		this.zhanghzt = zhanghzt;
	}
	public String getBeiz() {
		return beiz;
	}
	public void setBeiz(String beiz) {
		this.beiz = beiz;
	}
	
}
