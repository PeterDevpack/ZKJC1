package com.unitop.sysmgr.bo;

public class Pingzcshz {
	
	private String pich = "";//���κ�
	
	private String jigh ="";//������
	
	private String zhangh = "";//�˺�
	
	private String hum = "";//����
	
	private String pingzlx = "";//ƾ֤����
	
	private String qispzh="";//��ʼƾ֤��
	
	private String zhongzpzh="";//��ֹƾ֤��
	
	private Integer bens = 0;//��ӡ����
	
	private Integer zhangs = 0;//��ӡ����
	
	private String guiyh = "";//��Ա��
	
	private String riq = "";//����
	
	private String shij = "";//ʱ��
	
	private String zhuangt = "";//״̬
	
	public void setBens(Integer bens) {
		this.bens = bens;
	}
	
	public Integer getBens() {
		return bens;
	}
	
	public void setGuiyh(String guiyh) {
		this.guiyh = guiyh;
	}
	
	public String getGuiyh() {
		return guiyh;
	}
	
	public void setHum(String hum) {
		this.hum = hum;
	}
	
	public String getHum() {
		return hum;
	}
	
	public void setJigh(String jigh) {
		this.jigh = jigh;
	}
	
	public String getJigh() {
		return jigh;
	}
	
	public void setPich(String pich) {
		this.pich = pich;
	}
	
	public String getPich() {
		return pich;
	}
	
	public void setPingzlx(String pingzlx) {
		this.pingzlx = pingzlx;
	}
	
	public String getPingzlx() {
		return pingzlx;
	}
	
	public void setQispzh(String qispzh) {
		this.qispzh = qispzh;
	}
	
	public String getQispzh() {
		return qispzh;
	}
	
	public void setRiq(String riq) {
		this.riq = riq;
	}
	
	public String getRiq() {
		return riq;
	}
	
	public void setShij(String shij) {
		this.shij = shij;
	}
	
	public String getShij() {
		return shij;
	}
	
	public void setZhangh(String zhangh) {
		this.zhangh = zhangh;
	}
	
	public String getZhangh() {
		return zhangh;
	}
	
	public void setZhangs(Integer zhangs) {
		this.zhangs = zhangs;
	}
	
	public Integer getZhangs() {
		return zhangs;
	}
	
	public void setZhongzpzh(String zhongzpzh) {
		this.zhongzpzh = zhongzpzh;
	}
	
	public String getZhongzpzh() {
		return zhongzpzh;
	}
	
	public void setZhuangt(String zhuangt) {
		this.zhuangt = zhuangt;
	}
	
	public String getZhuangt() {
		return zhuangt;
	}
	
}
