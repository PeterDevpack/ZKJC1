package com.unitop.sysmgr.bo;

public class Danzrz {
	private DanzrzId id;
	private String ip;
	private String clerknum;
	private String clerkorgcode;
	private String clerkname;
	private String checkresult;
	private String checkmode;
	private String upflag;
	private String yinjbgh;
	private String yanybj;
	private String zhuzh;
	//V3.0����
	private String yanyzh;
	private String yanypcrq;
	private int hengxzb;
	private int shuxzb;
	private int yinzjd;
	private int yanyjb;
	private String pingzbsm;
	private String qiyrq;

	public int getHengxzb() {
		return hengxzb;
	}
	public void setHengxzb(int hengxzb) {
		this.hengxzb = hengxzb;
	}
	public int getShuxzb() {
		return shuxzb;
	}
	public void setShuxzb(int shuxzb) {
		this.shuxzb = shuxzb;
	}
	public int getYinzjd() {
		return yinzjd;
	}
	public void setYinzjd(int yinzjd) {
		this.yinzjd = yinzjd;
	}
	public int getYanyjb() {
		return yanyjb;
	}
	public void setYanyjb(int yanyjb) {
		this.yanyjb = yanyjb;
	}
	
	public String getYanyzh() {
		return yanyzh;
	}
	public void setYanyzh(String yanyzh) {
		this.yanyzh = yanyzh;
	}
	public String getYanypcrq() {
		return yanypcrq;
	}
	public void setYanypcrq(String yanypcrq) {
		this.yanypcrq = yanypcrq;
	}
	public String getPingzbsm() {
		return pingzbsm;
	}
	public void setPingzbsm(String pingzbsm) {
		this.pingzbsm = pingzbsm;
	}
	public String getClerkorgcode() {
		return clerkorgcode;
	}
	public void setClerkorgcode(String clerkorgcode) {
		this.clerkorgcode = clerkorgcode;
	}
	public DanzrzId getId() {
		return id;
	}
	public void setId(DanzrzId id) {
		this.id = id;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getClerknum() {
		return clerknum;
	}
	public void setClerknum(String clerknum) {
		this.clerknum = clerknum;
	}
	public String getClerkname() {
		return clerkname;
	}
	public void setClerkname(String clerkname) {
		this.clerkname = clerkname;
	}
	public String getCheckresult() {
		return checkresult;
	}
	public void setCheckresult(String checkresult) {
		this.checkresult = checkresult;
	}
	public String getCheckmode() {
		return checkmode;
	}
	public void setCheckmode(String checkmode) {
		this.checkmode = checkmode;
	}
	public String getUpflag() {
		return upflag;
	}
	public void setUpflag(String upflag) {
		this.upflag = upflag;
	}
	public String getYinjbgh() {
		return yinjbgh;
	}
	public void setYinjbgh(String yinjbgh) {
		this.yinjbgh = yinjbgh;
	}
	public String getYanybj() {
		return yanybj;
	}
	public void setYanybj(String yanybj) {
		this.yanybj = yanybj;
	}
	public String getZhuzh() {
		return zhuzh;
	}
	public void setZhuzh(String zhuzh) {
		this.zhuzh = zhuzh;
	}
	public void setQiyrq(String qiyrq) {
		this.qiyrq = qiyrq;
	}
	public String getQiyrq() {
		return qiyrq;
	}
}
