package com.unitop.sysmgr.bo;

import java.io.Serializable;

public class OrgPassRate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7775727318482851597L;

	private String jigh;
	
	private String leix;
	
	private String shangjjgh;

	private String riqfw;
	
	private Double zongs;
	
	private Double zid;
	
	private Double fuz;
	
	private Double reng;
	
	private Double wux;
	
	private Double tonggl;
	
	/**
	 * @return the zongs
	 */
	public Double getZongs() {
		return zongs;
	}

	/**
	 * @param zongs the zongs to set
	 */
	public void setZongs(Double zongs) {
		this.zongs = zongs;
	}

	/**
	 * @return the zid
	 */
	public Double getZid() {
		return zid;
	}

	/**
	 * @param zid the zid to set
	 */
	public void setZid(Double zid) {
		this.zid = zid;
	}

	/**
	 * @return the fuz
	 */
	public Double getFuz() {
		return fuz;
	}

	/**
	 * @param fuz the fuz to set
	 */
	public void setFuz(Double fuz) {
		this.fuz = fuz;
	}

	/**
	 * @return the reng
	 */
	public Double getReng() {
		return reng;
	}

	/**
	 * @param reng the reng to set
	 */
	public void setReng(Double reng) {
		this.reng = reng;
	}

	/**
	 * @return the wux
	 */
	public Double getWux() {
		return wux;
	}

	/**
	 * @param wux the wux to set
	 */
	public void setWux(Double wux) {
		this.wux = wux;
	}

	/**
	 * @return the tonggl
	 */
	public Double getTonggl() {
		return tonggl;
	}

	/**
	 * @param tonggl the tonggl to set
	 */
	public void setTonggl(Double tonggl) {
		this.tonggl = tonggl;
	}

	/**
	 * @return the jigh
	 */
	public String getJigh() {
		return jigh;
	}

	/**
	 * @param jigh the jigh to set
	 */
	public void setJigh(String jigh) {
		this.jigh = jigh;
	}

	/**
	 * @return the leix
	 */
	public String getLeix() {
		return leix;
	}

	/**
	 * @param leix the leix to set
	 */
	public void setLeix(String leix) {
		this.leix = leix;
	}

	/**
	 * @return the shangjjgh
	 */
	public String getShangjjgh() {
		return shangjjgh;
	}

	/**
	 * @param shangjjgh the shangjjgh to set
	 */
	public void setShangjjgh(String shangjjgh) {
		this.shangjjgh = shangjjgh;
	}

	/**
	 * @return the riqfw
	 */
	public String getRiqfw() {
		return riqfw;
	}

	/**
	 * @param riqfw the riqfw to set
	 */
	public void setRiqfw(String riqfw) {
		this.riqfw = riqfw;
	}

	
}

