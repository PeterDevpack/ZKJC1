package com.unitop.sysmgr.bo;

import java.io.Serializable;

public class Org implements Serializable {

	private static final long serialVersionUID = -4942397894039134471L;

	private String code;

	private String name;
	
	private String parentCode;

	private String paymentCode;
	
	private String wdflag;
	
	private String shOrgCode;
	
	private String tctd;
	
	private String guanljg;
	
	private String zhiszh;
	
	

	public String getZhiszh() {
		return zhiszh;
	}

	public void setZhiszh(String zhiszh) {
		this.zhiszh = zhiszh;
	}

	public String getGuanljg() {
		return guanljg;
	}

	public void setGuanljg(String guanljg) {
		this.guanljg = guanljg;
	}

	public String getPaymentCode() {
		return paymentCode;
	}

	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getParentCode() {
		return parentCode;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

	public String getWdflag() {
		return wdflag;
	}

	public void setWdflag(String wdflag) {
		this.wdflag = wdflag;
	}

	public String getShOrgCode() {
		return shOrgCode;
	}

	public void setShOrgCode(String shOrgCode) {
		this.shOrgCode = shOrgCode;
	}

	public String getTctd() {
		return tctd;
	}

	public void setTctd(String tctd) {
		this.tctd = tctd;
	}

	@Override
	public String toString() {
		return "Org [code=" + code + ", name=" + name + ", parentCode="
				+ parentCode + ", paymentCode=" + paymentCode + ", wdflag="
				+ wdflag + ", shOrgCode=" + shOrgCode + ", tctd=" + tctd
				+ ", guanljg=" + guanljg + ", zhiszh=" + zhiszh + "]";
	}

	
}
