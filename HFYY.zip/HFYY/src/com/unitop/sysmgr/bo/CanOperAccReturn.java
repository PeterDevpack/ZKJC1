package com.unitop.sysmgr.bo;

public class CanOperAccReturn {
	private boolean ReturnValue = false;
	private String ReturnMessage = "";
	
	public boolean getReturnValue() {
		return ReturnValue;
	}
	public void setReturnValue(boolean returnValue) {
		ReturnValue = returnValue;
	}
	public String getReturnMessage() {
		return ReturnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		ReturnMessage = returnMessage;
	}
}
