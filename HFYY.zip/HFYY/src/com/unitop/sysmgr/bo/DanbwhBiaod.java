package com.unitop.sysmgr.bo;

public class DanbwhBiaod {
	
	public UnionBiaod id;
	
	public String zhansmc;
	
	public String zidlx;
	
	public String shurlx;
	
	public String quzfw;
	
	public String morz;
	
	public String jiaoygz;
	
	public String shifbc;
	
	public String shifbj;
	
	public String shifzj;
	
	public String xianssx;
	
	public String beiz;

	public String getBeiz() {
		return beiz;
	}

	public void setBeiz(String beiz) {
		this.beiz = beiz;
	}

	public String getXianssx() {
		return xianssx;
	}

	public void setXianssx(String xianssx) {
		this.xianssx = xianssx;
	}

	public String getZhansmc() {
		return zhansmc;
	}

	public void setZhansmc(String zhansmc) {
		this.zhansmc = zhansmc;
	}

	public UnionBiaod getId() {
		return id;
	}

	public void setId(UnionBiaod id) {
		this.id = id;
	}

	public String getZidlx() {
		return zidlx;
	}

	public void setZidlx(String zidlx) {
		this.zidlx = zidlx;
	}

	public String getShurlx() {
		return shurlx;
	}

	public void setShurlx(String shurlx) {
		this.shurlx = shurlx;
	}

	public String getQuzfw() {
		return quzfw;
	}

	public void setQuzfw(String quzfw) {
		this.quzfw = quzfw;
	}

	public String getMorz() {
		return morz;
	}

	public void setMorz(String morz) {
		this.morz = morz;
	}

	public String getJiaoygz() {
		return jiaoygz;
	}

	public void setJiaoygz(String jiaoygz) {
		this.jiaoygz = jiaoygz;
	}

	public String getShifbc() {
		return shifbc;
	}

	public void setShifbc(String shifbc) {
		this.shifbc = (shifbc);
	}

	public String getShifbj() {
		return shifbj;
	}

	public void setShifbj(String shifbj) {
		this.shifbj = (shifbj);
	}

	public String getShifzj() {
		return shifzj;
	}

	public void setShifzj(String shifzj) {
		this.shifzj =  (shifzj);
	}
	
	

}
