package com.unitop.sysmgr.bo;

public class Zhidpz {
	private String zhidbs =null ;
	private String suoyz = null ;
	private String zhuanhz = null ;
	public String getSuoyz() {
		return suoyz;
	}
	public void setSuoyz(String suoyz) {
		this.suoyz = suoyz;
	}
	public String getZhidbs() {
		return zhidbs;
	}
	public void setZhidbs(String zhidbs) {
		this.zhidbs = zhidbs;
	}
	public String getZhuanhz() {
		return zhuanhz;
	}
	public void setZhuanhz(String zhuanhz) {
		this.zhuanhz = zhuanhz;
	}
	
}
