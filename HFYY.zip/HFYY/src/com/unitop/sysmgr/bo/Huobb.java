package com.unitop.sysmgr.bo;

public class Huobb {
	
	private String huobbh;
	private String huobmc;
	private String beiz;
	
	public String getHuobbh() {
		return huobbh;
	}
	public void setHuobbh(String huobbh) {
		this.huobbh = huobbh;
	}
	public String getHuobmc() {
		return huobmc;
	}
	public void setHuobmc(String huobmc) {
		this.huobmc = huobmc;
	}
	public String getBeiz() {
		return beiz;
	}
	public void setBeiz(String beiz) {
		this.beiz = beiz;
	}
}