package com.unitop.sysmgr.bo;

public class Pingzcszzrz {
	private String pingzh;//ƾ֤��
	private String guiyh;//��Ա��
	private String riq;//����
	private String shij;//ʱ��
	private String caoz;//����
	public String getPingzh() {
		return pingzh;
	}
	public void setPingzh(String pingzh) {
		this.pingzh = pingzh;
	}
	public String getGuiyh() {
		return guiyh;
	}
	public void setGuiyh(String guiyh) {
		this.guiyh = guiyh;
	}
	public String getRiq() {
		return riq;
	}
	public void setRiq(String riq) {
		this.riq = riq;
	}
	public String getShij() {
		return shij;
	}
	public void setShij(String shij) {
		this.shij = shij;
	}
	public String getCaoz() {
		return caoz;
	}
	public void setCaoz(String caoz) {
		this.caoz = caoz;
	}
	
	
}
