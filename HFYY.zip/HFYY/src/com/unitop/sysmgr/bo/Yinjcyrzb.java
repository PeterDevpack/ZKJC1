package com.unitop.sysmgr.bo;

import java.io.Serializable;

/**
 * ���--ӡ�����Ĺ��ܵ���־ʵ��
 * @author BBBBBBao
 *
 */

public class Yinjcyrzb implements Serializable {
	
	
	private String id;
	private String jigouhao ;
	private String jigoumc ;
	private String yinjbh ;
	private String guiymz ;
	private String guiyh ;
	private String chaxrq ;
	private String chaxtime ;
	private String beiz ;
	
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getJigouhao() {
		return jigouhao;
	}
	public void setJigouhao(String jigouhao) {
		this.jigouhao = jigouhao;
	}
	public String getJigoumc() {
		return jigoumc;
	}
	public void setJigoumc(String jigoumc) {
		this.jigoumc = jigoumc;
	}
	public String getYinjbh() {
		return yinjbh;
	}
	public void setYinjbh(String yinjbh) {
		this.yinjbh = yinjbh;
	}
	public String getGuiymz() {
		return guiymz;
	}
	public void setGuiymz(String guiymz) {
		this.guiymz = guiymz;
	}
	public String getGuiyh() {
		return guiyh;
	}
	public void setGuiyh(String guiyh) {
		this.guiyh = guiyh;
	}
	public String getChaxrq() {
		return chaxrq;
	}
	public void setChaxrq(String chaxrq) {
		this.chaxrq = chaxrq;
	}
	public String getChaxtime() {
		return chaxtime;
	}
	public void setChaxtime(String chaxtime) {
		this.chaxtime = chaxtime;
	}
	public String getBeiz() {
		return beiz;
	}
	public void setBeiz(String beiz) {
		this.beiz = beiz;
	}
	
	
	
}
