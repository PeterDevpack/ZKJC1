package com.unitop.sysmgr.bo;

import oracle.sql.BLOB;

public class Baobpz {
	String baobbs=null;
	String baobmc=null;
	String baobbt=null;
	String shifky=null;
	String shiffy=null;
	String fenytj;
	String shifdy=null;
	BLOB dayfa=null;
	String shifsc=null;
	BLOB shucfa=null;
	String shujhqfs=null;
	public String getBaobbs() {
		return baobbs;
	}
	public void setBaobbs(String baobbs) {
		this.baobbs = baobbs;
	}
	public String getBaobbt() {
		return baobbt;
	}
	public void setBaobbt(String baobbt) {
		this.baobbt = baobbt;
	}
	public String getBaobmc() {
		return baobmc;
	}
	public void setBaobmc(String baobmc) {
		this.baobmc = baobmc;
	}
	public BLOB getDayfa() {
		return dayfa;
	}
	public void setDayfa(BLOB dayfa) {
		this.dayfa = dayfa;
	}
	public String getFenytj() {
		return fenytj;
	}
	public void setFenytj(String fenytj) {
		this.fenytj = fenytj;
	}
	public String getShifdy() {
		return shifdy;
	}
	public void setShifdy(String shifdy) {
		this.shifdy = shifdy;
	}
	public String getShiffy() {
		return shiffy;
	}
	public void setShiffy(String shiffy) {
		this.shiffy = shiffy;
	}
	public String getShifky() {
		return shifky;
	}
	public void setShifky(String shifky) {
		this.shifky = shifky;
	}
	public String getShifsc() {
		return shifsc;
	}
	public void setShifsc(String shifsc) {
		this.shifsc = shifsc;
	}
	public BLOB getShucfa() {
		return shucfa;
	}
	public void setShucfa(BLOB shucfa) {
		this.shucfa = shucfa;
	}
	public String getShujhqfs() {
		return shujhqfs;
	}
	public void setShujhqfs(String shujhqfs) {
		this.shujhqfs = shujhqfs;
	}
}
