package com.unitop.sysmgr.bo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


/**
 * @author BBBBBBao
 *
 */
public class Usermanage implements Serializable {

	private static final long serialVersionUID = -5800698776555800275L;
	
	private String id;			//
	private String jigouhao;	//
	private String jigouname;	//
	private String userjues;	//�û���   ��ɫ
	private String userid;		//�û�ID
	private String username;	//�û���
	private String maintenance;	//ά����ʽ������/�޸�/ɾ����
	private String chaxrq;		//ά������
	private String chaxtime;	//ά��ʱ��
	private String clerkcode;	//������Աid
	private String clerkname;	//������Ա����
	private String beiz;		//
	
	
	
	
	public String getUserjues() {
		return userjues;
	}
	public void setUserjues(String userjues) {
		this.userjues = userjues;
	}
	public String getClerkname() {
		return clerkname;
	}
	public void setClerkname(String clerkname) {
		this.clerkname = clerkname;
	}
	public String getClerkcode() {
		return clerkcode;
	}
	public void setClerkcode(String clerkcode) {
		this.clerkcode = clerkcode;
	}
	
	public String getMaintenance() {
		return maintenance;
	}
	public void setMaintenance(String maintenance) {
		this.maintenance = maintenance;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBeiz() {
		return beiz;
	}
	public void setBeiz(String beiz) {
		this.beiz = beiz;
	}
	public String getJigouhao() {
		return jigouhao;
	}
	public void setJigouhao(String jigouhao) {
		this.jigouhao = jigouhao;
	}
	public String getJigouname() {
		return jigouname;
	}
	public void setJigouname(String jigouname) {
		this.jigouname = jigouname;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getChaxrq() {
		return chaxrq;
	}
	public void setChaxrq(String chaxrq) {
		this.chaxrq = chaxrq;
	}
	public String getChaxtime() {
		return chaxtime;
	}
	public void setChaxtime(String chaxtime) {
		this.chaxtime = chaxtime;
	}
	@Override
	public String toString() {
		return "Usermanage [id=" + id + ", jigouhao=" + jigouhao
				+ ", jigouname=" + jigouname + ", userjues=" + userjues
				+ ", userid=" + userid + ", username=" + username
				+ ", maintenance=" + maintenance + ", chaxrq=" + chaxrq
				+ ", chaxtime=" + chaxtime + ", clerkcode=" + clerkcode
				+ ", clerkname=" + clerkname + ", beiz=" + beiz + "]";
	}

	
	
	
	
	

}
