package com.unitop.sysmgr.bo;

public class Jiegyspz {
	private String baobbs = null ;
	private String yaosbs = null ;
	private String yaosbt = null ;
	private String yaoscd = null ;
	private String xianslx = null ;
	private String shifxs = null ;
	private String xianssx = null ;
	private String zhidbs = null ;
	public String getBaobbs() {
		return baobbs;
	}
	public void setBaobbs(String baobbs) {
		this.baobbs = baobbs;
	}
	public String getShifxs() {
		return shifxs;
	}
	public void setShifxs(String shifxs) {
		this.shifxs = shifxs;
	}
	public String getXianslx() {
		return xianslx;
	}
	public void setXianslx(String xianslx) {
		this.xianslx = xianslx;
	}
	public String getXianssx() {
		return xianssx;
	}
	public void setXianssx(String xianssx) {
		this.xianssx = xianssx;
	}
	public String getYaosbs() {
		return yaosbs;
	}
	public void setYaosbs(String yaosbs) {
		this.yaosbs = yaosbs;
	}
	public String getYaosbt() {
		return yaosbt;
	}
	public void setYaosbt(String yaosbt) {
		this.yaosbt = yaosbt;
	}
	public String getYaoscd() {
		return yaoscd;
	}
	public void setYaoscd(String yaoscd) {
		this.yaoscd = yaoscd;
	}
	public String getZhidbs() {
		return zhidbs;
	}
	public void setZhidbs(String zhidbs) {
		this.zhidbs = zhidbs;
	}
	
}
