package com.unitop.sysmgr.bo;

/**
 * Pingzyjlxgxb entity. @author MyEclipse Persistence Tools
 */

public class Pingzyjlxgxb implements java.io.Serializable {

	// Fields

	private PingzyjlxgxbId id;

	// Constructors

	/** default constructor */
	public Pingzyjlxgxb() {
	}

	/** full constructor */
	public Pingzyjlxgxb(PingzyjlxgxbId id) {
		this.id = id;
	}

	// Property accessors

	public PingzyjlxgxbId getId() {
		return this.id;
	}

	public void setId(PingzyjlxgxbId id) {
		this.id = id;
	}

}