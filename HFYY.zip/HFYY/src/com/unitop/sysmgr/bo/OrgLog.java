package com.unitop.sysmgr.bo;

import java.io.Serializable;

public class OrgLog implements Serializable {

	private static final long serialVersionUID = -4942397894039134471L;
	
	private String clerkName;
	
	private String clerkNum;
	
	private String operateType;
	
	private String operateContent;
	
	private String operateDate;
	
	private String oldOrgnum;
	
	private String newOrgnum;
	
	private String oldOrgname;
	
	private String newOrgname;

	private String clerkOrg;
	
	
	public String getClerkOrg() {
		return clerkOrg;
	}

	public void setClerkOrg(String clerkOrg) {
		this.clerkOrg = clerkOrg;
	}

	public String getClerkName() {
		return clerkName;
	}

	public void setClerkName(String clerkName) {
		this.clerkName = clerkName;
	}

	public String getClerkNum() {
		return clerkNum;
	}

	public void setClerkNum(String clerkNum) {
		this.clerkNum = clerkNum;
	}

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}

	public String getOperateContent() {
		return operateContent;
	}

	public void setOperateContent(String operateContent) {
		this.operateContent = operateContent;
	}

	public String getOperateDate() {
		return operateDate;
	}

	public void setOperateDate(String operateDate) {
		this.operateDate = operateDate;
	}

	public String getOldOrgnum() {
		return oldOrgnum;
	}

	public void setOldOrgnum(String oldOrgnum) {
		this.oldOrgnum = oldOrgnum;
	}

	public String getNewOrgnum() {
		return newOrgnum;
	}

	public void setNewOrgnum(String newOrgnum) {
		this.newOrgnum = newOrgnum;
	}

	public String getOldOrgname() {
		return oldOrgname;
	}

	public void setOldOrgname(String oldOrgname) {
		this.oldOrgname = oldOrgname;
	}

	public String getNewOrgname() {
		return newOrgname;
	}

	public void setNewOrgname(String newOrgname) {
		this.newOrgname = newOrgname;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
