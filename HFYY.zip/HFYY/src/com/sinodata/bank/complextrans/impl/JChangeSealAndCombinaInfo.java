package com.sinodata.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.sinodata.util.JUtils;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;

/**
 * @author Daniel
 * @Date 2013-3-11
 * @Describe ���ӽ���-���\�ؽ������ύ
 */
public class JChangeSealAndCombinaInfo extends BaseTrans {

	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		beginTrans();
		JSONArray jsonArray = new JSONArray(); // ���屾�������ص�json����
		try {
			List<String> childTrade = function.getMutil().getList(); // (��ȡ�ӽ����б�)

			String clearSealInfo = childTrade.get(0);
			String clearCombinaInfo = childTrade.get(1);
			String setSealTingyrq = childTrade.get(2);
			String setCombinaTingyrq = childTrade.get(3);
			String addSealInfo = childTrade.get(4);
			String addCombineInfo = childTrade.get(5);
			String changeUserCheckState = childTrade.get(6);
			String WriteWorkLogToDb = childTrade.get(7);

			boolean hasGUIYXX = datasets.getParamMap().containsKey("GUIYXX");
			boolean hasYINJXX = datasets.getParamMap().containsKey("YINJXX");
			boolean hasZUHXX = datasets.getParamMap().containsKey("ZUHXX");
			boolean hasQIYRQ = datasets.getParamMap().containsKey("QIYRQ");

			List<Map<String, String>> guiyxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> yinjxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> zuhxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> qiyrqObjList = new ArrayList<Map<String, String>>();

			Map<String, String> yinjxxTempMap = new HashMap<String, String>();
			List<Map<String, String>> pyinjxxTempList = new ArrayList<Map<String, String>>();

			Map<String, String> zuhTempMap = new HashMap<String, String>();
			List<Map<String, String>> zuhTempparamList = new ArrayList<Map<String, String>>();

			Map<String, String> n_riqTempMap = new HashMap<String, String>();
			Map<String, String> o_riqTempMap = new HashMap<String, String>();
			List<Map<String, String>> n_riqTempList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> o_riqTempList = new ArrayList<Map<String, String>>();

			//************************************************************
			/*
			 * ��ȡʱ��
			 */
			Map<String, String> tempMap = new HashMap<String, String>();
			tempMap.put(" ", " ");
			List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
			tempList.add(tempMap);
			JSONObject dataObject = new JSONObject();
			dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate", "", tempList, conn);// ִ�н���
			JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
			String sysDate = jsonObjData1.getString("getdate");
			String date = sysDate.substring(0, 10);
			String time = sysDate.substring(11, 19);
			//************************************************************

			if (hasGUIYXX && hasYINJXX && hasQIYRQ) {
				guiyxxObjList = datasets.getParamMap().get("GUIYXX"); // ��Ա��Ϣ
				yinjxxObjList = datasets.getParamMap().get("YINJXX"); // ӡ����Ϣ
				qiyrqObjList = datasets.getParamMap().get("QIYRQ");
				/*
				 * ȡ��һ��ӡ������ȡ��Ҫ�����ݣ�����map�����ӵ�list��
				 */
				Map<String, String> yinjxxMap = yinjxxObjList.get(0);// ����ĵ�һ��ӡ����Ϣ
				String zhangh = yinjxxMap.get("zhangh"); // 
				String yinjshzt = yinjxxMap.get("yinjshzt");
				yinjxxTempMap.put("zhangh", zhangh);
				if("���".equals(guiyxxObjList.get(0).get("caoz"))){
					yinjxxTempMap.put("zhanghshzt","����");
				}else{
					yinjxxTempMap.put("zhanghshzt",yinjshzt);
				}
				yinjxxTempMap.put("yinjshzt", yinjshzt);
				yinjxxTempMap.put("zuhshzt", yinjshzt);
				yinjxxTempMap.put("youwyj", "��");
				pyinjxxTempList.add(yinjxxTempMap);

				Map<String, String> riqMap = qiyrqObjList.get(0);
				String n_qiyrq = riqMap.get("nqiyrq"); // ������մ�������
				String o_qiyrq = riqMap.get("oqiyrq");// ����Ϊ��һ��ӡ������ͣ������

				n_riqTempMap.put("qiyrq", n_qiyrq);
				n_riqTempMap.put("zhangh", zhangh);
				
				o_riqTempMap.put("qiyrq", o_qiyrq);
				o_riqTempMap.put("zhangh", zhangh);
				o_riqTempMap.put("tingyrq", yinjxxObjList.get(0).get("qiyrq"));

				n_riqTempList.add(n_riqTempMap);
				o_riqTempList.add(o_riqTempMap);
			} else {
				throw new UfSealException("���ͱ�����ʵ��[GUIYXX]��[YINJXX]��[QIYRQ]δ����!");
			}
			if (hasZUHXX) {
				zuhxxObjList = datasets.getParamMap().get("ZUHXX"); // �����Ϣ
				/*
				 * ȡ��һ����ϣ���ȡ��Ҫ�����ݣ�����map�����ӵ�list��
				 */
				Map<String, String> zuhxxMap = zuhxxObjList.get(0);
				String zhangh = zuhxxMap.get("zhangh");
				String zuhshzt = zuhxxMap.get("zuhshzt");
				zuhTempMap.put("zhangh", zhangh);
				zuhTempMap.put("zuhshzt", zuhshzt);
				zuhTempparamList.add(zuhTempMap);
			} else {
				// ��ϲ�һ����,û��ϲ����쳣
			}
			List<Map<String, String>> guiyTempList = new ArrayList<Map<String, String>>();
			Map<String, String> guiyTempMap = new HashMap<String, String>();
			guiyTempMap.put("account", yinjxxObjList.get(0).get("zhangh"));
			guiyTempMap.put("managedate", date);
			guiyTempMap.put("managetime", time);
			guiyTempMap.put("managetype", guiyxxObjList.get(0).get("caoz"));
			guiyTempMap.put("clerknum", guiyxxObjList.get(0).get("guiyh"));
			guiyTempMap.put("clerkname", guiyxxObjList.get(0).get("guiym"));
			guiyTempMap.put("ip", guiyxxObjList.get(0).get("ip"));
			guiyTempMap.put("upflag", "");
			guiyTempMap.put("str1", "");
			guiyTempMap.put("str2", "");
			guiyTempMap.put("str3", "");
			guiyTempMap.put("managecontent","");
			guiyTempList.add(guiyTempMap);

			juniDBInterface.execSql(clearSealInfo, n_riqTempList, conn);// ��մ����������ڵ�ӡ����Ϣ
			juniDBInterface.execSql(clearCombinaInfo, n_riqTempList, conn);// ��մ����������ڵ������Ϣ
			juniDBInterface.execSql(setSealTingyrq, o_riqTempList, conn);// ����ӡ��ͣ������
			if (hasZUHXX) {
				juniDBInterface.execSql(setCombinaTingyrq, o_riqTempList, conn);// �������ͣ������
			}
			juniDBInterface.execSql(addSealInfo, yinjxxObjList, conn);// ����ӡ����Ϣ
			if (hasZUHXX) {
				juniDBInterface.execSql(addCombineInfo, zuhxxObjList, conn);// ���������Ϣ
			}
			juniDBInterface.execSql(changeUserCheckState, pyinjxxTempList, conn);// ����û�״̬
			juniDBInterface.execSql(WriteWorkLogToDb, guiyTempList, conn);// ��¼��Ա������־
			
			List<Map<String, String>> kaguiObjList = new ArrayList<Map<String, String>>();
			boolean hasJKWENJXX = datasets.getParamMap().containsKey("JKWENJXX");
			// ����yinjk����kagrw��
			if (hasJKWENJXX) {
				kaguiObjList = datasets.getParamMap().get("JKWENJXX"); // �����ļ���Ϣ��Ϣ
				List<Map<String, String>> kaguiTempList = new ArrayList<Map<String, String>>();
				for (int i = 0; i < kaguiObjList.size(); i++) {
					String strTemp = JUtils.getRandomID();
					Map<String, String> kaguiTempMap = new HashMap<String, String>();
					kaguiTempMap.put("yinjkh", kaguiObjList.get(i).get("yinjkh"));
					kaguiTempMap.put("zhangh", kaguiObjList.get(i).get("zhangh"));
					kaguiTempMap.put("jigh", kaguiObjList.get(i).get("jigh"));
					kaguiTempMap.put("zhengmwjm", kaguiObjList.get(i).get("zhengmwjm"));
					kaguiTempMap.put("fanmwjm", kaguiObjList.get(i).get("fanmwjm"));
					kaguiTempMap.put("qiyrq", kaguiObjList.get(i).get("qiyrq").replace("-", ""));
					kaguiTempMap.put("tingyrq", kaguiObjList.get(i).get("tingyrq").replace("-", ""));
					kaguiTempMap.put("renwbs", strTemp);
					kaguiTempMap.put("renwlx", "0");
					kaguiTempMap.put("yewlx", "1");
					kaguiTempMap.put("renwzt", "0");
					kaguiTempMap.put("yinjks", String.valueOf(kaguiObjList.size()));
					kaguiTempMap.put("shifzk", "1");
					kaguiTempList.add(kaguiTempMap);
				}
				List<Map<String, String>> bsList = new ArrayList<Map<String, String>>();
				Map<String, String> bsMap = new HashMap<String, String>();
				bsMap.put("cansid", "kag_kongzcs");
				bsList.add(bsMap);
				JSONObject kzObject = juniDBInterface.execSql("getKzcs", "", bsList, conn);// ִ�н���
				JSONObject kzObjectTemp = JSONObject.fromObject(kzObject.getJSONArray("objectdata").get(0));
				String value = kzObjectTemp.getString("parametervalue");
				//ϵͳ���������Ƿ���ӡ�����ſ�����
				if("1".equals(value))
				{
					juniDBInterface.execSql("insertKAGRW", kaguiTempList, conn);
					try{
						juniDBInterface.execSql("insertYinjk", kaguiTempList, conn);
					}catch(Exception e){
						juniDBInterface.execSql("updateYinjk", kaguiTempList, conn);
					}
				}
			}
			commit();
		}catch (Exception e) {
			rollback();
			throw e;
		}finally{
			release();
		}
		return jsonArray;
	}

	public String execute(Function function, DataSets datasets) throws Exception {
		return null;
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}
}
