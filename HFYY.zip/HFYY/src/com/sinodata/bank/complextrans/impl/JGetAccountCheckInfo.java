package com.sinodata.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.sinodata.bank.JResponseManager;
import com.sinodata.util.JUtils;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;

/**
 * @author Daniel
 * @Date 2013-3-18
 * @Describe ���Ӳ�ѯ-��ȡ�˻���δ���ӡ������ϡ��˻�������Ϣ�������(v3.0)
 */
public class JGetAccountCheckInfo extends BaseTrans {

	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		JSONArray jsonArray = new JSONArray(); // ���屾�������ص�json����
		try {
			List<String> childTrade = function.getMutil().getList(); // (��ȡ�ӽ����б�)
			//************************************************************
			/*
			 * �����б�
			 */
			String getAccountInfo = childTrade.get(0); // �Ӳ�ѯ1(��ȡ�˻���Ϣ,�����ж��û��Ƿ����),�˴��������Ϊ���ݿ��ж�Ӧ��
			String isZhuzh = childTrade.get(1); // �Ӳ�ѯ2
			String getSatisfySealToVerify = childTrade.get(2); // �Ӳ�ѯ3
			String getSatisfyZuheToVerify = childTrade.get(3); // �Ӳ�ѯ4
			//************************************************************
			
			boolean hasSHENHXX = datasets.getParamMap().containsKey("SHENHXX");
			boolean hasGUIYXX = datasets.getParamMap().containsKey("GUIYXX");
			
			List<Map<String, String>> shenhxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> guiyxxObjList = new ArrayList<Map<String, String>>();
			if(hasSHENHXX && hasGUIYXX) {
				shenhxxObjList = datasets.getParamMap().get("SHENHXX");
				guiyxxObjList = datasets.getParamMap().get("GUIYXX");
			}else {
				throw new UfSealException("���ͱ�����ʵ��[SHENHXX]��[GUIYXX]δ����!");
			}
			
			//************************************************************
			/*
			 * ��ȡʱ��
			 */
			Map<String, String> tempMap = new HashMap<String, String>();
			tempMap.put(" ", " ");
			List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
			tempList.add(tempMap);
			JSONObject dataObject = new JSONObject();
			dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate", "", tempList, conn);// ִ�н���
			JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
			String sysDate = jsonObjData1.getString("getdate");
			String date = sysDate.substring(0, 10);
//			String time = sysDate.substring(10, 16);
			//************************************************************
			
			
			//************************************************************
			/*
			 * ƴ��Ա��ϢList
			 */
			List<Map<String, String>> shenhexxTempList = new ArrayList<Map<String,String>>();
			Map<String, String> shenhxxTempMap = new HashMap<String, String>();
			shenhxxTempMap.put("zhangh", shenhxxObjList.get(0).get("zhangh"));
//			shenhxxTempMap.put("shenhrq", date);
			shenhexxTempList.add(shenhxxTempMap);
			//************************************************************
			
			
			Map<String, String> guiyMap = guiyxxObjList.get(0);// ����Ĺ�Ա��Ϣ
			String guiyOrg = guiyMap.get("guiyjgh"); // ��Ա������
			
			JSONObject childJsonObj1 = new JSONObject();
			JSONObject childJsonObj2 = new JSONObject();
			JSONObject childJsonObj3 = new JSONObject();
			JSONObject childJsonObj4 = new JSONObject();
			
			childJsonObj1 = juniDBInterface.execSql(getAccountInfo, "ZHANGHSHXX", shenhxxObjList, conn);
			boolean isAccountExist = JUtils.isObjDataContainValidData(childJsonObj1); // �жϽ�������Ƿ�������
			if (isAccountExist) {
				JSONObject jsonObjData = JSONObject.fromObject(childJsonObj1.getJSONArray("objectdata").get(0));
				String accountOrg = jsonObjData.getString("jigh"); // �˻�������
				String yinjshzt = jsonObjData.getString("yinjshzt");
				String zhanghzt = jsonObjData.getString("zhanghzt");
				String zhuzh = jsonObjData.getString("zhuzh");//���ʺ�
				if(zhuzh!=null)
				if(!("".equals(zhuzh)))
				{
					JResponseManager.jrResMsgSet(jsonRet, "��֧�����˻����!");
					return jsonArray; 
				}
				
				boolean isSatisfyJigh = this.isSatisfyJigh(accountOrg, guiyOrg);//�жϹ�Ա�Ƿ��в������˻���Ȩ��
				if(isSatisfyJigh) {
					if ("����".equals(yinjshzt)){
						JResponseManager.jrResMsgSet(jsonRet, "���˻������!");
					}else if("δ��".equals(yinjshzt)){
						if ("��Ч".equals(zhanghzt)) {
							childJsonObj2 =  juniDBInterface.execSql(isZhuzh, "", shenhxxObjList, conn);
							boolean isZhuzhBoolean = JUtils.isObjDataContainValidData(childJsonObj2);
							if (isZhuzhBoolean) {
								childJsonObj3 = juniDBInterface.execSql(getSatisfySealToVerify, "YINJSHXX", shenhexxTempList, conn);
								boolean isExistSatisfySeal = JUtils.isObjDataContainValidData(childJsonObj3);
								if (isExistSatisfySeal) {
									jsonArray.add(childJsonObj1);
									jsonArray.add(childJsonObj3);
									childJsonObj4 = juniDBInterface.execSql(getSatisfyZuheToVerify, "ZUHSHXX", shenhexxTempList, conn);
									jsonArray.add(childJsonObj4);
								}else {
									JResponseManager.jrResMsgSet(jsonRet, "��ӡ���ɹ����!");
								}
							}else {
								JResponseManager.jrResMsgSet(jsonRet, "���˻�Ϊ���ʺ�!");
							}
						}else {
							JResponseManager.jrResMsgSet(jsonRet, "���˻�������Ч�˻�!");
						}
					}else {
						if("".equals(yinjshzt)||yinjshzt==null)
						{
							JResponseManager.jrResMsgSet(jsonRet, "�˻���û�н���ӡ���������!");
							return jsonArray;
						}
						//�������״̬
					}
				}else {
					//�޸� WF Ҫ���޸� 20140411
					JResponseManager.jrResMsgSet(jsonRet, "û��Ȩ�޲������˻�!");
				}
			}else {
				JResponseManager.jrResMsgSet(jsonRet, "�޴��˻�!");
			}
		}catch (Exception e) {
//			e.printStackTrace();
			throw e;
		}finally{
			release();
		}
		return jsonArray;
	}
	
	/**
	 * 
	 * @param accountOrg �˻�������
	 * @param clerkOrg ��Ա������
	 * @return ��Ա�Ƿ��в������˻���Ȩ��
	 * @throws Exception
	 */
	private boolean isSatisfyJigh(String accountOrg, String clerkOrg) throws Exception {
		JSONObject tempObj = new JSONObject();
		Map<String, String> tempMap = new HashMap<String, String>();
		tempMap.put("guiyjgh", clerkOrg);
		tempMap.put("jigh", accountOrg);
		List<Map<String, String>> paramList = new ArrayList<Map<String, String>>();
		paramList.add(tempMap);
		tempObj = juniDBInterface.execSql("JudgeAccountOrgBelongToGuiyOrg", "", paramList, conn);
		boolean isAccountOrgBelongToGuiyOrg = JUtils.isObjDataContainValidData(tempObj);
		return isAccountOrgBelongToGuiyOrg;
	}
	
	public String execute(Function function, DataSets datasets) throws Exception {
		return null;
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

}
