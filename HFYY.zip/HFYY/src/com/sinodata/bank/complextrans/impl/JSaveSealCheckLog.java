package com.sinodata.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

//import com.sinodata.common.sequence.SequenceObtain;
import com.sinodata.util.JUtils;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;

/**
 * @author Daniel
 * @Date 2013-3-18
 * @Describe ���ӽ���-�ύ��ӡ��־(v3.0)
 */
//@Service("jsaveSealCheckLog")
public class JSaveSealCheckLog extends BaseTrans {
	//����begin
	private String sequenceNum="";//��ˮ��
	//end
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		beginTrans();
		//sequenceNum=SequenceObtain.getSequenceUUID();
		JSONArray jsonArray = new JSONArray(); // ���屾�������ص�json����
		try {
			//�滻�����ַ�
			String id = JUtils.getRandomID().replace("+", "Z").replace("-", "z");
			List<String> childTrade = function.getMutil().getList(); // (��ȡ�ӽ����б�)

			String WriteZhengpyylogToDb = childTrade.get(0); // �����˻���Ϣ(�ӽ���1)
			String WriteYulyjyylogToDb = childTrade.get(1); // �޸��˻���Ϣ(�ӽ���2)
			String WriteWorkLogToDb = childTrade.get(2); // ��¼��Ա������־(�ӽ���3)

			boolean hasPIAOJYYJGXX = datasets.getParamMap().containsKey("PIAOJYYJGXX");
			boolean hasYINJYYJGXX = datasets.getParamMap().containsKey("YINJYYJGXX");
			boolean hasGUIYXX = datasets.getParamMap().containsKey("GUIYXX");
			boolean TUXWJXX = datasets.getParamMap().containsKey("TUXWJXX");

			List<Map<String, String>> piaojyyjgxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> yinjyyjgxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> guiyxxObjList = new ArrayList<Map<String, String>>();

			if (hasPIAOJYYJGXX && hasYINJYYJGXX && hasGUIYXX) {
				piaojyyjgxxObjList = datasets.getParamMap().get("PIAOJYYJGXX");
				yinjyyjgxxObjList = datasets.getParamMap().get("YINJYYJGXX");
				guiyxxObjList = datasets.getParamMap().get("GUIYXX");
			} else {
				throw new UfSealException("���ͱ�����ʵ��[PIAOJYYJGXX]��[YINJYYJGXX]��[GUIYXX]δ����!");
			}
			
			//************************************************************
			/*
			 * ��ȡʱ��
			 */
			Map<String, String> tempMap = new HashMap<String, String>();
			tempMap.put(" ", " ");
			List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
			tempList.add(tempMap);
			JSONObject dataObject = new JSONObject();
			dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate", "", tempList, conn);// ִ�н���
			JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
			String sysDate = jsonObjData1.getString("getdate");
			String date = sysDate.substring(0, 10);
			String time = sysDate.substring(11, 19);
			//************************************************************
			
			//************************************************************
			/*
			 * ƴ��Ա��Ϣ
			 */
			List<Map<String, String>> guiyTempList = new ArrayList<Map<String, String>>();
			Map<String, String> guiyTempMap = new HashMap<String, String>();
			guiyTempMap.put("account", piaojyyjgxxObjList.get(0).get("zhangh"));
			guiyTempMap.put("managedate", date);
			guiyTempMap.put("managetime", time);
			guiyTempMap.put("managetype",  guiyxxObjList.get(0).get("caoz"));
			guiyTempMap.put("clerknum", guiyxxObjList.get(0).get("guiyh"));
			guiyTempMap.put("clerkorgcode", guiyxxObjList.get(0).get("guiyjgh"));
			guiyTempMap.put("clerkname", guiyxxObjList.get(0).get("guiym"));
			guiyTempMap.put("ip", guiyxxObjList.get(0).get("ip"));
			guiyTempMap.put("upflag", "");
			guiyTempMap.put("str1", "");
			guiyTempMap.put("str2", "");
			guiyTempMap.put("str3", "");
			guiyTempList.add(guiyTempMap);
			//************************************************************
			
			List<Map<String, String>> zhengpList = new ArrayList<Map<String,String>>();
			Map<String, String> zhengpMap = new HashMap<String, String>();
			zhengpMap.put("ip",  guiyxxObjList.get(0).get("ip"));
			zhengpMap.put("zhangh", piaojyyjgxxObjList.get(0).get("zhangh"));
			zhengpMap.put("pingzh", piaojyyjgxxObjList.get(0).get("pingzh"));//ƾ֤��
			zhengpMap.put("jine", piaojyyjgxxObjList.get(0).get("jine"));
			zhengpMap.put("checkdate", date);
			zhengpMap.put("checktime", time);
			zhengpMap.put("guiyh", guiyxxObjList.get(0).get("guiyh"));
			zhengpMap.put("guiym", guiyxxObjList.get(0).get("guiym"));
			zhengpMap.put("clerkorgcode", guiyxxObjList.get(0).get("guiyjgh"));
			zhengpMap.put("shuangqgyh", guiyxxObjList.get(0).get("shuangqgyh"));
			zhengpMap.put("shuangqgymc", "");
			zhengpMap.put("yanyjg", piaojyyjgxxObjList.get(0).get("yanyjg"));
			zhengpMap.put("yanyfs", piaojyyjgxxObjList.get(0).get("yanyms"));
			zhengpMap.put("yanybs", piaojyyjgxxObjList.get(0).get("yanybs"));
			zhengpMap.put("remark", "");
			zhengpMap.put("zuhgz", piaojyyjgxxObjList.get(0).get("yanyzh"));
			zhengpMap.put("xitlx", piaojyyjgxxObjList.get(0).get("xitlx"));
			zhengpMap.put("chuprq", piaojyyjgxxObjList.get(0).get("chuprq"));
			//zhengpMap.put("pingzbsm", id);
			zhengpMap.put("pingzbsm", sequenceNum);
			zhengpList.add(zhengpMap);
			juniDBInterface.execSql(WriteZhengpyylogToDb, zhengpList, conn);
			
			for(int i=0;i<yinjyyjgxxObjList.size();i++)
			{
				List<Map<String, String>> danzList = new ArrayList<Map<String,String>>();
				Map<String, String> danzMap = new HashMap<String, String>();
				danzMap.put("ip", guiyxxObjList.get(0).get("ip"));
				danzMap.put("zhangh", yinjyyjgxxObjList.get(i).get("yinjzh"));
				danzMap.put("pingzh", piaojyyjgxxObjList.get(0).get("pingzh"));//ƾ֤��
				danzMap.put("yinjzl", yinjyyjgxxObjList.get(i).get("yinjlx"));
				danzMap.put("yinjbh", yinjyyjgxxObjList.get(i).get("yinjbh"));
				danzMap.put("checkdate", date);
				danzMap.put("checktime", time);
				danzMap.put("guiyh", guiyxxObjList.get(0).get("guiyh"));
				danzMap.put("guiym",  guiyxxObjList.get(0).get("guiym"));
				danzMap.put("clerkorgcode",  guiyxxObjList.get(0).get("guiyjgh"));
				danzMap.put("yanyjg", yinjyyjgxxObjList.get(i).get("yanyjg"));
				danzMap.put("yanyfs", yinjyyjgxxObjList.get(i).get("yanyfs"));
				danzMap.put("henxzb", yinjyyjgxxObjList.get(i).get("hengzb"));
				danzMap.put("shuxzb", yinjyyjgxxObjList.get(i).get("zongzb"));
				danzMap.put("yinzjd", yinjyyjgxxObjList.get(i).get("yinjjd"));
				danzMap.put("yanyjb", yinjyyjgxxObjList.get(i).get("yanyjb"));
				danzMap.put("qiyrq", yinjyyjgxxObjList.get(i).get("qiyrq"));
				//danzMap.put("pingzbsm", id);
				danzMap.put("pingzbsm", sequenceNum);
				danzList.add(danzMap);
				juniDBInterface.execSql(WriteYulyjyylogToDb, danzList, conn);
			}
			
			//�ϴ���ӡͼ����Ϣ����
			List<Map<String, String>> MTUXWJXX = datasets.getParamMap().get("TUXWJXX");
//			System.out.println(MTUXWJXX);
			if(TUXWJXX)
			{
				Map<String, String> MTUXWJXXMap = MTUXWJXX.get(0);
				List<Map<String, String>> MTUXWJXXList = new ArrayList<Map<String,String>>();
				Map<String, String> map = new HashMap<String, String>();
				map.put("zhangh", MTUXWJXXMap.get("zhangh"));
				map.put("wenjbh", id);
				map.put("yxlx", MTUXWJXXMap.get("yxlx"));
				map.put("wenjfwdz", MTUXWJXXMap.get("wenjfwdz"));
				map.put("piaojyxdz", MTUXWJXXMap.get("piaojyxdz"));
				MTUXWJXXList.add(map);
				juniDBInterface.execSql("writeFileInfo", MTUXWJXXList, conn);
			}
			
			//��ӡ����Ҫ��¼�˻��䶯��־
			//juniDBInterface.execSql(WriteWorkLogToDb, guiyTempList, conn);
			commit();
		} catch (Exception e) {
			rollback();
			e.printStackTrace();
			throw e;
		} finally {
			release();
		}
		return jsonArray;
	}

	public String execute(Function function, DataSets datasets) throws Exception {
		return null;
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

}
