package com.sinodata.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.sinodata.bank.JResponseManager;
import com.sinodata.util.JUtils;
import com.sinodata.util.StringTool;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;

/**
 * @author Daniel
 * @Date 2013-3-15
 * @Describe ���Ӳ�ѯ-��ӡ����(v3.0)
 */
public class JGetSealCheckInfo extends BaseTrans {

	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		JSONArray jsonArray = new JSONArray(); // ���屾�������ص�json����
		try {
			List<String> childTrade = function.getMutil().getList(); // (��ȡ�ӽ����б�)

			String getAccountInfo = childTrade.get(0); // �Ӳ�ѯ1(��ȡ�˻���Ϣ,�����ж��û��Ƿ����),�˴��������Ϊ���ݿ��ж�Ӧ��
			String getSatisfySealToCheck = childTrade.get(1);
			String getSatisfyZuheToCheck = childTrade.get(2);
			
			boolean hasPIAOJXX = datasets.getParamMap().containsKey("PIAOJXX");
			boolean hasGUIYXX = datasets.getParamMap().containsKey("GUIYXX");
			
			List<Map<String, String>> piaojxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> guiyxxObjList = new ArrayList<Map<String, String>>();
			if (hasPIAOJXX && hasGUIYXX)
			{
				piaojxxObjList = datasets.getParamMap().get("PIAOJXX");// �����Ʊ����Ϣʵ��
				guiyxxObjList = datasets.getParamMap().get("GUIYXX"); // ����Ĺ�Աʵ���б�
			}else {
				throw new UfSealException("���ͱ�����ʵ��[PIAOJXX]��[GUIYXX]δ����!");
			}

			JSONObject childJsonObj1 = new JSONObject(); // �Ӳ�ѯ1�õ���json����,�˻���Ϣ(�˻���Ϣ)
			JSONObject childJsonObj2 = new JSONObject(); // �Ӳ�ѯ2�õ���json����,�˻���Ϣ(ӡ����Ϣ)
			JSONObject childJsonObj3 = new JSONObject(); // �Ӳ�ѯ3�õ���json����,�˻���Ϣ(�����Ϣ)
			
			Map<String, String> piaojxxMap = piaojxxObjList.get(0);
			String xitlx = piaojxxMap.get("xitlx");
			
			if ("".equals(xitlx) || null == xitlx) {
				throw new UfSealException("���ͱ�����ʵ��������󣬲�֧�ָ�ҵ��ϵͳ!");
			}
			
			childJsonObj2 = juniDBInterface.execSql("getSatisfySealToCheck", "YINJYYXX", piaojxxObjList, conn);
			boolean isZhang = JUtils.isObjDataContainValidData(childJsonObj2);
			if(!isZhang)
			{
				String zhangh = piaojxxObjList.get(0).get("zhangh");
				zhangh = zhangh.substring(0,zhangh.length()-4);
				piaojxxObjList.get(0).put("zhangh", zhangh);
			}

			Map<String, String> guiyMap = guiyxxObjList.get(0);// ����Ĺ�Ա��Ϣ
			String guiyOrg = guiyMap.get("guiyjgh"); // ��Ա������

			childJsonObj1 = juniDBInterface.execSql(getAccountInfo, "ZHANGHYYXX", piaojxxObjList, conn);
			boolean isAccountExist = JUtils.isObjDataContainValidData(childJsonObj1); // �жϽ�������Ƿ�������
			// �˻�����
			if (isAccountExist) 
			{
				jsonArray.add(childJsonObj1);
				JSONArray accountaArray = childJsonObj1.getJSONArray("objectdata");
				JSONObject jsonObjData = JSONObject.fromObject(accountaArray.get(0));
				String zhanghzt = jsonObjData.getString("zhanghzt"); // �˻�״̬
				String zhanghshzt = jsonObjData.getString("zhanghshzt");// �˻����״̬
				String tongctd = jsonObjData.getString("tongctd");
				String zhanghOrg = jsonObjData.getString("jigh");
				boolean isSatisfy = this.isSatisfyTongctd(zhanghOrg, guiyOrg, tongctd); //�ж�ͨ��ͨ��Ȩ��
				if ("��Ч".equals(zhanghzt)) 
				{
					if ("����".equals(zhanghshzt))
					{
						if (isSatisfy)
						{
							childJsonObj2 = juniDBInterface.execSql(getSatisfySealToCheck, "YINJYYXX", piaojxxObjList, conn);
							boolean isExistSatisfySeal = JUtils.isObjDataContainValidData(childJsonObj2);
							//������˻���û���ҵ�ӡ��ȥ���˻�����ӡ��
							if (!isExistSatisfySeal)
							{
								Object zhuzh = jsonObjData.get("zhuzh");
								if(zhuzh!=null&&!"".equals(zhuzh))
								{
									Map piaojxxObjMap = piaojxxObjList.get(0);
									piaojxxObjMap.put("zhuzh", zhuzh);
									childJsonObj2 = juniDBInterface.execSql("getSatisfySealToCheckForzhuzh", "YINJYYXX", piaojxxObjList, conn);
									isExistSatisfySeal = JUtils.isObjDataContainValidData(childJsonObj2);
								}
							}
							
							//����а���ӡ����Ϣ
							Map yinjxxMap = new HashMap();
							JSONArray newYinjArray = new JSONArray();
							if (isExistSatisfySeal)
							{
								childJsonObj3 = juniDBInterface.execSql(getSatisfyZuheToCheck, "ZUHYYXX", piaojxxObjList, conn);
								boolean isExistSatisfyZuhe = JUtils.isObjDataContainValidData(childJsonObj3);
								StringBuffer zuheSb = new StringBuffer("");
								//********************ȡϵͳ��ӡ����***********************
								List<JSONObject> yinjList = JUtils.objectdataToList(childJsonObj2);
								JSONObject xityygzObj =  juniDBInterface.execSql("getXityygz", "ZHANGHYYXX", piaojxxObjList, conn);	//��ȡ��Ӧϵͳ���͵���ӡ����
								List<JSONObject> xityygzList = JUtils.objectdataToList(xityygzObj);
								String xityygz = xityygzList.get(0).getString("yanygz");
								String xityygzBackup = xityygz;
								String xityygzbz = xityygzList.get(0).getString("beiz");
								String[] yinjlxArr = xityygzbz.split("\\|");
								JUtils.sortByStrLength(yinjlxArr);// ӡ�����������ַ����ȣ�������ǰ����ֹ�ظ��滻
								List<String> yinjlxList = new ArrayList<String>();
								for (int i =0; i < yinjlxArr.length; i ++)
								{
									yinjlxList.add(yinjlxArr[i]);
								}
								
								if (isExistSatisfyZuhe) 
								{	
									// ������������ϵ����
									JSONArray tempArray = childJsonObj3.getJSONArray("objectdata");
									int objDataCount = tempArray.size();
									if (1 == objDataCount) 
									{
										JSONObject tempJsonObj = JSONObject.fromObject(tempArray.get(0));
										zuheSb.append(tempJsonObj.get("zuhgz"));
										StringTool.fingNumberInString(yinjxxMap,tempJsonObj.get("zuhgz").toString());
									}else {
										for (int i = 0; i < objDataCount; i++) 
										{
											JSONObject tempJsonObj = JSONObject.fromObject(tempArray.get(i));
											zuheSb.append("(");
											zuheSb.append(tempJsonObj.get("zuhgz"));
											zuheSb.append(")");
											if (!(i == objDataCount - 1))
											{
												zuheSb.append("|");
											}
											StringTool.fingNumberInString(yinjxxMap,tempJsonObj.get("zuhgz").toString());
										}
									}
									JSONObject zuheObj = new JSONObject();
									zuheObj.put("zuhgz", zuheSb.toString());
									JSONArray zuheArray = new JSONArray();
									zuheArray.add(zuheObj);
									JSONObject retZuheObj = new JSONObject();
									retZuheObj.put("objectname", "ZUHYYXX");
									retZuheObj.put("objectdata", zuheArray);
									jsonArray.add(retZuheObj);
								} else {
									//�ж��Ƿ����˻�
									Object zhuzh = jsonObjData.get("zhuzh");
									if(zhuzh!=null&&!"".equals(zhuzh))
									{
										Map piaojxxObjMap = piaojxxObjList.get(0);
										piaojxxObjMap.put("zhuzh", zhuzh);
										childJsonObj3 = juniDBInterface.execSql("getSatisfyZuheToCheckForzhuzh", "ZUHYYXX", piaojxxObjList, conn);
										isExistSatisfyZuhe = JUtils.isObjDataContainValidData(childJsonObj3);
										if(isExistSatisfyZuhe)
										{
											JSONArray tempArray = childJsonObj3.getJSONArray("objectdata");
											int objDataCount = tempArray.size();
											if (1 == objDataCount) 
											{
												JSONObject tempJsonObj = JSONObject.fromObject(tempArray.get(0));
												StringTool.fingNumberInString(yinjxxMap,tempJsonObj.get("zuhgz").toString());
											}else {
												for (int i = 0; i < objDataCount; i++) 
												{
													JSONObject tempJsonObj = JSONObject.fromObject(tempArray.get(i));
													StringTool.fingNumberInString(yinjxxMap,tempJsonObj.get("zuhgz").toString());
												}
											}
											jsonArray.add(childJsonObj3);
										}
									}
									//������������ϵ�����������ϵͳ������ƴ����
									//��xityygz���е�biz�е����滻�ɶ�Ӧ��ӡ�����
									//Empty��Ϊ�˷�ֹӡ�����|һ����ֵ���������|��&��Emptyһ���滻��''
									for (int i = 0; i < yinjlxList.size(); i++)
									{
											String yinjlx = yinjlxList.get(i);
											if (xityygz.contains(yinjlx)) 
											{	
												StringBuffer zuhSb = new StringBuffer("");
												int yinjCount = 0;
												for (int j = 0; j < yinjList.size(); j++)
												{
													if (yinjList.get(j).getString("yinjlx").equals(yinjlx)) 
													{
														if (0 == yinjCount)
														{
															zuhSb.append(yinjList.get(j).getString("yinjbh"));
														}
														if (yinjCount > 0) 
														{
															zuhSb.append("&");
															zuhSb.append(yinjList.get(j).getString("yinjbh"));
														}
														yinjCount++;
													}
												}
												if ("".equals(zuhSb.toString()))
												{
													zuhSb.append("Empty");
												}
												xityygz = xityygz.replace(yinjlx, zuhSb.toString());
												xityygz= xityygz.replace("|Empty", "");
												xityygz = xityygz.replace("Empty|", "");
												xityygz = xityygz.replace("Empty&", "");
												xityygz = xityygz.replace("&Empty", "");
												xityygz = xityygz.replace("Empty", "");
											}
										}
										JSONObject zuheObj = new JSONObject();
										zuheObj.put("zuhgz", xityygz);
										JSONArray zuheArray = new JSONArray();
										zuheArray.add(zuheObj);
										JSONObject retZuheObj = new JSONObject();
										retZuheObj.put("objectname", "ZUHYYXX");
										retZuheObj.put("objectdata", zuheArray);
										jsonArray.add(retZuheObj);
										StringTool.fingNumberInString(yinjxxMap,xityygz);
										
									JSONArray yinjArray = (JSONArray) childJsonObj2.get("objectdata");
									int yinjArraySize = yinjArray.size();
									for(int i = 0; i < yinjArraySize; i++) 
									{
										JSONObject yinjObj = JSONObject.fromObject(yinjArray.get(i));
										if(xityygzBackup.contains(yinjObj.getString("yinjlx"))) 
										{
											newYinjArray.add(yinjObj);
										}
									}
									childJsonObj2.remove("objectdata");
									childJsonObj2.put("objectdata", newYinjArray);
								}
								//shanc yinj
								JSONArray yinjArray = childJsonObj2.getJSONArray("objectdata");
								int size = yinjArray.size();
								for(int i= 0;i<size;i++)
								{
									Map tt = (Map) yinjArray.get(i);
									String yinjbh = (String) tt.get("yinjbh");
									if(yinjxxMap.get(yinjbh)==null)
									{
//										System.out.println("delete"+yinjbh);
										yinjArray.remove(i);
										size--;
										i--;
									}
								}
								boolean isContainSeal = JUtils.isObjDataContainValidData(childJsonObj2);
								if(!isContainSeal) {
									JResponseManager.jrResMsgSet(jsonRet, "û�л�ȡ����Ч��ӡ����������Ϣ�Ƿ�������ȷ!");
								}
								jsonArray.add(childJsonObj2);
							} else {
								//HF Ҫ���޸�20130411
								JResponseManager.jrResMsgSet(jsonRet, "û�л�ȡ����Ч��ӡ����������Ϣ�Ƿ�������ȷ!");
							}
						} else {
							JResponseManager.jrResMsgSet(jsonRet, "�˻������ܶԴ��˻���ӡ!");
						}
					} else {
						JResponseManager.jrResMsgSet(jsonRet, "���˻�δ��!");
					}
				} else {
					JResponseManager.jrResMsgSet(jsonRet, "���˻�״̬������Ч!");
				}
			} else {
				JResponseManager.jrResMsgSet(jsonRet, "���˻�������!");
			}
		}catch (Exception e) {
			throw e;
		}finally{
			release();
		}
		return jsonArray;
	}

	/**
	 * ͨ���û�������,��Ա������,ͨ��ͨ���ж�Ȩ��
	 * @param accountOrg
	 * @param clerkOrg
	 * @param tongctd
	 * @return
	 * @throws Exception
	 */
	private boolean isSatisfyTongctd(String accountOrg, String clerkOrg, String tongctd) throws Exception {
		try {
			JSONObject childJsonObj1 = new JSONObject();
			JSONObject childJsonObj2 = new JSONObject();
			JSONObject childJsonObj3 = new JSONObject();
			//if (accountOrg.equals(clerkOrg)) {
			if(true){
				return true;
			}else {
				if ("��".equals(tongctd)) {
					return true;
				}else {
					if ("ʡ".equals(tongctd)) {
						List<Map<String, String>> tempObjList1 = new ArrayList<Map<String, String>>();
						Map<String, String> tempMap1 = new HashMap<String, String>();
						tempMap1.put("organnum", accountOrg);
						tempObjList1.add(tempMap1);
						List<Map<String, String>> tempObjList2 = new ArrayList<Map<String, String>>();
						Map<String, String> tempMap2 = new HashMap<String, String>();
						tempMap2.put("organnum", clerkOrg);
						tempObjList2.add(tempMap2);
						childJsonObj1 = juniDBInterface.execSql("getShenghjgh", "", tempObjList1, conn);
						childJsonObj2 = juniDBInterface.execSql("getShenghjgh", "", tempObjList2, conn);
						JSONObject jsonObjData1 = JSONObject.fromObject(childJsonObj1.getJSONArray("objectdata").get(0));
						JSONObject jsonObjData2 = JSONObject.fromObject(childJsonObj2.getJSONArray("objectdata").get(0));
						String accountSHENGHJGH = jsonObjData1.getString("shenghjgh");
						String clerkSHENGHJGH = jsonObjData2.getString("shenghjgh");
						if (accountSHENGHJGH.equals(clerkSHENGHJGH)) {
							return true;
						} else {
							return false;// tongctdΪʡ,��ʡ�л����Ų�һ��
						}
					} else {
						if ("��".equals(tongctd)) {
							List<Map<String, String>> paramList3 = new ArrayList<Map<String, String>>();
							Map<String, String> tempMap3 = new HashMap<String, String>();
							tempMap3.put("guiyjgh", clerkOrg);
							tempMap3.put("jigh", accountOrg);
							paramList3.add(tempMap3);
							childJsonObj3 = juniDBInterface.execSql("judgeAccountOrgBelongToGuiyOrg", "", paramList3, conn);
							boolean isAccountOrgBelongToGuiyOrg = JUtils.isObjDataContainValidData(childJsonObj3);
							if (isAccountOrgBelongToGuiyOrg) {
								return true;
							} else {
								return false; // tongctdΪ��,���˻������Ų����ڹ�Ա��������
							}
						} else {
							throw new UfSealException("����[ͨ��ͨ��]����Чֵ!");
						}
					}
				
				}
			}
		}
		catch (Exception e) {
			throw e;
		}
	}

	public String execute(Function function, DataSets datasets) throws Exception {
		return null;
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

}
