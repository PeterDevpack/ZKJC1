package com.sinodata.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.sinodata.util.JUtils;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;

/**
 * @author Daniel
 * @Date 2013-3-11
 * @Describe ���ӽ���-�ύӡ��&�����Ϣ[����](v3.0����)
 */
public class JSubmitSealAndCombinaInfo extends BaseTrans {

	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		beginTrans();
		JSONArray jsonArray = new JSONArray(); // ���屾�������ص�json����
		try {
			List<String> childTrade = function.getMutil().getList(); // (��ȡ�ӽ����б�)

			String addSealInfo = childTrade.get(0); // ����ӡ����Ϣ(�ӽ���1)
			String changeUserCheckState = childTrade.get(1); // ���˻�״̬-ӡ���ӽ���2)
			String addCombineInfo = childTrade.get(2); // ���������Ϣ(�ӽ���3)
			String changeCombineCheckState = childTrade.get(3);// ���˻�״̬-���(�ӽ���4)
			String WriteWorkLogToDb = childTrade.get(4); // ��¼��Ա������־(�ӽ���5)
			String insertYinjk = "insertYinjk";
			String insertKAGRW = "insertKAGRW";

			boolean hasGUIYXX = datasets.getParamMap().containsKey("GUIYXX");// �жϴ���ı������Ƿ���ĳʵ��
			boolean hasYINJXX = datasets.getParamMap().containsKey("YINJXX");
			boolean hasZUHXX = datasets.getParamMap().containsKey("ZUHXX");
			boolean hasJKWENJXX = datasets.getParamMap().containsKey("JKWENJXX");

			List<Map<String, String>> guiyxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> yinjxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> zuhxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> kaguiObjList = new ArrayList<Map<String, String>>();

			Map<String, String> yinjxxMap = new HashMap<String, String>();
			Map<String, String> tempMap1 = new HashMap<String, String>();
			List<Map<String, String>> paramList1 = new ArrayList<Map<String, String>>();

			Map<String, String> zuhxxMap = new HashMap<String, String>();
			Map<String, String> tempMap2 = new HashMap<String, String>();
			List<Map<String, String>> paramList2 = new ArrayList<Map<String, String>>();

			// ************************************************************
			/*
			 * ��ȡʱ��
			 */
			Map<String, String> tempMap = new HashMap<String, String>();
			tempMap.put(" ", " ");
			List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
			tempList.add(tempMap);
			JSONObject dataObject = new JSONObject();
			dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate", "", tempList, conn);// ִ�н���
			JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
			String sysDate = jsonObjData1.getString("getdate");
			String date = sysDate.substring(0, 10);
			String time = sysDate.substring(11, 19);
			// ************************************************************

			if (hasGUIYXX && hasYINJXX) {
				guiyxxObjList = datasets.getParamMap().get("GUIYXX"); // ��Ա��Ϣ
				yinjxxObjList = datasets.getParamMap().get("YINJXX"); // ӡ����Ϣ
				
				//��ӡ����Ϣ������
				
				/*
				 * ȡ��һ��ӡ������ȡ��Ҫ�����ݣ�����map�����ӵ�list��
				 */
				yinjxxMap = yinjxxObjList.get(0);// ����ĵ�һ��ӡ����Ϣ
				String zhangh = yinjxxMap.get("zhangh"); // 
				String yinjshzt = yinjxxMap.get("yinjshzt");
				tempMap1.put("zhangh", zhangh);
				tempMap1.put("yinjshzt", yinjshzt);
				tempMap1.put("zhanghshzt", yinjshzt);
				tempMap1.put("zuhshzt", yinjshzt);
				tempMap1.put("youwyj", "��");
				paramList1.add(tempMap1);
			} else {
				throw new UfSealException("���ͱ�����ʵ��[GUIYXX]��[YINJXX]δ����!");
			}
			if (hasZUHXX) {
				zuhxxObjList = datasets.getParamMap().get("ZUHXX"); // �����Ϣ
				/*
				 * ȡ��һ����ϣ���ȡ��Ҫ�����ݣ�����map�����ӵ�list��
				 */
				zuhxxMap = zuhxxObjList.get(0);
				String zhangh = zuhxxMap.get("zhangh");
				String zuhshzt = zuhxxMap.get("zuhshzt");
				tempMap2.put("zhangh", zhangh);
				tempMap2.put("zuhshzt", zuhshzt);
				tempMap2.put("youwzh", "��");
				paramList2.add(tempMap2);
			} else {

			}

			if (hasYINJXX) {
				juniDBInterface.execSql(addSealInfo, yinjxxObjList, conn);
				juniDBInterface.execSql(changeUserCheckState, paramList1, conn);
			} else {

			}
			if (hasZUHXX) {
				juniDBInterface.execSql(addCombineInfo, zuhxxObjList, conn);
			} else {

			}
			if (hasGUIYXX) {
				List<Map<String, String>> guiyTempList = new ArrayList<Map<String, String>>();
				Map<String, String> guiyTempMap = new HashMap<String, String>();
				guiyTempMap.put("account", yinjxxMap.get("zhangh"));
				guiyTempMap.put("managedate", date);
				guiyTempMap.put("managetime", time);
				guiyTempMap.put("managetype", guiyxxObjList.get(0).get("caoz"));
				guiyTempMap.put("clerknum", guiyxxObjList.get(0).get("guiyh"));
				guiyTempMap.put("clerkname", guiyxxObjList.get(0).get("guiym"));
				guiyTempMap.put("ip", guiyxxObjList.get(0).get("ip"));
				guiyTempMap.put("upflag", "");
				guiyTempMap.put("str1", "");
				guiyTempMap.put("str2", "");
				guiyTempMap.put("str3", "");
				guiyTempMap.put("managecontent","");
				guiyTempList.add(guiyTempMap);
				juniDBInterface.execSql(WriteWorkLogToDb, guiyTempList, conn);
				juniDBInterface.execSql(changeCombineCheckState, paramList2, conn);
			}

			// ����yinjk����kagrw��
			if (hasJKWENJXX) {
				kaguiObjList = datasets.getParamMap().get("JKWENJXX"); // �����ļ���Ϣ��Ϣ
				List<Map<String, String>> kaguiTempList = new ArrayList<Map<String, String>>();
				for (int i = 0; i < kaguiObjList.size(); i++) {
					String strTemp = JUtils.getRandomID();
					Map<String, String> kaguiTempMap = new HashMap<String, String>();
					kaguiTempMap.put("yinjkh", kaguiObjList.get(i).get("yinjkh"));
					kaguiTempMap.put("zhangh", kaguiObjList.get(i).get("zhangh"));
					kaguiTempMap.put("jigh", kaguiObjList.get(i).get("jigh"));
					kaguiTempMap.put("zhengmwjm", kaguiObjList.get(i).get("zhengmwjm"));
					kaguiTempMap.put("fanmwjm", kaguiObjList.get(i).get("fanmwjm"));
					kaguiTempMap.put("qiyrq", kaguiObjList.get(i).get("qiyrq").replace("-", ""));
					kaguiTempMap.put("tingyrq", kaguiObjList.get(i).get("tingyrq").replace("-", ""));
					kaguiTempMap.put("renwbs", strTemp);
					kaguiTempMap.put("renwlx", "0");
					kaguiTempMap.put("yewlx", "0");
					kaguiTempMap.put("renwzt", "0");
					kaguiTempMap.put("yinjks", String.valueOf(kaguiObjList.size()));
					kaguiTempMap.put("shifzk", "1");
					kaguiTempList.add(kaguiTempMap);
				}
				List<Map<String, String>> bsList = new ArrayList<Map<String, String>>();
				Map<String, String> bsMap = new HashMap<String, String>();
				bsMap.put("cansid", "kag_kongzcs");
				bsList.add(bsMap);
				JSONObject kzObject = juniDBInterface.execSql("getKzcs", "", bsList, conn);// ִ�н���
				JSONObject kzObjectTemp = JSONObject.fromObject(kzObject.getJSONArray("objectdata").get(0));
				String value = kzObjectTemp.getString("parametervalue");
				//ϵͳ���������Ƿ���ӡ�����ſ�����
				if("1".equals(value))
				{
						juniDBInterface.execSql("insertKAGRW", kaguiTempList, conn);
					try{
						juniDBInterface.execSql("insertYinjk", kaguiTempList, conn);
					}catch(Exception e){
						juniDBInterface.execSql("updateYinjk", kaguiTempList, conn);
					}
				}
			}
			commit();
		}catch (Exception e) {
			rollback();
			throw e;
		}
		finally {
			release();
		}
		return jsonArray;
	}

	public String execute(Function function, DataSets datasets) throws Exception {
		return null;
	}

	public String execute(Map<String, String> parameters) throws Exception {
		return null;
	}

}
