package com.sinodata.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
/**
 * 
 * @author hss
 * �����˻������Ϣ
 *
 */
public class JSaveInfoCheckInfo extends BaseTrans{
	
	public JSONArray jexecute(Function function, DataSets datasets,	JSONObject jsonRet) throws Exception {
		beginTrans();//���￪��
		JSONArray jsonArray=new JSONArray();
		try{
			List<String> childTrade = function.getMutil().getList(); // (��ȡ�ӽ����б�)
			
			String GetWSqyrq = childTrade.get(0);//��ȡδ��ӡ����������
			String getAccountInfo = childTrade.get(1);//��ȡ�˻���Ϣ
			String NcheckAccountInfo = childTrade.get(2);//�����˻������Ϣ
			String NcheckSeals = childTrade.get(3);//����ӡ�����״̬
			String NcheckGroups = childTrade.get(4);//����������״̬
			String WriteWorkLogToDb = childTrade.get(5);//д��Ա������־
			
			boolean hasZHANGHSHJG = datasets.getParamMap().containsKey("RENWXX");
			boolean hasYINJSHXX = datasets.getParamMap().containsKey("YINJJGXX");			
			
			List<Map<String, String>> renwxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> yinjshxxObjList = new ArrayList<Map<String, String>>();			
			
			StringBuffer sb=new StringBuffer();//��־��������
			
			String shenhlx="";//�����������ӡ��
			if (hasZHANGHSHJG && hasYINJSHXX)
			{
				renwxxObjList = datasets.getParamMap().get("RENWXX");
				yinjshxxObjList = datasets.getParamMap().get("YINJJGXX");				
				
				String managetype=renwxxObjList.get(0).get("managetype");				
				if("1".equals(managetype) && managetype!=null && !"".equals(managetype)){
					//����ӡ����˽����¼
					String shenhjg = yinjshxxObjList.get(0).get("y");
					shenhlx="���ǰ��ӡ";
					sb.append("���ǰ��ӡ|");
					sb.append("ӡ���������ڣ�"+yinjshxxObjList.get(0).get("qiyrq"));	
				}else if("2".equals(managetype) && managetype!=null && !"".equals(managetype)){
					List<Map<String, String>> zhangList = new ArrayList<Map<String,String>>();					
					Map<String, String> zhanghMap = new HashMap<String, String>();
					zhanghMap.put("zhangh", renwxxObjList.get(0).get("zhangh"));
					zhangList.add(zhanghMap);
					shenhlx="�˻�����";
					JSONObject qyrqObj=juniDBInterface.execSql(GetWSqyrq, "",zhangList, conn);
					String qyrq=JSONObject.fromObject(qyrqObj.getJSONArray("objectdata").get(0)).getString("qiyrq");					
					
					Map<String,String> accoMap=new HashMap<String,String>();
					accoMap.put("zhangh", renwxxObjList.get(0).get("zhangh"));					
					accoMap.put("shzt", renwxxObjList.get(0).get("state"));
					
					//��ȡ��Ա��Ϣ
					List<Map<String,String>> zhanghList=new ArrayList<Map<String,String>>();
					Map<String,String> zhanghaoMap=new HashMap<String,String>();
					zhanghaoMap.put("clerknum",renwxxObjList.get(0).get("guiyh"));
					zhanghList.add(zhanghaoMap);
					//�������Ա
					JSONArray clerkjson = juniDBInterface.execSql("GetClerkInfo",zhanghList,conn);
					JSONObject clerkobj = JSONObject.fromObject(clerkjson.get(0));
					JSONObject clerkdata = JSONObject.fromObject(clerkobj.getJSONArray("objectdata").get(0));
					String shenhy=clerkdata.getString("clerkname");
					String clerknum=renwxxObjList.get(0).get("guiyh");


					
					List<Map<String,String>> ysList=new ArrayList<Map<String,String>>();
					
					Map<String,String> sealMap=new HashMap<String,String>();
					sealMap.put("zhangh", renwxxObjList.get(0).get("zhangh"));
					sealMap.put("shzt", renwxxObjList.get(0).get("state"));
					sealMap.put("qiyrq", qyrq);
					sealMap.put("shenhy", shenhy);
					sealMap.put("shenhynum", clerknum);
					List<Map<String, String>> tempList = new ArrayList<Map<String,String>>();
					tempList.add(sealMap);					
					if ("ͨ��".equals(renwxxObjList.get(0).get("yanyjg")))
					{						
						JSONObject accoObj=juniDBInterface.execSql(getAccountInfo, "",zhangList, conn);//����˻���Ϣ
						String zhanghshzt=JSONObject.fromObject(accoObj.getJSONArray("objectdata").get(0)).getString("zhanghshzt");//����˻����״̬						
						if("����".equals(zhanghshzt) && zhanghshzt!=null && !"".equals(zhanghshzt)){							
							accoMap.put("zhanghshzt", "����");							
							ysList.add(accoMap);
							juniDBInterface.execSql(NcheckAccountInfo, ysList, conn);
							juniDBInterface.execSql(NcheckSeals, tempList, conn);
							juniDBInterface.execSql(NcheckGroups, tempList, conn);
						}else{
							accoMap.put("zhanghshzt",renwxxObjList.get(0).get("state"));							
							ysList.add(accoMap);
							juniDBInterface.execSql(NcheckAccountInfo, ysList, conn);
							juniDBInterface.execSql(NcheckSeals, tempList, conn);
							juniDBInterface.execSql(NcheckGroups, tempList, conn);
						}
						sb.append("���δ��ӡ��|");
						sb.append("ӡ���������ڣ�"+yinjshxxObjList.get(0).get("qiyrq"));
						
						//�˻���չ��ά����¼
						Map<String, String> zhanghkzbMap = new HashMap<String, String>();
						zhanghkzbMap.put("zhangh", renwxxObjList.get(0).get("zhangh"));
						JSONObject JSONObject = this.executeJY("selectZhangkzb", zhanghkzbMap);
					}else {
						//��˲�ͨ��
						Map<String, String> accMap = new HashMap<String, String>();
						accMap.put("zhangh", renwxxObjList.get(0).get("zhangh"));	
						accMap.put("shzt", "δ��");
						accMap.put("yinjshzt", "δ��");
						accMap.put("zuhshzt", "δ��");
						accMap.put("zhanghshzt", "δ��");
						ysList.add(accMap);
						juniDBInterface.execSql(NcheckAccountInfo, ysList, conn);
					}
				}else{
					throw new UfSealException("δʶ���ϵͳ���ܱ�ʶ!");
				}				
			} else {
				throw new UfSealException("���ͱ�����ʵ��[RENWXX]��[YINJYYJGXX]δ����!");
			}
			//************************************************************
			/*
			 * ��ȡʱ��
			 */
			Map<String, String> tempMap = new HashMap<String, String>();
			tempMap.put(" ", " ");
			List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
			tempList.add(tempMap);
			JSONObject dataObject = new JSONObject();
			dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate", "", tempList, conn);// ִ�н���
			JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
			String sysDate = jsonObjData1.getString("getdate");
			String date = sysDate.substring(0, 10);
			String time = sysDate.substring(11, 19);
			//************************************************************
			new HashMap<String, String>().put("", "");
			
			//************************************************************
			/*
			 * ƴ��Ա��Ϣ
			 */
			List<Map<String, String>> guiyTempList = new ArrayList<Map<String, String>>();
			Map<String, String> guiyTempMap = new HashMap<String, String>();
			guiyTempMap.put("account", renwxxObjList.get(0).get("zhangh"));
			guiyTempMap.put("managedate", date);
			guiyTempMap.put("managetime", time);
			guiyTempMap.put("managetype", shenhlx);
			guiyTempMap.put("clerknum", renwxxObjList.get(0).get("guiyh"));
			guiyTempMap.put("clerkname", "");
			guiyTempMap.put("clerkorgcode", renwxxObjList.get(0).get("guiyjgh"));
			guiyTempMap.put("qiyrq", yinjshxxObjList.get(0).get("qiyrq"));
			guiyTempMap.put("ip", "");
			guiyTempMap.put("upflag", "");
			guiyTempMap.put("str1", "");
			guiyTempMap.put("str2", "");
			guiyTempMap.put("str3", "");
			sb.append(" |���ģʽΪ��"+renwxxObjList.get(0).get("yanyms")+"|��˽��Ϊ��"+renwxxObjList.get(0).get("yanyjg"));
			guiyTempMap.put("managecontent",sb.toString());
			guiyTempList.add(guiyTempMap);
			
			juniDBInterface.execSql(WriteWorkLogToDb, guiyTempList, conn);//��¼��Ա������־
			
			commit();
		}catch(Exception e){
			rollback();
			e.printStackTrace();
			throw e;
		}finally{
			release();
		}
		return jsonArray;
	}
	
	/*
	 * ִ�н��׺���
	 */
	private JSONObject executeJY(String jiaoyid,Map<String, String> pMap) throws Exception{
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		list.add(pMap);
		JSONObject jsonObjData = juniDBInterface.execSql(jiaoyid,"",list, conn);
		if(jsonObjData.size()!=0)
		jsonObjData = JSONObject.fromObject(jsonObjData.getJSONArray("objectdata").get(0));
		return jsonObjData;
	}
	public String execute(Function function, DataSets datasets) throws Exception {return null;}
	public String execute(Map<String, String> parameters) throws Exception { return null;}
}