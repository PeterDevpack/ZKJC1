package com.sinodata.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.sinodata.bank.JResponseManager;
import com.sinodata.util.JUtils;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
/*
 * 2014��01��21��
 * by ldd
 * �����˻�״̬����
 * ֧��ҵ�������������ָ�
 *  "MANAGETYPE": "0" ����ҵ���ʶ
 *  "MANAGETYPE": "1" �����ָ�ҵ���ʶ
 */
public class IChangeAccountState extends BaseTrans{

	public JSONArray jexecute(Function function, DataSets datasets,JSONObject jsonRet) throws Exception {
		JSONArray jsonArray = new JSONArray();
		beginTrans();
		try {
			List<String> childTrade = function.getMutil().getList();
			String getAccountInfo = childTrade.get(0);		//��ȡ�˻���Ϣ
			String updateAccountState = childTrade.get(1);  //�����˻�״̬
			String writeWorkLogToDb = childTrade.get(2); 	//д�˻�������־
			List<Map<String, String>> infoList = datasets.getParamMap().get("INFO"); //������Ϣ
			
			/*
			 * ��ȡʱ��
			 */
			Map<String, String> tempMap = new HashMap<String, String>();
			tempMap.put(" ", " ");
			List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
			tempList.add(tempMap);
			JSONObject dataObject = new JSONObject();
			dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate","",tempList,conn);
			JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
			String sysDate = jsonObjData1.getString("getdate");
			String date = sysDate.substring(0, 10);
			String time = sysDate.substring(11, 19);
			
			
			JSONObject childJsonObj1 = new JSONObject();//�˻���Ϣ

			childJsonObj1 = juniDBInterface.execSql(getAccountInfo, "getAccountInfo", infoList, conn);
			boolean isAccountExist = JUtils.isObjDataContainValidData(childJsonObj1);//�жϽ�������Ƿ�������
			//�˻�������
			if (!isAccountExist) 
			{
				JResponseManager.jrResMsgSet(jsonRet,"�˺Ų�����!");
				return jsonArray;
			}
			String managetype = infoList.get(0).get("managetype");
			if("0".equals(managetype))
			{	
				//��������
				Map<String,String> accoMap=new HashMap<String,String>();
				accoMap.put("zhangh",  infoList.get(0).get("zhangh"));					
				accoMap.put("zhanghzt","����");
				List<Map<String,String>> ysList=new ArrayList<Map<String,String>>();
				ysList.add(accoMap);
				juniDBInterface.execSql(updateAccountState, "updateAccountState", ysList, conn);
				
				//����������־
				List<Map<String, String>> guiyTempList = new ArrayList<Map<String, String>>();
				Map<String, String> guiyTempMap = new HashMap<String, String>();
				guiyTempMap.put("account", infoList.get(0).get("zhangh"));
				guiyTempMap.put("managedate", date);
				guiyTempMap.put("managetime", time);
				guiyTempMap.put("managetype", "����");
				guiyTempMap.put("clerknum", infoList.get(0).get("guiyh"));
				guiyTempMap.put("clerkname", "");
				guiyTempMap.put("clerkorgcode", infoList.get(0).get("guiyjgh"));
				guiyTempMap.put("ip", "");
				guiyTempMap.put("upflag", "");
				guiyTempMap.put("str1", "");
				guiyTempMap.put("str2", "");
				guiyTempMap.put("str3", "");
				guiyTempMap.put("managecontent","");
				guiyTempList.add(guiyTempMap);
				juniDBInterface.execSql(writeWorkLogToDb, guiyTempList, conn);
			}else if("1".equals(managetype)){
				//�����ָ�����
				Map<String,String> accoMap=new HashMap<String,String>();
				accoMap.put("zhangh",  infoList.get(0).get("zhangh"));					
				accoMap.put("zhanghzt","��Ч");
				List<Map<String,String>> ysList=new ArrayList<Map<String,String>>();
				ysList.add(accoMap);
				juniDBInterface.execSql(updateAccountState, "updateAccountState", ysList, conn);
				
				//�����ָ�������־
				List<Map<String, String>> guiyTempList = new ArrayList<Map<String, String>>();
				Map<String, String> guiyTempMap = new HashMap<String, String>();
				guiyTempMap.put("account", infoList.get(0).get("zhangh"));
				guiyTempMap.put("managedate", date);
				guiyTempMap.put("managetime", time);
				guiyTempMap.put("managetype", "�����ָ�");
				guiyTempMap.put("clerknum", infoList.get(0).get("guiyh"));
				guiyTempMap.put("clerkname", "");
				guiyTempMap.put("clerkorgcode", infoList.get(0).get("guiyjgh"));
				guiyTempMap.put("ip", "");
				guiyTempMap.put("upflag", "");
				guiyTempMap.put("str1", "");
				guiyTempMap.put("str2", "");
				guiyTempMap.put("str3", "");
				guiyTempMap.put("managecontent","");
				guiyTempList.add(guiyTempMap);
				juniDBInterface.execSql(writeWorkLogToDb, guiyTempList, conn);
			}
			this.commit();
		} catch (Exception e) {
			rollback();
			e.printStackTrace();
			throw e;
		}finally{
			release();
		}
		return jsonArray;
	}
	
	public String execute(Function function, DataSets datasets)throws Exception {return null;}
	public String execute(Map<String, String> parameters) throws Exception {return null;}
}