package com.sinodata.bank.complextrans.impl;

import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
/**  
 * @author hss
 * @Describe  ����Ҫ
 */
public class AddYinjkInfo extends BaseTrans{
	public JSONArray jexecute(Function function, DataSets datasets,JSONObject jsonRet) throws Exception {
		JSONArray jsonArray = new JSONArray(); // ���屾�������ص�json����
		try {
			List<String> childTrade = function.getMutil().getList();
			String addYinjk = childTrade.get(0); // �Ӳ�ѯ1�����ӣ�	
			
			List<Map<String, String>> renwxxObjList = datasets.getParamMap().get("SSRENWXX");//������Ϣ
			System.out.println(renwxxObjList);
			String qiyrq=renwxxObjList.get(0).get("qiyrq");
			if(qiyrq!=null&&!qiyrq.equals("")){
				qiyrq=qiyrq.substring(0, 4)+qiyrq.substring(5, 7)+qiyrq.substring(8, 10);
			}
			renwxxObjList.get(0).put("qiyrq", qiyrq);
			renwxxObjList.get(0).put("shifzk", "1");
			renwxxObjList.get(0).put("yewlx", "0");
			renwxxObjList.get(0).put("tingyrq", "");
			String retObjName = "ZHANGHXX";
			
			
			JSONObject yinjkObject = juniDBInterface.execSql(addYinjk,retObjName,renwxxObjList,conn);
			
		} catch (Exception e) {			
			e.printStackTrace();
			throw e;
		}finally{
			release();
		}
		return jsonArray;
	}

	public String execute(Function function, DataSets datasets)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public String execute(Map<String, String> parameters) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
}
