package com.sinodata.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.sinodata.bank.JResponseManager;
import com.sinodata.util.JUtils;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;
/**
 * 
 * @Describe ƽ̨+����  ���ӽ���-������Ϣ
 *
 */
public class JSaveAllAccountInfo extends BaseTrans{
	
	public JSONArray jexecute(Function function, DataSets datasets, JSONObject jsonRet) throws Exception {
		beginTrans();//��������
		JSONArray jsonArray = new JSONArray();
		try{
			List<String> childTrade = function.getMutil().getList();
			/*
			 *��ȡ�ӽ��� 
			 */
			String JudgeAccountOrgBelongToGuiyOrg = childTrade.get(0); // �Ӳ�ѯ1(�ж��˺Ż����Ƿ������Ա��������)
			String DelAccount = childTrade.get(1);//�ӽ���2�������˺�ɾ���˻���Ϣ��
			String DelAllYinj = childTrade.get(2);//�ӽ���3��ɾ���˻�������ӡ����Ϣ��
			String DelAllZh = childTrade.get(3);//�ӽ���4��ɾ���˻������������Ϣ��			
			
			String addAccountInfo = childTrade.get(4);//�ӽ���5�������˻���Ϣ��
			String addSealInfo = childTrade.get(5);//�ӽ���6������ӡ����Ϣ��			
			String addCombineInfo = childTrade.get(6);//�ӽ���7�����������Ϣ��
			
			String changeUserCheckState = childTrade.get(7); //�ӽ���8�����˻�״̬-ӡ����
			String changeCombineCheckState = childTrade.get(8);//�ӽ���9�� ���˻�״̬-��ϣ�
			
			String UpdateAccountInfo = childTrade.get(9);//�ӽ���10�������˻�������Ϣ��
			String DelWSyinj = childTrade.get(10);//�ӽ���11��ɾ���˻������С�δ��ӡ��+������ӡ����Ϣ��
			String DelWSZh = childTrade.get(11);//�ӽ���12��ɾ���˻������С�δ�����+�����������Ϣ��
						
			String setSealTingyrq = childTrade.get(12);//�ӽ���13��Ϊ��һ����ӡ������ͣ�����ڣ�
			String setCombinaTingyrq = childTrade.get(13);//�ӽ���14��Ϊ��һ����ӡ���������ͣ�����ڣ�
			
			String WriteWorkLogToDb = childTrade.get(14); //�ӽ���15�� ��¼��Ա������־��	
			//String savaYinjkdjb = childTrade.get(15); //�ӽ���16�� ӡ�����Ǽǲ��� modify by binbin ��ɳ��ӡ	
			
			String updateAccountState = "updateAccountState";  //�ӽ���17�������˻�״̬�����ڹ�ʧ�½���
			
			//�������ʵ����Ϣ
			List<Map<String, String>> renwxxObjList = new ArrayList<Map<String,String>>();				
			List<Map<String, String>> zhanghxxObjList = new ArrayList<Map<String,String>>();				
			List<Map<String, String>> yinjxxObjList = new ArrayList<Map<String,String>>();				
			List<Map<String, String>> zuhxxList = new ArrayList<Map<String,String>>();				
			List<Map<String, String>> jkwenjxxList = new ArrayList<Map<String,String>>();
			
			boolean hasRenwxx = datasets.getParamMap().containsKey("SSRENWXX");
			boolean hasZhanghxx = datasets.getParamMap().containsKey("ZHANGHXX");
			boolean hasYinjxx = datasets.getParamMap().containsKey("YINJXX");
			boolean hasZuhxx = datasets.getParamMap().containsKey("ZUHXX");
			boolean hasJkwenjxx = datasets.getParamMap().containsKey("JKWENJXX");		
			if(!hasRenwxx){
				throw new UfSealException("���ͱ�����ʵ��[SSRENWXX]δ����!");
			}else{
				renwxxObjList = datasets.getParamMap().get("SSRENWXX");
			}
			if(hasZhanghxx){				
				zhanghxxObjList = datasets.getParamMap().get("ZHANGHXX");//�˻���Ϣ
			}	
			if(hasYinjxx){
				yinjxxObjList = datasets.getParamMap().get("YINJXX");//ӡ����Ϣ
			}
			if(hasZuhxx){
				zuhxxList = datasets.getParamMap().get("ZUHXX");//ӡ�������Ϣ
			}
			if(hasJkwenjxx){
				jkwenjxxList = datasets.getParamMap().get("JKWENJXX");//�����ļ���Ϣ
			}			
			
			Map<String, String> tempMap1 = new HashMap<String, String>();
			List<Map<String, String>> paramList1 = new ArrayList<Map<String, String>>();
			
			Map<String, String> tempMap2 = new HashMap<String, String>();
			List<Map<String, String>> paramList2 = new ArrayList<Map<String, String>>();			
				
			
			Map<String, String> getYinjkh = new HashMap<String, String>();
			List<Map<String, String>> setYinjkh = new ArrayList<Map<String, String>>();
			getYinjkh.put("yinjkbh", yinjxxObjList.get(0).get("yinjkbh"));
			setYinjkh.add(getYinjkh);
			JSONArray jarray = juniDBInterface.execSql("GetYinjkh",setYinjkh,conn);
			JSONObject jarrayObj = JSONObject.fromObject(jarray.get(0));
			JSONObject jobjectdata = JSONObject.fromObject(jarrayObj.getJSONArray("objectdata").get(0));
			String job=jobjectdata.toString();
			//�ж�ӡ�����Ƿ����
			if(!("{}".equals(job))){
				String zhangh1=jobjectdata.getString("zhangh");		
				String zhangh2=renwxxObjList.get(0).get("zhangh");	
				String yinjshzt=jobjectdata.getString("yinjshzt");	
				if(!(zhangh1.equals(zhangh2))){//�˻���ͬ
					
					JResponseManager.jrResMsgSet(jsonRet, "ӡ�������Ѵ���!");
					return jsonArray;
				}else{
					if("����".equals(yinjshzt)){
						JResponseManager.jrResMsgSet(jsonRet, "ӡ�������Ѵ���!");
						return jsonArray;
				}
			}		
		}						
			
						
			/*
			 * ��ȡʱ��
			 */
			Map<String, String> tempMap = new HashMap<String, String>();
			tempMap.put(" ", " ");
			List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
			tempList.add(tempMap);
			JSONObject dataObject = new JSONObject();
			dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate", "", tempList, conn);
			JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
			String sysDate = jsonObjData1.getString("getdate");
			String date = sysDate.substring(0, 10);
			String time = sysDate.substring(11, 19);			
			
			/*
			 * ��ȡ�˻���Ϣ
			 */
			boolean contype = true;
			JSONArray accoArray = new JSONArray();
			JSONObject accoObj = new JSONObject();
			Map<String,String> accoMap=new HashMap<String,String>();
			List<Map<String,String>> accoList=new ArrayList<Map<String,String>>();
			String usecontype = renwxxObjList.get(0).get("usecontype");
			String r_zhangh = renwxxObjList.get(0).get("zhangh");
			if("2".equals(usecontype)){//���Ĳ��ϴ���ZHANGHXX��
				accoMap.put("zhangh", r_zhangh);
				accoList.add(accoMap);				
				contype = false;
			}else{
				accoMap.put("zhangh", zhanghxxObjList.get(0).get("zhangh"));
				accoList.add(accoMap);				
			}
			accoObj=juniDBInterface.execSql("getAccountInfo","",accoList, conn);//����˻���Ϣ
			accoArray=accoObj.getJSONArray("objectdata");
			/*
		     * ���ݡ�ʹ�ñ�ʶ��tag�����жϹ�Ա�Ƿ��в���Ȩ��		     		     		     
		     */		    
			String tag = renwxxObjList.get(0).get("TAG");// ���ʹ�ñ�ʶ,ȷ��ƽ̨ '0'--ƽ̨��'1'--�ӿ�
		
			String guiOrg = renwxxObjList.get(0).get("guiyjgh");// ������ͱ��Ĺ�Ա������
			String zhangOrg = "";
			if(contype){
				zhangOrg = zhanghxxObjList.get(0).get("jigh");
			}else{
				zhangOrg = JSONObject.fromObject(accoArray.get(0)).getString("jigh");//����˻�������
			}
			
			
		
			Map<String, String> map = new HashMap<String, String>();
			map.put("guiyjgh", guiOrg);
			map.put("jigh", zhangOrg);
			List<Map<String, String>> paramList = new ArrayList<Map<String, String>>();
			paramList.add(map);
			zhanghxxObjList.get(0).put("guiyjgh", guiOrg);//���ӹ�Ա������
			JSONObject childJsonObj2 = juniDBInterface.execSql(JudgeAccountOrgBelongToGuiyOrg, "previllege", paramList, conn);
			boolean isAccountOrgBelongToGuiyOrg = JUtils.isObjDataContainValidData(childJsonObj2);
			if("0".equals(tag) && tag!=null){//���� ��ƽ̨�������ж�Ȩ��
				if (!isAccountOrgBelongToGuiyOrg) { // �жϹ�Ա�Ƿ���Ȩ��
					JResponseManager.jrResMsgSet(jsonRet, "��Ա��Ȩ�޲������˻�!");
					return jsonArray;
				} 
			}else{}//����ƽ̨			
			
			/*
			 * ������������
			 */
			String manageType=renwxxObjList.get(0).get("managetype");//��á�ϵͳ���ܱ�ʶ��			
			if("0".equals(manageType)){
				/*
				 * ����˻�ȫ����Ϣ������ӡ����ӡ����ϡ������ļ���Ϣ
				 */
				String zhangh=accoMap.get("zhangh");
				Map<String,String> zhanghaoMap=new HashMap<String,String>();
				zhanghaoMap.put("zhangh",zhangh);
				zhanghaoMap.put("clerknum",renwxxObjList.get(0).get("guiyh"));
				List<Map<String,String>> zhanghList=new ArrayList<Map<String,String>>();
				zhanghList.add(zhanghaoMap);
				if(contype){	
					juniDBInterface.execSql(DelAccount, "", zhanghList, conn);//ɾ����ZHANGHXX��ʵ�������˻���Ϣ					
					juniDBInterface.execSql(addAccountInfo, "", zhanghxxObjList, conn);//�����˻���Ϣ
				}	
				juniDBInterface.execSql(DelAllYinj, "", zhanghList, conn);//ɾ���˻�����ӡ����Ϣ
				juniDBInterface.execSql(DelAllZh, "", zhanghList, conn);//ɾ���˻�����ӡ�������Ϣ
				juniDBInterface.execSql("DelKAGRW", "", zhanghList, conn);//ɾ�������ļ���Ϣ--��������
				juniDBInterface.execSql("DelYinjk", "", zhanghList, conn);//ɾ�������ļ���Ϣ--ӡ����
				/*
				 * �����˻�ȫ����Ϣ�������˻���ӡ����ӡ����ϡ������ļ���Ϣ
				 */	
												
				if(hasYinjxx){					
					String zhanghao = yinjxxObjList.get(0).get("zhangh");  
					String yinjshzt = yinjxxObjList.get(0).get("yinjshzt");//��ʼ��δ��
					
					//��ȡ��Ա��Ϣ
					JSONArray clerkjson = juniDBInterface.execSql("GetClerkInfo",zhanghList,conn);
					JSONObject clerkobj = JSONObject.fromObject(clerkjson.get(0));
					JSONObject clerkdata = JSONObject.fromObject(clerkobj.getJSONArray("objectdata").get(0));
					String kaihy=clerkdata.getString("clerkname");					
					for(int i = 0;i<yinjxxObjList.size(); i++){
						yinjxxObjList.get(i).put("kaihy", kaihy);
						yinjxxObjList.get(i).put("kaihynum", renwxxObjList.get(0).get("guiyh"));
					}
	/*				yinjxxObjList.get(0).put("yinjtp", "AAN1AP3P64aFvQ3gAax1NLYQt8rb4FN0bQ3q3T8Tq1VZSBLctUf2i8hWr+8k3oUNhuZgvl4F6QWL\nSKouEfHxzYWJgfnhbqPpWK+xOejNuhZFiqqjyU2fNRjCAmSQ8DeT7d7b9/sYkWpa3D56ALub/x0k\ndPw10ARPzP2SmPCvI3+T8bW5F/0/rfgCVL/Has/oZH693aG94tasAHEOre2Gh32Uju0TAsz16Nkp\ng1OG3BCA7ieqcA+AOvWzQ1k6DLOKpPZRkE+0mYyoh7ioT3OXBqfkM0+4qMtjy0ywlxspTpsVuQIy\na6eRLQICeYAeVnn63BZp26RY/smmjIZe8cr0kg2c9GOutbYvMjKsa54FbbIUA4B39Pb7f+sbIcCc\n5EOb99pShuLcQYzFnMpPwtQzi4yzi9h6klGJqX7TIjDHlaOj8cmamVoXTPKnxkyGwyaL4+U7aYMw\nS/+OvZvx1WblKvwk5Rmh9kBT4vcAvP9xRKDsYa+zRKcNaG62jUDhhYthZidTnwOFr1GW2Obh6wAk\nGFN0D9Z/QZfKg+268+HHlNg76oo10Tku0XYt8yq568h36yTx1e7ora9UH/HoYDd2+GlMU/FrPCmQ\n8VdDDvddW+ni+kEpNhIi3sxn5FnygJ/Jz+/Ry2hnYxPlgHLzlOfbgR/o7AnDVk9rqfwwtQR7FChy\njh5swW0hn5VCJrgcmBZ1Un9WE823UYBpI1VGcu6npG1Kx8+iExMx4Ra36mDK3k3KO1BDcvTwtgsx\nWHFL/qjH1je9cui6KvxU9p09K3J/WYTBAw+lTOOhfh3p3ed83ZGNHCmS3aJX0+HNjgSTZ7LeKnd+\nmfHIpEzaLz2cEN7c6xQOsV/AVNvnN+Nyy6ySYtao/Q2smKJeJBwkbSv6mWwgdkNKvcskKs1Ry1fp\nKkU1L4m9ksVpTfib4//aanSdvQgVhOJcC99kOFMHwPRGUL3AgFTpC3FNn6VjmtiwdzFPlaT2PpVo\n6MSvR53wWXXkjWdh5pWL/YzwcScaUbeE+6POqG11NOID5yE3HLSA3LBcFDVeILyI0LUmC9z0NnxZ\ns/8mPBVt/VQlmM7LEALacbS/4zqK9Tw0No+4swWjaG9eYnHuYit/wu7buKG7mcZjrxCuW/GWQItr\nAYRrdB9fdLPYx/h2SGpTel/rmoTJhWxDcnPXGqYgAwnYbk5JantjspBPmPxH89Rt/H+t3RUNjkOb\n6hEuijv0fQkmPcmqAg8kaTXSHwWN6hVARvDjUc7gTSPOGpMcjKVqGiOnOpLbKDZB2j4XgAiGYYL1\nPWHZFXPGqVcmjBlSCk2Y3QjyqLaJ239jf7KYp7BzFX2NoJzX3eAytf0lSI/B5T8Xs1j3RxpdkEra\noqaz5OO7MjZDUn6jiV1Rmu+iyeofi+wjVzGz7kcJyLJlsH8cLUb3u4NMPBfz5UZ86Q82SYm6EeMx\no6jNN40eZYPynIX+B8aPjUnAB8nuXVCz22PDmAoRuUA5PM1xGwxCiUqXDmvn9nJvdmMQfxcVQ/7I\nL1padvGxcvps4h/Tl01uz262YeUUeyydxbu0YK0oxNVcFf4GMtPPzBsmkbTvaKVtvmqlKkOTfxvL\n7GtoLU18qbDp8MfdCDC+oIDEo6i/wAxiWEJET8jjAIdS2lK1mrfqGuVOlEds2NgMIaP9FBF6OvDI\naq8cWiRBusk4/v4La19Y/4aYp+FlBlyzDFo3hVTS+ajKECvD1TcSWrP0qYW63GAPhqhFXHFvu2Cx\naqaXgR2d0crFlJAI/Q1INKMQU+OBzoApwJUmIm2QLRfg/dMEYRIWzb39aTLX9ggOkS8edkQbwz0T\nAidhwh082WLI2DSwOMoOe4hP/B5VQbrX0RGCSM2W05RCq1IHz3rpMGzsnxmnUU9MK2MeeGNL2wJO\nBaxjUW9ML5ImV91SO0D8vQrlycE7xIwUe8rFLMKUh2ZaBIteJWDCXXEpQILrLsZSdaa7wTBN/e7h\nenBJExgk0pRS/Aor4LDkhur1ak1Fp+mgHGFwGgkmCza07wXAFcQhLQREcikfhCYzSS1LCLrg/jri\nSFpxu4Qp52WSvEbqou6Cj+tCU/q+xPl6QdDwurx3+/SAuLjl7JJv9pLpRhh1Rm2gePm/Sc0FiQf2\n47FPEYaLcLhQ9I8C7JX3iTwBMUhxDDph+RScKiRMhbtckK6SpFdLM2tGI8y5A26J7z9qkiGPuTH4\nz2uO5mVVOr7Xs2INctqTLhoE5w0ugQCjTwvPgXh8QZVPprszeDUWVBUwPnmdESF148UJC0evY5S/\n+V6icsdhQfabw3+CMivSRzgTGvP5wjD8K3TtmB7J7h1P8RDqIoXjTPKyT7E+HsPoOkmmP1/IrMct\ntRgMBZDgvkKKdD/dLhFtL6xwjNpijC5fg6LHqs6f+IM0GZDGVWNtM0gPz3SxAZBJmgwup65Qb33f\nkE5GRk5H/9qHQ3Q4XDxeM4uEUmWU9szNs+YbEscvJlBdLAMFwqgGv+U8UJ8aI0RKi1ApL/BjOBu1\nuKCqUy1x8nMNuIToLjd3jfDQZrk/3GjPZ1kaB9LIqTmMhUencjuN5Sc0zG3+JVovJTGBoEkqlMRy\nRBAVlyEDb3IxOH8n7pI2KdC6or3Krj4IG61ltygekY7rUD6IBdBxCWMo2eXdffV1a1Cjir3y5nY6\nuIYYfgN32del8YHjoX1HEmoCSLWxOvDAFf6mDhE6y78AaZODaIbwmAMWOdScweQoVb0hE/dCdN2Q\nOLSzswRoX/jUW2MXTecBnijT46eZdr3NruQUJU7QmXDSV+ddkRPl5DUqOt3avTRriwVa8RgeTxQG\nhMW0MYzyrDp3kbnP8eFF8BKsA1VL3jm8p3+FPBa20L6lJDc7nczlAeEn/pLPugkfIAwrDXM0ACUT\nO6q6ra2L4rnU5wWBgUnCoAvRK/DHZTt8X1MGWA0o9MmUDf6ICE2dXVXH9sIezAZqui87KqWU64M1\nzPmEkxP455n92FRQdxV4kmGlFpgc+TYwWkd4LQEhK6JDl9zGrKyUKIpdlSFEL/9a7/9MFr5S4Mqy\nNxds0jGhHSfJXo7H8udvsXwRkrfWUtc3ANgtt3RDghQh4j+tjvVX1J/+VbfkPkyePfqr2SoRykWi\nqfeUNpm3+LLFayaGNMhjOKLCJcxrwuOfv1JMJD5qzPd/McmfM4as4pJoo3Czi9wz34v2rNpFHJ9f\nr9W4P7FW3xw6Y4S84amykRSW0ARSVdx+8kZAZJmXFWU9j+ICnh5vHNDiJmj/sS2FXt/YYo4ZQKbY\n18mBOSJ63g2Nh38OBit6CVJlIKCONfs1+aCZd6wWs1cl/Pra2nu8wUMg0uYlX6DjADrB/kLEJ4Da\n4QPnLXI2hkGC3JmL3DY7LX9eDL+b8Vv6nfDLRZWu0ra8PLvRJ3lo3fQB/pdZsLTBVtB9YseqfNfR\nvFHHEAg5HCh5pZDmKcdPuJyIobkWuS1OhHKaboUVHqRoAjOx8P4DVTzzoF9ijQNKrDvcGshuozst\nOi+F4C0J7uRyB+G9+RcTLumtcjVX0HU3XJE1uJwmcaRm8Zxq6rvXVPgPkn2hUtc2jbsXiWDjR4MW\nApG/mNClxkBQKOgtDIZXywMPhtCLe3u3pLGXCvKoY2yTltwXo/zv7Fjp0l/juI+WJwmjYs0UNaBp\n2U47L7MIaMHer0uba0DHQxAOOiivr0dF5VjGg0oPJvE3KP13YQcDgFhpfL3A8rDFVpEO5hCE2O03\nSmOJYZ0uk0ipKR+GN+eJckQw4j1jA52kHeFnkvpscS3uHeFqd8PHDCMxzZhYJpM0XMIVbIQN+xS1\ngUTguabkE7KOcm8SCE2+27jwDs0DwJoEeLFlDWtHf938suoVWonoR453lvG6eKGrfcvzCdOXsx5n\n0+sjFStRQdC4YQhrrLxOFPO1OLWiaz2quL9Deok0KbJaAyrVx39CYZXZo3m5J3xpYB+cxcIfJH2V\ng7LRHXCKa8H3Z3E6MoOANz5xJ481I8Sgl4yGP57noc2ZZOLm9VB47m6apTPvzSJ6/HDQ1/Hi1ooh\n9DGMQ5YePWlfXbx1nU156jtCrg4k0s/UQ89PBzRT+eCkQUGOCNWnLuWzgfEDzCsx9cpEHqAW/p0o\naM4OwZKeyIb6BF0CVRV/gZuAu9XnbCbT1xXrc8pE6cZWcotmP36mDm4Y1ttlf0z6Ofm0NY13WX5e\nvgcbFCyoAkKRqzwybfBQQr7JxzGhHXMRMxRZ21YF2JVIOfiD2KkdnRSRLpSmjA3edKuJVTjWCMKi\nFMLMgGKalwU92LP7DW38GoAC+Mi8krKdxsVir8n0RD/GjmXytfsu0My8UZpDL1E7kGDQS2mM1P9V\n18vhcDrg/uGxqOIpD17ZvVDuUfchx9QfqVDcvfn/vYFMyBAdlkbwVrWc9LeyN/7XyOoM3hiB2BEK\nIUeH3rQs6H7jK1CqI4F9oc0aVvJPLlyGYAfzHDj1I5ZDCggDItWaeSi4ftuhCSMM6KyssLiOpMgT\nZKamat+o5IAaijaL9x0hMWXeOX/cnMmf3J7GLlzPrddNAt0wkdivnS7uxXjXOv3rMS6uPZ+e5uYy\nEONtut20fc4N04acDiFPalXeCK3YxCpQ1X5TnTyE0OaHBXBO+8cHYbAWiZI2FbeI9f5Kcj98XIZH\n1Ld5f/JiODh33YZPs2P6/OTD8CMvQf/FeDS6FQWmvfMbtdNWNJyw7af+M0TJGpi67rvA2dokcx7g\nq0FqKMoE0stpw/liRiyDLWT+v3CdN3zCnncg2AoxKFioxgZ0WXxt2zGE8tDQWUXGFnWW0p2defeM\nHBFY10CWJm+12kz1wjI5Zee5teoOBIwGzsJSY4cEO3BykR8eyeb7n6Ly3A6CxcvD8yYxoAm4WdFv\nrBvDwmySLJ0Z7B/OLMupkmXthHrR5CZNNhDBsGZmuxyWCbjqdSetE6z629LqxDz7KfD/SbvYDr+d\nFkNKcaEEqxUlc8rHyokZNtE0O1P6d7xd+cV1HSMmYv4SdG1W7YxGSOhwZZe1WhQoMvaXvmDlqXkJ\nYrc4pqn9bzShlucsgGE/h2wJHt2xifdaWRd7V7itWX+q5PH49cFP6HTr6ZdfdFTmRneKJN3nF7C5\nwpBp5LlAw1P3GxjWt0w+znwstNwWKnQ59oyuNWUoVl+uT7mxdDF3aXYR6o7PF9vU0ND46wEgO7e2\nUftiCAt/x8oB5vZjojPlnKCJVl+0mYVBdFeEKALbOVbxXCDO2pPOzxbd/ncHiXT9khZRQqVry9tR\n1skHQhgyupHYIyOjBjKWrPdHn3fz4UKkojbnI8ewmLDwD1rdG+g7apO3rSm8pv+ftN3onAIQKAjF\n2kRdmqdsWzo0lPJ+pcK+RZ+4IXvHJRRiVoqADjSEKjIyS0SWsvyfmvrx1wF6qEk+jSPXhkbKUtRJ\nqUsuPhCYGj7swRejf1ZbKO8tI01tTFR3SyMxCWtcRfLcLAeNuwjpAsvAmViBp7Sj8QcD7l0PwIzp\nuXPlBusutOVwnpfv/7BDdJErqsX90stFfscOVc0HGoSp40I/Cn4zKW55ptdDx2lpBsG0z9xdMeoo\nW3UZVgmkcskxOhztwaAG6BluTptbRycFYjUWJTl8RwfubRobsXwes9yeMYvvhf/6HDQHeOSHyJCn\nX920z2wMNTbjM403fwkWJxFnj1TDCNoN3lryOz9b7PucLae6QqSt1AI7U2U962i9FsDebaIm9/FQ\ne01bFaihGWPBDQwr/LewPPPu69vDxVy+f7egHTnBqTGVlVqV84tHNNoAK+wRTH6IaQ38aM8pVagp\n73UsZqm2vTZEXsNpDuGmgsUqFkzGXLbtcba0eivo27F0pagHlItoiBCSiMmLwgEZBkhakjxyWeIA\nUBoUmpB997vjI1NtTc4aUA0VBiob0qgXZ54P1h0PQW1ktcPWRdKKZfQ4XEIxKTUn3UX7xhMbCK72\nI5TRRPJiVlb/7qjyzuvJ88kK0RCiMPNJ0u0BDa2D3EVZaVPFTtYE1niTA/2T5e8n5c5vPex2s9FR\nUFvus5u6g8H+WS9jNQy/u4Yqh4WEREvtFgpI2fCbaE0tiUlx9RoihTTiaF1SDJJWB+jVhl51++XL\nxhrbl3a/AX7o1p2/klC8CgrD2I+IovZXLj1mvjhrTaiR7IyprLtwzEkaGPHHrUKvqJKC7IBslOU2\nySJ7vN8d0fOzk76zTEIg6nlRXRhEyO1a9K7oqA6y8WUwyySA/EmySlMx4xBShAGoyhj5jlqJfmGo\n0oncW+31+TNIYyWy/J+hBEZupfjmZDliKXHMnPz/oHFXuRdB7WtkF66kbMf8Syo+HPaRCUCSCDTb\nNt1eGYkafZz/RKFrPrRqkPXLqDwFemMcqbwM3m5IvKzvwDloRAcAqv+Kbz5cD1uSDQVF3JDJLKqW\n/cP9Eua+/sgc6MQCDM6hGKhfV5Vz/LwUAKhXICHW7JL0VHDJQ7mU6VB6isJu5UyPIkpl/oOR0Ggy\n4q3FOEw3uKZL5cJFjgARpJ2W6XRoHJkij3IgFj7F3o7QODeX3Sl4LAae5iqPbmn4hoQG2EnQpX6y\nDjOn6N0J3s00I4soWDg6YjIFJovn10GfPwB7JkvmmoLe+Mky6Kf/q76EsV8U0UjvPMc01hZz/aeg\nPWYd5RIzgjOMpF6/JwWwgANAburBGya53x6+GDg200Xz4BjfyHHuW58TKMlSHkwG8JhkyS9RDUdp\na3oI7MMYz9NXexRDDAU3nRM4wNgNjzlEsbB3PZS0AdoEtc3/W2MtwB5J9761GWEN83pjR1HjYccf\n7rhgkivj6shRuDV3TYTdBNBO70bSEd9o8174dBm8lHtkbOxigX/OxP8TPwBMHrRjWibUh5jg8xFV\nKf9U0HH9FyvjQ2t7w8kF/kEyUkFDTNs7MCAyWuYA+N6qiX2UxGQGvniu/a+MIAJ88ixtibP+P9+9\nkbhGI23QyIWTRIK6Z9tXhvYlhcR2JQJiXN6Is3IFh5+dkUQtZLTwLv+iExO3oELP6i2a/ESoFRZc\nAUAyM6i9CC8ZFpcN0LzMjqviiu/nUrPxU1C8SOcZyAAIJdbQ3Wzwy2vUy20BDGt8bTR/6MWMPaIh\nitOAV2f7O3XU0yx5J4CuYsOT4NJ2EE4vMsOxXfBQRDVFfzBmZYPv48O1JkQmtmHjxBwDOLvYs1As\nxlkUPfPL/GWYQTdLPkJMOu546dzQd9FOzZguiuHKxdM7cocBvEVnnFb2Ct10vTSiMdw0oZ3a1D7c\nB5PbBmYZhfYuABTHNZDELwUiqxCNwpSXDdd285D1tKLDyh9Ik5e6+LRYkfCE9Fssf613e8c8iv7A\n6zJBXDFAt4KECvhzQYhxBNFanoje0dFEZKsa1h+65HPrAnCRrMQTxCug3qflnnLbi9iCkDgJH3li\np9p/LN9FcnJErY2OUIpJRdrsLUkTi+4Csj74Z4cXNuGRyRM3OGt9NwS+4aVVLRvGCVqFL67/1+bS\neZSHc/fiYTzRVYjUBGCFAyvFgAvOx734e3gTARyA1o8Bgze9Bc7sNj1JFtjpo5mJCMmchZcLLy19\nADS+CaNqnmgCKPrU+IM8Zc8SWl/IczR7aPzG3JmWyoH5hLK+uoL4VcISblwYBMIVdqQ0T0aS7xYR\n9HqbzadV6FkWhjfdd5kyr++de1oMZvcodLTsyqf5KlRL7QlOv43mih+0iMMwLwpUhg88xaT1WJxO\nPtFRyf3uN8rfclohkadg1sXgb2QCw2Ew84nbgdPSZ25yw5cx2w8zt4bhXAIVC8u9GJa6TtbvwiGV\nmYwwCy94FbARr/wQ1H8AGQOw7w1MwdKxNp2YJyQb+qgf+BB13HfIa+4N7o72DmKUnQIvbyD1gRl0\n7TC+wieU08/FREw7qF3ie+JFJF8prlaKtQZWQ76S+esPVy4QFSXyfPoygkIA5KBNGhxjokD2laOS\nxaQen2acYJKu5XbNkHTGj7pYvibAK9e9f4yuh4cEhtbHy/aGuthGALO0yoeXw9x0fjlirpKTmQ87\nyF7pi4HV0a5a1OFwNR7R7/sz2qNWjucqG2HkhwnZEWc1Ev1tMDDFPm0WL41kyQQH5yYnzhs3jV4U\n/zdi5ARl+S4P/yW9pccVi95ghSjn2hf+Cev6TEc0DmMlqt7m8N0WVz8WPuVda8XWXP/JuF6jsSpz\nX6xC/Q694fgB3s4wdwqT+5V8t+GXP047oEAzbQwRoz0N8FmG/91kZ3WtdlZSNBbflswU2FQFzHpS\ncIkjVk3jeuhCUb0snvR+iq0u+6LA+UGpkl4GxYvW3UbSi1JZHrUbp0mJmQD6vyQ/nxMBnBM/2c8V\nmnXZ9U3BbbbdRGP9zpdxOY1HJZhgWDBRA0et8P7jSat3532QAGbKa4Sm656YAEVhNC77nEVgSJsZ\n6kmrBMWzqUuLVio7gqy/gDHYzMBOXNdpcKPZpgcdDVPySaMBl3jnEqR3GEiJs/MPMEX8B1mcfVN9\nmOHXFLrWuNgYeGZSEh+27Z7Mgw44dnUnkGF8ps6MuDkEOzcKZys+HDLzzlKINwCBCzAQADlKMJFy\nh8jLftIOR9dcOAX3GIOzVOxkCFZgyma2CQLGB0y5fT0kLN5Am2oKDT45rlSsraTLoOJlPhQvmRKR\n7DrvMtmgBPQv1atIHZM3esI3ZSxybVT5tL83Z9Q3/fAfbu50dLsos+2FWVs9ZaF/6494n16QfMKc\nufhtzMPCnifzO70hF1nL/cLma8+g+TvTWQj9lNvLRDfmLT2r+OcjDhhRHZNmng/0HHSqo+asX/0e\n2Z9zXGnL7+j8SU+MJRIfERlD8j8qFLdthZpe/DofFnjdr24hx2b5/IU1Sv9G4oY2HahumIESTWru\nYG95KbRKFE1/t0wrn2VHdJtwwoYQTZTviNLGmM3YGjyTYJPz+OywKXYNVxj252BZmn5yJiZ92YwA\nq68MYkmm5Zu9kjuWuJzWdAr3RU+/FlZ054fnkIL/gDBU2EkfJ452CPc4T8lN6LQaTamPq0Ncp2wO\nXYXr4H208EvJ0FTZWQ9cyVOVWEqcurXfUwp6EmoS6L8dRZH6epRSW3I0A0fAL4FV9TueKoUd5jMl\n2zEgoa5lds5FAM/J2F6LlcTW/7M+ubxnl+A4HTm3dqmVLHI/B5c7eqoErRdaxvJI1nEoJGuZvkJ7\nuk1K1CedxQ1Fli7rXhvgzfRUJNRNWu529ak3h10kRBGX6OAzZCKtyFjEgPj7LrIBGPBJqitSVPuI\n0Mc/sp0QCFd1nHv55QXWa0ul5BiSaqijywJrqZil7RSyfKxO3zkbNdqMkHqMJFIvEsFAz1Z2bpfA\nbh/IUgiZdThIVzQioUFRl2YYHmaM2e9DvzYvxDszx+1uEpto97i8BoQFNbynsnhEr4LKRPvIqcaZ\nfABik++8qyRbwmGQ0knAaTb6E1kqE1+RfAel24EhyGjz5QgZxAeQSJf0nPUkoxh8Gk/qn5x4ggwq\n9LP8WvDDjTHa0EwIJO8wMZPRk7SUZ+docuqyYjPkVoToCaf1DgxnZdyOuE71IIuAy100HgOeIomC\nH08/s78MP3WYfAYWvtITX+Wqihe01gPLSI/TQw51JGn4kzjbmpViJzKLTTsLySXQzjSPciW4+WyS\n+4ueuzi7XDt+HKM7hsRF/JCV4bSQSIwIWHDjzdjZTWcZcJBI6B/gdvZ8+vBSOWnffBAsdCCEtZuM\ntsc5iNsMUA54bQ/1Oh/VOZLEzZPAxN+mvlV+BH7zFaV3tYM6L5RTsKeyHRP+9WbnCKfEhJKB34zH\nElGvWTbGgnWgodl3mZLD//AgDwxlJRqGdMcz9Zs/OkWNefDw+8pbkyi3k68Q5uRe+0WUMH/ziD64\nK21tbrE3mVOwsI05XaD4uClGHGFqOslkDLdyMfbhJhVynGJzE89f7ycElJ9usT03Z0TSwrFYuKI5\npc1Lpz8fU8qgqTafWaXQhkOsyacXl/haRZvOgzhWVLcrf5gF7CIphfruqXVQ56xA36Kx6uwzjIKK\nSgx7ZRPyxC8oxK5RanRqdG99aQB/zDRbR4BIPgeLaaCG6U32cwQ3+//WDlmgVCXw9C9GbvOM5vEi\n5PGN2otsLo80fOvN9SYK4rWbOTEXOLCSLU46kDFPjc9bfaL+1mZO65WwLLYnMlTKIXiekEMST0YY\nC96KRBcTWJdF4yABj3Ffefb8JBhJdDM1G5hwMtEje68P5nkBUtsbNRSfWoDUbvcWemWPoumvTdgE\nJBSzawyMs4yekriyXvSwHnC7M0tPWgroinfoHXn5LBh/JtXm+bBnLTHUsz+08Ix7AzvC3RFhjb4y\nPLHs3XgeU0QYlEGIB4rjMy1l2GwWSLcq3LJ0swSgb5AtNFjjIKvkyvm2laeFrcCQp6CZBWZLAqi9\nseU1IVBGpxxlQ6PQ4kZL7vpQ1CQv5v4QdyK1pT8pVXGzNYtI6Fs0OC459805kKE+lkzJ51pDyfz5\nJRgp5Cy9eNUz2Zrid2J+dl5ilg2rAJXYp1wBFi5mbAOmTcIq8RqYL2Hu/dfvK0QWjWn4N2IwVITN\nJ7OqgCzm5kp2iNjVW+GNu/xdvR2Sza7QVE2fWpcrBiZ6qBjbQt3wbsj9Vu1ARjAVQye7wxFQJWgx\ngA5b2ThMPOnQbD6cGPjk63aNMev9/YE2Rml3XtzQ2IBHVIqyLq8T05TvUpBqPHS+fnFXAWgrGqpq\nZECWwUyAslGlD5t0ftyIlbIRa91CH/4T5bFWB7IwpfUaNxL2icN2s4RxZalDxP09ajyDjw0cTS2U\nn0UDpwB95G3lbvaffauacDURDgPr19t8e4KZihyqjwPjXwHCAYaZV2Teap5CkpDl+XOeQsll7Umy\nGLLkOe0qT6oxIzwraD0yzPORi78f2OetcEMqNpOWxt4wq56JtOJqlUZhjInqgnE9aQkgz0QNk6QT\nGKtdYPve1TYqPucoxuefbMgJUSLInPnS4lXALJvMrGYrbcbRN44pY3UTUSHASOrn58Fx8oH+abyj\nHfTXHtrULwqLq+9t0dLLnrGp39cEIh/UgQEpXOKe34WcoCD3WxOsUuNIPOTdESkkpeNPLQxK4oK9\nUQlzmSVAt8BYLJSGrWeZ44LabcWaWvLgjD1d/VVpjLjVcrsADHm/3UZ7MGNMJAqBL9k7lOQ730y0\n+/83ula99+e08gDKmg/qfHCR8P7HvOc+0dBvIM/4v9w5gdPCI6SoJ/Pjk7qve/23wMDn1NxqC16t\nQsJq315ktsdDD35aTJVYVMTHLt7wTAI/FFTM3hIs6XFX0e+YZszZTTuKB01nCuifRNaQCIyYXd8j\n7NeeLOt29isIugUCg/pbK3dz/MPUV3Q7eGFjTHwvQLCNBpmaOvJY1/luFch4tCNyC5gAzqD7mhMi\nCBdTTI5fHWprM2Bem4Hz0iqNfuFnL1pZDdePjNe/u3QxrgkErvK/YsgwnGBN9SqhLSwJC36G3PmY\nLbDSoldGgjSNgo2P4lc/UPaMMmPtnoNXS5E+fiVz8HpLJ/sdgI6HZHr2HJSMto2RA7FwhlcWoIZI\nkftKV980uM0+Bkey+/H9pQ0A4rObriFKRSzruzb0yJM3F7w2Ejru6SG9CQtKkDUglaUy2thc3egK\npwuHvSZxXA+yHRDegDwh+AC3LTd+ijRd1autyZAEKY/wjFQAwTrEzJ65z6eoDcN0+x7m/vn7wCGy\nvynkLhwAeY8QDo0fkNZmNAiKjWXT3eWFcnCugHpAISz4FoscjJVX51SYHCqYzZSQ933ZrnqPs4yb\nZ8rDHA8uZ7VmTUM9pmHE3wkQnY8THGzi0Wm6RSuliaznwkOH8UzbkrB3ALDAD5tptmHivbUE0NtG\ntHINm7j4Mxo6S/ZIhfHm/197S7nnxNWIHbhZLO+5KLtbL4/4F0i+JInCo/r1e9ulmikLttSBDb+O\nXErkluJ0gjVtnDDKui2YtAce86DyMA2hJpQ6Qgp+ukUC3Sz+6JD3VcSvJPlHYRXnEY9vBR2QemiK\n66Iy59URd0QyY44LLzf0KOSAydXx11Gdbgz3UHPzfDSKWkAtiSbfHjnVt/71wg4eb/Pa1K/2ZZQm\nRtpM5M6EWOn0S3RKZgk+s04HD4sATSiVhjGQfntWhDR46N/yhvV3SiPBTCIl0JUdQJ+HQSOSBxe7\nVpD+L47RGysXBaX0TsvjbgoDJhuKU3pV8cd2kyCDtgMW1Goen/pMlhadYK5JcJgfxG8zOwjVb2xn\nxTadx8aB5TgnlYg9Lc4Ywie9QtwFcgF8F3DrUx3GUneM2HIx2stEe5LaBrzjDKlMOkHbnABqaBq2\nb/5sbUibPjU9ZlTkIQHfoRtQ/+qcs/F3v3YycoqladFKsM4WTHt/PbdKUcDKtF9RgBGEXEx5vgtP\nhcXq6PdMJbMxUjKjD86ZZzhyvI/aACEpc6g+H4mji/adaXZBdH1E+MLHKo7lTtEqW7fYCInBEBN9\nrUACtqaUw8J3FIXflvHae/nvgCjaxgzTQmbNqf6WlFcwtBQK0lDEDGPYHJxiktVgvjahVd57Ca3U\nGtNvqdg77D6SQsRA23bhPhHROofSkAnk8kUMejV8UCfrWNxjdGOOljyRmezcqWxv5eKOgAOvwdor\nQYFg/Co35IdGCqTAsZRszz24Efw1UA6dpBFbgxy1j8yofCGt1LPLAh4ZZV9zy6U1iuiyNPsEG5za\naOEmpDHFgFbbumw7rx7dTL3mT5iLynZNZyPEe30IW/Xx8Rg7kG1ugE4PdFcawNoNo4bfLOgOaszx\na0Rvm/U+he2Dwov9Les/VIwbxti3qDyuRw6eN5IejQZS+0ez4fwbnRNE0JOnO90dTmO7wdRWQ9KI\nHcqw2IGBnLQTg7okq/IhhCxraxYEHQNM67H7t60ABYh81em9Ezm3JiDsxI7XMyrWZuWVa05biCGT\nTZQtMjA7SV6gfAHJJ8aOeB9N7eOTBiaI4YOg1xWO8Bqk2YrW16E3bc0+psw259c6uNewztukVqF5\nubCLORTHgmfoJwDe");
					yinjxxObjList.get(1).put("yinjtp", "AAOUUdR/kRqshuJWRzJTDMe45eyDmbGotQJvIpDaxee1j/ZHELf246HpYu0Bpdg/C+1w7Ce8Br4W\n/kDL/MapDI2MktJHfVVAvMgGTQbKE9mWx9yT4YXCUwQ+V/fXsGMBlFLnyrq+kokXnskGOITHN01p\nJs7WxD4I6I6mojI+N0vAzAi+KrIy8y5bLyFb5G54DJhzEnU1iMDUoXm2BmksorVxhs3CcRKXUsqu\nN9LbUALgyBS6WtGQ9jNZy1HCOARElsxLsdhTKh3aZNGK80L1n8DcR/AOL4osXbp+F/mhX/PX7Thl\nXO1Kprh5BS6tE/H8q8911qei2SNwnAJnDakyxPpLkiNgxebbEWxyyKi9aXl2mp1DiPCM1112pNFe\nWQBPr8sNdVz2SKzLitp3jQq0G6NHA3b7ejTMCV3OluekOqmEi47IvZDL7SCyfVCrItazH9oSHZwI\n3YHDdmsGebJwW5HGR9jl7qVZfVLJDYPlNuPvb32XWGGU/YDBvAoTJMrRymnypU3ghZ/1p/JifxqK\niY27LK59B4zBv+Pq7OXnYBq7YNLv60WCxmi6p2k5DQcjZsY4So6Ks4ZFueIi0yca8q/wc+GWuabo\nJLOEALn0tRiw6r2u7KDEGgj39C3nSlEMvQnqenhB5PDaP8odUCK4563pZWlqNS2INsgjlTGOW+7y\nOj6zZvpBVPAlDjkWy1sp85ChJvJHaScYoH+aWRdb7Z+vgEp+0MYaDWppoy9UVA4S7d8FW1suGOq+\nwIbvgHUoiprw/qGFcZBHUPeI5KqNhrb3iuUo+rnRsJdL+HtigO2TbrjgJPwhpYAYsWIpQfDAcWEy\nChk0gxZzJDrJBd0Cxf7JcYpe6v1sH1VejU88VqE3mtUpIeV/LogQDAalN1CHIc8c4yGJXK6x6Ra/\ng5XgCN5g6O9AFYyCo3nL/ZrgMkq7agva6LEbWG3jM3IdFG67ytvS0KoSsujVNzga7f3/XheRQG24\nj2s+YN1rr7NU7uE25zj02MsFnFob/UfXeL+X7ZhdnKD7jiA94aRWuAgtG3ySVnVWFUIw5eGWv4Io\ntj+cDHlXpic06nQuN8R0Bj4mvNTfNT/zNUqO2QRmt0SsVJsFWtrcZP5UuTSI2VTTVrox8Fh2yEO7\n0lL/l2EcSOJ0oNb93iQ3hG/3+SWSY6CMwPtlObTylq9YAYhu6+HlPdP2QJuqkATTwnE79jev+tGI\nqp7is2dbYWNPcx9KsQOO9xVNtf6Wp3hx+afhAQjUccl3U7f81czdwnI0D4ehz2eoqu1O40rkm4eT\nhuuchZYsBUzeaag6/Kkxs1YiqKkJ9j4ihqx/nq/rrq6qztwhy9a8rO9TtpdP9s05X1Yx2nXfOtWl\n7KqVHgjJu3s4tOyi5BR+qDomGZZpQ77HolsuwMGGuSUXeuctj42i4psqiij/5xvgCWC6NNdzVDAp\nKL8gQaSfhKtQ0uFM39HcEGR4ZVj1vNEV4LbYkRAcJa68IIooxqxidcJqGA8kKrPQ1tdcEKpgZvCH\nUxd+psWkeJvjt89j2cQHmQcXwaKFHaF9EHmiXSCzrmhvNmRQDZ03aVvFxp8B5homf7zJ6xvOTlFL\nWgrtAmeyKrdKci33cABMqY57OZtF1NMS1ATw9Ghoyu/v1NPC9K7s80S4b4eOMVeSOjdWLo3zieLm\nhX7kta4ClhidhCDByCg3IvM36aVI+ublKEH+pSyH0BWtqcgSzABlAqUzRC80iOhKX4dfOJYqLNEq\nFbAigKny7ABTQYg4SSCkjs3G3160QClOgwjUAftDGzlQoQIF2TSg66C6n72uGrGtbmTKImeK3Zr7\nzU/BfA0iXpHf5Ts/e1ShtFhZ9+4+WtSZylmW1K59b7DqwVllFTihr8JE9nnpSH5RTCAdp1aw/NGk\njl7RsyVYpvXe56yCvzrLk/kzE6PddZ4kpP8Bj7BD8IxeS34QC8kd+jNvXM6vs6un4goDEAFDip1e\n+Zt0SYnEjutlnn4wlNIV7exhf/dI7hE5Yp4v7htaEhIh1M6NULKv/V+2wqdHFKhDXMioIUXFJiui\nx6BvHhgHWkZLqkcywiqmyAtF6/aaMUnYV9evNqazoxu2N6q7VAVq9cOg4wTMS/9QHcv8xxPDjU3j\nYtBD4KqXVAxrGxqaTEmKxrr0R5zn/uIB8lGwSYOpFw3S76dfiEz1Hrx30p+RNi28mrKJkU1Pume0\nWmf6gCabHZ1Q0Tz4+afyCETQJzhorPX/ETdVAoh2ZIo0csasEnjHTZVgPznhgASkWeJY/kq04hkG\ns80/WEAn27dWyv/efiR9bMHxgWazF1wM9hmKaamGmKYH2SfKeU0jgouJBIlfHUzbrFcfqbagAgUx\nl1nYsGJt4SWEAtFHLKZP/nBQJKefjsBzfuTf6NQFc7zSZ7fYjjHKyMtwqsWGBSto6cS6y8PxgkQy\nkt47jTiILqdHK3cczjzQtufZCsmSb/IQgzBmq0PYoiqH34g+ZAmlLrUL+hEqeT9JUeqzpbbWqrta\nxMj19cGfGp8fYgjBkE0I1RCnzQoiYln6eG3SXjBTPVRhqSOQdRSLzjsoHh2gRoF8NkJnSVPA5oGM\nCvp630cjZX2ziG51ta0cO/gn7BRo/bDMKxmoSEqztV88VKAeW6uLLWPQMWQaxo3f/iSCam/2CaQO\n2i4I0cSywgDfaWOBbvJieMFCmd7tTTb/gVM+olSrD24YhkC8TrDwQYYi1dmSP36pX3OepuHwxyjl\nbpcsgztWnsV8EqSQ8aiEGLYQRBnh8tSaYEqsTshOhZRljI9xv+/2VFaciK590aF7WCLZG24MdHck\nkrqou7IFKLdeDr5MxnlQWY3XEd3yhTMbkF3hHw6j57uD/FXOaJoT4JbjmkKsGAdpdDViUlGWXwKV\nQhYXS7P8bApF3ueIXux9putpHvDQuKLmexj5pjGHBVo5GSqkgVI8erMhQZLyEMQzwIVSlbGpEOgH\ng9p42ioB2WrLbUZYzxEgVPaydO0Ii2r+kjhN8CSobo2uOMnWYV3bet6dg06GCZAoL3+UZ8NRNTgT\nzm7QWh+Bd3v7/whH8ofowzyV7zFzmsoy2Xq793KTeRwhHQ86/Xx4ukGAQc15wh1OrjIiZaZq3eoI\n0/jHpdPF+dedq6eb+0OT7tTXy/iOBnUXb6c8LJPCB5sQejeYc6lnMoYJ6KMuhQdMZ0aj7yZdEdlB\nOIWTgybLz//hcwNsf26mSYWB8dDvUN9WLg+HV3Zs457Ju0IxcsfQPpz+rMUTDqSwdd8tKhIsgIh3\nJKw5NXjgc71NGRX2o0CaqUW6eD59gtt132wLvqmp9uC/cFJJ09WrtZA8BYpguf2GneiJ9RBdIJdc\nzcZHmYTAzdAQVXOKeOwEV9MjYqZNOJtvkVYz7O5nXqmFIizr89pX+blol/vG+NKlcXe4s+PfGSm9\nyvLFIlKNiuLwFLHCrWdT/kYr1X5+igKFBwQMw1Ei9KjiUqmfaxSgMVE0glbegHOAS5aO+ImZWch5\nhVe2oqRx470VEltnAisX1BIc3syYG23MSERhsCXDqFZhXnB7TFYV724l26pr2wU5I2CAVcGf7MIw\nNofy3GWTyLfVJbukOqF+g7p1WacPcIzOE+W2pz1/sYnHtxGRFV8nIFMuvd58Q9GdCkJG7yf3hNFM\nL/QYOnYxNYLqwQfh6OHmsmJp0et1ocvPmWHcye+iE4uG/asgOh9m+B0pGsv9Tdc3Wzh12cnZM2nU\naBT6S2XYmcXQzcIluRWviBlN6CL5zQgE1+0Lvk2qkG0QkNComweDiCPZ4KSj5KYVnkVdXQ3kytXG\njuD+DcRbpBCXT6Z2/lXy6YYnWMCjuZMoNeYff1vJBaQEYscEhvJ+XB1uo9PQAUjfDvLOSFJjJ+RB\nEG+cu8f31Z9dWQhJxRfI2SKbjzkwClO6KfKOMA==");
					*/
					tempMap1.put("zhangh", zhanghao);
					tempMap1.put("yinjshzt", yinjshzt);
					tempMap1.put("zhanghshzt", yinjshzt);
					tempMap1.put("zuhshzt", yinjshzt);
					tempMap1.put("youwyj", "��");
					paramList1.add(tempMap1);

					juniDBInterface.execSql(addSealInfo,"", yinjxxObjList, conn);//����ӡ����Ϣ
					juniDBInterface.execSql(changeUserCheckState,"", paramList1, conn);//�ı��˻�ӡ��״̬
				}
				if(hasZuhxx){					
					String zhanghao = zuhxxList.get(0).get("zhangh");
					String zuhshzt = zuhxxList.get(0).get("zuhshzt");
					tempMap2.put("zhangh", zhanghao);
					tempMap2.put("zuhshzt", zuhshzt);
					tempMap2.put("youwzh", "��");
					paramList2.add(tempMap2);
					juniDBInterface.execSql(addCombineInfo,"", zuhxxList, conn);//���������Ϣ
					juniDBInterface.execSql(changeCombineCheckState,"", paramList2, conn);//�ı��˻����״̬
				}
				// ���뽨���ļ���Ϣ������yinjk����kagrw��
				if (hasJkwenjxx) {					
					List<Map<String, String>> kaguiTempList = new ArrayList<Map<String, String>>();
					for (int i = 0; i < jkwenjxxList.size(); i++) {
						String strTemp = JUtils.getRandomID();
						Map<String, String> kaguiTempMap = new HashMap<String, String>();
						kaguiTempMap.put("yinjkh", jkwenjxxList.get(i).get("yinjkh"));
						kaguiTempMap.put("zhangh", jkwenjxxList.get(i).get("zhangh"));
						kaguiTempMap.put("jigh", jkwenjxxList.get(i).get("jigh"));
						kaguiTempMap.put("zhengmwjm", jkwenjxxList.get(i).get("zhengmwjm"));
						kaguiTempMap.put("fanmwjm", jkwenjxxList.get(i).get("fanmwjm"));
						kaguiTempMap.put("qiyrq", jkwenjxxList.get(i).get("qiyrq").replace("-", ""));
						kaguiTempMap.put("tingyrq", jkwenjxxList.get(i).get("tingyrq").replace("-", ""));
						kaguiTempMap.put("renwbs", strTemp);
						kaguiTempMap.put("renwlx", "0");
						kaguiTempMap.put("yewlx", "0");
						kaguiTempMap.put("renwzt", "0");
						kaguiTempMap.put("yinjks", String.valueOf(jkwenjxxList.size()));
						kaguiTempMap.put("shifzk", "1");
						kaguiTempList.add(kaguiTempMap);
					}
					List<Map<String, String>> bsList = new ArrayList<Map<String, String>>();
					Map<String, String> bsMap = new HashMap<String, String>();
					bsMap.put("cansid", "kag_kongzcs");
					bsList.add(bsMap);
					JSONObject kzObject = juniDBInterface.execSql("getKzcs", "", bsList, conn);// ִ�н���
					JSONObject kzObjectTemp = JSONObject.fromObject(kzObject.getJSONArray("objectdata").get(0));
					String value = kzObjectTemp.getString("parametervalue");
					//ϵͳ���������Ƿ���ӡ�����ſ�����
					if("1".equals(value))
					{
							juniDBInterface.execSql("insertKAGRW", kaguiTempList, conn);						
							juniDBInterface.execSql("insertYinjk", kaguiTempList, conn);						
					}
				}
				//��¼��Ա������־
				saveCaozRZ(manageType,date,time,WriteWorkLogToDb,accoMap,renwxxObjList,yinjxxObjList,zhanghxxObjList);
				
				String taskid = JUtils.getRandomID();
				//�˻���չ��ά����¼
				/*
				 * �˽���id�����ݿ��н������ݱ��ﲻ���ڣ��޸����ݿ������˴˽���id��sql���£�
				 * 
				 * 
				 * */
				Map<String, String> zhanghkzbMap = new HashMap<String, String>();
				zhanghkzbMap.put("zhangh", zhangh);
				zhanghkzbMap.put("taskid", taskid);
				zhanghkzbMap.put("type", "����");
				this.executeJY("deleteZhangkzb", zhanghkzbMap);
				this.executeJY("insertZhangkzb", zhanghkzbMap);
				
				
				//ӡ�����Ǽǲ�
			/*	Map<String, String> yinjkdjbMap = new HashMap<String, String>();
				yinjkdjbMap.put("taskid", taskid);
				yinjkdjbMap.put("jigh", zhangOrg);
				yinjkdjbMap.put("zhangh", zhangh);
				yinjkdjbMap.put("hum", renwxxObjList.get(0).get("hum"));
				yinjkdjbMap.put("fzhangh", "");
				yinjkdjbMap.put("yinjkh", "");
				yinjkdjbMap.put("zhuxrq", "");
				yinjkdjbMap.put("yinjkzt", "����");
				yinjkdjbMap.put("qiyrq", renwxxObjList.get(0).get("qiyrq"));
				yinjkdjbMap.put("jinbgy",  renwxxObjList.get(0).get("guiyh"));
				yinjkdjbMap.put("wangdfh", "����");
				yinjkdjbMap.put("zhongxsh","����");
				yinjkdjbMap.put("caorq", date);
				yinjkdjbMap.put("caozsj", time);
				yinjkdjbMap.put("caozlx", "����");
				this.executeJY(savaYinjkdjb, yinjkdjbMap); modify by binbin ӡ�����ǼǱ�����Ҫ ��ɳ��ӡ */ 
			}else if("2".equals(manageType)){//�������											
				String beginyinjshzt=JSONObject.fromObject(accoArray.get(0)).getString("yinjshzt");//���ӡ�����״̬
				String youwzh=JSONObject.fromObject(accoArray.get(0)).getString("youwzh");//�ж��������

				JSONObject lastqyrqObj=juniDBInterface.execSql("getYSqyrq","",accoList, conn);
				lastqyrqObj=JSONObject.fromObject(lastqyrqObj.getJSONArray("objectdata").get(0));
				String preQyrq=lastqyrqObj.getString("maxtime");
				/*
				 * �������������˻���ӡ���������Ϣ��BAK_YINJB,BAK_YINJZHB,BAK_ZHANGHB
				 */
				
				//���������1 ����������  2 δ����������     �������˻���ӡ�����״̬
				if("����".equals(beginyinjshzt)){
					if(hasZhanghxx){
						juniDBInterface.execSql("DelBakzhanghb",accoList, conn);// ����˻����ݱ������˻���Ϣ
						juniDBInterface.execSql("Bakzhanghb",accoList, conn);//�����˻���
						accoList.remove(accoMap);						
						accoMap.put("changedate", date);
						accoList.add(accoMap);
						juniDBInterface.execSql("ChangeZhanghDate",accoList, conn);//���ӱ���ʱ�䵽�˻���
					}
					if(hasYinjxx){
						juniDBInterface.execSql("DelBakyinjb",accoList, conn);//���ӡ����ӡ����Ϣ
						accoList.remove(accoMap);
						accoMap.put("qiyrq",preQyrq);
						accoList.add(accoMap);
						juniDBInterface.execSql("Bakyinjb",accoList, conn);//����ӡ����
						accoList.remove(accoMap);
						accoMap.remove("qiyrq");
						accoMap.put("changedate", date);
						accoList.add(accoMap);
						juniDBInterface.execSql("ChangeYinjDate",accoList, conn);//���ӱ���ʱ�䵽ӡ����						
					}
					if(hasZuhxx){
						juniDBInterface.execSql("DelBakyinjzhb",accoList, conn);//���ӡ����ϱ������Ϣ
						accoList.remove(accoMap);
						accoMap.put("qiyrq",preQyrq);
						accoList.add(accoMap);
						if("��".equals(youwzh)){
							juniDBInterface.execSql("Bakyinjzhb",accoList, conn);//������ϱ�
						}
						accoList.remove(accoMap);
						accoMap.remove("qiyrq");
						accoMap.put("changedate", date);
						accoList.add(accoMap);
						if("��".equals(youwzh)){
							juniDBInterface.execSql("ChangeZuhDate",accoList, conn);//���ӱ���ʱ�䵽��ϱ�
						}		
					}					
				}				
				
				/*
				 * ���δ��ӡ����Ϣ�������Ϣ�������ļ���Ϣ
				 */
				String zhangh = "";
				Map<String,String> zhanghaoMap=new HashMap<String,String>();
				List<Map<String,String>> zhanghList=new ArrayList<Map<String,String>>();
				
				if(hasZhanghxx){
					//�û���ע����ӡ����ע���ֿ�
					String[] beiz=zhanghxxObjList.get(0).get("beiz").split("&");
					if(beiz!=null&&beiz.length>0){						
							String bz=beiz[0];															
							zhanghxxObjList.get(0).put("beiz",bz);					
					}else{
						zhanghxxObjList.get(0).put("beiz","");		
					}
						juniDBInterface.execSql(UpdateAccountInfo,"",zhanghxxObjList, conn);// �����˻�������Ϣ			
					if(beiz!=null&&(beiz.length>1)){					
							String bgbe=beiz[1];															
							zhanghxxObjList.get(0).put("beiz",bgbe);					
					}else{
						zhanghxxObjList.get(0).put("beiz","");	
					}
						
						zhangh=zhanghxxObjList.get(0).get("zhangh");
					
				}else{
					zhangh = accoMap.get("zhangh");
				}				
				
				if(hasYinjxx){
					String qiyrq=yinjxxObjList.get(0).get("qiyrq");					
					zhanghaoMap.put("zhangh",zhangh);
					zhanghaoMap.put("qiyrq",qiyrq);					
					zhanghList.add(zhanghaoMap);
					juniDBInterface.execSql(DelWSyinj,"",zhanghList, conn);// ����˻���δ��ӡ��+������ӡ����Ϣ
					juniDBInterface.execSql(DelWSZh,"",zhanghList, conn);// ����˻���δ�����+�����������Ϣ
				}
				
				/*
				 * ��ս����ļ���Ϣ
				 */
				String ssqyrq = "";
				if(hasJkwenjxx){
					JSONObject qyrqObject=new JSONObject();
					qyrqObject=juniDBInterface.execSql("GetWSqyrq","",zhanghList, conn);// ִ�л���˻���δ��ӡ���������ڽ���				
					qyrqObject=JSONObject.fromObject(qyrqObject.getJSONArray("objectdata").get(0));
					if(qyrqObject.containsKey("qiyrq")){
						String qyrq=qyrqObject.getString("qiyrq");//��á�δ��ӡ����������
						zhanghaoMap.put("qiyrq", qyrq.replace("-", ""));
						List<Map<String,String>> qyrqList=new ArrayList<Map<String,String>>();
						juniDBInterface.execSql("DelWSkagrw","",qyrqList, conn);//��ա�δ��ӡ����Ӧ������Ϣ---��������
						juniDBInterface.execSql("DelWSyinjk","",qyrqList, conn);//��ա�δ��ӡ����Ӧ������Ϣ---ӡ����
					}							
					
					ssqyrq=yinjxxObjList.get(0).get("qiyrq");//��ø�������������,Ϊ֧���������
					Map<String,String> ssqyrqMap=new HashMap<String,String>();
					ssqyrqMap.put("zhangh",zhangh);
					List<Map<String,String>> ssqyrqList=new ArrayList<Map<String,String>>();
					ssqyrqList.add(ssqyrqMap);				
					ssqyrqMap.put("qiyrq",ssqyrq.replace("-", ""));
					List<Map<String,String>> jiankList=new ArrayList<Map<String,String>>();
					jiankList.add(ssqyrqMap);
					juniDBInterface.execSql("DelWSkagrw","",jiankList, conn);//��ո�����ӡ����Ӧ������Ϣ---��������
					juniDBInterface.execSql("DelWSyinjk","",jiankList, conn);//��ո�����ӡ����Ӧ������Ϣ---ӡ����	
				}
							
				
				/*
				 * ���������ӡ������ϡ������ļ���Ϣ(����yinjk����kagrw��)
				 */
				
				if(hasYinjxx){
					//��ȡ��Ա��Ϣ
					Map<String,String> zhanghaoMap2=new HashMap<String,String>();
					zhanghaoMap2.put("clerknum",renwxxObjList.get(0).get("guiyh"));
					List<Map<String,String>> zhanghList2=new ArrayList<Map<String,String>>();
					zhanghList2.add(zhanghaoMap2);
					JSONArray clerkjson = juniDBInterface.execSql("GetClerkInfo",zhanghList2,conn);
					JSONObject clerkobj = JSONObject.fromObject(clerkjson.get(0));
					JSONObject clerkdata = JSONObject.fromObject(clerkobj.getJSONArray("objectdata").get(0));
					String kaihy=clerkdata.getString("clerkname");
					yinjxxObjList.get(0).put("kaihy", kaihy);
					for(int i = 0;i<yinjxxObjList.size(); i++){
						yinjxxObjList.get(i).put("kaihy", kaihy);
						yinjxxObjList.get(i).put("kaihynum", renwxxObjList.get(0).get("guiyh"));
					}
					
					String zhanghao = yinjxxObjList.get(0).get("zhangh");  
					String yinjshzt = yinjxxObjList.get(0).get("yinjshzt");//��ʼ��δ��
					tempMap1.put("zhangh", zhanghao);
					tempMap1.put("zhanghshzt", "����");
					tempMap1.put("yinjshzt", yinjshzt);
					tempMap1.put("zuhshzt", yinjshzt);									
					tempMap1.put("youwyj", "��");
					paramList1.add(tempMap1);
					juniDBInterface.execSql(addSealInfo,"", yinjxxObjList, conn);//����ӡ����Ϣ
					juniDBInterface.execSql(changeUserCheckState,"", paramList1, conn);//�ı��˻�ӡ��״̬
				}
				if(hasZuhxx){					
					String zhanghao = zuhxxList.get(0).get("zhangh");
					String zuhshzt = zuhxxList.get(0).get("zuhshzt");
					tempMap2.put("zhangh", zhanghao);
					tempMap2.put("zuhshzt", zuhshzt);
					tempMap2.put("youwzh", "��");
					paramList2.add(tempMap2);
					juniDBInterface.execSql(addCombineInfo,"", zuhxxList, conn);//���������Ϣ
					juniDBInterface.execSql(changeCombineCheckState,"", paramList2, conn);//�ı��˻����״̬
				}		
				if (hasJkwenjxx) {					
					List<Map<String, String>> kaguiTempList = new ArrayList<Map<String, String>>();
					for (int i = 0; i < jkwenjxxList.size(); i++) {
						String strTemp = JUtils.getRandomID();
						Map<String, String> kaguiTempMap = new HashMap<String, String>();
						kaguiTempMap.put("yinjkh", jkwenjxxList.get(i).get("yinjkh"));
						kaguiTempMap.put("zhangh", jkwenjxxList.get(i).get("zhangh"));
						kaguiTempMap.put("jigh", jkwenjxxList.get(i).get("jigh"));
						kaguiTempMap.put("zhengmwjm", jkwenjxxList.get(i).get("zhengmwjm"));
						kaguiTempMap.put("fanmwjm", jkwenjxxList.get(i).get("fanmwjm"));
						kaguiTempMap.put("qiyrq", jkwenjxxList.get(i).get("qiyrq").replace("-", ""));
						kaguiTempMap.put("tingyrq", jkwenjxxList.get(i).get("tingyrq").replace("-", ""));
						kaguiTempMap.put("renwbs", strTemp);
						kaguiTempMap.put("renwlx", "0");
						kaguiTempMap.put("yewlx", "0");
						kaguiTempMap.put("renwzt", "0");
						kaguiTempMap.put("yinjks", String.valueOf(jkwenjxxList.size()));
						kaguiTempMap.put("shifzk", "1");
						kaguiTempList.add(kaguiTempMap);
					}
					List<Map<String, String>> bsList = new ArrayList<Map<String, String>>();
					Map<String, String> bsMap = new HashMap<String, String>();
					bsMap.put("cansid", "kag_kongzcs");
					bsList.add(bsMap);
					JSONObject kzObject = juniDBInterface.execSql("getKzcs", "", bsList, conn);// ִ�н���
					JSONObject kzObjectTemp = JSONObject.fromObject(kzObject.getJSONArray("objectdata").get(0));
					String value = kzObjectTemp.getString("parametervalue");
					//ϵͳ���������Ƿ���ӡ�����ſ�����
					if("1".equals(value))
					{
							juniDBInterface.execSql("insertKAGRW", kaguiTempList, conn);						
							juniDBInterface.execSql("insertYinjk", kaguiTempList, conn);						
					}					
				}
				/*
				 * Ϊ��һ��ӡ����������ӡ�ͣ�����ڡ�(��ʧ״̬����)
				 */		
				if(!"��ʧ".equals(accoArray.getJSONObject(0).getString("zhanghzt"))){
					
					if(hasYinjxx){
						String yzhangh=yinjxxObjList.get(0).get("zhangh");//���ӡ��ʵ�������˺�					
						if(lastqyrqObj.containsKey("maxtime")){					
							String lastqyrq=lastqyrqObj.getString("maxtime");//�����һ��ӡ���������ڣ���������������ӡ���������ڣ�
							if(!ssqyrq.equals(lastqyrq)){
								Map<String,String> tingyMap=new HashMap<String,String>();
								tingyMap.put("qiyrq", lastqyrq);
								tingyMap.put("zhangh",yzhangh);
								tingyMap.put("tingyrq", yinjxxObjList.get(0).get("qiyrq"));//������һ��ӡ��ͣ������Ϊ�����ε���������
								List<Map<String, String>> tingyrqList = new ArrayList<Map<String, String>>();
								tingyrqList.add(tingyMap);
								juniDBInterface.execSql(setSealTingyrq,"", tingyrqList, conn);// ����ӡ��ͣ������
//								if(hasZuhxx) {
									juniDBInterface.execSql(setCombinaTingyrq,"", tingyrqList, conn);// �������ͣ������
//								}
							}					
						}			
					}					
				}
				//��¼��Ա������־
				saveCaozRZ(manageType,date,time,WriteWorkLogToDb,accoMap,renwxxObjList,yinjxxObjList,zhanghxxObjList);
				
				String taskid = JUtils.getRandomID();
				//�˻���չ��ά����¼
				Map<String, String> zhanghkzbMap = new HashMap<String, String>();
				zhanghkzbMap.put("zhangh", zhangh);
				zhanghkzbMap.put("taskid", taskid);
				zhanghkzbMap.put("type", "���");
				this.executeJY("deleteZhangkzb", zhanghkzbMap);
				this.executeJY("insertZhangkzb", zhanghkzbMap);
				
				//ӡ�����Ǽǲ�
				/*Map<String, String> yinjkdjbMap = new HashMap<String, String>();
				yinjkdjbMap.put("taskid",taskid);
				yinjkdjbMap.put("jigh", zhangOrg);
				yinjkdjbMap.put("zhangh", zhangh);
				yinjkdjbMap.put("hum", renwxxObjList.get(0).get("hum"));
				yinjkdjbMap.put("fzhangh", "");
				yinjkdjbMap.put("yinjkh", "");
				yinjkdjbMap.put("zhuxrq", "");
				yinjkdjbMap.put("yinjkzt", "����");
				yinjkdjbMap.put("qiyrq", renwxxObjList.get(0).get("qiyrq"));
				yinjkdjbMap.put("jinbgy",  renwxxObjList.get(0).get("guiyh"));
				yinjkdjbMap.put("wangdfh", "����");
				yinjkdjbMap.put("zhongxsh","����");
				yinjkdjbMap.put("caorq", date);
				yinjkdjbMap.put("caozsj", time);
				yinjkdjbMap.put("caozlx", "���");
				this.executeJY(savaYinjkdjb, yinjkdjbMap); modify by binbin ȥ��ӡ�����Ǽ� ��ɳ��ӡ */
				
				
				
			}else if("3".equals(manageType)){				
				//�����˻�������Ϣ
				juniDBInterface.execSql(UpdateAccountInfo, "",zhanghxxObjList, conn);
				//��¼��Ա������־
				saveCaozRZ(manageType,date,time,WriteWorkLogToDb,accoMap,renwxxObjList,yinjxxObjList,zhanghxxObjList);
			}else{
				JResponseManager.jrResMsgSet(jsonRet, "δʶ���ϵͳ���ܱ�ʶ��");
				return jsonArray;				
			}					
			commit();			
		}catch(Exception e){
			rollback();
			e.printStackTrace();
			throw e;
		}finally{
			release();
		}
		return jsonArray;
	}
	/*
	 * ��¼��Ա������־(ͨ�ú���)
	 */
	private void saveCaozRZ(String managetype,String date,String time,String WriteWorkLogToDb,Map<String,String> zhanghMap,List<Map<String, String>> renwxxObjList,List<Map<String, String>> yinjxxObjList,List<Map<String, String>> zhanghxxObjList) throws Exception{
	
		if("0".equals(managetype)){
			managetype="����";
		}
		if("2".equals(managetype)){
			managetype="���";
		}
		if("3".equals(managetype)){
			managetype="�޸�����";
		}
		List<Map<String, String>> guiyTempList = new ArrayList<Map<String, String>>();
		Map<String, String> guiyTempMap = new HashMap<String, String>();		
		guiyTempMap.put("account", zhanghMap.get("zhangh"));
		guiyTempMap.put("managedate", date);
		guiyTempMap.put("managetime", time);
		guiyTempMap.put("managetype", managetype);
		
		guiyTempMap.put("clerknum", renwxxObjList.get(0).get("guiyh"));
		guiyTempMap.put("clerkname", renwxxObjList.get(0).get("guiym"));
		if(renwxxObjList.get(0).containsKey("IP")){
			guiyTempMap.put("ip", renwxxObjList.get(0).get("IP"));
		}else{
			guiyTempMap.put("ip","");
		}		
		guiyTempMap.put("upflag", "");
		guiyTempMap.put("str1", "");
		guiyTempMap.put("str2", "");
		guiyTempMap.put("str3", "");
		guiyTempMap.put("qiyrq",yinjxxObjList.get(0).get("qiyrq"));
		//�˻�ά������
		StringBuilder sb = new StringBuilder();
		if("����".equals(managetype) || "�޸�����".equals(managetype)){
			sb.append(managetype+"|");
			sb.append("�˺�:" + zhanghMap.get("zhangh") + "," + 
					"�ͻ���:" + zhanghxxObjList.get(0).get("kehh") + "," + 
					"����:" 	+ zhanghxxObjList.get(0).get("hum") + "," + 
					"������:"+ zhanghxxObjList.get(0).get("jigh") + "," + 
					
					
					/*"��ַ:"	+ zhanghMap.get("diz") + "," +
					"��������:"	+ zhanghMap.get("youzbm") + "," +
					"��ϵ��:"+ zhanghMap.get("lianxr") + "," + 
					"�绰:"	+ zhanghMap.get("lianxr") + "," + */
					"��������:"	+ zhanghxxObjList.get(0).get("kaihrq") + "," +
					/*"ͨ��ͨ��:"	+ zhanghMap.get("tongctd") + "," +
					"���Һ�:"+ zhanghMap.get("huobh") + "," + 
					"�˻����״̬:"+zhanghMap.get("zhanghshzt") + "," + 
					"ӡ�����״̬:"	+ zhanghMap.get("yinjshzt") + "," + 
					"������״̬:"	+ zhanghMap.get("zuhshzt") + "," + 
					"�˻�״̬:"	+ zhanghMap.get("zhanghzt") + "," +*/
					"�˻����:"	+ zhanghxxObjList.get(0).get("zhanghxz") + "," +
					/*"���ʺ�:"+ zhanghxxObjList.get(0).get("zhuzh") + "," +
					"��������:"	+ zhanghxxObjList.get(0).get("fuyrq") + "," +
					"ȡ����������:"+ zhanghxxObjList.get(0).get("quxfyrq") + "," +*/ 
					//"�����ʶ:"	+ zhanghxxObjList.get(0).get("jiankbs") + "," +
					//"ͣ������:"	+ zhanghxxObjList.get(0).get("tingyrq") + "," + 
					"��ע:"	+ zhanghxxObjList.get(0).get("beiz"))//+ "," +
					//"���Һ�:"+ zhanghxxObjList.get(0).get("huobh"))
					;
		}else if("���".equals(managetype)){
			sb.append("ӡ���������������Ϊ��"+yinjxxObjList.get(0).get("qiyrq")+ "," + "��ע:"	+ zhanghxxObjList.get(0).get("beiz"));
		}		
		guiyTempMap.put("managecontent",sb.toString());
		guiyTempList.add(guiyTempMap);		
		juniDBInterface.execSql(WriteWorkLogToDb,"",guiyTempList, conn);		
	}
	
	/*
	 * ִ�н��׺���
	 */
	private void executeJY(String jiaoyid,Map<String, String> pMap) throws Exception{
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		list.add(pMap);
		juniDBInterface.execSql(jiaoyid,"",list, conn);	
	}
	
	public String execute(Function function, DataSets datasets) throws Exception { return null;}
	public String execute(Map<String, String> parameters) throws Exception { return null; }
}