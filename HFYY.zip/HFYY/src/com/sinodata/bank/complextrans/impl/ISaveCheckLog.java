package com.sinodata.bank.complextrans.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

//import com.sinodata.common.sequence.SequenceObtain;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
import com.unitop.exception.UfSealException;

public class ISaveCheckLog extends BaseTrans{
	
	public JSONArray jexecute(Function function, DataSets datasets,JSONObject jsonRet) throws Exception {
		JSONArray jsonArray = new JSONArray();//���屾�������ص�json����
		try {
			beginTrans();
			List<String> childTrade = function.getMutil().getList();
			String WriteZhengpyylogToDb = childTrade.get(0);//��Ʊ��ӡ��־д�����ݿ�(�ӽ���1)
			String WriteYulyjyylogToDb = childTrade.get(1);//������ӡ��־д�����ݿ�(�ӽ���2)
			boolean hasRZRENWXX = datasets.getParamMap().containsKey("RZRENWXX");//������Ϣ
			boolean hasZPRZXX = datasets.getParamMap().containsKey("ZPRZXX");//��ƱƱ��־��Ϣ
			boolean hasDZRZXX = datasets.getParamMap().containsKey("DZRZXX");//������־��Ϣ
			
			List<Map<String, String>> rwObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> zhengprzxxObjList = new ArrayList<Map<String, String>>();
			List<Map<String, String>> danzrzxxObjList = new ArrayList<Map<String, String>>();
			
			if (hasRZRENWXX && hasZPRZXX && hasDZRZXX) 
			{
				rwObjList = datasets.getParamMap().get("RZRENWXX");
				zhengprzxxObjList = datasets.getParamMap().get("ZPRZXX");
				danzrzxxObjList = datasets.getParamMap().get("DZRZXX");
			}else{
				throw new UfSealException("���ͱ�����ʵ��[RZRENWXX]��[ZPRZXX]��[DZRZXX]δ����!");
			}
			
			/*
			 * ��ȡʱ��
			 */
			List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
			tempList.add(new HashMap<String, String>());
			JSONObject dataObject = new JSONObject();
			dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate","",tempList,conn);
			JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
			String sysDate = jsonObjData1.getString("getdate");
			String date = sysDate.substring(0, 10);
			String time = sysDate.substring(11, 19);
			
			//String sequenceNum = SequenceObtain.getSequenceUUID();//ҵ����ˮ��
			//�޸Ĺ��治�ܻ�ȡ�˻�������accorgno
			JSONArray accoArray = new JSONArray();
			JSONObject accoObj = new JSONObject();
			List<Map<String,String>> accoList=new ArrayList<Map<String,String>>();			
			Map<String,String> accoMap=new HashMap<String,String>();
			accoMap.put("zhangh",rwObjList.get(0).get("ACCNO"));
			accoList.add(accoMap);				
			accoObj=juniDBInterface.execSql("getAccountInfo","",accoList, conn);//����˻���Ϣ
			accoArray=accoObj.getJSONArray("objectdata");
			String accorgno = JSONObject.fromObject(accoArray.get(0)).getString("jigh");
			/*
			 *��Ʊ��־��Ϣ �ύ
			 */
			List<Map<String, String>> zhengpList = new ArrayList<Map<String,String>>();
			Map<String,String> zhengpMap = new HashMap<String, String>();
			
			//zhengpMap.put("pingzbsm", sequenceNum);
			zhengpMap.put("yewly",  rwObjList.get(0).get("SYSCODE"));
			zhengpMap.put("yelx",   rwObjList.get(0).get("NODECODE"));
			zhengpMap.put("zhangh", rwObjList.get(0).get("ACCNO"));
			zhengpMap.put("yewbs",  rwObjList.get(0).get("TASKID"));
			zhengpMap.put("yanyrwlx", rwObjList.get(0).get("TASKTYPE"));
			zhengpMap.put("yanyrwlsbs", rwObjList.get(0).get("CHECKID"));
			zhengpMap.put("yewxtbh", rwObjList.get(0).get("XITLX"));
			zhengpMap.put("checktype", rwObjList.get(0).get("CHECKTYPE"));
			zhengpMap.put("guiyh", rwObjList.get(0).get("TELLNO"));
			zhengpMap.put("clerkorgcode", rwObjList.get(0).get("TELLORGNO"));
			zhengpMap.put("zhangh", rwObjList.get(0).get("ACCNO"));
			zhengpMap.put("zhanghjgh", accorgno);
			zhengpMap.put("pingzh", rwObjList.get(0).get("BILLNO"));
			zhengpMap.put("credencetype", rwObjList.get(0).get("BILLTYPE"));
			zhengpMap.put("jine", rwObjList.get(0).get("AMOUNT"));
			zhengpMap.put("chuprq", rwObjList.get(0).get("BILLDATE"));
			zhengpMap.put("tuxbs", rwObjList.get(0).get("PICTYPE"));
			zhengpMap.put("imagetype", rwObjList.get(0).get("imagetype"));
			zhengpMap.put("dpi", rwObjList.get(0).get("DPI"));
			try
			{
				//��̨������ӡ��Ҫ�õ�
				zhengpMap.put("renwid", rwObjList.get(0).get("RENWID"));
			} catch (Exception e) {
				//�����Ĳ���Ҫ
				// TODO: handle exception
				zhengpMap.put("renwid", "");
			}
			
			
			String _tuxmc = rwObjList.get(0).get("filepath");
			String tuxmc = "";
			if(_tuxmc!=null && !"".equals(_tuxmc)){
				tuxmc = _tuxmc.replaceAll("\\\\", "\\\\\\\\");	//��1����б�� "\\yany\\b1190c6f-c697-4dfc-b16c-fcfa35056315.jpg" ת��Ϊ2����б��  "\\\\yany\\\\b1190c6f-c697-4dfc-b16c-fcfa35056315.jpg"
			}else{
				tuxmc = "";
			}
			
			zhengpMap.put("tuxmc", tuxmc);	//Ӱ�����ļ�������·��
			zhengpMap.put("tuxdpi", rwObjList.get(0).get("DPI"));
			zhengpMap.put("yanyjg", zhengprzxxObjList.get(0).get("YANYJG"));
			zhengpMap.put("yanyfs", zhengprzxxObjList.get(0).get("YANYMS"));
			zhengpMap.put("zuhgz", zhengprzxxObjList.get(0).get("YANYZH"));
			zhengpMap.put("ip", "");
			zhengpMap.put("guiym", "");
			zhengpMap.put("shuangqgyh", rwObjList.get(0).get("shuangqgyh"));
			zhengpMap.put("shuangqgymc", "");
			zhengpMap.put("remark", "");
			zhengpMap.put("xitlx", rwObjList.get(0).get("XITLX"));
			zhengpMap.put("yanybs",rwObjList.get(0).get("SYSCODE"));
			zhengpMap.put("checkdate", date);
			zhengpMap.put("checktime", time);
			zhengpMap.put("accorgno",accorgno);
			zhengpList.add(zhengpMap);
			if(!((rwObjList.get(0).get("TASKTYPE")).equals("2"))){
			juniDBInterface.execSql(WriteZhengpyylogToDb, zhengpList, conn);
			}
			/*
			 *������־��Ϣ �ύ
			 */
		if(!((rwObjList.get(0).get("TASKTYPE")).equals("2"))){
			for(int i=0;i<danzrzxxObjList.size();i++)
			{
				List<Map<String, String>> danzList = new ArrayList<Map<String,String>>();
				Map<String, String> danzMap = new HashMap<String, String>();
				//danzMap.put("pingzbsm", sequenceNum);
				danzMap.put("zhangh", rwObjList.get(0).get("ACCNO"));
				danzMap.put("pingzh", rwObjList.get(0).get("BILLNO"));
				danzMap.put("yinjzl", danzrzxxObjList.get(i).get("YINJLX"));
				danzMap.put("yinjbh", danzrzxxObjList.get(i).get("YINJBH"));
				danzMap.put("guiyh", rwObjList.get(0).get("TELLNO"));
				danzMap.put("guiym",  "");
				danzMap.put("clerkorgcode", rwObjList.get(0).get("TELLORGNO"));
				danzMap.put("yanyjg", danzrzxxObjList.get(i).get("YANYJGSTR"));
				danzMap.put("yanyfs", danzrzxxObjList.get(i).get("YANYFS"));
				danzMap.put("henxzb", danzrzxxObjList.get(i).get("HENGZB"));
				danzMap.put("shuxzb", danzrzxxObjList.get(i).get("ZONGZB"));
				danzMap.put("yinzjd", danzrzxxObjList.get(i).get("YINZJD"));
				danzMap.put("yanyjb", danzrzxxObjList.get(i).get("YINJJD"));
				danzMap.put("yanywgyy", danzrzxxObjList.get(i).get("WEIGYY"));
				danzMap.put("qiyrq", danzrzxxObjList.get(i).get("QIYRQ"));
				danzMap.put("checkdate", date);
				danzMap.put("checktime", time);
				danzMap.put("ip", "");
				danzList.add(danzMap);
				
				
					juniDBInterface.execSql(WriteYulyjyylogToDb, danzList, conn);
				}
			}
			//������ˮ��
			HashMap sequenceNumMap = new HashMap();
			sequenceNumMap.put("objectname", "taskid");
			
			List<Map<String, String>> tempL = new ArrayList<Map<String, String>>();
			HashMap tempM = new HashMap();
			//tempM.put("taskid", sequenceNum);
			tempM.put("checktime", date+" "+time);
			tempL.add(tempM);
			sequenceNumMap.put("objectdata", tempL);
			jsonArray.add(sequenceNumMap);
			
			
			
			commit();
		} catch (Exception e) {
			e.printStackTrace();
			this.rollback();
			throw e;
		}finally{
			this.release();
		}
		return jsonArray;
	}
	
	public String execute(Function function, DataSets datasets) throws Exception { return null; }
	public String execute(Map<String, String> parameters) throws Exception { return null;}
}
