package com.sinodata.bank.complextrans.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.sinodata.bank.JResponseManager;
import com.sinodata.util.JUtils;
import com.unitop.bank.complextrans.BaseTrans;
import com.unitop.bean.DataSets;
import com.unitop.bean.Function;
/*
 *add by binbin 
 *
 *�����޸��˻���Ϣ�ӿ�
 *�������޸��˺ŵĻ����š��������ͻ��š��˻������Լ���ע�ֶε���Ϣ��
 *�����˺ŵĻ�������������ʵ�֣�
 */
public class IChangeAccountInfo extends BaseTrans{
	public JSONArray jexecute(Function function, DataSets datasets,JSONObject jsonRet) throws Exception {
		JSONArray jsonArray = new JSONArray();
		beginTrans();
		try {
			List<String> childTrade = function.getMutil().getList();
			String getAccountInfo = childTrade.get(0);		//��ȡ�˻���Ϣ
			String iUpdateAccountInfo = childTrade.get(1);  //����ӿ��޸��˻���Ϣ
			String writeWorkLogToDb = childTrade.get(2); 	//д�˻�������־
			List<Map<String, String>> infoList = datasets.getParamMap().get("INFO"); //������Ϣ
			
			/*
			 * ��ȡʱ��
			 */
			Map<String, String> tempMap = new HashMap<String, String>();
			tempMap.put(" ", " ");
			List<Map<String, String>> tempList = new ArrayList<Map<String, String>>();
			tempList.add(tempMap);
			JSONObject dataObject = new JSONObject();
			dataObject = juniDBInterface.execSql("SystemMgrService_getSystetemNowDate","",tempList,conn);
			JSONObject jsonObjData1 = JSONObject.fromObject(dataObject.getJSONArray("objectdata").get(0));
			String sysDate = jsonObjData1.getString("getdate");
			String date = sysDate.substring(0, 10);
			String time = sysDate.substring(11, 19);
			
			JSONObject childJsonObj1 = new JSONObject();//�˻���Ϣ

			childJsonObj1 = juniDBInterface.execSql(getAccountInfo, "getAccountInfo", infoList, conn);
			boolean isAccountExist = JUtils.isObjDataContainValidData(childJsonObj1);//�жϽ�������Ƿ�������
			//�˻�������
			if (!isAccountExist) 
			{
				JResponseManager.jrErrInfoSet(jsonRet,"1111","�˺Ų�����!");
				return jsonArray;
			}
				//�޸��˻���Ϣ����
				Map<String,String> accoMap=new HashMap<String,String>();
				accoMap.put("zhangh",  infoList.get(0).get("zhangh"));
				accoMap.put("jigh",infoList.get(0).get("jigh"));
				accoMap.put("kehh",infoList.get(0).get("customno"));
				accoMap.put("hum",infoList.get(0).get("accname"));
				accoMap.put("zhanghxz",infoList.get(0).get("zhanghxz"));
				accoMap.put("beiz",infoList.get(0).get("remark"));
				accoMap.put("tongctd",infoList.get(0).get("autwithf"));
				
				//ZZ 10/23
				accoMap.put("lianxr",infoList.get(0).get("lianxr"));
				accoMap.put("dianh",infoList.get(0).get("dianh"));
				accoMap.put("diz",infoList.get(0).get("diz"));
				accoMap.put("jiesywsqr",infoList.get(0).get("jiesywsqr"));
				accoMap.put("jiesywsqrdh",infoList.get(0).get("jiesywsqrdh"));
				
				//ZZ181221
				
				//accoMap.put("zhlb",infoList.get(0).get("acctype"));
				accoMap.put("kaihrq",infoList.get(0).get("taskdate"));
				accoMap.put("shefzid",infoList.get(0).get("shefzid"));
				accoMap.put("youzbm",infoList.get(0).get("youzbm"));
				
				List<Map<String,String>> ysList=new ArrayList<Map<String,String>>();
				ysList.add(accoMap);
				juniDBInterface.execSql(iUpdateAccountInfo, "iUpdateAccountInfo", ysList, conn);
				
				//�˻��޸Ĳ�����־
				List<Map<String, String>> guiyTempList = new ArrayList<Map<String, String>>();
				Map<String, String> guiyMap = new HashMap<String, String>();
				guiyMap.put("account", infoList.get(0).get("zhangh"));
				guiyMap.put("managedate", date);
				guiyMap.put("managetime", time);
				guiyMap.put("managetype", "�޸�����");
				guiyMap.put("clerknum", infoList.get(0).get("guiyh"));
			
			/*	ApplicationContext context = new FileSystemXmlApplicationContext("D:\\eclipse-jee-luna-SR1-win32-x86_64\\workspace\\JZYY\\WebContent\\WEB-INF\\initFile\\applicationContext.xml");
				TabsDao tabsDao = (TabsDao) context.getBean("TabsDaoImpl");
			*/	
				
	   		//	���潻���еĶ���û������spring����������tabsDao�����ڱ�����ע��tabsDao����������spring�л�ȡBaseHibernateDao����ʧ�ܣ����������ָ���쳣		
	   		//	TabsDao tabsDao=new TabsDaoImpl();
			//	String qiyrq=tabDao.qiyrq(infoList.get(0).get("zhangh"), date);
			
			//  ����һ��simpleQuery����  begin
				HashMap<String, String> paramMap = new HashMap<String,String>();
				paramMap.put("account", infoList.get(0).get("zhangh"));
				paramMap.put("operatedate", date);
				List<Map<String, String>> paramList = new ArrayList<Map<String, String>>();
				paramList.add(paramMap);
				
				JSONArray jarray = juniDBInterface.execSql("GetQiyrqByZhanghAndCaozrq",paramList,conn);
				JSONObject jarrayObj = JSONObject.fromObject(jarray.get(0));
				JSONObject jobjectdata = JSONObject.fromObject(jarrayObj.getJSONArray("objectdata").get(0));
				//String qiyrq = jobjectdata.getString("qiyrq");
			//  ����һ��simpleQuery����  end
				
				//guiyMap.put("qiyrq", qiyrq);
				guiyMap.put("clerkname", "");
				guiyMap.put("ip","");
				guiyMap.put("upflag", "");
				guiyMap.put("str1", "");
				guiyMap.put("str2", "");
				guiyMap.put("str3", "");				
				String managecontent = "";
				managecontent +=
					  "�˺�:"+infoList.get(0).get("zhangh")+","+
					  "�ͻ���:"+infoList.get(0).get("customno")+","+
					  "����:"+infoList.get(0).get("accname")+","+
					  "������:"+infoList.get(0).get("jigh")+","+
					  "�˻����:"+infoList.get(0).get("zhanghxz")+","+
					  "ͨ��ͨ��:"+infoList.get(0).get("autwithf")+","+
					  "��ϵ��:"+infoList.get(0).get("lianxr")+","+
					  "�绰:"+infoList.get(0).get("dianh")+","+
					  "��ַ:"+infoList.get(0).get("diz")+","+
					  "������Ȩ��:"+infoList.get(0).get("jiesywsqr")+","+
					  "������Ȩ�˵绰:"+infoList.get(0).get("jiesywsqrdh")+","+
					  "��������:"+infoList.get(0).get("taskdate")+","+
					  "����֤:"+infoList.get(0).get("shefzid")+","+
					  "��������:"+infoList.get(0).get("youzbm")+","+
					  "��ע:"+infoList.get(0).get("remark");
					guiyMap.put("managecontent",managecontent);
					guiyTempList.add(guiyMap);
				juniDBInterface.execSql(writeWorkLogToDb, guiyTempList, conn);
			this.commit();
		} catch (Exception e) {
			rollback();
			e.printStackTrace();
			throw e;
		}finally{
			release();
		}
		return jsonArray;
	}
	
	public String execute(Function function, DataSets datasets)throws Exception {return null;}
	public String execute(Map<String, String> parameters) throws Exception {return null;}
}