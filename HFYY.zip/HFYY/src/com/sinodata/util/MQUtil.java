package com.sinodata.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.unitop.bank.CommonUtil;

public class MQUtil {

	/**
	 * ����MQ������ MQ��������IP��ַ: ip ���������ӵ�ͨ��: youdao �û���: user ���룺 password �ַ���
	 * (Integer����)�� zifj �˿�(Integer����)�� port MQ �Ķ��й��������ƣ� qmname MQ ���е����� qname
	 */
	public static MQQueueManager mqconn(String ip, String youdao, Integer zifj, Integer port, String qmname,
			String qname) {
		MQEnvironment.hostname = ip;
		MQEnvironment.channel = youdao;
		MQEnvironment.CCSID = zifj;
		MQEnvironment.port = port;
		try {
			MQQueueManager qMgr = new MQQueueManager(qmname);
			return qMgr;
		} catch (MQException e) {
			CommonUtil.error("Initial MQ anomaly", e);
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * MQ�ر�����
	 */
	public static void mqclose(MQQueueManager qMgr) {
		if (qMgr != null) {
			try {
				qMgr.disconnect();
			} catch (MQException e) {
				CommonUtil.error("Close MQ exception", e);
				e.printStackTrace();
			}
		}
	}

	/**
	 * ��MQ������Ϣ
	 * @param message��Ϣ
	 * @param qMgr ���Ӷ���
	 * @param QUEUEMANAGER �жӹ�����
	 * @param RequestQueue�����ж�
	 * @param ReplyQueue �ظ��ж�
	 */
	public static void sendMessage(String message, MQQueueManager qMgr,
			String QUEUEMANAGER, String RequestQueue, String ReplyQueue) {
		try {

			int openOptions = MQC.MQOO_OUTPUT | MQC.MQOO_FAIL_IF_QUIESCING;
			if (qMgr == null || !qMgr.isConnected()) {
				qMgr = new MQQueueManager(QUEUEMANAGER);
			}
			MQQueue queue = qMgr.accessQueue(RequestQueue, openOptions);
			MQMessage putMessage = new MQMessage();
			putMessage.encoding = MQEnvironment.CCSID;
			putMessage.characterSet = MQEnvironment.CCSID;
			putMessage.replyToQueueName = ReplyQueue;
			putMessage.format = "MQSTR";
			putMessage.writeString(message);
			MQPutMessageOptions pmo = new MQPutMessageOptions();
			pmo.options = pmo.options + MQC.MQPMO_NEW_MSG_ID ;
			pmo.options = pmo.options + MQC.MQPMO_SYNCPOINT ;
			queue.put(putMessage, pmo);
			queue.close();
			qMgr.commit();
			CommonUtil.info("MQ message sent successfully");
		} catch (MQException ex) {
			//��Ϣ����ʧ�ܵĴ���    ���ó�ʱʱ��
			long startTime_1=System.currentTimeMillis();//��¼��ʼʱ��
			float time  = 0.0000f;
			while (time < 2.0000f) {
				try {
					int openOptions = MQC.MQOO_OUTPUT | MQC.MQOO_FAIL_IF_QUIESCING;
					MQQueue queue = qMgr.accessQueue(RequestQueue, openOptions);
					MQMessage putMessage = new MQMessage();
					putMessage.encoding = MQEnvironment.CCSID;
					putMessage.characterSet = MQEnvironment.CCSID;
					putMessage.replyToQueueName = ReplyQueue;
					putMessage.format = "MQSTR";
					putMessage.writeString(message);
					MQPutMessageOptions pmo = new MQPutMessageOptions();
					pmo.options = pmo.options + MQC.MQPMO_NEW_MSG_ID ;
					pmo.options = pmo.options + MQC.MQPMO_SYNCPOINT ;
					queue.put(putMessage, pmo);
					queue.close();
					qMgr.commit();
					long startTime_2=System.currentTimeMillis();//��¼��ʼʱ��
					time = (float)(startTime_2 - startTime_1);
				} catch (MQException e) {
					CommonUtil.error("In the message delivery system exception MQ, the error number:" + ex.reasonCode , e);
				} catch (IOException e) {
					CommonUtil.error("IO flow exception, write message failed" , e);
				} 
			}
		} catch (IOException ex) {
			CommonUtil.error("IO flow exception, write message failed" , ex);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// ��ȡmessageID ��ȷ��΢��
	public static String getmicrosecond() {
		Calendar Cld = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		System.out.println(dateFormat.format(Cld.getTime()));
		return dateFormat.format(Cld.getTime()) + "001";
	}

	public static StringBuffer getmessage_master(Map<String, String> map) {
		StringBuffer message = new StringBuffer();
		message.append("ISM Fixed V02.00YYHSBCOHSW.OHCVSOL_UAT_GENSRV                                     HUB_COREBANK                                                    CHOPLSTENQ                                                      01.0001.00                                                                                            181                                                                              Z2018-11-22T03:50:37.663000+00:00                                                                                                                                                                                                                                                                               0000009330000000000000002540000004530000002260020101OH_SERVICE_HEADER               00860100000000CVS CNHSBC                                                        PFS       0102SWHCB_APPLICATION_HEADER        00850100000000                                                                           0101000218000218HUB_COREBANK                                                    CHOPLSTENQ                                                      01.0001.00xy                                                                                                                                                                                                                                                                                                         01000218");
		message.append("I");
		message.append("CHOPLSTENQ");
		message.append(map.get("instanceid"));// ��Ϣid
		message.append(map.get("zhangh"));
		if (map.get("limit") != null) {
			String limit = map.get("limit");
			boolean boo = true;
			while (boo) {
				if (limit.length() < 9) {
					limit = "0" + limit;
				} else {
					boo = false;
				}
			}
			message.append(limit);
		} else {
			message.append("000000000");
		}

		if (map.get("ccode") != null) {
			String ccode = map.get("ccode");
			boolean boo_ = true;
			while (boo_) {
				if (ccode.length() < 3) {
					ccode = ccode + " ";
				} else {
					boo_ = false;
				}
			}
			message.append(ccode);
		} else {
			message.append("   ");
		}
		return message;
	}

	public static StringBuffer getmessage_child(Map<String, String> map) {
		StringBuffer message = new StringBuffer();
		message.append("ISM Fixed V02.00YYHSBCOHSW.OHCVSOL_UAT_GENSRV                                     HUB_COREBANK                                                    CHOPLSTENQ                                                      01.0001.00                                                                                            181                                                                              Z2018-11-22T03:50:37.663000+00:00                                                                                                                                                                                                                                                                               0000009330000000000000002540000004530000002260020101OH_SERVICE_HEADER               00860100000000CVS CNHSBC                                                        PFS       0102SWHCB_APPLICATION_HEADER        00850100000000                                                                           0101000218000218HUB_COREBANK                                                    CHOPLSTENQ                                                      01.0001.00xy                                                                                                                                                                                                                                                                                                         01000218");
		message.append("I");
		message.append("CHOPENQ   ");
		message.append(map.get("instanceid"));// ��Ϣid
		message.append(map.get("zhangh"));
		message.append(map.get("imagekey"));
		if (map.get("limit") != null) {
			String limit = map.get("limit");
			boolean boo = true;
			while (boo) {
				if (limit.length() < 9) {
					limit = "0" + limit;
				} else {
					boo = false;
				}

			}
			message.append(limit);
		} else {
			message.append("000000000");
		}

		if (map.get("ccode") != null) {
			String ccode = map.get("ccode");
			boolean boo_ = true;
			while (boo_) {
				if (ccode.length() < 3) {
					ccode = ccode + " ";
				} else {
					boo_ = false;
				}
			}
			message.append(ccode);
		} else {
			message.append("   ");
		}

		return message;
	}

}
