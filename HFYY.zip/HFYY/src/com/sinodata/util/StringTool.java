package com.sinodata.util;

import java.util.HashMap;
import java.util.Map;

public class StringTool {
	
	//���ַ�����Ѱ������ �㷨
	public static Map fingNumberInString(Map<String,String> map ,String str) {
		if(str==null)str="";
		if(map==null) map = new HashMap();
		for (String sss : str.replaceAll("[^0-9]", ",").split(",")) 
		{
			if (sss.length() > 0)map.put(sss, "");
		}
		return map;
	}
	
	public static void main(String[] args) {
		String ss="(1&5)|(1&C2[2,3,4])";
		String[] tt =null;
		tt=zuhGuiZZH(ss);
		for(int i=0;i<tt.length;i++){
			System.out.println(tt[i]);
		}
		
	}
	/**
	 * ɾ������ӡ��
	 * @param map
	 * @param str
	 * @return
	 */
	public static String[] zuhGuiZZH(String zuhgz) {
		String[] list=null;
		if(zuhgz!=null){
			zuhgz = zuhgz.replaceAll("C[0-9]*\\[", ",");
			zuhgz = zuhgz.replaceAll("&", ",");
			zuhgz = zuhgz.replaceAll("\\|", ",");
			zuhgz = zuhgz.replaceAll(" ", "");
			zuhgz = zuhgz.replaceAll("\\[", "");
			zuhgz = zuhgz.replaceAll("\\]", "");
			zuhgz = zuhgz.replaceAll("\\(", "");
			zuhgz = zuhgz.replaceAll("\\)", "");
			list = zuhgz.split(",");
		}
		return list;
	}
}
