package com.sinodata.report.util;


//
public class ReportValidateTool {

	
	
}
