package com.sinodata.user;

import java.util.HashMap;
import java.util.Map;

import com.sinodata.common.SpringContent;
import com.sinodata.report.model.ReportReturn;
import com.sinodata.report.util.UreportUserInterface;
import com.sinodata.table.model.Table;
import com.unitop.exception.BusinessException;
import com.unitop.framework.util.DateTool;
import com.unitop.sysmgr.bo.Clerk;

public class YinjkrzcxImpl extends UreportCommon implements
		UreportUserInterface {

	public ReportReturn UserRules(Clerk clerk, Table table,SpringContent springContent) throws BusinessException {
		Map bigEqual = table.getWhere().getWhereBigEqualsValue();
		Map smaillEqual = table.getWhere().getWhereSmaillEqualsValue();
		
		String bcaozrq = (String) bigEqual.get("caozrq");
		String ecaozrq = (String) smaillEqual.get("caozrq");
		if(bcaozrq!=null&&ecaozrq!=null)
		{
			int days = DateTool.bDate(bcaozrq, ecaozrq);
			if(days>366)
			{
				return new ReportReturn(null,"��ѯ���ڿ�Ȳ��ܳ���һ��(366��)!",new HashMap());
			}
		}
		return this.doCommon(clerk, table, springContent);
	}
	public ReportReturn doInit(Clerk clerk, Table table,SpringContent springContent) throws BusinessException {
		return null;
	}
}
