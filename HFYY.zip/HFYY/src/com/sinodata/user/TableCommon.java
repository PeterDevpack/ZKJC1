package com.sinodata.user;

public class TableCommon {
	
}
