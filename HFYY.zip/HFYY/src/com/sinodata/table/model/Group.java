package com.sinodata.table.model;

import java.util.HashMap;
import java.util.Map;

//����-ʵ��
public class Group {
	private Map groupValue = new HashMap();

	public Map getGroupValue() {
		return groupValue;
	}

	public void setGroupValue(Map groupValue) {
		this.groupValue = groupValue;
	}
}
