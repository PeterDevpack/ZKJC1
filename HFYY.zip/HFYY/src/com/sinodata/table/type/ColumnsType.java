package com.sinodata.table.type;

public class ColumnsType {
	private String VARCHAR;
	private int INT;
	private float FLOAT;
}
