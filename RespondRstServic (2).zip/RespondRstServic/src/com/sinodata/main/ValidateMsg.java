package com.sinodata.main;
import java.util.Properties;
import org.apache.log4j.Logger;
/**
 * 用于该服务中的所有验证
 */
public class ValidateMsg {
	
	private static Logger _log = GetLogger.getLogger();
	private static Properties pro = LoadFile.getInstance().getPro();
	
	//用于服务启动验证
	public boolean startValid(){
		ValidateMsg vm = new ValidateMsg();
		//验证服务启动配置项是否存在
		if(pro.isEmpty()){
			/*_log.info("请确认config文件夹下配置文件StartAdr.properties是否存在内容");*/
			return false;
		}else{
			//验证一般配置参数，验证jdbc的配置
			if(!vm.validConfParam()||!vm.validJDBCParam()) {
				return false;
			}
		}
		//检验文件是否存在，若存在则删除
		//检验系统参数是否配置正确
		_log.debug("Configuration validation is complete. What you are currently using is"+pro.getProperty("version").trim()+"Edition");
		return true; 
	}
	
	//验证配置文件中的一般参数
	public boolean validConfParam(){
		//试用版本必输，可做挡板
		String version = pro.getProperty("version").trim();
		if(null == version || version.length()<=0){
			//_log.info("使用版本参数 version 未配置");
			return false;
		}else if(!version.equals("test")&&!version.equals("official")) {
			/*_log.info("没有您配置的version");*/
			return false;
		}
		//轮询间隔时间必输 且 要求大于等于零
		String waitTime = pro.getProperty("waitTime").trim();
		if(null == waitTime || waitTime.length()<=0){
			_log.info("轮询间隔时间参数 waitTime 未配置");
			return false;
		}
		if(Long.valueOf(waitTime) < 0){
			_log.info("使用版本参数 wait 异常");
			return false;
		}
		return true;
	}
	//验证配置文件中的JDBC参数 及 是否可连接
	public boolean validJDBCParam() {
		//检验写库方式
		String writetodbtype = pro.getProperty("writetodbtype").trim();
		if(null == writetodbtype || writetodbtype.length()<=0){
			//System.out.println("请配置数据库写入方式");
			_log.info("请配置数据库写入方式");
			return false;
		}else if("jdbc".equals(writetodbtype)){
			String db_user = pro.getProperty("db_user").trim();
			String db_url = pro.getProperty("db_url").trim();
			String db_pass = pro.getProperty("db_pass").trim();
			String db_driveclassname = pro.getProperty("db_driveclassname").trim();
			if(null == db_pass || db_pass.length()<=0 || null == db_url || db_url.length()<=0 
				|| null == db_user || db_user.length()<=0 ||null == db_driveclassname || db_driveclassname.length()<=0 ){
				_log.debug("以JDBC方式写入数据库，需要驱动，地址，用户，密码");
				return false;
			}
		}
		//检验好否能连接数据库
		try {
			String db_time = new Jdbc().SelectDbTime();
			if(db_time!=null&&db_time.length()>0) {
				_log.debug("数据库连接正常，当前数据库时间为"+db_time);
			}else {
				_log.info("数据库连接异常，请检查配置");
				return false;
			}
		} catch (Exception e) {
			_log.info("数据库连接异常，请检查配置:"+e.getMessage());
			return false;
		}
		return true;
	}
}

