package com.sinodata.main;

import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.ibm.mq.MQQueueManager;

public class MqTest {
	/**
	 * 轮询访问mq
	 * */
	public void polling() {

		Logger _log = GetLogger.getLogger();
		Properties configPro = LoadFile.getInstance().getPro();
		long waitTime = 0;

		waitTime = Long.valueOf(configPro.getProperty("waitTime"));

		String ip = configPro.getProperty("mqip");
		String youdao = configPro.getProperty("mqyoudao");
		Integer zifj = Integer.valueOf(configPro.getProperty("mqzifj"));
		Integer port = Integer.valueOf(configPro.getProperty("mqport"));
		String qmname = configPro.getProperty("mqqmname");
		String qname = configPro.getProperty("mqqname");

		_log.info("ip:" + ip);
		_log.info("youdao:" + youdao);
		_log.info("zifj:" + zifj);
		_log.info("port:" + port);
		_log.info("qmname:" + qmname);
		_log.info("qname:" + qname);

		while (true) {

			// 打开MQ连接
			_log.info("Open MQ connection");
			MQQueueManager qMgr = MQconnection.mqconn(ip, youdao, zifj, port,qmname, qname);
			_log.info("MQ Open Link Successfully");

			// 记录任务开始时间
			long startTime = System.currentTimeMillis();
			try {
				// 接收MQ消息
				String message = MQconnection.getMessage(qMgr, qmname, qname);
				
				if (message != null && !"".equals(message)) {
					// message 转map
					Map<String, Object> map = MQconnection.getmessagemap(message);
					if (!map.isEmpty()) {
						_log.info("Successful map transformation");
						if (("CHOPLSTENQ").equals(map.get("requesttype"))) {
							_log.info("insert" + map.get("instanceid") + "Head Office Result Beginning");
							// 拆分主任务结果 进行插库
							boolean flag = new MqOracle().insert(map);
							if (("false").equals(flag)) {
								_log.info("Director Business Results Insertion into Database Failed");
							}
							boolean flag1 = new MqOracle().insertFb(map);
							if (("false").equals(flag1)) {
								_log.info("Director's Subtable Results Insertion into Database Failed");
							}

							// 当任意主任务表 或者副标插入失败时候 将信息保存下来
							if (!flag || !flag1) {

							}
						}
						if (("CHOPENQ   ").equals(map.get("requesttype"))) {
							_log.info("insert" + map.get("instanceid") + "Subtask results start");
							// 子任务结果
							boolean flag2 = new MqOracle().insertZib(map);
							if (("false").equals(flag2)) {
								_log.info("Subtask result insertion into database failed");
							}
						}
						// 记录任务结束时间
						long endTime = System.currentTimeMillis();
						// 如果任务用时 不足 设定的两次查询间隔 则沉睡差值时间
						long useTime = endTime - startTime;
						_log.info("Single polling is time-consuming：" + useTime + "Millisecond");
						if (useTime < waitTime) {
							Thread.sleep(waitTime - useTime);
						}

					} else {
						_log.info("No task results, rest for 1 second!");
						Thread.sleep(1000);
					}
				}else{
					_log.info("message is null!");
					Thread.sleep(1000);
				}
				
			} catch (InterruptedException e) {
				_log.info("When polling, an exception occurs when the main thread sleeps:"+ e.getMessage());
			} catch (Exception e) {
				_log.info("Errors in polling:" + e.getMessage());
				continue;
			}

		}
	}
}
