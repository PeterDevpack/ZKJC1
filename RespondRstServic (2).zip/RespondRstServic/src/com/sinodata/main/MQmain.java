package com.sinodata.main;

import java.util.Calendar;

import org.apache.log4j.Logger;

public class MQmain {
	//主方法，用于启动该jar应用的入口
	public static void main(String[] args) {
		//加载配置文件；加载日志配置文件；创建log日志文件夹
		Logger _log = GetLogger.getLogger();
		
		//验证参数是否配及参数是否可用
		if(!(new ValidateMsg().startValid())) {
			_log.info("Cannot start normally, please check parameter configuration");
			return;
		}
		//启动服务中的轮询
		try {
			new MqTest().polling();
		}catch(Exception e) {
			_log.info("Error in polling"+e.getMessage());
			return;
		}
		_log.info(Calendar.getInstance().getTime()+"Successful start of polling procedure");
	}
}
