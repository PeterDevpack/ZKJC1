package com.sinodata.main;

public class MqUpSql {
	// 获取数据库时间 所需sql
		public String getDBTime() {
			return "select systimestamp from dual";
		}
}
