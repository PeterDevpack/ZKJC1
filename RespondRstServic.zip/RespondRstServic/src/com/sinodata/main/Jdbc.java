package com.sinodata.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 * JDBC任务
 */
public class Jdbc {
	
	//JDBC方式操作数据库
	private Logger _log = GetLogger.getLogger();
	private static String driverclassname ="";
	private static String url = "";
	private static String user = "";
	private static String pass = "";
	
	static{
		Properties pro = LoadFile.getInstance().getPro();
		url = pro.getProperty("db_url");
		driverclassname=pro.getProperty("db_driveclassname");
		user=pro.getProperty("db_user");
		pass=pro.getProperty("db_pass");
	}
	/**
	 * 查询数据库时间
	 * @return
	 */
	public String SelectDbTime(){
		String sql = new MqUpSql().getDBTime();
		String db_time= "";
		Connection conn = null;
		Statement stm = null;
		ResultSet rs = null;
		try{
			Class.forName(driverclassname);
			conn = DriverManager.getConnection(url, user, pass);
			stm = conn.createStatement();
			rs = stm.executeQuery(sql);
			if(rs.next()) {
				db_time = rs.getString("systimestamp");
			}
		}catch(Exception e){
			_log.info("查询数据库失败："+sql);
			e.printStackTrace();
		}finally{
			closeDb(stm,conn);
		}
		_log.debug("查询数据库成功："+sql);
		return db_time;
	}
	
	/**
	 * 关闭连接数据库的相应资源
	 */
	public void closeDb(Statement stm , Connection conn){
		
		if(stm !=null){
			try {
				stm.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	

}
