package com.sinodata.main;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.sinodata.util.AccessTextFile;

/**
 * 读取log4j的配置文件
 */
public class GetLogger {
	static {
		AccessTextFile.makeDirs("log");
		PropertyConfigurator.configure("config/log4j.properties");
	}
	private static Logger _log = Logger.getLogger(GetLogger.class);
	
	public static Logger getLogger(){
		return _log;
	}
}
