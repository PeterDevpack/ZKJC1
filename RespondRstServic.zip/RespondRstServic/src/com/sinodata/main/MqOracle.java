package com.sinodata.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

public class MqOracle {
	private static String USERNAMR = "";
	private static String PASSWORD = "";
	private static String DRVIER ="";
	private static String URL ="";
	//日志声明参数
	final Logger _log = GetLogger.getLogger();
	static{
		Properties pro = LoadFile.getInstance().getPro();
		URL = pro.getProperty("db_url");
		DRVIER=pro.getProperty("db_driveclassname");
		USERNAMR=pro.getProperty("db_user");
		PASSWORD=pro.getProperty("db_pass");
	}
    
    Connection connection = null;
    PreparedStatement pstn = null;
    ResultSet rs = null;
    //连接数据库
    public Connection getConnection() {
        try {
            Class.forName(DRVIER);
            connection = DriverManager.getConnection(URL, USERNAMR, PASSWORD);
            _log.info("connect succ!");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("class not find !", e);
        } catch (SQLException e) {
            throw new RuntimeException("get connection error!", e);
        }
        return connection;
    }
    public void ReleaseResource() {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
            	_log.info("释放资源rs："+e.getMessage());
            }
        }
        if (pstn != null) {
            try {
                pstn.close();
            } catch (SQLException e) {
            	_log.info("释放资源pstn:"+e.getMessage());
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
            	_log.info("释放资源连接关闭异常："+e.getMessage());
            }
        }
    }
   
    //主任务结果插入
    public boolean insert(Map<String, Object> map){
    	connection = getConnection();    
    	String sql="INSERT INTO TASKZJGB(INSTANCEID,ZHANGH,INDICATOR,INSTRUCTION,NOTELINE,OCCURRENCECOUNT,NUMBERSIGNATURE,NOTOSIGNATURE)VALUES(?,?,?,?,?,?,?,?)";
    	try {  
    		connection.setAutoCommit(false);
    		pstn = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
    		if("".equals((String)map.get("instanceid")) && (String)map.get("instanceid") != null){
    			pstn.setString(1, (String)map.get("instanceid") );
    		}
    		if("".equals((String)map.get("zhangh")) && (String)map.get("zhangh") != null){
    			pstn.setString(2, (String)map.get("zhangh") );
    		}
    		if("".equals((String)map.get("cbindicator")) && (String)map.get("cbindicator") != null){
    			pstn.setString(3, (String)map.get("cbindicator") );
    		}
    		if("".equals((String)map.get("instruction")) && (String)map.get("instruction") != null){
    			pstn.setString(4, (String)map.get("instruction") );
    		}
    		if("".equals((String)map.get("noteline")) && (String)map.get("noteline") != null){
    			pstn.setString(5, (String)map.get("noteline") );
    		}
    		if("".equals((String)map.get("occurrencecount")) && (String)map.get("occurrencecount") != null){
    			pstn.setString(6, (String)map.get("occurrencecount") );
    		}
    		if("".equals((String)map.get("numberSignature")) && (String)map.get("numberSignature") != null){
    			pstn.setString(7, (String)map.get("numberSignature") );
    		}
    		if("".equals((String)map.get("notoSignature")) && (String)map.get("notoSignature") != null){
    			pstn.setString(8, (String)map.get("notoSignature") );
    		}
			pstn.executeUpdate();
			pstn.getGeneratedKeys();
			connection.commit();
			connection.setAutoCommit(true);
			}catch (Exception e) {  
    		_log.info("插库异常："+e.getMessage());
    		return false;
    	}  finally {
    		ReleaseResource();
    	}
		return true;
    }
    //主任务副表结果插入(多任务循环体)  
    @SuppressWarnings("unchecked")
	public boolean insertFb(Map<String, Object> map){
    	connection = getConnection();
    	try {  
    		connection.setAutoCommit(false);
    		List<Map<String, String>> list=(List<Map<String, String>>) map.get("list");
	    	for (int i = 0; i < list.size(); i++) {
	    		String sql="INSERT INTO TASKJGFB(masterinstanceid , zhangh , limit , ccode , indicator , recordsequence , signaturename , imagekey)VALUES(?,?,?,?,?,?,?,?,?)";
	    		pstn = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
	    		/*pstn.setString(1, list.get(i).get("occurrencecount"));*/
	    		pstn.setString(1, list.get(i).get("limit"));
				pstn.setString(2, list.get(i).get("ccode"));
				pstn.setString(3, list.get(i).get("noteline"));
				pstn.setString(4, list.get(i).get("recordsequence"));
				pstn.setString(5, list.get(i).get("signaturename"));
				pstn.setString(6, list.get(i).get("imagekey"));
				pstn.setString(7, (String)map.get("instanceid"));
				pstn.setString(8, (String)map.get("zhangh"));
				pstn.executeUpdate();
				pstn.getGeneratedKeys();
				connection.commit();
			}
	    	connection.setAutoCommit(true);
			}catch (Exception e) {  
    		_log.info("插入主任务副表结果异常:"+e.getMessage());
    		return false;
    	}  finally {
    		ReleaseResource();
    	}
		return true;
    }
    
    //子任务结果插入
    public boolean insertZib(Map<String, Object> map){
    	connection = getConnection();
    	String sql="INSERT INTO TASKJGZIB(INSTANCEID,ZHANGH,IMAGEKEY,LIMIT,CCODE,CHOPINDICATOR,RECORDSEQUENCE,SIGNATURENAME,IMAGE)VALUES(?,?,?,?,?,?,?,?,?)";
    	try {  
    		connection.setAutoCommit(false);
    		pstn = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
    		
    		pstn.setString(1, (String)map.get("instanceid"));
			pstn.setString(2, (String)map.get("zhangh"));
			pstn.setString(3, (String)map.get("imagekey"));
			pstn.setString(4, (String)map.get("limit"));
			pstn.setString(5, (String)map.get("ccode"));
			pstn.setString(6, (String)map.get("chopindicator"));
			pstn.setString(7, (String)map.get("recordsequence"));
			pstn.setString(8, (String)map.get("signaturename"));
			pstn.setString(9, (String)map.get("image"));
			pstn.executeUpdate();
			pstn.getGeneratedKeys();
			connection.commit();
			connection.setAutoCommit(true);
			}catch (Exception e) {  
    		_log.info("插入子任务结果异常:"+e.getMessage());
    		return false;
    	}  finally {
    		ReleaseResource();
    	}
		return true;
    }
}
