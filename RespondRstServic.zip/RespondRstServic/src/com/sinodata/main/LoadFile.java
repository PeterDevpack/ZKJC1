package com.sinodata.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * 读取properties文件
 */
public class LoadFile {
	//加载配置文件config/StartAdr.properties
	//存数据库方式配置
	//自动控制配置
	//启动地址配置
	private static Logger _log = GetLogger.getLogger();
	private static LoadFile loadfile = null;
	private static Properties prop_addr = new Properties();
	private String URI = "config"+File.separator+"InitialConf.properties";
	
	
	private LoadFile(){
		InputStream in;
		try {				
			in = new FileInputStream(URI);
			prop_addr.load(in);
			in.close();
			_log.debug("StartAdr.properties配置文件读取成功");
		} catch (IOException e) {
			_log.info("StartAdr.properties配置文件读取错误，请确认是否存在"+e.getMessage());
		}
	}
	public static LoadFile getInstance(){
		if(loadfile==null){
			loadfile = new LoadFile();
		}
		return loadfile;
	}
	
	public Properties getPro(){
		return prop_addr;
	}
	
	public void setPro(Properties prop_addr){
		LoadFile.prop_addr = prop_addr;
	}
}
