package com.sinodata.main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

/**
 * 连接MQ
 * 
 * @author BBBBBBao
 * 
 */
public class MQconnection {

	// 定义队列管理器和队列的名称
	private static String qmName;
	private static String qName;
	private static MQQueueManager qMgr;
	static Logger _log = GetLogger.getLogger();


	public static void mqconn(String ip, String youdao, Integer zifj, Integer port, String qmname,
			String qname) {
		MQEnvironment.hostname = ip; 
		MQEnvironment.channel = youdao; 
		MQEnvironment.CCSID = zifj;
		MQEnvironment.port = port;
		qmName = qmname;
		qName = qname;
		try {
			qMgr = new MQQueueManager(qmName);
		} catch (MQException e) {
			_log.info("MQ开启连接失败！" , e);
		}
	}


	public static String getMessage() {
		String message = null;
		try {
			int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT;
			MQMessage retrieve = new MQMessage();
			MQGetMessageOptions gmo = new MQGetMessageOptions();
			gmo.options = gmo.options + MQC.MQGMO_SYNCPOINT;
			gmo.options = gmo.options + MQC.MQGMO_WAIT;
			gmo.options = gmo.options + MQC.MQGMO_FAIL_IF_QUIESCING;
			if (qMgr == null || !qMgr.isConnected()) {
				qMgr = new MQQueueManager(qmName);
			}
			MQQueue queue = qMgr.accessQueue(qName, openOptions);
			queue.get(retrieve, gmo);
			message = retrieve.readStringOfByteLength(retrieve.getDataLength());
			queue.close();
			qMgr.commit();
		} catch (MQException ex) {
			_log.info("MQ收取消息异常：" + ex.completionCode + " Reason code " + ex.reasonCode + ex);
		} catch (IOException ex) {
			_log.info("IO异常"  + ex);
		} catch (Exception ex) {
			_log.info(ex);
		} finally {
			try {
				qMgr.disconnect();
				_log.info("关闭MQ链接！");
			} catch (MQException e) {
				_log.info("关闭MQ链接异常！" + e);
			}
		}
		return message;
	}

	/**
	 * 将消息转为Map
	 * 
	 * @param message
	 * @return
	 */
	public static Map<String, Object> getmessagemap(String message) {
		// 通过判断message 的 messagetype requesttype 来确定 是主任务消息 还是子任务消息 
		String messagetype = message.substring(1332, 1333);
		String requesttype = message.substring(1333, 1343);
		// 主任务结果消息
		if ("O".equals(messagetype) && "CHOPLSTENQ".equals(requesttype)) {
			_log.info("主消息转map");
			int max = message.length();
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("header", message.substring(0, 1332));
			map.put("messagetype", messagetype);
			map.put("requesttype", requesttype);
			map.put("instanceid", message.substring(1343, 1363));
			map.put("zhangh", message.substring(1363, 1381));
			map.put("ERRMSG", message.substring(1381, 1391));
			String error = message.substring(1381, 1391);
			//判断是否有错误信息  
			if("          ".equals(error)){
				map.put("groupid_begin", message.substring(1476, 1486));
				// 子任务次数 只用存储一次 所以放在循环的外面
				int count = Integer.parseInt(message.substring(1486, 1491));
				map.put("occurrencecount", count);// 子任务次数
				List<Map<String, String>> list = new ArrayList<Map<String, String>>();
				//count == 0    循环体中其他数据全是null
				if(count !=  0){
					_log.info("循环体消息计数为：" + count);
					for (int i = 0; i < count; i++) {
						Map<String, String> map_ = new HashMap<String, String>();
						int index_1 = 1486 + (i * 207);
						int index_2 = 1486 + (i * 207) + ((i + 1) * 5);
						int index_3 = 1486 + (i * 207) + ((i + 1) * 5) + ((i + 1) * 9);
						int index_4 = 1486 + (i * 207) + ((i + 1) * 5) + ((i + 1) * 9) + ((i + 1) * 3);
						int index_5 = 1486 + (i * 207) + ((i + 1) * 5) + ((i + 1) * 9) + ((i + 1) * 3) + ((i + 1) * 1);
						int index_6 = 1486 + (i * 207) + ((i + 1) * 5) + ((i + 1) * 9) + ((i + 1) * 3) + ((i + 1) * 1) + ((i + 1) * 5);
						int index_7 = 1486 + (i * 207) + ((i + 1) * 5) + ((i + 1) * 9) + ((i + 1) * 3) + ((i + 1) * 1) + ((i + 1) * 5) + ((i + 1) * 175);
						int index_8 = 1486 + (i * 207) + ((i + 1) * 5) + ((i + 1) * 9) + ((i + 1) * 3) + ((i + 1) * 1) + ((i + 1) * 5) + ((i + 1) * 175) + ((i + 1) * 9);
						map_.put("limit", message.substring(index_2, index_3));
						map_.put("ccode", message.substring(index_3, index_4));
						map_.put("chopindicator", message.substring(index_4, index_5));
						map_.put("recordsequence", message.substring(index_5, index_6));
						map_.put("signaturename", message.substring(index_6, index_7));
						map_.put("imagekey", message.substring(index_7, index_8));
						list.add(map_);
					}
				}else{
					_log.info("循环体消息计数为0！");
				}
				map.put("list", list);
				map.put("groupid_end", message.substring(max - 2488, max - 2498));
				map.put("crossindicator", message.substring(max - 2498, max - 2499));
				map.put("numberSignature", message.substring(max - 2499, max - 2504));
				map.put("notoSignature", message.substring(max - 2504, max - 2505));
				map.put("instruction", message.substring(max - 2505, max - 1200));
				map.put("noteline", message.substring(max - 1200, max));
			}else{
				_log.info("MQ消息发现异常信息：！" + error + "。" + "reeortest:" + message.substring(1398, 1476));
				map.put("errorid", message.substring(1391, 1398));
				map.put("errortext", message.substring(1398, 1476));
			}
			_log.info("主消息MAP：" + map);
			return map;
		}
		// 子任务结果消息
		if ("O".equals(messagetype) && "CHOPENQ   ".equals(requesttype)) {
			_log.info("子消息转map");
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("header", message.substring(0, 1332));
			map.put("messagetype", messagetype);
			map.put("requesttype", requesttype);
			map.put("instanceid", message.substring(1343, 1363));
			map.put("errorid", message.substring(1363, 1370));
			map.put("errotext", message.substring(1370, 1448));
			map.put("zhangh", message.substring(1448, 1466));
			map.put("imagekey", message.substring(1466, 1475));
			map.put("limit", message.substring(1475, 1484));
			map.put("ccode", message.substring(1484, 1487));
			map.put("chopindicator", message.substring(1487, 1488));
			map.put("recordsequence", message.substring(1488, 1493));
			map.put("signaturename", message.substring(1493, 1668));
			map.put("image", message.substring(1668, 131668));
			_log.info("子消息MAP：" + map);
			return map;
		}

		return null;

	}

}
