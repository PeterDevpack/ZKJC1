package com.sinodata.main;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

/**
 * 连接MQ
 * 
 * @author BBBBBBao
 * 
 */
public class MQconnection {

	static Logger _log = GetLogger.getLogger();


	public static MQQueueManager mqconn(String ip, String youdao, Integer zifj, Integer port, String qmname,
			String qname) {
		_log.info("Connect MQ！");
		MQEnvironment.hostname = ip; 
		MQEnvironment.channel = youdao;
		MQEnvironment.CCSID = zifj;
		MQEnvironment.port = port;
		try {
			MQQueueManager qMgr = new MQQueueManager(qmname);
			return qMgr;
		} catch (MQException e) {
			_log.info("MQ Open Connection Failed！" , e);
			return null;
		}
	}

	


	public static String getMessage(MQQueueManager qMgr , String qmname, String qname) {
		String message = null;
		try {
			int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT;
			MQMessage retrieve = new MQMessage();
			MQGetMessageOptions gmo = new MQGetMessageOptions();
			gmo.options = gmo.options + MQC.MQGMO_SYNCPOINT;
			gmo.options = gmo.options + MQC.MQGMO_WAIT;
			//gmo.options = gmo.options + MQC.MQGMO_FAIL_IF_QUIESCING;
			if (qMgr == null || !qMgr.isConnected()) {
				qMgr = new MQQueueManager(qmname);
			}
			MQQueue queue = qMgr.accessQueue(qname, openOptions);
			queue.get(retrieve, gmo);
			message = retrieve.readStringOfByteLength(retrieve.getDataLength());
			queue.close();
			qMgr.commit();
			return message;
		} catch (MQException ex) {
			_log.info("MQ receives message exceptions： Reason code " + ex.reasonCode + " ,"+ ex.getMessage());
			return null;
		} catch (IOException ex) {
			_log.info("IO anomaly"  + ex);
			return null;
		} catch (Exception ex) {
			_log.info(ex);
			return null;
		} finally {
            try {
            		qMgr.disconnect();
                _log.info("close MQ");
            } catch (MQException e) {
                e.printStackTrace();
            }
        }
	}

	/**
	 * 将消息转为Map
	 * 
	 * @param message
	 * @return
	 */
	public static Map<String, Object> getmessagemap(String message) {
		// 通过判断message 的 messagetype requesttype 来确定 是主任务消息 还是子任务消息 
		String messagetype = message.substring(1332, 1332+1);
		String requesttype = message.substring(1332+1, 1343);
		// 主任务结果消息
		int max = message.length();
		if ("O".equals(messagetype) && "CHOPLSTENQ".equals(requesttype)) {
			_log.info("Master message to map");
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("header", message.substring(0, 1332));
			map.put("messagetype", messagetype);
			map.put("requesttype", requesttype); 
			map.put("instanceid", message.substring(1343, 1363));
			map.put("zhangh", message.substring(1363, 1381));
			map.put("error", message.substring(1381, 1391));
			String errorid =  message.substring(1391, 1398);
			//判断是否有错误信息  
			if("       ".equals(errorid)){
				map.put("groupid_begin", message.substring(1476, 1486));
				// 子任务次数 只用存储一次 所以放在循环的外面
				int count = Integer.parseInt(message.substring(1486, 1491));
				map.put("occurrencecount", count+"");// 子任务次数
				List<Map<String, String>> list = new ArrayList<Map<String, String>>();
				//count == 0    循环体中其他数据全是null
				if(count !=  0){
					_log.info("The loop body message count is：" + count);
					for (int i = 0; i < count; i++) {
						Map<String, String> map_ = new HashMap<String, String>();
						int index_1 = 1491 + (i * 202);
						int index_2 = index_1 + 9;
						int index_3 = index_2 + 3;
						int index_4 = index_3 + 1;
						int index_5 = index_4 + 5;
						int index_6 = index_5 + 175;
						int index_7 = index_6 + 9;
						map_.put("limit", message.substring(index_1, index_2));
						map_.put("ccode", message.substring(index_2, index_3));
						map_.put("chopindicator", message.substring(index_3, index_4));
						map_.put("recordsequence", message.substring(index_4, index_5));
						map_.put("signaturename", message.substring(index_5, index_6));
						map_.put("imagekey", message.substring(index_6, index_7));
						list.add(map_);
					}
				}else{
					_log.info("Loop body message count is 0！");
				}
				
				map.put("list", list);
				map.put("groupid_end", message.substring(1491+(count*202), 1501+(count*202)));  
				map.put("crossindicator", message.substring(1501+(count*202), 1502+(count*202)));
				map.put("numberSignature", message.substring(1502+(count*202), 1507+(count*202)));
				map.put("notoSignature", message.substring(1507+(count*202), 1508+(count*202)));
				map.put("instruction", message.substring(1508+(count*202), 2813+(count*202)));
				map.put("noteline", message.substring(2813+(count*202), 4013+(count*202)));
			}else{
				_log.info("MQ message discovery exception information：！" + errorid + "。" + "reeortest:" + message.substring(1398, 1476));
				map.put("errorid", message.substring(1391, 1398));
				map.put("errortext", message.substring(1398, 1476));
			}
			_log.info("Main message MAP：" + map);
			return map;
		}
		// 子任务结果消息
		if ("O".equals(messagetype) && "CHOPENQ   ".equals(requesttype)) {
			_log.info("Submessage to map");
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("header", message.substring(0, 1332));
			map.put("messagetype", messagetype);
			map.put("requesttype", requesttype);
			map.put("instanceid", message.substring(1343, 1363));
			map.put("errorid", message.substring(1363, 1370));
			map.put("errotext", message.substring(1370, 1448));
			map.put("zhangh", message.substring(1448, 1466));
			map.put("imagekey", message.substring(1466, 1475));
			map.put("limit", message.substring(1475, 1484));
			map.put("ccode", message.substring(1484, 1487));
			map.put("chopindicator", message.substring(1487, 1488));
			map.put("recordsequence", message.substring(1488, 1493));
			map.put("signaturename", message.substring(1493, 1668));
			map.put("image", message.substring(1668, max));
			_log.info("Sub message MAP：" + map);
			return map;
		}

		return null;

	}

}
