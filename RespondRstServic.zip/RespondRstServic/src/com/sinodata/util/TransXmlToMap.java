package com.sinodata.util;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.xml.sax.InputSource;

@SuppressWarnings("unchecked")
public class TransXmlToMap {
	
	// 创建XML解析器
		public Map<String, String> transXML(String message) throws JDOMException,
				IOException {
			StringReader read = new StringReader(message);
			InputSource source = new InputSource(read);
			SAXBuilder saxb = new SAXBuilder();
			Document doc = null;
			doc = saxb.build(source);
			Element root = doc.getRootElement();
			// System.out.println(root.getName());
			Map<String, String> map = new HashMap<String, String>();
			parseXML(root, map);
			return map;
		}

		// 循环遍历
		public void parseXML(Element root, Map<String, String> map) {
			List<Element> root0 = (List<Element>) root.getChildren();
			if (root0.size() <= 0) {
				return;
			}
			for (int i = 0; i < root0.size(); i++) {
				Element et = (Element) root0.get(i);
				parseXML(et, map);
				map.put(et.getName(), et.getText());
				// System.out.println(et.getName());
				// System.out.println(et.getText());

			}
		}
		
	/*	public static void main(String[] args) {
			String msg = "<autoProve><RequestBody><SYSCODE>1</SYSCODE><NODEID>1</NODEID><ACCNO>1</ACCNO><XITLX>1</XITLX><AMOUNT>100</AMOUNT><BILLNO>1</BILLNO><BILLDATE>20180112</BILLDATE><BILLTYPE>1</BILLTYPE><CHECKTYPE>1</CHECKTYPE><IMAGEGETTYPE>1</IMAGEGETTYPE><IMAGENAME>1</IMAGENAME><TELLNO>1</TELLNO><TELLORGNO>1</TELLORGNO><REMARK>1</REMARK><TASKID>1</TASKID><TASKDATE>1</TASKDATE><TASKTIME>1</TASKTIME></RequestBody></autoProve>";
		
			TransXmlToMap test = new TransXmlToMap();
			try {
				Map<String,String> map = test.transXML(msg);
				System.out.println(map.toString());
			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//System.out.println(Date.parse(new Date("20180202").toString()));
		}*/
}
