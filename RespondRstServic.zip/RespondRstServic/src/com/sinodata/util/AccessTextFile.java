package com.sinodata.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/**
 * 操作文件的工具类
 * @author eleven
 *
 */
public final class AccessTextFile {

	/**
	 * 操作本地文件函数
	 */
	public String readToBuffer(String directory) throws IOException {//读取本地文件信息
		FileInputStream fis = new FileInputStream(new File(directory));
		InputStreamReader reader = new InputStreamReader(fis);
		BufferedReader breader = new BufferedReader(reader);
		String outputString="";
		String judge=breader.readLine();
		while(judge!=null)
		{
			outputString +=(judge+"@");
			judge=breader.readLine();
		}
		rwriteToFiler("", directory);
		breader.close();
		reader.close();
		fis.close();
		return outputString;
	}

	//将信息添加到文件
	public void writeToFiler(String inputString,String directory) throws IOException {
		FileOutputStream fos = new FileOutputStream(new File(directory), true);
		OutputStreamWriter writer = new OutputStreamWriter(fos);
		BufferedWriter bwriter = new BufferedWriter(writer);

		bwriter.write(inputString);
		bwriter.newLine();
		bwriter.flush();

		bwriter.close();
		writer.close();
		fos.close();
	}
	
	//重写文件的信息
	public void rwriteToFiler(String inputString,String directory) throws IOException {
		FileOutputStream fos = new FileOutputStream(new File(directory));
		OutputStreamWriter writer = new OutputStreamWriter(fos);
		BufferedWriter bwriter = new BufferedWriter(writer);

		bwriter.write(inputString);
		bwriter.flush();

		bwriter.close();
		writer.close();
		fos.close();
	}
	
	//文件是否存在，不存在则创建一个
	public static boolean makeDirs(String Dir) {
		boolean ReturnValue = true;
		File f = new File(Dir);
		if (!f.exists())
			ReturnValue = f.mkdirs();
		return ReturnValue;
	}
	
	public static void createFileByDirs(String Dir) throws IOException {
		File f = new File(Dir);
		if (!f.exists()) {
			f.createNewFile();
		}
	}
	
}