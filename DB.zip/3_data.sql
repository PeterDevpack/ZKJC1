set define off;
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('icheck_version', null, null, '3.0', null, null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('getVersion_Addr', '辅助OCX版本地址', 'string', 'http://172.168.1.196', '系统参数', '辅助OCX版本地址');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('xit_sequence', '流水号', 'string', '31312', '系统参数', '不允许修改');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('maxmeibzs', '最大输入每本张数', 'int', '1000', '系统参数', '最大输入每本张数限制');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('versionnum', '产品版本号', 'string', 'V3.0', '系统参数', '产品版本号');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('oper_tctd', '系统通存通兑修改时间', 'string', '13:00', '系统参数', '不能修改');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('org_ranking', '机构层级控制参数', 'int', '5', '系统参数', '控制系统机构层级数量');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('admin', '配置平台管理员密码', 'string', 'admin', '系统参数', '后台控制台管理员密码');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('file_address_ip', '文件服务器IP', 'string', '172.167.1.133', '系统参数', '文件服务器IP地址');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('version', '版本类型', 'string', 'zhengshi', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('productperiod', '产品试用截止日期', 'string', '2011-12-22', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('empower', '系统授权方式', 'string', 'w', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('clerkquantity', '柜员创建数量', 'string', '500', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('onlinenum', '同时在线柜员数', 'string', '1000', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('biz_date', '后台批量处理日期', 'string', '2014-08-13', '批量服务参数', '不能修改');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('report_line', 'Ureport一行栏位数量', 'string', '4', 'Ureport引擎', 'Ureport定制参数');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('db_type', '支持数据库类型', 'string', 'oracle', '系统参数', '支持数据库类型:oracle db2');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('rootcode', '总行机构号', 'string', 'HFYY', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('rootname', '总行名称', 'string', '总行', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('supermanager', '系统管理员编号', 'string', '0', '系统参数', '分行创建处理系统管理员,规则:[机构号+补充编码]');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('adminPassword', '柜员默认密码', 'string', '111111', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('systemmodle', '系统是否开启测试模式', 'string', 'test', '系统参数', '设置:test开启;设置shengc表示生成模式');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('changpassworddays', '强制柜员修改密码天数', 'string', '30', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('updatepasswordtimes', '不能使用最近几次密码', 'string', '5', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('errorpasswordtimes', '几次密码锁定', 'string', '6', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('outtime', '柜员登录session超时设置(单位:秒)', 'string', '1800', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('forcedtosign', '是否开启强制签退功能', 'string', '0', '系统参数', ' 1:开启 0:关闭');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('tesyw_shuangrhq', '是否“特殊业务”双人会签', 'string', '0', '系统参数', ' 1:开启 0:关闭');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('pingzyxll', '是否开启影像浏览', 'string', '1', '系统参数', ' 1:开启 0:关闭');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('yingjkll', '是否开启印鉴卡浏览', 'string', '1', '系统参数', ' 1:开启 0:关闭');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('startPz', '凭证号开头字母', 'string', 'J', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('maxpings', '凭证一次最多出售多少张', 'string', '100', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('yanyinlogType', '账户维护日志类型', 'string', '开户|账户复核|变更|修改资料|账户销户|销户恢复|账户挂失|账户解挂|账户物理删除', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('admincode', '超级管理员)', 'string', '000000', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('baobys', '报表页面记录条数', 'string', '25', '系统参数', '报表默认页面显示记录条数');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('ocx_version', 'ocx版本信息', 'string', '3.1.0.3', 'OCX版本参数', 'oxc版本信息');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('kzcs_version', 'ocx控制参数信息版本', 'string', '1.5', 'OCX版本参数', 'ocx控制参数信息版本号');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('sxkz_version', 'ocx属性扩展信息版本', 'string', '1.4', 'OCX版本参数', 'ocx属性扩展信息版本');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('org_guanlms', '机构管理模式', 'string', '2', '系统参数', '1:集中管理;2:分行管理');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('file_address_port', '文件服务器端口', 'int', '7001', '系统参数', '文件服务器端口');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('file_address_outtime', '文件服务器超时', 'int', '10000', '系统参数', '文件服务器超时');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('clerk_guanlms', '柜员管理模式', 'string', '1', '系统参数', '1:集中管理;2:分行管理');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('maxbens', '最大输入本数', 'int', '50', '系统参数', '最大输入本数限制');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('dic_version', 'ocx字典数据版本', 'string', '3.3', 'OCX版本参数', 'ocx字典数据版本');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('kag_kongzcs', '开户是否生成卡柜任务', 'string', '1', '系统参数', '1:开启;0关闭');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('clerk_firstlogincpw', '柜员第一次登录强制修改密码', 'string', '1', '系统参数', '1:开启;2:关闭');
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('datasync', '同步业务规则和提示信息数据', 'string', 't', '系统参数', null);
insert into BSKONGZCS (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM) values ('local_image', '是否显示本地影像按钮', 'string', '1', '系统参数', ' 1:开启 0:关闭');



INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'CANSSM', '参数描述', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('12', 'REMARK', '备注栏位', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('12', 'INDUSTRYCHARACTER', '货币号', 'string', '文本框', null, null, null, '1', '1', '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('13', 'cansid', '控制参数ID', 'string', '文本框', null, null, 'required', '1', '1', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'YUANSNAME', '元素name', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('13', 'canslx', '控制参数类型', 'string', '文本框', null, 'int', null, '1', '1', '1', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('13', 'parametervalue', '控制参数值', 'string', '文本框', null, '1', null, '1', '1', '1', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('001', 'postnum', '主键', 'string', '文本框', null, null, null, '1', '1', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('001', 'postname', '权限名称', 'string', '文本框', null, null, null, '1', '0', '1', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'BAOBBS', '报表标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'BAOBMC', '报表名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'BAOBBT', '报表标题', 'string', '文本框', null, null, null, '1', null, '0', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHIFKY', '是否可用', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHIFFY', '是否分页', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'FENYTJ', '分页条件', 'int', '文本框', null, null, null, '1', null, '1', '0', '5', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHIFDY', '是否打印', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHIFSC', '是否删除', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHUJHQFS', '数据获取方式', 'string', '文本域', null, null, null, '1', null, '0', '0', '8', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'ZHIDYL', '自定义类', 'string', '文本域', null, null, null, '1', null, '0', '0', '9', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('15', 'QUANXID', '权限ID', 'string', '文本框', null, null, null, ' ', ' ', ' ', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('15', 'QUANXMC', '权限名称', 'string', '文本框', null, null, null, ' ', ' ', ' ', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('15', 'QUANXLX', '权限类型', 'string', '文本框', null, null, null, ' ', ' ', ' ', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('15', 'QUANXZT', '权限状态', 'string', '文本框', null, null, null, ' ', ' ', ' ', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('13', 'CANSID', '控制参数ID', 'string', '文本框', null, null, 'required', '1', ' ', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'BAOBBS', '报表标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSMC', '要素名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSBS', '要素标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'MSGID', '提示信息ID', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('22', 'account', '账号', 'string', '文本框', null, null, null, '1', ' ', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSBT', '要素标题', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSLX', '要素类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'SHIFBT', '是否必填', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'STYLECLASS', 'class', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'MOYZ', '默认值', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'XIANSSX', '显示顺序', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSGS', '要素格式', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'BEIZ', '备注', 'string', '文本域', null, null, null, '1', null, '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'VALIDATERULE', '校验规则', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('12345', 'account', '账号', 'string', '文本框', null, null, null, '1', ' ', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'YUANSID', '元素id', 'string', '文本框', null, null, null, '1', ' ', '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'YUANSSTYLE', '元素style', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '6', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'MAXLENGTH', '最大输入数', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '5', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSCD', '要素长度', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'BAOBBS', '报表标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '0', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSBS', '要素标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSMC', '要素名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'VALUE', '参数值', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSBT', '要素标题', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSCD', '要素长度', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'XIANSLX', '显示类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'SHIFXS', '是否显示', 'string', '文本框', null, null, null, '1', null, '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'XIANSSX', '显示顺序', 'string', '文本框', null, null, null, '1', null, '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'ZHIDBS', '字典标识', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'TARGET', '参数类型', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'DEFAULTVALUE', '默认值', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'REMARK', '备注', 'string', '文本域', null, null, null, '1', ' ', '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'KEY', '参数编号', 'string', '文本框', null, null, null, '1', ' ', '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('zhidb', 'ZDID', '字典ID', 'string', '文本框', null, null, null, '1', ' ', '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSGS', '要素格式', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('zhidb', 'ZIDMC', '字典名称', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('zhidb', 'ZIDCD', '字典长度', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('zhidb', 'ZIDLX', '字典类型', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'CANSID', '参数ID', 'string', '文本框', null, null, null, '1', ' ', '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'CANSM', '参数名称', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'CANSLX', '参数类型', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'PARAMETERVALUE', '参数值', 'string', '文本域', null, null, null, '1', ' ', '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'TYPE', '参数模块', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'BEIZ', '备注', 'string', '文本域', null, null, null, '1', null, '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_ZHIDPZ', 'ZHIDBS', '字段标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_ZHIDPZ', 'SUOYZ', '索引值', 'string', '文本框', null, null, null, '1', null, '1', '1', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_ZHIDPZ', 'ZHUANHZ', '转换值', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'DPIID', '编号', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'DIQH', '地区号', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'WANGDH', '网点号', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'YEWLX', '业务类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'SECBZ', '色彩标识', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'DPI', 'DPI', 'string', '文本框', null, null, null, '1', null, '1', '0', '6', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'TIAOYCS', '调优参数', 'string', '文本框', null, null, null, '1', null, '1', '0', '7', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'JIEDBS', '节点标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSBS', '参数标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSMC', '参数名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSLX', '参数类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSFL', '参数分类', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSZ', '参数值', 'string', '文本框', null, null, null, '1', null, '1', '0', '6', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSSM', '参数说明', 'string', '文本框', null, null, null, '1', null, '1', '0', '7', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitjd', 'JIEDBS', '节点标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitjd', 'JIEDMC', '节点名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_yewxt', 'XITBS', '系统标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_yewxt', 'XITMC', '系统名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_yewxt', 'YANZXX', '验证信息', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'XITBS', '系统标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'PINGZBS', '凭证标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'PINGZMC', '凭证名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'ZHAOZQ', '找章区', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'FAZQ', '阀值区', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'YANYJB', '验印级别', 'int', '文本框', null, null, null, '1', null, '1', '0', '6', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'XFENBL', 'X分辨率', 'int', '文本框', null, null, null, '1', null, '1', '0', '7', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'YFENBL', 'Y分辨率', 'int', '文本框', null, null, null, '1', null, '1', '0', '8', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'XSUOF', 'X缩放', 'float', '文本框', null, null, null, '1', null, '1', '0', '9', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'YSUOF', 'Y缩放', 'float', '文本框', null, null, null, '1', null, '1', '0', '10', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'XITBS', '系统标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSBS', '参数标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSMC', '参数名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSLX', '参数类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSFL', '参数分类', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSZ', '参数值', 'string', '文本框', null, null, null, '1', null, '1', '0', '6', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSSM', '参数说明', 'string', '文本框', null, null, null, '1', null, '1', '0', '7', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('XITYYGZB', 'xitbh', '系统编号', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('XITYYGZB', 'xitmc', '系统名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('XITYYGZB', 'yanygz', '验印规则', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('XITYYGZB', 'beiz', '备注', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');





INSERT INTO DANBWHGXB (ID, ZHUBBH, ZIBBH, ZHUBZD, ZIBZD, SHIFLJZD, ZHIBWHMC) VALUES ('2c2785693d5d27fb013d5d3dc4a60001', 'R_BAOBPZ', 'R_BIAODYSPZ', 'BAOBBS', 'BAOBBS', '1', '表单要素维护');
INSERT INTO DANBWHGXB (ID, ZHUBBH, ZIBBH, ZHUBZD, ZIBZD, SHIFLJZD, ZHIBWHMC) VALUES ('2c2785693d67b426013d67bdb3bc0001', 'R_BAOBPZ', 'R_JIEGYSPZ', 'BAOBBS', 'BAOBBS', '1', '结果要素维护');
INSERT INTO DANBWHGXB (ID, ZHUBBH, ZIBBH, ZHUBZD, ZIBZD, SHIFLJZD, ZHIBWHMC) VALUES ('2c2785693d81e24e013d81f87f900002', 'R_JIEGYSPZ', 'R_ZHIDPZ', 'ZHIDBS', 'ZHIDBS', '0', '字典维护');



INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('R_BAOBPZ', 'Ureport维护', 'R_BAOBPZ', 'doDanbwh.do?method=list&gongnid=R_BAOBPZ', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('R_BIAODYSPZ', 'Ureport表单维护', 'R_BIAODYSPZ', 'doDanbwh.do?method=list&gongnid=R_BIAODYSPZ', '1', '1', '1', '0', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('R_JIEGYSPZ', 'Ureport结果维护', 'R_JIEGYSPZ', 'doDanbwh.do?method=list&gongnid=R_JIEGYSPZ', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('R_ZHIDPZ', 'Ureport字典维护  ', 'R_ZHIDPZ', 'doDanbwh.do?method=list&gongnid=R_ZHIDPZ', '1', '1', '1', '0', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('peizdpi', '配置DPI', 'peizdpi', 'doDanbwh.do?method=list&gongnid=peizdpi', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('yewgz', '业务规则定制', 'yewgz', 'doDanbwh.do?method=list&gongnid=yewgz', '1', '1', '1', null, null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_jiedcs', '节点参数维护', 'ci_jiedcs', 'doDanbwh.do?method=list&gongnid=ci_jiedcs', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_xitjd', '节点信息维护', 'ci_xitjd', 'doDanbwh.do?method=list&gongnid=ci_xitjd', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('07', 'ocx参数控制', 'ocxkongzcsb', 'doDanbwh.do?method=list&gongnid=07', '1', '1', '1', null, null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_yewxt', '系统信息维护', 'ci_yewxt', 'doDanbwh.do?method=list&gongnid=ci_yewxt', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('bskongzcs', '系统控制参数', 'bskongzcs', 'doDanbwh.do?method=list&gongnid=bskongzcs', '1', '1', '1', null, null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_pingzcs', '系统凭证信息维护', 'ci_pingzcs', 'doDanbwh.do?method=list&gongnid=ci_pingzcs', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_xitcs', '系统参数信息维护', 'ci_xitcs', 'doDanbwh.do?method=list&gongnid=ci_xitcs', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('XITYYGZB', '系统验印规则维护', 'XITYYGZB', 'doDanbwh.do?method=list&gongnid=XITYYGZB', '1', '1', '1', '1', null);





insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('001', '人民币', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('012', '英镑', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('013', '港币', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('014', '美元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('015', '瑞士法郎', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('018', '新加坡元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('027', '日元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('028', '加元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('029', '澳元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('038', '欧元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('088', '韩元', null);






insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('isshowautotip', '否', '系统', '否', '输入账号后回车，是否弹出模糊匹配结果框'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('SealUploadMode', '1', '系统', '1', '印鉴加载模式：1(不会重新搜索)，2（会重新搜索）'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('IsSetSmallCount', '是', '账户', '是', '是否设置小码章位数_V3.0'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('infochekedstate', '已审', '审核', '已审', '审核提交后账户印鉴审核状态值'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('isautobsealcheck', '1', '批量验印', '0', '是否开启批量验印的自动模式'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifkzzhxx', '是', '账户', '是', '是否启用账户信息扩展项'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('isautoinfocheck', '1', '审核', '0', '审核是否启用自动模式'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifkzyjxx', '是', '印鉴', '是', '是否启用印鉴信息扩展项'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifkzzuhxx', '是', '组合', '是', '是否启用组合信息扩展项'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shiysmorpy', 'shaom', '系统', 'shaom', '使用扫描or票影（shanm or piaoy）'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealcolor', '2', '验印', '0', '预留印鉴镂空图展示的颜色，0红1绿2黄'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyydgsz', '√', '验印印鉴', '否', '印鉴列表控件验印通过时展示数值'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyywgsz', '×', '验印印鉴', '否', '印鉴列表控件验印未过时展示数值'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyywysz', '×', '验印印鉴', '否', '印鉴列表控件验印未验时展示数值'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyydgzt', 'Verdana', '验印印鉴', '否', '印鉴列表控件验印通过时展示字体类型'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyywgdx', '40', '验印印鉴', '否', '印鉴列表控件验印通过时展示字体大小'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyydgdx', '30', '验印印鉴', '否', '印鉴列表控件验印通过时展示字体大小'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyywyzt', 'Verdana', '验印印鉴', '否', '印鉴列表控件验印通过时展示字体类型'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyywgzt', 'Verdana', '验印印鉴', '否', '印鉴列表控件验印通过时展示字体类型'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyywgys', 'Gray', '验印印鉴', '否', '印鉴列表控件验印通过时展示字体颜色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyydgys', 'Green', '验印印鉴', '否', '印鉴列表控件验印通过时展示字体颜色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyywydx', '40', '验印印鉴', '否', '印鉴列表控件验印通过时展示字体大小'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjyywyys', 'Gray', '验印印鉴', '否', '印鉴列表控件验印通过时展示字体颜色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjzdzzsz', '已增加', '自动找章', '否', '自动找章中控件的展示字体数值'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjzdzzys', 'Blue', '自动找章', '否', '自动找章中控件的展示字体颜色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjzdzzdx', '15', '自动找章', '否', '自动找章中控件的展示字体大小'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjzdzzzt', 'Verdana', '自动找章', '否', '自动找章中控件的展示字体类型'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('jiankzsfs', '1|2|3|4|5', '印鉴展示', '是', '建库展示方式（枚举值UserManageShow）'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shenhzsfs', '1|2|3|4|5|6', '印鉴展示', '是', '审核展示方式（枚举值VerifyShow）'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yanyzsfs', '1|2|3|6', '印鉴展示', '是', '验印展示方式（枚举值CheckShow）'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('pilyyzsfs', '1|2|3|4|6', '印鉴展示', '是', '批量验印展示方式（枚举值BatchCheckShow）'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('zidzzzsfs', '1|7', '印鉴展示', '是', '自动找章展示方式（枚举值AutoSearchSeal）'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('attributetime', '2012-08-15 19:04:41', '系统', '否', '属性扩展功能最后更新时间'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjbhzt', 'Verdana', '系统', '0', '印鉴列表控件的编号字体类型'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjbhdx', '10', '系统', '0', '印鉴列表控件的编号字体大小'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjlxys', 'Black', '系统', '0', '印鉴列表控件的印鉴类型及状态颜色显示'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('piaoyingstart', '是', '系统', '否', '票影是否启用'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('isrebuildgroupsvisible', '否', '账户', '是', '重建时是否显示老组合'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('saomiaosave', '否', '系统', '否', '扫描的图像是否保存，默认为不保存'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjsjzt', 'Verdana', '系统', '0', '印鉴列表控件的启用时间字体类型'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifzdzz', '是', '建库', '是', '是否自动找章'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjsjdx', '10', '系统', '0', '印鉴列表控件的启用时间字体大小'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjsjys', 'Green', '系统', '0', '印鉴列表控件的启用时间颜色显示'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjlxdx', '10', '系统', '0', '印鉴列表控件的印鉴类型及状态字体大小'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjlxzt', 'Verdana', '系统', '0', '印鉴列表控件的印鉴类型及状态字体类型'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjbgdx', '10', '系统', '0', '印鉴列表控件的变更字体大小'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjbgzt', 'Verdana', '系统', '0', '印鉴列表控件的变更字体类型'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjbgys', 'Red', '系统', '0', '印鉴列表控件的变更颜色显示'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('dpifordb', '300', '建库', '300', '建库支持的影像分辨率'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('YY_008', '200', '验印', '300', '验印时支持的影像分辨率'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealcheckgrade', '75', '验印', '50', '验印等等'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealcheckresultmodel', '0', '验印', '0', '默认的验印结果展示方式，默认为三色展示(23)'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealbackcolor', '0', '系统', '0', '预留印鉴展示的背景色，默认为0（白色），0 白底；1绿底；2黑底；不能大于2'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifkzyyxx', '是', '验印', '否', '是否启用验印信息扩展项'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sysconfigtime', '2013-03-14 17:22:17', '系统', '默认值', '系统参数最后更改时间'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('zhanghwssfky', '是', '验印', '否', '账户信息未审是否可以验印'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('zuhwssfky', '是', '验印', '否', '有组合信息未审是否可以验印'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjwssfky', '是', '验印', '否', '有印鉴信息未审是否可以验印'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjbhys', 'Blue', '系统', '0', '印鉴列表控件的编号颜色显示'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifjejc', '否', '系统', '否', '组合金额是否可以交叉'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifqyfileup', '否', '系统', '否', '是否启用文件上传'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifqymorehint', '是', '系统', '是', '审核时是否启用多提示让流程走圆'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifqyprint', '否', '系统', '否', '是否启用验印结果打印'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('bingxq', '10', '系统', '10', '并行期'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjbgjjrsy', '0', '印鉴', '是', '变更印鉴时的节假日顺延（0 不顺延 1 顺延'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjfyandx', '20', '印鉴列表', '是', '印鉴列表展示控件的翻页按钮大小'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('yinjzskjkk', '135', '印鉴列表', '是', '印鉴展示控件框的宽'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('FileSeverIp', '192.168.1.73', '系统', '192.168.1.148', '文件上传时文件服务器的IP'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('FileSeverPort', '7004', '系统', '7004', '文件上传时文件服务器的端口'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifbillinfofirst', '否', '系统', '是', '先显示票据信息控件还是单个显示'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('gfrfile', 'Scheme\Scheme.gfr', '系统', 'Scheme\Scheme.gfr', 'ocr方案文件路径'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('dbms_tonggl', '90', 'dbms', '90', '打标模式的通过率'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('dbms_shibl', '95', 'dbms', '95', '打标模式的识别率'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('isuseprint', '否', '验印', '否', '验印是否启用打印功能_V3.0'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('issealsmall', '否', '账户', '是', '开户是否开启小码章_V3.0'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealsmallcount', '13', '账户', '13', '小码章位数_V3.0'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('PiaoYingDoubleExposure', '是', '系统', '是', '票影是否开始二次曝光'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifqyLagDelete', '3', '滞后删除', '3', '是否启用滞后删除 1.启用 2.不启用 3.柜员选择是否启用滞后删除'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('isautosealcheck', '1', '验印', '0', '前台验印是否启用自动模式'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('dbms_type', '0', 'dbms', '0', '打标模式的类型'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('zuhbgjjrsy', '1', '组合', '0', '变更组合时是否节假日顺延（0 不顺延 1 顺延'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('pingzyxq', '10', '验印', '10', '凭证参数缺省情况下的凭证有效期'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('shifpzyxqjjrsy', '是', '验印', '是', '凭证有效期在验印时是否节假日顺延'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('99993Deletedoublecheck', '否', '账户', '是', '销户：强制通过时是否启用双人会签'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('99993Freezedoublecheck', '否', '账户', '是', '冻结：强制通过时是否启用双人会签'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('99993Reportdoublecheck', '否', '账户', '是', '挂失：强制通过时是否启用双人会签'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('99993Sealinfodoublecheck', '否', '账户', '是', '新增印鉴确认：强制通过时是否启用双人会签'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('99990Infocheckdoublecheck', '否', '账户', '是', '账户审核：强制通过时是否启用双人会签'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('CameraType', '2', '系统', '0', '票影的采集模式，0，白光；1， 紫光；2 ，白+紫'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('ScanType', '5', '系统', '2', '图像来源方式,2为采集组件， 【0为标准Twain、1为票影】不再使用'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealresulttype', '23', '系统', '23', '验印结果的默认展示方式'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('resultforecolor', 'Black', '系统', 'Blue', '验印结果图的前景色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('resultbackcolor', 'White', '系统', 'White', '验印结果图的背景色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('maskforecolor', 'Blue', '系统', 'Yellow', '掩码图的前景色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('maskbackcolor', 'Black', '系统', 'Black', '掩码图的背景色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealforecolornormal', 'Red', '系统', 'Red', '印鉴列表(未验)的前景色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealbackcolornormal', 'White', '系统', 'White', '印鉴列表(未验)的背景色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealforecolorpass', 'Lime', '系统', 'Red', '印鉴列表(通过)的前景色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealbackcolorpass', 'White', '系统', 'Lime', '印鉴列表(通过)的背景色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK) values ('sealforecolornotpass', 'Black', '系统', 'Red', '印鉴列表(未过)的前景色'); 
insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealbackcolornotpass', 'White', '系统', 'Black', '印鉴列表(未过)的背景色');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('dabms', '0', '验印', '0', '打标模式');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('maxgrade', '100', '验印', '100', '最大');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('mingrade', '1', '验印', '100', '最小');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealBorderSelColor', 'Black', '系统', 'Black', '印鉴选中状态下的边框颜色');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealBorderDefColor', 'Blue', '系统', 'Blue', '印鉴默认状态下的边框颜色');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('pingzlxdefault', '0', '验印', '0', '默认凭证类型');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isAccountInfoModify', '1', '账户', '0', '审核用户后资料是否可编辑：0，不可编辑；1，可编辑');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993AccountInfodoublecheck', '否', '账户', '是', '编辑已审核用户资料是否双签');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isYinJInfoModify', '1', '账户', '0', '审核后的印鉴信息是否可编辑：0，不可编辑；1，可编辑');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isGroupSealModify', '1', '账户', '0', '审核后组合是否可编辑：0，不可编辑；1，可编辑');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993GroupSealdoublecheck', '否', '账户', '是', '编辑已审核组合是否双签');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('deljjrsy', '3', '滞后删除', '3', '删除操作时的节假日顺延  1.顺延 2.不顺延 3.柜员选择是否顺延');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsdelDateModify', '是', '滞后删除', '是', '滞后删除操作时日期是否可更改(默认用并行期天数)');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isusebanktrans', '1', '验印', '1', '是否与核心交互');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBDFlag', '1', '验印', '1', '工行分支开关，0关1开');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBCFrameFlag', '1', '验印', '1', '工行判断边框误差开关，0关1开');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBCStarFlag', '1', '验印', '1', '工行判断五角星分支开关，0关1开');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBCBigCharFlag', '1', '验印', '1', '工行判断大字符区分支开关，0关1开');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBCSmallCharFlag', '1', '验印', '1', '工行判断小字符区分支开关，0关1开');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ocrserverip', '172.167.7.122', '系统', '192.168.1.149', 'ocr服务端所在ip');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ocrserverport', '5868', '系统', '5868', 'ocr服务端启用的端口');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('kaihzhshzt', '未审', '账户', '未审', '开户账户审核状态默认值_V3.0');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('xiugzlzhshzt', '已审', '账户', '已审', '账户已审状态下修改资料账户审核状态默认值_V3.0');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('groupbing', '&', '组合', '&', '组合中并且的标识符');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('grouphuo', '|', '组合', '|', '组合中或者的标识符');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('jiankyjshzt', '未审', '账户', '未审', '建库状态下印鉴与组合的审核状态默认值_V3.0');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('infochecktype', '10|20|21', '验印', '20', '审核的验印种类');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealchecktype', '10|20|21', '验印', '20', '验印的验印种类');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993InfoModifyDoublecheck', '否', '账户', '是', '账户信息修改：账户信息修改时是否启用双人会签');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('DoubleCheckMode', '0', '系统', '0', '双人会签调用方式：0,内部调用；1,外部调用');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993InfoChangeDoublecheck', '否', '账户', '是', '变更：账户变更时是否启用双人会签');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993InfoRebuildDoublecheck', '否', '账户', '是', '重建：账户重建时是否启用双人会签');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('jkshifqyfileup', '否', '系统', '否', '建库是否启用文件上传');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('jkFileSeverIp', '10.11.162.102:7005', '系统', '192.168.217.128:7005', '建库时文件上传时文件服务器的IP与端口---在使用');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ischangesealsvisible', '否', '账户', '是', '变更时是否显示老印鉴');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isOneGongzhang', '是', '账户', '是', '增加印章时只允许有一个公章_V3.0');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('InfoCheckFileSeverIp', '172.167.1.133:7001', '系统', '192.168.1.148', '审核时文件上传时文件服务器的IP与端口');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealCheckFileSeverIp', '172.167.1.133:7001', '系统', '192.168.1.148', '验印时文件上传时文件服务器的IP与端口');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('InfoCheckshifqyfileup', '否', '系统', '否', '审核是否启用文件上传');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealCheckshifqyfileup', '否', '系统', '是', '验印是否启用文件上传');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealCheckDPI', '200', '系统', '200', '验印DPI');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('InfoCheckDPI', '200', '系统', '200', '审核DPI');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('infocheckshifqyreadbill', '否', '审核', '否', '账户审核是否启用影像识别');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealcheckshifqyreadbill', '否', '验印', '否', '前台验印是否启用影像识别');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ischangegroupsvisible', '否', '账户', '是', '变更时是否显示老组合');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isrebuildsealsvisible', '否', '账户', '是', '重建时是否显示老印鉴');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('typeforsanse', '0', '验印', '0', '三色图样式（0 or 23）');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('usecontogether', '是', '账户', '是', '开户模块是否与印鉴管理模块联合使用_V3.0');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ocrdllpath', 'DLL\OCRDLL', '账户', 'DLL\OCRDLL', 'ocr动态库文件路径_V3.0');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('identifyType_zhgl', '4', '账户', '0', '开户影像识别方式：0,ocr;1:二维码；2:先ocr后二维码；3:先二维码后ocr_V3.0');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('identifyType_zhsh', '4', '审核', '0', '审核影像识别方式：0,ocr;1:二维码；2:先ocr后二维码；3:先二维码后ocr_V3.0');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('identifyType_zhyy', '4', '验印', '0', '验印影像识别方式：0,ocr;1:二维码；2:先ocr后二维码；3:先二维码后ocr_V3.0');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isOpenFileButton_J', '否', '开户', '否', '开户模块接口状态下是否启用本地加载按钮_接口');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isScanButton_J', '否', '开户', '否', '开户模块接口状态下是否启用影像采集按钮_接口');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isOpenFileButton_P', '否', '开户', '否', '开户模块平台状态下是否启用本地加载按钮_接口');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isScanButton_P', '否', '开户', '否', '开户模块平台状态下是否启用影像采集按钮_接口');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993InfoModifyAlwaysDoublecheck', '否', '账户', '是', '修改账户基本信息是否在任何情况下都进行双签');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsSideSealOpen', '否', '账户', '否', '是否开启小码边框');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('accountpartial', '1', '账户', '0', '账户管理USECONTYPE=0时 默认显示 0:账户信息 1:印鉴信息');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isInfoCheckManualable', '1', '系统', '1', '审核是否允许人工通过，0，印鉴不允许，签字允许；1，都允许');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsUseFileServer', '0', '验印接口', '0', '是否上传到文件服务器');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('FileServerIP', '10.11.162.102', '验印接口', '10.11.162.102', '文件服务器IP---在使用');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('FileServerPort', '7005', '验印接口', '0', '文件服务器端口');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealCreateShowName', '建库', 'I账户管理', '保存', '在建库界面能保存成功或者失败的提示，建库成功，建库失败');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('maxSmallLen', '25', 'I账户管理', '20', '小码数值的最大长度');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isReUseYinjkbh', '是', 'I账户管理', '否', '是否重用之前的印鉴卡编号');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('CodeScore', '80', '系统', '100', '修改小码后的可信度');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsShowNotpassReason', '是', '系统', '否', '验印控件中是否展示印鉴未过原因');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsAssiCheckDoubleCheck', '0', '验印接口', '0', '是否人工通过双人会签');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('btnNameOnNotpass', '退回', '审核接口', '0', '审核不通过时，提交按钮的显示文本');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('DoubleCheckMoney', '0', '验印接口', '1', '强制进行双签的金额，配置为0时，不根据金额双签');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isSaveAotuNotpass', '0', '验印接口', '1', '无界面自动验印不通过时是否提交，0不提交，1提交');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealLengthVissible', '0', 'I账户管理', '0', '自动提章上面是否展示小码位数的选项 1：显示 0：隐藏');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('AutoSearchMode', '1', 'I账户管理', '0', '自动提章的模式：0 默认，1 考虑印章靠得很近的模式');

insert into OCXKONGZCSB (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isGetYinjkxx', '1', 'I账户管理', '0', '查看账户印鉴信息时是否获取印鉴卡影像：0 不获取，1 从文件服务获取');






insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('87', '授权双签', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('40', '账户查询', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('41', '日志查询', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('42', '统计分析', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('43', '系统管理', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('44', '特殊业务', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('50', '账户管理', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('51', '账户审核', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('52', '印签验印', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('53', '账户简单查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('54', '客户简单查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('55', '账户高级查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('56', '未审核清单查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('57', '验印结果当日查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('58', '验印日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('59', '账户日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('60', '管理员日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('61', '机构管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('62', '基本岗位管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('63', '详细岗位管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('64', '柜员管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('65', '通存通兑管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('66', '节假日管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('67', '销户恢复', null, null, '44');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('68', '账户物理删除', null, null, '44');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('70', '账户数量统计', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('74', '账户验印通过率统计', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('76', '凭证参数设置', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('77', '清楚柜员IP限制', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('78', '省行机构通过率排名', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('79', '二级分行通过率排名', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('80', '机构通过率排名', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('81', '账号通过率排名', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('82', '账户信息定制查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('83', '验印日志定制查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('84', '机构凭证日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('85', '批量验印', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('86', '凭证验印日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('PLYY_001', '单章通过', null, null, '85');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('PLYY_002', '单章不通过', null, null, '85');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('QTYY_001', '单章通过', null, null, '52');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('QTYY_002', '单章不通过', null, null, '52');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_001', '开户', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_005', '修改资料', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_006', '新增印章', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_007', '新增签字', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_008', '本地影像', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_009', '采集影像', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_010', '删除印鉴', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_011', '新增组合', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_012', '删除组合', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHSH_001', '审核通过', null, null, '51');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHSH_002', '审核不通过', null, null, '51');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHSH_003', '印鉴通过', null, null, '51');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHSH_004', '印鉴不通过', null, null, '51');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_014', '重建', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_015', '变更', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_016', '二维码识别', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_017', 'OCR识别', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_019', '自动找章', null, null, '50');






insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('0009', '账户同步查询', '账户同步查询', '是', null, 25, null, null, null, null, 'accountinfo', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('002', '账户高级查询', '账户高级查询', '是', null, 25, null, null, null, null, 'zhanghb', 'com.sinodata.user.ZhanghugjcxImpl');

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('003', '账户通过率排名', '账户通过率排名', '是', null, 25, null, null, null, null, '(SELECT  ROWNUM,A.* FROM (select * from zhanghtgl) A order by A.Tonggl desc) ', 'com.sinodata.user.TongglForZhanghImpl');

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('004', '机构通过率排名', '机构通过率排名', '是', null, 25, null, null, null, null, '(SELECT  ROWNUM,A.* FROM (select * from jigtgl) A order by A.Tonggl desc) ', 'com.sinodata.user.TongglForjigImpl');

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('005', '账户审核查询', '账户审核查询', '是', '是', 25, '是', null, '是', null, 'zhanghb', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('006', '实物风险跟踪', '风险跟踪记录', '是', null, 25, null, null, null, null, '(select RENWBS, ZHANGH, JIGH, HUM, case RENWLX when ''0'' then ''放卡'' else ''取卡''end as RENWLX, RENWRQ, RENWSJ, YINJKS,case YEWLX when ''0'' then ''开户'' when ''1'' then ''变更'' when ''2'' then ''查阅'' else ''归还''end as YEWLX, RENWZT, GUIY, CAOZRQ, CAOZSJ, ZUOB from kagrw)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('009', '客户号查询', '客户号查询', '是', null, 25, null, null, null, null, 'zhanghb', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('13000', '重空凭证 - 大库余额明细查询', '查询结果列表', '是', null, 25, null, null, null, null, '(select k.jigh,p.pingzmc as pingzlx,k.zongs,k.yilzs,k.shengyzs,k.zuofzs from pingzkcsyb k,pingzpzb p where k.pingzlx=p.pingzbs)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('13001', '重空凭证 - 机构余额明细查询', '查询结果列表', '是', null, 25, null, null, null, null, '(select j.jigh,p.pingzmc as pingzlx,j.yilzs,j.shengyzs,j.zuofzs from pingzjgsyb j,pingzpzb p where j.pingzlx=p.pingzbs)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('13008', '重空凭证 - 柜员余额明细查询', '查询结果列表', '是', null, 25, null, null, null, null, '(select c.lingyjg,c.guiyh,c.pingzlx ,c.a as yilzs,c.b as zuofzs,case when c.a-c.b>0 then to_number(c.a-c.b) else 0 end as shengyzs from (select g.lingyjg,g.guiyh,p.pingzmc as pingzlx,sum(case g.pingzzt when ''已领'' then 1 else 0 end)as a ,sum(case g.pingzzt when ''作废'' then 1 else 0 end)as b from pingzgcb g,pingzpzb p where g.pingzlx=p.pingzbs group by p.pingzmc,g.guiyh,g.lingyjg)c)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('clerktable', '查询柜员信息', '查询柜员信息', '是', null, 25, null, null, null, null, 'clerktable', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('huizong_cx', '汇总查询', '汇总查询', '是', null, 25, null, null, null, null, '(select zhangh,guiyh clerknum,jigh organnum,pingzlx,riq,hum,qispzh,zhongzpzh,bens,zhangs,shij,pich from pingzcshz)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('pingz_01', '凭证日志追踪', '凭证日志追踪', '是', null, 25, null, null, null, null, 'pingzcsmx', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('u_danz', '接口单章日志查询', '接口单章日志列表', '是', null, 25, null, null, null, null, 'ci_yyrz', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('u_jiek', '接口整票日志查询', '接口整票日志列表', '是', null, 25, null, null, null, null, 'ci_renwxx', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('yinjkdjb', '管理印鉴卡日志查询', '管理印鉴卡日志查询', '是', null, 25, null, null, null, null, '(select * from YINJKDJB order by zhangh,caozrq desc,caozsj desc)', 'com.sinodata.user.YinjkrzcxImpl');





insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'PINGZLX', 'PINGZLX', '凭证类型', '动态多选框', '是', null, '4', null, null, 'string', null, 'select  pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'JIGH1', 'JIGH', '是否包含下级', '子集输入', '是', null, '2', null, null, 'string', null, 'SELECT

organnum  FROM TABLE(ORGFUNCTION(?)) AS A');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'guiyh', 'GUIYH', '柜员号', '文本输入', '否', null, '3', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_danz', 'yanyjg', 'YANYJG', '验印结果', '静态多选框', '是', null, '4', null, null, 'string', null, '通过=通过|未过=未过|未验=未验|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('002', 'JIGH', 'JIGH', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('002', 'YOUWYJ', 'YOUWYJ', '印签标志', '静态多选框', '否', null, '4', null, null, 'string', null, '有=有|无=无');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('002', 'ZHANGHZT', 'ZHANGHSHZT', '账户审核状态', '静态多选框', '否', null, '5', null, null, 'string', null, '已审=已审|未审=未审');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('002', 'begindate', 'KAIHRQ', '开户日期', '日期范围', '否', null, '7', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('003', 'JIGH', 'JIGH', '机构号', '回显输入', '是', null, '2', null, null, 'string', null, 'select organname from organarchives where organnum =?');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('003', 'LEIX', 'LEIX', '统计类型', '静态多选框', '是', null, '3', null, null, 'string', null, '单章=章|整票=票|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('003', 'RIQFW', 'RIQFW', '统计时间', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('004', 'JIGH1', 'JIGH', '是否查看明细', '子集输入', '是', null, '3', null, null, 'string', null, 'SELECT organnum  FROM TABLE(ORGFUNCTION(?)) AS A');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('004', 'LEIX', 'LEIX', '统计类型', '静态多选框', '是', null, '4', null, null, 'string', null, '单章=章|整票=票|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('004', 'RIQFW', 'RIQFW', '统计时间', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('004', 'JIGH', 'JIGH', '机构号', '回显输入', '是', null, '2', null, null, 'string', null, 'select organname from organarchives where organnum =?');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'JIGH', 'JIGH', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'YINJSHZT', 'YINJSHZT', '印鉴审核状态', '静态多选框', '是', null, '3', null, null, 'string', null, '已审=已审|未审=未审|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'ZHANGHZT', 'ZHANGHSHZT', '账户审核状态', '静态多选框', '是', null, '4', null, null, 'string', null, '已审=已审|未审=未审|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'ZUHSHZT', 'ZUHSHZT', '组合审核状态', '静态多选框', '是', null, '5', null, null, 'string', null, '已审=已审|未审=未审|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('009', 'KEHH', 'KEHH', '客户号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('111', 'jigh', 'JIGH', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('111', 'zhanghzt', 'ZHANGHZT', '账户状态', '静态多选框', '是', null, '2', null, null, 'string', null, '有效=有效|销户=销户|冻结=冻结|挂失=挂失|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('JH_001', '001_0', 'N_ORGANNUM', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_jiek', 'renwbs', 'renwbs', '任务标识', '文本输入', '否', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_jiek', 'renwrq', 'RENWRQ', '任务日期', '日期范围', '是', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_jiek', 'yanyjg', 'YANYJG', '验印结果', '静态多选框', '是', null, '4', null, null, 'string', null, '通过=通过|未过=未过|未验=未验|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_jiek', 'yanyms', 'YANYMS', '验印模式', '静态多选框', '是', null, '3', null, null, 'string', null, '自动=自动|辅助=辅助|人工=人工|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'zhangh', 'ZHANGH', '账号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'jigh', 'JIGH', '机构号', '文本输入', '否', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_danz', 'renwbs', 'RENWBS', '任务标识', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_danz', 'xitbs', 'XITBS', '系统标识', '文本输入', '是', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'RIQ', 'RIQ', '出售日期', '日期范围', '是', null, '5', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'organnum', 'ORGANNUM', '机构号', '文本输入', '否', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'PINGZLX', 'PINGZLX', '凭证类型', '动态多选框', '是', null, '4', null, null, 'string', null, 'select  pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'RIQ', 'RIQ', '出售日期', '日期范围', '是', null, '6', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'zhangh', 'ZHANGH', '账号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'ZHUANGT', 'ZHUANGT', '凭证状态', '静态多选框', '是', null, '5', null, null, 'string', null, '已打印=已打印|未打印=未打印|已作废=已作废|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_danz', 'yanyms', 'YANYMS', '验印模式', '静态多选框', '是', null, '3', null, null, 'string', null, '自动=自动|辅助=辅助|人工=人工|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'clerknum', 'CLERKNUM', '柜员号', '文本输入', '否', null, '3', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('clerktable', 'orgcode', 'n_organnum', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('clerktable', 'clerknum', 'clerknum', '柜员号', '文本输入', '否', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('0009', 'jigh', 'jigh', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('0009', 'daorsj', 'daorsj', '导入时间', '日期范围', '是', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('0009', 'chengbz', 'chengbz', '成功标志', '静态多选框', '是', null, '3', null, null, 'string', null, '成功=成功|失败=成功|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('0009', 'daorlx', 'daorlx', '导入类型', '静态多选框', '是', null, '4', null, null, 'string', null, '开户=开户|销户=销户|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13001', 'jigh', 'jigh', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13001', 'pingzlx', 'pingzlx', '凭证类型', '动态多选框', '是', null, '2', null, null, 'string', null, 'select pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13000', 'pingzlx', 'pingzlx', '凭证类型', '动态多选框', '是', null, '2', null, null, 'string', null, 'select pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13008', 'pingzlx', 'pingzlx', '凭证类型', '动态多选框', '是', null, '3', null, null, 'string', null, 'select pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('006', 'zhangh', 'ZHANGH', '账号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13008', 'lingyjg', 'lingyjg', '机构号', '文本输入', '否', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13008', 'guiyh', 'guiyh', '柜员号', '文本输入', '是', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13000', 'jigh', 'jigh', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);








insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('009', 'JIGH', 'jigh', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('111', 'zhangh', 'zhangh', '账号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'WDFLAG', 'WDFLAG', 'WDFLAG', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_UPDATEDATE', 'N_UPDATEDATE', 'N_UPDATEDATE', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('111', 'jigh', 'jigh', '机构号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('111', 'zhanghzt', 'zhanghzt', '账户状态', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('111', 'kehh', 'kehh', '客户号', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'CLERKPWD', 'CLERKPWD', 'CLERKPWD', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('009', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'wdflag', 'wdflag', '网点标识', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('009', 'KEHH', 'kehh', '客户号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('009', 'YOUWYJ', 'youwyj', '有无印鉴', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('005', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('005', 'YINJSHZT', 'yinjshzt', '印鉴审核状态', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'ZONGS', 'zongs', '验印总笔数', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('005', 'ZUHSHZT', 'zuhshzt', '组合审核状态', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('005', 'ZHANGHSHZT', 'zhanghshzt', '账户资料审核状态', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'JIGH', 'jigh', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'LEIX', 'leix', '统计类型', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'ZID', 'zid', '自动验印总笔数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'FUZ', 'fuz', '辅助验印总笔数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'RENG', 'reng', '人工验印总笔数', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'TONGGL', 'tonggl', '通过率(%)', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'ROWNUM', 'rownum', '排名', null, '普通显示', '是', '-1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '0', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'ROWNUM', 'rownum', '排名', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'JIGH', 'jigh', '机构号', null, '报表链接', '是', '2', null, 'string', 'reportService.do?method=exeReport&baobbs=004&JIGH=');

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'LEIX', 'leix', '统计类型', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'ZONGS', 'zongs', '验印总笔数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'ZID', 'zid', '自动验印总笔数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'FUZ', 'fuz', '辅助验印总笔数', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'TONGGL', 'tonggl', '通过率(%)', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_ORGANNUM', 'N_ORGANNUM', 'N_ORGANNUM', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'RENWRQ', 'RENWRQ', 'RENWRQ', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH2', 'ZHANGH2', 'ZHANGH2', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'CHULGY', 'CHULGY', 'CHULGY', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'PINGZH', 'PINGZH', 'PINGZH', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'CHULRQ', 'CHULRQ', 'CHULRQ', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH', 'ZHANGH', 'ZHANGH', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'XITLX', 'XITLX', 'XITLX', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH3', 'ZHANGH3', 'ZHANGH3', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'WEIGYY', 'WEIGYY', 'WEIGYY', null, '普通显示', '是', '9', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'HUIZSJ', 'HUIZSJ', 'HUIZSJ', null, '普通显示', '是', '10', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'FAZQ', 'FAZQ', 'FAZQ', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'JINE', 'JINE', 'JINE', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YANYMS', 'YANYMS', 'YANYMS', null, '普通显示', '是', '13', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YFENBL', 'YFENBL', 'YFENBL', null, '普通显示', '是', '14', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'TUXSY', 'TUXSY', 'TUXSY', null, '普通显示', '是', '15', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHAOZQ', 'ZHAOZQ', 'ZHAOZQ', null, '普通显示', '是', '16', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'WENJM', 'WENJM', 'WENJM', null, '普通显示', '是', '17', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'FAQSJ', 'FAQSJ', 'FAQSJ', null, '普通显示', '是', '18', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YANYJG', 'YANYJG', 'YANYJG', null, '普通显示', '是', '19', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'XITBS', 'XITBS', 'XITBS', null, '普通显示', '是', '20', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'CHULZT', 'CHULZT', 'CHULZT', null, '普通显示', '是', '21', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YEWTZ1', 'YEWTZ1', 'YEWTZ1', null, '普通显示', '是', '22', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'CHUPRQ', 'CHUPRQ', 'CHUPRQ', null, '普通显示', '是', '23', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH4', 'ZHANGH4', 'ZHANGH4', null, '普通显示', '是', '24', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'XFENBL', 'XFENBL', 'XFENBL', null, '普通显示', '是', '25', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YANYJB', 'YANYJB', 'YANYJB', null, '普通显示', '是', '26', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'PINGZBS', 'PINGZBS', 'PINGZBS', null, '普通显示', '是', '27', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'RENWBS', 'RENWBS', 'RENWBS', null, '普通显示', '是', '28', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'TONGGZH', 'TONGGZH', 'TONGGZH', null, '普通显示', '是', '29', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH1', 'ZHANGH1', 'ZHANGH1', null, '普通显示', '是', '30', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'JIEDBS', 'JIEDBS', 'JIEDBS', null, '普通显示', '是', '31', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'n_organnum', 'n_organnum', '机构号', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'shenghjgh', 'shenghjgh', '省行机构号', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'n_ip', 'n_ip', '锁定IP', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'n_creator', 'n_creator', '创建机构', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'clerkname', 'clerkname', '柜员名称', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'n_logdate', 'n_logdate', '登录日期', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('0009', 'zhangh', 'zhangh', '帐号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'CLERKNUM', 'clerknum', '柜员号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'HUM', 'hum', '户名', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'ORGANNUM', 'organnum', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'RIQ', 'riq', '日期', null, '普通显示', '是', '10', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'ZHONGZPZH', 'zhongzpzh', '终止凭证号', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'ZHANGS', 'zhangs', '张数', null, '普通显示', '是', '9', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'SHIJ', 'shij', '时间', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'QISPZH', 'qispzh', '起始凭证号', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'PINGZLX', 'pingzlx', '凭证类型', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'PICH', 'pich', '查看明细', null, '链接显示', '是', '90', null, 'string', 'pingz.do?method=getPingzListByPich&pich=');

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'GUIYH', 'guiyh', '柜员号', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'HUM', 'hum', '户名', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'JIGH', 'jigh', '机构号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'PINGZH', 'pingzh', '追踪日志', null, '链接显示', '是', '33', null, 'string', 'pingz.do?method=getPingzMxRizListByPich&pingzh=');

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'PINGZLX', 'pingzlx', '凭证类型', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'RIQ', 'riq', '日期', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'SHIJ', 'shij', '时间', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'CLERKNAME', 'clerkname', '柜员名称', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'SHENGHJGH', 'SHENGHJGH', 'SHENGHJGH', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'HENGXZB', 'HENGXZB', 'HENGXZB', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'RENWRQ', 'RENWRQ', 'RENWRQ', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YINJBZ', 'YINJBZ', 'YINJBZ', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YINJBH', 'YINJBH', 'YINJBH', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YANYJG', 'YANYJG', 'YANYJG', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'CHULGY', 'CHULGY', 'CHULGY', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'SHANGBJ', 'SHANGBJ', 'SHANGBJ', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'XITBS', 'XITBS', 'XITBS', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'CHULRQ', 'CHULRQ', 'CHULRQ', null, '普通显示', '是', '9', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'CHULSJ', 'CHULSJ', 'CHULSJ', null, '普通显示', '是', '10', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'ZHANGH', 'ZHANGH', 'ZHANGH', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'XITLX', 'XITLX', 'XITLX', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YINQBGH', 'YINQBGH', 'YINQBGH', null, '普通显示', '是', '13', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YINZJD', 'YINZJD', 'YINZJD', null, '普通显示', '是', '14', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YANYMS', 'YANYMS', 'YANYMS', null, '普通显示', '是', '15', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'RENWLX', 'RENWLX', 'RENWLX', null, '普通显示', '是', '16', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'RENWBS', 'RENWBS', 'RENWBS', null, '普通显示', '是', '17', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'SHUXZB', 'SHUXZB', 'SHUXZB', null, '普通显示', '是', '18', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YOUBJ', 'YOUBJ', 'YOUBJ', null, '普通显示', '是', '19', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'ZUOBJ', 'ZUOBJ', 'ZUOBJ', null, '普通显示', '是', '20', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'XIABJ', 'XIABJ', 'XIABJ', null, '普通显示', '是', '21', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'JIEDBS', 'JIEDBS', 'JIEDBS', null, '普通显示', '是', '22', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'CLERKNUM', 'clerknum', '柜员号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('0009', 'jigh', 'jigh', '机构号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('0009', 'hum', 'hum', '户名', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('0009', 'cgbz', 'cgbz', '成功标志', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'jigh', 'jigh', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'pingzlx', 'pingzlx', '凭证类型', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'zongs', 'zongs', '总数', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'yilzs', 'yilzs', '已领张数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'shengyzs', 'shengyzs', '剩余张数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'zuofzs', 'zuofzs', '作废张数', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'jigh', 'jigh', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'pingzlx', 'pingzlx', '凭证类型', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'yilzs', 'yilzs', '已领张数', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'shengyzs', 'shengyzs', '剩余张数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'zuofzs', 'zuofzs', '作废张数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'renwlx', 'renwlx', '任务类型', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'zhangh', 'zhangh', '账号', null, '普通显示', '是', '0', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'hum', 'hum', '户名', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'caozrq', 'caozrq', '操作日期', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'caozsj', 'caozsj', '操作时间', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'yewlx', 'yewlx', '业务类型', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'guiy', 'guiy', '操作柜员', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'lingyjg', 'lingyjg', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'guiyh', 'guiyh', '柜员号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'pingzlx', 'pingzlx', '凭证类型', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'shengyzs', 'shengyzs', '剩余张数', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'yilzs', 'yilzs', '已领张数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'zuofzs', 'zuofzs', '作废张数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'CLERKNUM', 'CLERKNUM', 'CLERKNUM', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'POSTNUM', 'POSTNUM', 'POSTNUM', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_IP', 'N_IP', 'N_IP', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'POSTNAME', 'POSTNAME', 'POSTNAME', null, '普通显示', '是', '9', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_CREATOR', 'N_CREATOR', 'N_CREATOR', null, '普通显示', '是', '10', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'CLERKNAME', 'CLERKNAME', 'CLERKNAME', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_LOGDATE', 'N_LOGDATE', 'N_LOGDATE', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_ERROR', 'N_ERROR', 'N_ERROR', null, '普通显示', '是', '13', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'KAIHRQ', 'kaihrq', '开户日期', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'KEHH', 'kehh', '客户号', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'HUM', 'hum', '户名', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'YOUWYJ', 'youwyj', '有无印鉴', null, '普通显示', '是', '9', '001', 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'YOUWZH', 'youwzh', '有无组合', null, '普通显示', '是', '10', '002', 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'ZHANGHSHZT', 'zhanghshzt', '账户审核状态', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'JIGH', 'jigh', '机构号', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'diz', 'diz', '地址', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'zhangh', 'zhangh', '账户', null, '普通显示', '是', '1', null, 'string', null);







insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('diz', '1', '60', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('hum', '1', '60', '@inside[EmptyValidator]|', null, '户名不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('beiz', '1', '100', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('jigh', '3', '9', '@inside[CompareLength]|<=,9', null, '机构号不为6位');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('jine', '8', '13', '@inside[EmptyValidator]|', null, '金额不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('kehh', '3', '15', '@inside[CompareLength]|<=,15', null, '客户号不为10位');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('dianh', '6', '13', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('huobh', '2', '5', null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetHuobhResource', '|获取货币失败|号');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('qiyrq', '4', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('xitlx', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetXitlxResource', '|获取系统类型失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zuhgz', '1', '100', '@inside[EmptyValidator]|', null, '组合规则不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('bingxq', '1', '2', null, '$10,30', '|获取并行期失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('jinesx', '10', '13', '@inside[EmptyValidator]|', null, '金额上限不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('jinexx', '10', '13', '@inside[EmptyValidator]|', null, '金额下限不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('kaihrq', '4', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('lianxr', '1', '20', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('pingzh', '3', '10', '@inside[LengthValidator]|10', null, '凭证号不为10位');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('pofish', '-1', '-1', null, '$peryu,peryu1,peryu2,peryu3', null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('yinjlx', '-1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetYinjlxResource', '|获取印鉴类型失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('yinjys', '-1', null, null, '$红色,蓝色,其它', '|获取印鉴颜色失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('youzbm', '2', '6', '@inside[LengthValidator]|6', null, '邮政编码不为6位');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zhangh', '2', '30', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('pingzlx', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetPingzlxResource]|', '|获取凭证类型失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('shancrq', '5', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('tongctd', '1', '4', null, '$是,否', '|获取通存通兑失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('yinjkbh', '3', '10', '@inside[CompareLength]|<=,10', null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('yinjbgh', '1', '2', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zhanghxz', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetZhanghxzResource', null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('chuprq', '4', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zhuzh', '2', '25', '@inside[CompareLength]|>=,12@inside[CompareLength]|<=,25', null, '主账号长度不正确，12~25');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('daxx', '1', null, null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zuhzt', null, null, null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zuhshzt', null, null, null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zhanghzt', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetZhanghztResource', null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('tingyrq', '4', null, null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('fuyrq', '4', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('guiyh', '3', '7', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('guiymm', '9', '6', null, null, null);





insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhanghxz', '账户详情', '账户类别', '是', '1', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('lianxr', '账户详情', '联系人', '否', '14', null, '否', '1', null, null, '@inside[CompareLength]|<=,20', null, '最大只能输入10个汉字或20个字母', '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('huobh', '账户详情', '货币号', '否', '6', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('dianh', '账户详情', '电话', '否', '15', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('beiz', '账户详情', '备注', '是', '16', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '账户详情', '账号', '是', '2', null, '是', '1', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('kehh', '账户详情', '客户号', '是', '4', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('hum', '账户详情', '户名', '是', '3', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jigh', '账户详情', '机构号', '是', '5', '#Inside[GetInitDefault]|S[guiyjgh]', '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('diz', '账户详情', '地址', '否', '13', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('youzbm', '账户详情', '邮政编码', '否', '15', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('kaihrq', '账户详情', '开户日期', '是', '10', '#Inside[GetDefaultTime]|', '否', '1', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '账户详情', '启用日期', '否', '11', '#Inside[GetDefaultTime]|', '否', '1', null, null, '@inside[CompareValidator]|>=,2,C[kaihrq]@inside[CompareValidator]|%,3,C[kaihrq]', null, '启用日期不能小于开户日期并且时间间隔不能超过3个月', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tongctd', '账户详情', '通存通兑', '是', '9', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('bingxq', '账户详情', '并行期', '否', '9', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('fuyrq', '账户详情', '复用日期', '否', '12', null, '否', '1', null, null, '@inside[CompareValidator]|>=,2,C[kaihrq]@inside[CheckFuyrq]|C[zhuzh]', null, '复用日期不能早于开户日期', '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhuzh', '账户详情', '主账号', '否', '2', null, '是', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][CheckZhuzh]|C[zhangh]', null, '主账号校验失败', '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhanghzt', '账户详情', '账户状态', '是', '8', null, '否', '1', null, null, null, null, null, '2', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '账户详情', '停用日期', '否', '11', null, '否', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjbh', '印鉴信息', '印鉴编号', '是', '2', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjkbh', '印鉴信息', '印鉴卡编号', '是', '1', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '印鉴信息', '停用日期', '是', '4', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhanghxz', '账户', '账户类别', '是', '1', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('lianxr', '账户', '联系人', '否', '14', null, '否', '1', null, null, '@inside[CompareLength]|<=,20', null, '最大只能输入10个汉字或20个字母', '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('huobh', '账户', '货币号', '否', '6', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('dianh', '账户', '电话', '否', '15', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('beiz', '账户', '备注', '是', '16', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjlx', '印鉴', '印鉴种类', '是', '3', null, '是', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjys', '印鉴', '印鉴颜色', '是', '4', null, '是', '2', null, null, null, '$红色,蓝色,黑色', null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '印鉴', '启用日期', '是', '5', '#Inside[GetDefaultTime]|', '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('shancrq', '印鉴', '删除日期', '否', '6', null, '是', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjkbh', '印鉴', '印鉴卡号', '是', '1', null, '是', '1', null, null, null, null, null, '1', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jinexx', '组合', '金额下限', '是', '3', '0', '否', '1', null, '16', '@inside[CompareValidator]|<=,0,c[jinesx]', null, '金额下限必须小于金额上限||获取金额下限失败', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jinesx', '组合', '金额上限', '是', '4', '9999999999', '否', '1', null, '16', '@inside[CompareValidator]|>=,0,c[jinexx]', null, '金额上限必须大于金额下限||获取金额下限失败', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zuhgz', '组合', '组合规则', '是', '5', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '组合', '启用日期', '是', '2', '#Inside[GetDefaultTime]|', '否', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('pingzh', '票据', '凭证号', '是', '3', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '账户', '账号', '是', '2', null, '是', '1', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('kehh', '账户', '客户号', '是', '4', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('hum', '账户', '户名', '是', '3', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jigh', '账户', '机构号', '是', '5', '#Inside[GetInitDefault]|S[guiyjgh]', '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('diz', '账户', '地址', '否', '13', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('youzbm', '账户', '邮政编码', '否', '15', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('kaihrq', '账户', '开户日期', '是', '10', '#Inside[GetDefaultTime]|', '否', '1', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '账户', '启用日期', '否', '11', '#Inside[GetDefaultTime]|', '否', '1', null, null, '@inside[CompareValidator]|>=,2,C[kaihrq]@inside[CompareValidator]|%,3,C[kaihrq]', null, '启用日期不能小于开户日期并且时间间隔不能超过3个月', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tongctd', '账户', '通存通兑', '是', '9', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('bingxq', '账户', '并行期', '否', '9', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jine', '票据', '金额', '是', '4', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('pingzlx', '验印', '凭证类型', '是', '1', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '审核', '账号', '是', '1', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '验印', '账号', '是', '1', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('xitlx', '印鉴', '系统类型', '是', '2', null, '是', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('xitlx', '组合', '系统类型', '是', '1', null, '否', '2', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('chuprq', '票据', '出票日期', '是', '5', null, '否', '1', null, null, '@inside[CompareNowDate]', null, '出票日期不允许为空！', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjbh', '印鉴详情', '印鉴编号', '是', '3', null, '是', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '印鉴详情', '停用日期', '是', '6', null, '是', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '组合列表', '停用日期', '是', '7', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjkbh', '印鉴详情', '印鉴卡号', '是', '1', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjlx', '印鉴详情', '印鉴种类', '是', '4', null, '是', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjys', '印鉴详情', '印鉴颜色', '是', '5', null, '是', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '印鉴详情', '启用日期', '是', '2', '#Inside[GetDefaultTime]|', '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '票据', '账号', '是', '1', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('fuyrq', '账户', '复用日期', '否', '12', null, '否', '1', null, null, '@inside[CompareValidator]|>=,2,C[kaihrq]@inside[CheckFuyrq]|C[zhuzh]', null, '复用日期不能早于开户日期', '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhuzh', '账户', '主账号', '否', '2', null, '是', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][CheckZhuzh]|C[zhangh]', null, '主账号校验失败', '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('daxx', '票据', '大小写', '否', '6', null, '否', '2', null, null, null, '$不相符,相符', null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '组合列表', '账号', '否', '1', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jinexx', '组合列表', '金额下限', '是', '2', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jinesx', '组合列表', '金额上限', '是', '3', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('xitlx', '组合列表', '系统类型', '是', '4', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zuhgz', '组合列表', '组合规则', '是', '5', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '组合列表', '启用日期', '是', '6', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('xitlx', '票据', '系统类型', '是', '2', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zuhshzt', '组合列表', '审核状态', '是', '9', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhanghzt', '账户', '账户状态', '是', '8', null, '否', '2', null, null, null, null, null, '2', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '账户', '停用日期', '否', '11', null, '否', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('guiyh', '双签', '柜员号', '是', '1', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('guiymm', '双签', '密  码', '是', '2', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '印鉴信息', '启用日期', '是', '3', null, '是', '1', null, null, null, null, null, '0', null, '是');



insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YY_meibzs', '各凭证每本张数不能超过1000！', '凭证参数设置', '新增凭证', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-ip_err2', '本机器已经有柜员【${clerknum}】登陆验印系统，不允许再次登陆！', '登陆', null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_account_isPost', '没有权限查询账号[${account}]', 'UREPORT报表', 'UREPORT报表', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_account_isNull', '[${account}]账号不存在', 'UREPORT报表', 'UREPORT报表', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-clerknum', '柜员号格式不正确！', null, null, '柜员错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_account_jygz', '柜员编号格式不正确，最少输入12位！', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_clerknum_isPost', '没有权限查询柜员[${clerknum}]', 'UREPORT报表', 'UREPORT报表', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_clerknum_isNull', '[${clerknum}]柜员不存在', 'UREPORT报表', 'UREPORT报表', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-import-ok', '导入数据成功！', null, null, '导入错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-import-error', '导入数据失败！', null, null, '导入错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-export-ok', '导出数据成功！', null, null, '导出成功提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-export-error', '导出数据失败，${exception}！', null, null, '导出错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-orgCode', '机构代码格式不正确,必须为5或6位数字！', null, null, '机构号错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-paymentCode', '人行支付系统行号格式不正确！', '机构管理', '添加机构', '人行支付系统行号提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-password', '柜员密码格式不正确！', null, null, '柜员密码提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-pwdError', '账号或密码错误，${leavetimes}次后用户将被锁定!', '登录', '登录', '密码错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-account', '账号格式不正确！', null, null, '账号错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-englishname', '客户号格式不正确！', '客户号查询', null, '客户号错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-checknum', '凭证号必须为10位字母或数字！', null, null, '凭证号提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYF-sealchecklog', '需要同时输入【账号+票据号】', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYF-voucherchecklog', '请输入：【账号】或【柜员号】（可以加上凭证号进行过滤）！', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-pwdErrorCat', '密码错误！', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-ip_err1', '柜员【${clerknum}】已在IP为:${clerkip}的机器上登录!', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY_PINGZH', '凭证号格式不正确！', '凭证销售', '凭证出售', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-juesid', '角色ID应为字母或数字', '角色管理', '添加角色', '角色id错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('PJCS_success', '录入成功！', null, null, '票据出售成功提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('PJCS_alreadyhave', '请重新录入！凭证号已存在！', null, null, '票据出售错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('PJCS_error', '录入过程发生错误！', null, null, '票据出售错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('pingzcssz_youxq', '有效期最多4位数字', '系统管理', '凭证参数设置', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('pingzxs_pzcs', '凭证号必须10位数字!', '凭证销售', '凭证出售', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-kagid', '卡柜编号格式不正确', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YY_BENS', '本数必须是数字，且不能为0！', '凭证入库、领用、退回', null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('zhongk_ly', '凭证领用成功！', '重控凭证', '凭证领用', '领用成功提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('zhongk_th', '凭证退回成功！', '重控凭证', '凭证退回', '退回成功提示信息');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('zhongk_zf', '凭证作废成功！', '重控凭证', '凭证作废', '作废成功提示信息');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('zhongk_rk', '凭证入库成功！', '重控凭证', '凭证入库', '入库成功提示信息');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YY_pingzbs', '凭证标识为2位！', null, null, null);







insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('meibzs', '每本张数', '4', null, null, null, '/[0-9]{0,4}/', 'YY_meibzs', '限定各种凭证每本张数不超过1000');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('pingzhqz', '凭证前缀', '10', null, null, null, null, null, null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('account', '帐号', '30', 'width:175px;', null, null, '/^[a-zA-Z0-9]{1,30}$/', 'YYY-account', '账户简单查询，账户定制查询，日志查询，特殊业务');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('englishname', '客户号', '15', null, null, null, '/\w{15}/', 'YYY-englishname', '账户定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('clerknum_7', '柜员号', '8', null, null, null, '/(^\w{3,8})/', 'YYY-clerknum', '柜员管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('netpointflag', '机构号', '6', 'width:65px;', null, null, '/(^[0-9]{2,8}$)/', 'YYY-orgCode', '按机构清IP，账户定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('paymentCode', '人行支付系统行号', '12', null, null, null, '/[0-9]{12}/', 'YYY-paymentCode', '机构管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('password', '柜员密码', '6', null, null, null, '/\w{6}/', 'YYY-password', '柜员密码');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('gongnid', '功能id', null, null, null, null, '/[^\u4e00-\u9fa5]+/', null, '功能菜单定制');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zignid', '子功能ID', null, null, null, null, '/[^\u4e00-\u9fa5]+/', null, '功能菜单定制');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('BAOBBS', '报表标识', null, null, null, null, '/[^\u4e00-\u9fa5]+/', null, null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('password1', '柜员密码', '6', null, null, null, '/\w{6}/', 'YYY-password', '确认柜员密码');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('orgCode', '机构号', '6', 'width:65px;', null, null, '/(^{4}$)/', 'YYY-orgCode', '机构管理，机构凭证日志查询，账户信息定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('clerknum', '柜员号', '8', null, null, null, '/(^\w{3,8})/', 'YYY-clerknum', '管理员日志查询，验印日志定制查询，整票日志查询，单张日志查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('JIGH', '机构号', '6', 'width:65px;', null, null, '/(^[0-9]{2,8}$)/', 'YYY-orgCode', '账户审核查询，账户高级查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('checknum', '凭证号', '10', null, null, null, '/\w{10}/', 'YYY-checknum', '验印日志定制查询，整票日志查询，单张日志查询，验印结果当日查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('KEHH', '客户号', '15', null, null, null, '/[0-9]{15}/', 'YYY-englishname', '客户简单查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('begindate', '开始日期', '10', 'width:70px;', null, null, null, 'YYY-begindate', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('enddate', '结束日期', null, 'width:70px;', null, null, null, null, null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('jigh', '机构号', '6', 'width:155px;', null, null, '/(^[0-9]{2,8}$)/', 'YYY-orgCode', '账户审核查询，账户高级查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('password2', '原密码', '6', null, null, null, '/\w{6}/', 'YYY-password', '修改密码');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zhangh', '账号', '30', 'width:175px;', null, null, '/^[a-zA-Z0-9]{1,30}$/', 'YYY-account', '账户简单查询，账户定制查询，日志查询，特殊业务');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('guiyh', '柜员号', '8', null, null, null, '/(^\w{3,8})/', 'YYY-clerknum', '管理员日志查询，验印日志定制查询，整票日志查询，单张日志查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('organnum', '机构号', '6', 'width:65px;', null, null, '/(^[0-9]{2,8}$)/', 'YYY-orgCode', '机构管理，机构凭证日志查询，账户信息定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('qispzh', '起始凭证号', '10', null, null, null, '/[0-9]{10}/', 'pingzxs_pzcs', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zhongzpzh', '终止凭证号', '10', null, null, null, '/[0-9]{10}/', 'pingzxs_pzcs', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('juesid', '角色ID', '12', null, null, null, '/^(\w){1,12}$/', 'YYY-juesid', '角色管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('juesmc', '角色名称', '25', null, null, null, null, null, '角色管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('clerkname', '柜员名称', '20', null, null, null, null, null, null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('organname', '机构名称', '20', null, null, null, null, null, '机构管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('RIQFW', '月份格式', '6', 'width:62px;', null, null, null, 'RIQFW', '账户通过率、机构通过率');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('pingzbs', '凭证标识', '2', null, null, null, ' /^(\w){2,2}$/', 'YY_pingzbs', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('lingyjg', '领用机构号', '6', 'width:65px;', null, null, '/(^[0-9]{6}$)|(^[0-9]{5}$)/', 'YYY-orgCode', '重控凭证管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('rengwms', '任务描述', '100', null, null, null, null, null, '账户定制查询、验印日志定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('youxq', '有效期', '4', null, null, null, '/[0-9]{1,4}/', 'pingzcssz_youxq', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('qispzh_', '起始凭证号', '10', null, null, null, '/[0-9]{10}/', 'pingzxs_pzcs', '凭证入库、凭证退回、凭证作废');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('bens', '本数', '2', 'width:40px;', null, null, ' /[0-9]/', 'YY_BENS', '凭证入库');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('kagid', '卡柜编号', '20', null, null, null, '/^[0-9]{1,20}$/', 'YYY-kagid', '卡柜维护');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('rukjg', '入库机构', '6', 'width:65px;', null, null, ' /(^[0-9]{6}$)|(^[0-9]{5}$)/', 'YYY-orgCode', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('jiglyfzr', '机构领用负责人', '7', null, null, null, '/(^\w{7})|(^\w{6})/', 'YYY-clerknum', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zh', '帐号', '32', 'width:175px;', null, null, '/^[a-zA-Z0-9]{1,32}$/', null, '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('hm', '户名', '120', 'width:175px;', null, null, null, null, '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('khh', '客户号', '15', 'width:175px;', null, null, '/[0-9]{15}/', 'YYY-englishname', '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zhjgh', '账户机构号', '6', 'width:175px;', null, null, '/[0-9]{6}/', 'YYY-orgCode', '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('khrq', '开户日期', '10', 'width:175px;', null, null, '/[0-9]{10}/', 'YYY-begindate', '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('jgmc', '机构名称', '20', 'width:175px;', null, null, null, null, '机构管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('bghkhrq', '变更后开户日期', '10', 'width:175px;', null, null, '/[0-9]{10}/', null, '印鉴审核');







insert into YINHDJ (ID, NAME, PID)
values ('1', '一级', null);

insert into YINHDJ (ID, NAME, PID)
values ('2', '二级', '1');









insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getGroups', 'simpleQuery', 1, 'select  ZHANGH,JINEXX,JINESX,XITLX,ZUHGZ,QIYRQ,SHANCRQ,ZUHZT,ZUHSHZT from yinjzhb where zhangh = (select CASE WHEN (zhuzh is null )or(zhuzh = '''' ) THEN zhangh ELSE zhuzh END  from zhanghb where zhangh=:zhangh) and zuhzt||zuhshzt!=''删除已审''', '根据帐号获取账户下可用的组合信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getGroupsToCheck', 'simpleQuery', 1, 'select * from yinjzhb where zhangh =(select CASE WHEN (zhuzh is null )or(zhuzh = '''' ) THEN zhangh ELSE zhuzh END from zhanghb where zhangh=:zhangh) and zuhzt||zuhshzt !=''删除已审'' and zuhzt||zuhshzt!=''新增未审'' and zuhzt||zuhshzt!=''更增未审'' and qiyrq <= current date', '获取账户下可供验印的组合信息列表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetHolidayData', 'simpleQuery', 1, 'select year as holidayyear, month_01||month_02||month_03||month_04||month_05||month_06||month_07||month_08||month_09||month_10||month_11||month_12 as holidaystr from jiejrgl', '获取节假日表数据，供ocx判断是否是节假日', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetHuobhResource', 'simpleQuery', 1, 'select HUOBMC key, HUOBBH value from HUOBB order by to_number(HUOBBH)', '获取货币号数据源', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetInfoToCheckByRenwBS', 'simpleQuery', 1, 'select * from ci_renwxx where xitbs||renwbs = :renwbs', '(供辅助接口、自动处理用)根据任务信息获取验印任务信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getOCXConfig', 'simpleQuery', 1, 'select * from ocxkongzcsb', '获取ocx控制参数表ocxkongzcsb的数据', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetPici', 'simpleQuery', 1, 'select count(distinct qiyrq) sealtimes from yinjb where zhangh=:zhangh', '获得批次启用日期（辅助验印接口用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getYSqyrq', 'simpleQuery', 1, 'select max(qiyrq) maxtime from yinjb where zhangh=:zhangh and yinjshzt=''已审''', '获得所有已审启用日期（辅助验印接口用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelAllYinj', 'simpleTrans', 1, 'delete from yinjb where zhangh=:zhangh', '删除账户下所有印鉴（江西新增用） ', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelBakzhanghb', 'simpleTrans', 1, 'delete bak_zhanghb where zhangh=:zhangh', '清空备份帐户表特定账户信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('delCombineReal', 'simpleTrans', 1, 'delete from yinjzhb where zhangh=:zhangh and jinexx=:jinexx and jinesx=:jinesx and xitlx=:xitlx and zuhgz=:zuhgz and qiyrq=:qiyrq', '删除一条组合（未审的直接删除）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DeleteAllOcxkongzcsb', 'simpleTrans', 1, 'delete from ocxkongzcsb', '删除OCX控制参数表中的全部数据（为了还原数据库）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DeleteOcxkongzcsb', 'simpleTrans', 1, 'delete from ocxkongzcsb where key=:key', '同步删除OCX控制参数表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('deleteRoleByClerk', 'simpleTrans', 1, 'delete from guiyjsgxb where guiyid=:guiyid', '删除柜员角色关系', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSettingInfoBySN', 'simpleQuery', 1, 'select * from shuxkzgxb where gongnym = :gongnym  order by to_number(zhanssx)', '获取指定模块的扩展配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelAllZh', 'simpleTrans', 1, 'delete from yinjzhb where zhangh=:zhangh', '删除账户下所有组合（江西新增用） ', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelKAGRW', 'simpleTrans', 1, 'delete from kagrw where zhangh=:zhangh', '删除账户下所有建库信息--卡柜任务（江西新增用） ', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelYinjk', 'simpleTrans', 1, 'delete from yinjk where zhangh=:zhangh', '删除账户下所有建库信息--印鉴卡（江西新增用） ', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelWSyinj', 'simpleTrans', 1, 'delete from yinjb where (yinjshzt<>''已审'' or qiyrq=:qiyrq) and zhangh=:zhangh ', '删除账户下所有未审印鉴+传入批次印鉴（江西变更用） ', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelWSZh', 'simpleTrans', 1, 'delete from yinjzhb where (zuhshzt<>''已审'' or qiyrq=:qiyrq) and zhangh=:zhangh  ', '删除账户下所有未审组合+该批次组合（江西变更用） ', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetWSqyrq', 'simpleQuery', 1, 'select distinct(qiyrq) from yinjb t where yinjshzt=''未审'' and zhangh=:zhangh ', '查询账户下的“未审”印鉴启用日期（江西变更用） ', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelWSkagrw', 'simpleTrans', 1, 'delete from kagrw where zhangh=:zhangh and qiyrq=:qiyrq', '删除“未审”印鉴对应建库信息（江西变更用） ', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelWSyinjk', 'simpleTrans', 1, 'delete from yinjk where zhangh=:zhangh and qiyrq=:qiyrq', '删除“未审”印鉴对应建库信息（江西变更用） ', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelAccount', 'simpleTrans', 1, 'delete from zhanghb where zhangh=:zhangh', '删除账户信息（江西新增用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JSaveAllAccountInfo', 'complexTrans', 1, 'JudgeAccountOrgBelongToGuiyOrg,DelAccount,DelAllYinj,DelAllZh,addAccountInfo,addSealInfo,addCombineInfo,changeUserCheckState,changeCombineCheckState,UpdateAccountInfo,DelWSyinj,DelWSZh,setSealTingyrq,setCombinaTingyrq,WriteWorkLogToDb', '保存账户信息（江西新增用） ', 'JudgeAccountOrgBelongToGuiyOrg,DelAccount,DelAllYinj,DelAllZh,addAccountInfo,addSealInfo,addCombineInfo,changeUserCheckState,changeCombineCheckState,UpdateAccountInfo,DelWSyinj,DelWSZh,setSealTingyrq,setCombinaTingyrq,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelBakyinjb', 'simpleTrans', 1, 'delete from bak_yinjb where zhangh=:zhangh', '清空备份印鉴表特定账户印鉴信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DelBakyinjzhb', 'simpleTrans', 1, 'delete from bak_yinjzhb where zhangh=:zhangh', '清空备份印鉴表特定账户组合信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('Bakzhanghb', 'simpleTrans', 1, 'insert into bak_zhanghb(ZHANGH,KEHH,HUM,JIGH,DIZ,YOUZBM,LIANXR,DIANH,KAIHRQ,TONGCTD,HUOBH,YOUWYJ,YOUWZH,YINJSHZT,ZHANGHSHZT,ZUHSHZT,ZHANGHZT,ZHANGHXZ,YANYJB,YANYJG,BEIZ,ZHUZH,FUYRQ,QUXFYRQ,
 JIANKBS,TINGYRQ) (SELECT ZHANGH,KEHH,HUM,JIGH,DIZ,YOUZBM,LIANXR,DIANH,KAIHRQ,TONGCTD,HUOBH,YOUWYJ,YOUWZH,YINJSHZT,ZHANGHSHZT,ZUHSHZT,ZHANGHZT,ZHANGHXZ,YANYJB,YANYJG,
 BEIZ,ZHUZH,FUYRQ,QUXFYRQ,JIANKBS,TINGYRQ FROM ZHANGHB where zhangh=:zhangh)', '备份账户信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('Bakyinjb', 'simpleTrans', 1, 'insert into bak_yinjb (ZHANGH,YINJBH,QIYRQ,SHANCRQ,YINJLX,YINJZL,YINJYS,YINJTP,YINJZT,YINJSHZT,YINJKBH,YANYJB,YANYJG,TINGYRQ)select ZHANGH,YINJBH,QIYRQ,SHANCRQ,YINJLX,YINJZL,YINJYS,YINJTP,YINJZT,YINJSHZT,YINJKBH,YANYJB,YANYJG,TINGYRQ from yinjb  where zhangh=:zhangh and qiyrq=:qiyrq', '备份账户印鉴信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('Bakyinjzhb', 'simpleTrans', 1, 'insert into bak_yinjzhb (ZHANGH,JINEXX,JINESX,XITLX,ZUHGZ,QIYRQ,SHANCRQ,ZUHZT,ZUHSHZT,TINGYRQ) select ZHANGH,JINEXX,JINESX,XITLX,ZUHGZ,QIYRQ,SHANCRQ,ZUHZT,ZUHSHZT,TINGYRQ from yinjzhb where zhangh=:zhangh and qiyrq=:qiyrq', '备份账户组合信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ChangeYinjDate', 'simpleTrans', 1, 'update bak_yinjb set changedate=:changedate where zhangh=:zhangh', '添加备份时间到印鉴备份表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ChangeZuhDate', 'simpleTrans', 1, 'update bak_yinjzhb set changedate=:changedate where zhangh=:zhangh', '添加备份时间到组合备份表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getExaminedSealNoGZ', 'simpleQuery', 1, 'select * from yinjb where qiyrq = (select max(qiyrq) from yinjb where zhangh =:zhangh and yinjshzt =''已审'') and zhangh=:zhangh and yinjlx<>''公章'' order by to_number(yinjbh)', '获得“非公章”已审印鉴信息（江西获得审核信息用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getExaminedSealGZ', 'simpleQuery', 1, 'select * from yinjb where qiyrq = (select max(qiyrq) from yinjb where zhangh =:zhangh and yinjshzt =''已审'') and zhangh=:zhangh and yinjlx=''公章'' order by to_number(yinjbh)', '获得只有“公章”已审印鉴信息（江西获得审核信息用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JGetAccoCheckInfo', 'complexQuery', 1, 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg,getYSqyrq,getExaminedSeal,getExaminedGroup,getExaminedSealNoGZ,getExaminedSealGZ,getSatisfySealToVerify,getSatisfyZuheToVerify', '获得账户审核信息（江西）', 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg,getYSqyrq,getExaminedSeal,getExaminedGroup,getExaminedSealNoGZ,getExaminedSealGZ,getSatisfySealToVerify,getSatisfyZuheToVerify');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('NcheckAccountInfo', 'simpleTrans', 1, 'update zhanghb set yinjshzt=:shzt,zhanghshzt=:zhanghshzt,zuhshzt=:shzt  where zhangh = :zhangh', '更改账户审核状态', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('NcheckSeals', 'simpleTrans', 1, 'update yinjb set yinjshzt = :shzt ,shenhy=:shenhy, shenhynum=:shenhynum  where zhangh = :zhangh and qiyrq=:qiyrq and yinjshzt= ''未审''', '更改印鉴审核状态', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('NcheckGroups', 'simpleTrans', 1, 'update yinjzhb set zuhshzt = :shzt where zhangh = :zhangh and qiyrq=:qiyrq and zuhshzt= ''未审''', '更改组合审核状态', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetOcxkongzcsb', 'simpleQuery', 1, 'select * from ocxkongzcsb', '获取OCX控制参数表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetInterfaceConfig', 'simpleQuery', 1, 'select cansbs, cansz from ci_xitcs where xitbs = :xitbs union all select cansbs, cansz from ci_jiedcs where jiedbs = :jiedbs', '（接口用）根据系统标识、节点标识获取配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('updateCombine', 'simpleTrans', 1, 'update yinjzhb set zuhzt=:zuhzt,zuhshzt=:zuhshzt,shancrq=:shancrq where zhangh=:zhangh and jinexx=:jinexx and jinesx=:jinesx and xitlx=:xitlx and zuhgz=:zuhgz and qiyrq=:qiyrq', '修改组合信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('UpdateOcxkongzcsb', 'simpleTrans', 1, 'update ocxkongzcsb set key=:key,value=:value,target=:target,defaultvalue=:defaultvalue,remark=:remark where key=:key', '更新OCX控制参数表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetXitlx', 'simpleQuery', 1, 'select * from XITLXB', '获取系统类型', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('updateCombineInfo', 'simpleTrans', 1, 'update yinjzhb set jinexx=:jinexxnew,jinesx=:jinesxnew,zuhgz=:zuhgznew,qiyrq=:qiyrqnew,xitlx=:xitlxnew where zhangh=:zhangh and jinexx=:jinexx and jinesx=:jinesx and xitlx=:xitlx and zuhgz=:zuhgz and qiyrq=:qiyrq', '修改新增未审的组合的简单交易', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('updateSealDelDate', 'simpleTrans', 1, 'update yinjb set yinjzt=''变更'',yinjshzt=''未审'',shancrq=:shancrq where zhangh=:zhangh and yinjbh=:yinjbh and yinjbgh=:yinjbgh', '更改印鉴删除时间（用于变更印鉴时修改变更前印鉴的删除时间）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('simpleTrans-data', 'simpleTrans', 1, 'INSERT INTO accountespecialexpand (account,str10,str11,str12,str13) values (:account,date8,date8,date8,date8)', '日期检测', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('query-union', 'simpleQuery', 1, 'select account from accountespecialexpand intersect select account from accountinfo', '多表查询', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('r_baobpz', 'simpleQuery', 1, 'select a.account ,a.accountname from accountinfo a where  a.industrycharacter =:industrycharacter', '定制---报表查询', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('isZhuzh', 'simpleQuery', 1, 'select * from zhanghb where zhangh =:zhangh and (zhuzh is null or zhuzh='''')', '判断是否为主账户(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSatisfySealToVerify', 'simpleQuery', 1, 'select * from yinjb where zhangh = :zhangh  and yinjshzt=''未审'' order by to_number(yinjbh)', '获取满足审核日期的印鉴(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSatisfyZuheToVerify', 'simpleQuery', 1, 'select * from yinjzhb where zhangh = :zhangh and zuhshzt =''未审''', '获取满足审核日期的组合(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.GetSysInitInfo', 'complexQuery', 1, 'GetClerk,GetClerkQX,getAllOrganAsOrganNumber,GetSysConfig,GetSysConfigValue,getAttribute,getAllQx', '系统初始化时获取所有相应的参数', 'GetClerk,GetClerkQX,getAllOrganAsOrganNumber,GetSysConfig,GetSysConfigValue,getAttribute,getAllQx');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('CheckParentAccount', 'simpleQuery', 1, 'select zhangh,zhuzh from zhanghb where zhangh=:zhangh', '检查主账户是否存在且不为子账户', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SystemMgrService_clearAllOrgclerkIP', 'simpleTrans', 1, 'update clerktable c set c.n_ip=null where c.n_organnum =:organnum', '清除机构下柜员的锁定IP', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SystemMgrService_ClearClerkIP', 'simpleTrans', 1, 'update clerktable set n_ip=null where clerknum =:clerknum', '清除柜员的锁定IP', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SystemMgrService_getClerkIP', 'simpleQuery', 1, 'select c.clerkname,o.organname,c.n_ip from clerktable c, organarchives o where c.n_organnum = o.organnum and c.clerknum = :clerknum', '获取柜员信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SystemMgrService_getOrgclerkIP', 'simpleQuery', 1, 'select c.clerknum,c.organnum,c.clerkname,c.organname,c.n_ip from (select c.clerknum,o.organnum,c.clerkname,o.organname,c.n_ip,c.postnum from  clerktable c, organarchives o where c.n_organnum = o.organnum) c  where  c.n_ip is not null  and c.organnum=:organnum', '获取机构下柜员的锁定IP列表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SystemMgrService_getSystetemNowDate', 'simpleQuery', 1, 'select to_char(sysdate,''yyyy-mm-dd hh24:mi:ss'') GETDATE from dual', '获取数据库时间(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetXitlxResource', 'simpleQuery', 1, 'select xitlx key,xitlx value from XITLXB where SHIFQY=''1'' order by to_number(beiz)', '获取系统类型', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetYinjlxResource', 'simpleQuery', 1, 'select yinjlx key,yinjlx value from YINJLXB where SHIFQY=''1'' order by to_number(beiz)', '获取印鉴类型', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetYinjlx', 'simpleQuery', 1, 'select * from YINJLXB', '获取印鉴类型', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('delSeal', 'simpleTrans', 1, 'delete from yinjb where zhangh=:zhangh and yinjbh=:yinjbh and yinjbgh=:yinjbgh', '删除当前用户的指定印鉴（真删除）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('delSealag', 'simpleTrans', 1, 'update yinjb set yinjzt=''滞删'',yinjshzt=''未审'',shancrq=:shancrq where zhangh=:zhangh and yinjbh=:yinjbh and yinjbgh=:yinjbgh', '删除印鉴，假删除，滞后删除', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('delSealAsState', 'simpleTrans', 1, 'update yinjb set yinjzt=''删除'',yinjshzt=''未审'',shancrq=:shancrq where zhangh=:zhangh and yinjbh=:yinjbh and yinjbgh=:yinjbgh', '删除一个印鉴，只是更改状态为废章，（假删除）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('delSettingInfo', 'simpleTrans', 1, 'delete  xinzxxxlb where gongnym=:gongnym and shuxm=:shuxm', '删除配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('EditGroupInfo', 'combinTrans', 1, 'updateCombine,addCombineInfo,changeCombineCheckState', '编辑组合信息', 'updateCombine,addCombineInfo,changeCombineCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAllRole', 'simpleQuery', 1, 'select * from juesb', '获取所有角色', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getYinjkxx', 'simpleQuery', 1, 'select * from yinjk where zhangh=:zhangh', '获取账号的印鉴卡信息（锦州银行印鉴查阅）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAttribute', 'simpleQuery', 1, ' select a.shuxm,a.gongnym,a.zhansm,a.zhanssx,a.morz,a.shifzd,a.shifzhxs,a.zhansfs,a.liandfs,a.shifkk,CASE WHEN (a.shurkz is null )or(a.shurkz = '''' ) THEN b.shurkz ELSE a.shurkz END shurkz,CASE WHEN (a.zuidcd is null )or(a.zuidcd = '''' ) THEN b.zuidcd ELSE a.zuidcd END zuidcd,CASE WHEN (a.yanzzfc is null )or(a.yanzzfc = '''' ) THEN b.yanzzfc ELSE a.yanzzfc END   yanzzfc,CASE WHEN (a.shujy is null )or(a.shujy = '''' ) THEN b.shujy ELSE a.shujy END shujy,CASE WHEN (a.tisxx is null )or(a.tisxx = '''' ) THEN b.tisxx ELSE a.tisxx END tisxx ,a.shifzs from shuxkzgxb a left join shuxkzb b on a.shuxm=b.shuxm order by a.gongnym,to_number(a.zhanssx)', '获取属性扩展相关数据（采用两表连接，排序显示）(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAttributePart', 'simpleQuery', 1, 'select * from shuxkzb', '获取属性扩展表所有数据（供工具使用，需要更改）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAttributeWhole', 'simpleQuery', 1, 'select * from shuxkzgxb order by Double(zhanssx)', '获取属性扩展关系表所有数据（供工具使用，需要更改）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetBillConfig', 'simpleQuery', 1, 'select  yanyjb yy_004,xfenbl yy_008 from ci_pingzcs where xitbs = :xitbs and pingzbs =:pingzbs', '根据系统、凭证标识获取凭证参数（需要查询出来的列名与参数设置的id一致）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getCheckSeals', 'simpleQuery', 1, 'select * from yinjb where zhangh=:zhangh and yinjzt!=''删除'' and yinjshzt==''已审'' order by Double(yinjbh)', '获取验印状态下所有可验印的印鉴的列表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetClerk', 'simpleQuery', 1, 'select * from clerktable where clerknum =:shuangqgyh', '获取柜员信息（用于ocx中判断柜员权限时用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetClerkInfo', 'simpleQuery', 1, 'select * from clerktable where clerknum = :clerknum', '获取柜员信息（复杂交易用来判断柜员权限）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetClerkQX', 'simpleQuery', 1, 'select quanxid from juesqxgxb where juesid in (select juesid from guiyjsgxb where guiyid = :clerknum) ', '获取柜员的权限列表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetClerkQXExist', 'simpleQuery', 1, 'select * from juesqxgxb where juesid in (select juesid from guiyjsgxb where guiyid= :shuangqgyh) and quanxid=''32123''', '查询柜员是否有某项权限', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getCombineCount', 'simpleQuery', 1, 'select count(*) as combine_count from yinjzhb where zhangh=:zhangh', '获取当前账户的组合个数，用于判断是否有组合', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getdatenow', 'simpleQuery', 1, 'select char(current date) sysdate_string from sysibm.sysdummy1 ', '获取系统时间', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetDBPingzPZ', 'simpleQuery', 1, 'select * from dbpz_zhanghpz where zhangh=:zhangh and pingzh =:pingzh', '获取打标模式下的票据配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JInitializeOcx', 'complexQuery', 1, 'getOcxVersionInfo,getAttribute,GetSysConfig,SystemMgrService_getSystetemNowDate', 'OCX初始化交易(V3.0-引擎)', 'getOcxVersionInfo,getAttribute,GetSysConfig,SystemMgrService_getSystetemNowDate');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetInterfaceRenWxx', 'combinQuery', 1, 'getMaxSealNumber,addSealInfo,changeUserCheckState', '用于辅助验印接口获取任务信息(当辅助验印单独使用时调用)', 'GetRenwxx,GetYYRZ');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getMaxChangeNumber', 'simpleQuery', 1, 'select coalesce(max(to_number(yinjbgh)),0) max_number_yinjbgh from yinjb where zhangh=:zhangh and yinjbh=:yinjbh', '获取当前用户选定的印鉴的最大变更号', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getMaxSealNumber', 'simpleQuery', 1, 'select coalesce(max(to_number(yinjbh)),0) as max_number_yinjbh from yinjb where zhangh =:zhangh', '获取当前用户的最大印鉴编号', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetNormalPingzlx', 'simpleQuery', 1, 'select pingzbs||pingzmc key,pingzbs value from pingzpzb where netpointflag=''000000'' and shifqy=''1''', '获取基础的凭证类型（大猫下的）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetOcxkongzcsbWithTarget', 'simpleQuery', 1, 'select * from ocxkongzcsb where target=:target', '根据OCXtongkzcsb中的target字段选取记录', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetOneSeal', 'simpleQuery', 1, 'select * from yinjb where zhangh=:zhangh and yinjbh=:yinjbh and qiyrq =:qiyrq', '获取指定预留印鉴(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetPingZlxByNetPoint', 'simpleQuery', 1, 'select pingzbs||pingzmc key,pingzbs value from pingzpzb where netpointflag=:netpointflag and shifqy=''1''', '根据机构号获取凭证类型', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetPingzlxResource', 'combinQuery', 1, 'GetPingZlxByNetPoint,GetNormalPingzlx', '获取凭证类型-数据源', 'GetPingZlxByNetPoint,GetNormalPingzlx');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetPingzPZ', 'combinQuery', 1, 'GetPingzPZByNetpoint,GetPingzPZNormal', '获取凭证配置信息', 'GetPingzPZByNetpoint,GetPingzPZNormal');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetPingzPZByNetpoint', 'simpleQuery', 1, 'select * from pingzpzb where netpointflag = :netpointflag and pingzbs=:pingzbs  and shifqy=''1''', '获取凭证配置信息（根据机构）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetPingzPZNormal', 'simpleQuery', 1, 'select * from pingzpzb where netpointflag = ''000000'' and pingzbs=:pingzbs and shifqy=''1''', '获取凭证配置信息(通用)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AddZhanghyxxxb', 'simpleTrans', 1, 'insert into zhanghyxxxb(zhangh, yxlx, wenjbh, wenjfwdz, piaojyxdz,wenjw,wenjh) values (:zhangh, :yxlx, :wenjbh, :wenjfwdz, :piaojyxdz,:wenjw,:wenjh)', '新增影像信息到数据库', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('alert_table', 'simpleTrans', 1, 'alter table accountespecialexpand add COLUMN phone DOUBLE', '新增列', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('alert-delete', 'simpleTrans', 1, 'alter table accountespecialexpand drop column phone', '删除列', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('asdfasd', 'complexQuery', 1, 'r_baobpz,query-union', '阿隆索的发卡顺口溜', 'r_baobpz,query-union');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AssGetAccountInfo', 'simpleQuery', 1, 'select * from zhanghb where zhangh=:zhangh', '接口用-获取账户信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getVersion_Addr', 'simpleQuery', 1, 'select * from bskongzcs t where cansid=''OCX_version_addr''', '获取账户全部信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AssBillLogSave', 'simpleTrans', 1, 'INSERT INTO jk_renwxx (xitbs, jiedbs, renwbs, xitlx, zhangh, pingzh, jine, chuprq, pingzbs, wenjm, tuxsy, yanyjb, chulzt, yanyms, yanyjg, weigyy, chulrq, faqsj, huizsj, chulgy, yewtz1, zhangh1, zhangh2, zhangh3, zhangh4, tonggzh, renwrq) values (:xitbs, :jiedbs, :renwbs, :xitlx, :zhangh, :pingzh, :jine, :chuprq, :pingzbs, :wenjm, :tuxsy, :yanyjb, :chulzt, :yanyms, :yanyjg, :weigyy, :chulrq, :faqsj, :huizsj, :chulgy, :yewtz1, :zhangh1, :zhangh2, :zhangh3, :zhangh4, :tonggzh, :renwrq)', '接口用:记录整票验印结果日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AssGetGroupsToCheck', 'simpleQuery', 1, 'select * from yinjzhb where zhangh =(select CASE WHEN (zhuzh is null )or(zhuzh = '''' ) THEN zhangh ELSE zhuzh END from zhanghb where zhangh=:zhangh) and zuhzt||zuhshzt !=''删除已审'' and zuhzt||zuhshzt!=''新增未审'' and zuhzt||zuhshzt!=''更增未审'' and qiyrq <= current date', '接口用-获取组合信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AssGetSealsToCheck', 'simpleQuery', 1, 'select * from yinjb where zhangh =(select CASE WHEN (zhuzh is null )or(zhuzh = '''' ) THEN zhangh ELSE zhuzh END from zhanghb where zhangh=:zhangh) and yinjzt||yinjshzt !=''删除已审'' and yinjzt||yinjshzt!=''新增未审'' and yinjzt||yinjshzt!=''更增未审'' and qiyrq <= current date order by to_number(yinjbh),to_number(yinjbgh)', '接口用-获取印鉴信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AssLogSave', 'combinTrans', 1, 'AssBillLogSave,AssSealLogSave', '接口用，记录日志', 'AssBillLogSave,AssSealLogSave');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AssSealLogSave', 'simpleTrans', 1, 'INSERT INTO jk_yyrz (xitbs, jiedbs, zhangh, renwbs, renwlx, xitlx, yinjbh, yinjbgh, yinjzl, yanyms, yanyjg, hengxzb, shuxzb, yinjjd, chulrq, chulsj, chulgy, renwrq) values (:xitbs, :jiedbs, :zhangh, :renwbs, :renwlx, :xitlx, :yinjbh, :yinjbgh, :yinjzl, :yanyms, :yanyjg, :hengxzb, :shuxzb, :yinjjd, :chulrq, :chulsj, :chulgy, :renwrq)', '接口用：记录单张印鉴的验印结果日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AttributeToolGetshuxkzb', 'simpleQuery', 1, 'select * from shuxkzb', '属性扩展工具中获取属性扩展表中的所有工具', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AttributeToolGetshuxkzgxb', 'simpleQuery', 1, 'select * from shuxkzgxb', '属性扩展工具中获取属性扩展关系表中的所有数据', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AttributeToolGetshuxkzgxbWithKey', 'simpleQuery', 1, 'select * from shuxkzgxb where shuxm=:shuxm and gongnym=:gongnym', '属性扩展工具，根据属性名、功能页面获取属性扩展关系表数据，用于验证存在', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addCombineInfo', 'simpleTrans', 1, 'INSERT INTO     yinjzhb     (         zhangh,         jinexx,         jinesx,         xitlx,         zuhgz,         qiyrq,         zuhzt,         zuhshzt     )     VALUES     (         :zhangh,         :jinexx,         :jinesx,         :xitlx,         :zuhgz,         :qiyrq,         :zuhzt,         :zuhshzt     )', '新增加一个组合信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AddRenWXX', 'simpleTrans', 1, 'INSERT INTO ci_renwxx (xitbs, jiedbs, renwbs, xitlx, zhangh, pingzh, jine, chuprq, pingzbs, zhaozq, fazq, wenjm, tuxsy, xfenbl, yfenbl, yanyjb, chulzt, yanyms, yanyjg, weigyy, chulrq, faqsj, huizsj, chulgy, yewtz1, zhangh1, zhangh2, zhangh3, zhangh4, tonggzh, renwrq) values (:xitbs, :jiedbs, :renwbs, :xitlx, :zhangh, :pingzh, :jine, :chuprq, :pingzbs, :zhaozq, :fazq, :wenjm, :tuxsy, :xfenbl, :yfenbl, :yanyjb, :chulzt, :yanyms, :yanyjg, :weigyy, :chulrq, :faqsj, :huizsj, :chulgy, :yewtz1, :zhangh1, :zhangh2, :zhangh3, :zhangh4, :tonggzh, :renwrq)', '(接口用)新增任务信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addSeal', 'combinTrans', 1, 'addSealInfo,changeUserCheckState', '为当前用户新增(或更改)一个印鉴的组合实现过程', 'addSealInfo,changeUserCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AttributeToolInsertCombineData', 'combinTrans', 1, 'AttributeToolInsertshuxkzb,AttributeToolInsertshuxkzgxb', '属性扩展工具,新增属性项,组合交易', 'AttributeToolInsertshuxkzb,AttributeToolInsertshuxkzgxb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AttributeToolInsertshuxkzb', 'simpleTrans', 1, 'INSERT INTO shuxkzb (shuxm, shurkz, zuidcd, yanzzfc, shujy, tisxx) values (:shuxm, :shurkz, :zuidcd, :yanzzfc, :shujy, :tisxx)', '属性扩展工具,向属性扩展表中新增数据', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AttributeToolInsertshuxkzgxb', 'simpleTrans', 1, 'INSERT INTO shuxkzgxb(shuxm, gongnym, zhansm, shifzs, zhanssx, morz, shifzhxs, zhansfs, shurkz, zuidcd, yanzzfc, shujy, tisxx) values (:shuxm, :gongnym, :zhansm, :shifzs, :zhanssx, :morz, :shifzhxs, :zhansfs, :shurkz, :zuidcd, :yanzzfc, :shujy, :tisxx)', '属性扩展工具,向属性扩展关系表中新增数据', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('WriteYulyjyylogToDb', 'simpleTrans', 1, 'insert into sealchecklog (ip,account,checknum,sealinktype,sealinknum,checkdate,checktime,clerknum,clerkname,clerkorgcode,checkresult,checkmode,henxzb,shuxzb,yinzjd,yanyjb,qiyrq,pingzbsm) VALUES (:ip,:zhangh,:pingzh,:yinjzl,:yinjbh,:checkdate,:checktime,:guiyh,:guiym,:clerkorgcode,:yanyjg,:yanyfs,:henxzb,:shuxzb,:yinzjd,:yanyjb,:qiyrq,:pingzbsm)', '写预留印鉴日志到数据库(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAllQx', 'simpleQuery', 1, 'select case zignid when ''0'' then gongnid else gongnid||''|''||zignid end quanxid from chanpgncd ', '获取所有权限', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AttributeToolsGetshuxkzbWithKey', 'simpleQuery', 1, 'select * from shuxkzb where shuxm=:shuxm', '扩展工具使用，根据属性名，获取属性扩展表信息，用于进行存在判断', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.addBatch', 'simpleTrans', 1, 'INSERT INTO batchwork (id, name, type, time_type, time_value, parameter_type, parameter_value) values (:id, :name, :type, :time_type, :time_value, :parameter_type, :parameter_value)', '增加后台服务', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.addSQL', 'simpleTrans', 1, 'INSERT INTO batchwork_sql (id, sql_id,sql_value) values (:id, :sql_id, :sql_value)', '增加SQL', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.deleteBatch', 'simpleTrans', 1, 'delete batchwork where id =:id', '删除某一后台服务', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.deleteSQL', 'simpleTrans', 1, 'delete batchwork_sql where id =:id and sql_id =:sql_id', '删除某一SQL', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.findBatchList', 'simpleQuery', 1, 'select id, name, type, time_type, time_value, parameter_type, parameter_value from batchwork', '查询服务列表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.findSQLList', 'simpleQuery', 1, 'select id, sql_id,sql_value from batchwork_sql where id=:id', '查询某一服务的SQL列表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.getBatch', 'simpleQuery', 1, 'select id, name, type, time_type, time_value, parameter_type, parameter_value from batchwork where id=:id', '获取单一服务信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.getSQL', 'simpleQuery', 1, 'select id, sql_id,sql_value from batchwork_sql where id=:id and sql_id =:sql_id', '获取某一服务的SQL', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ceshi', 'simpleQuery', 1, 'select str1 from accountespecialexpand', 'ceshi', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('a11', 'complexTrans', 1, 'changeCombineCheckState,Report_DictionaryElementMgrAction.addDictionary', 'ceshi', 'changeCombineCheckState,Report_DictionaryElementMgrAction.addDictionary');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('combintrans-zuhe', 'combinTrans', 1, 'deletedata1,updatedata2,updatedata1,deletedata2', '组合测试交易', 'deletedata1,updatedata2,updatedata1,deletedata2');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('complextrans', 'complexTrans', 1, '士大夫', '负载交易', '士大夫');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('date8Test', 'simpleQuery', 1, 'select date8 from zhanghb', '测试date8', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('delAccountInfo', 'simpleTrans', 1, 'delete zhanghjbxx where zhangh = :zhangh', '根据帐号删除账户信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('delCombineAsState', 'simpleTrans', 1, 'update yinjzhb set zuhzt=''删除'',zuhshzt=''未审'',shancrq=:shancrq where zhangh=:zhangh and jinexx=:jinexx and jinesx=:jinesx and xitlx=:xitlx and zuhgz=:zuhgz and qiyrq=:qiyrq', '删除组合，（非滞后删除）只是更改状态', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ChangeAccountInfoSealState', 'simpleTrans', 1, 'update zhanghb set youwyj=:youwyj,yinjshzt=:yinjshzt where zhangh=:zhangh', '修改账户表下的youwyj属性', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('delCombinelag', 'simpleTrans', 1, 'update yinjzhb set zuhzt=''滞删'',zuhshzt=''未审'',shancrq=:shancrq where zhangh=:zhangh and jinexx=:jinexx and jinesx=:jinesx and xitlx=:xitlx and zuhgz=:zuhgz and qiyrq=:qiyrq', '滞后删除(修改为滞删未审，同时更新删除日期)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('insertKAGRW', 'simpleTrans', 1, 'insert into kagrw(RENWBS,ZHANGH,QIYRQ,JIGH,RENWLX,YEWLX,RENWZT,YINJKS,YINJKH,zhengmwjm) values(:RENWBS,:ZHANGH,:QIYRQ,:JIGH,:RENWLX,:YEWLX,:RENWZT,:YINJKS,:YINJKH,:zhengmwjm) ', '建库时插入卡柜任务表(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('insertYinjk', 'simpleTrans', 1, 'insert into yinjk (YINJKH, ZHANGH,JIGH,ZHENGMWJM,FANMWJM,QIYRQ,TINGYRQ,SHIFZK,YEWLX) values (:YINJKH,:ZHANGH,:JIGH,:ZHENGMWJM,:FANMWJM,:QIYRQ,:TINGYRQ,:SHIFZK,:YEWLX)', '建库yinjk表插入信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addAccountInfo', 'simpleTrans', 1, 'INSERT INTO     zhanghb     (         zhangh,         zhuzh ,         kehh,         hum,         jigh,         diz,         youzbm,         lianxr,         dianh,         kaihrq,         tongctd,         huobh,         yinjshzt,         zhanghshzt,         zuhshzt,         zhanghzt,         beiz,         zhanghxz,         yanyjb,         yanyjg,         fuyrq,         quxfyrq,         jiankbs,         tingyrq   ,guiyjgh  )     VALUES     (         :zhangh,         :zhuzh,         :kehh,         :hum,         :jigh,         :diz,         :youzbm,         :lianxr,         :dianh,         :kaihrq,         :tongctd,         :huobh,         :yinjshzt,         :zhanghshzt,         :zuhshzt,         :zhanghzt,         :beiz,         :zhanghxz,         :yanyjb,         :yanyjg,         :fuyrq,         :quxfyrq,         :jiankbs,         :tingyrq   ,:guiyjgh  )', '新建账户基本信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ChangeAccountInfoCombineState', 'simpleTrans', 1, 'update zhanghb set youwzh=:youwzh,zuhshzt=:zuhshzt,zhanghshzt=:zhanghshzt where zhangh=:zhangh', '修改账户表中的youwzh字段', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ChangeAccountStateForInfoCheck', 'simpleTrans', 1, 'update zhanghb set zhanghshzt=:zhanghshzt,zuhshzt=:zuhshzt,youwzh=:youwzh,yinjshzt=:yinjshzt,youwyj=:youwyj where zhangh=:zhangh', '账户审核时，至账户状态', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('changeCombineCheckState', 'simpleTrans', 1, 'update zhanghb set zuhshzt=:zuhshzt,youwzh=:youwzh where zhangh=:zhangh', '在为某用户新增或修改组合时进行账户组合审核状态的更改(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('changeUserCheckState', 'simpleTrans', 1, 'UPDATE     zhanghb SET     yinjshzt=:yinjshzt,     youwyj=:youwyj,     zhanghshzt=:zhanghshzt,     zuhshzt=:zuhshzt WHERE     zhangh=:zhangh', '在为某用户新增或更改某印鉴时(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('checkAccount', 'combinTrans', 1, 'checkGroups,checkSeals,checkAccountInfo', '将账户下所有的未审核信息通过审核', 'checkGroups,checkSeals,checkAccountInfo');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('checkAccountInfo', 'simpleTrans', 1, 'update zhanghb set yinjshzt=''已审'' ,zhanghshzt=''已审'',zuhshzt=''已审''  where zhangh = :zhangh', '将账户表的审核状态通过验证(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('checkAccountNumber', 'simpleQuery', 1, 'select * from zhanghb where zhangh=:zhangh', '判断开户的账号是否已经存在', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('checkGroups', 'simpleTrans', 1, 'update yinjzhb set zuhshzt = ''已审'' where zhangh = :zhangh and zuhshzt= ''未审''', '将某个账户下的所有未审核的组合通过审核(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('checkSeals', 'simpleTrans', 1, 'update yinjb set yinjshzt = ''已审'' where zhangh = :zhangh and yinjshzt= ''未审''', '将某个账户下的所有印鉴通过审核(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('checkuserlogin', 'simpleQuery', 1, 'select clerknum,n_organnum from clerktable where clerknum = :clerknum and clerkpwd = :clerkpwd ', '柜员双签时，查看是否双签登录成功，成功则返回帐号', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ci_get_node_params', 'simpleQuery', 1, 'select jiedbs,cansbs,cansz from ci_jiedcs where jiedbs=:jiedbs', '得到节点参数(自动控制-自动验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.updateBatch', 'simpleTrans', 1, 'update batchwork set name=:name ,type=:type ,time_type=:time_type ,time_value=:time_value , parameter_type=:parameter_type,parameter_value=:parameter_value where id=:id', '更新某一后台服务', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('BatchWorkMgrAction.updateSQL', 'simpleTrans', 1, 'update batchwork_sql set sql_value=:sql_value where id=:id and sql_id =:sql_id', '更新某一SQL', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ci_get_redo_task_list', 'simpleQuery', 1, 'select jiedbs,xitbs,renwbs from ci_renwxx where jiedbs=:jiedbs and chulzt=0', '根据节点获取自动控制任务列表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ci_get_vouch_params', 'simpleQuery', 1, 'select xitbs, pingzbs, pingzmc,zhaozq as yy_001,fazq as yy_002,yanyjb as yy_004,xfenbl as yy_008 from ci_pingzcs', '查询凭证参数信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.AddCombine', 'complexTrans', 1, 'addCombineInfo,changeCombineCheckState', '新增组合', 'addCombineInfo,changeCombineCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.AddSeal', 'complexTrans', 1, 'getMaxSealNumber,addSealInfo,changeUserCheckState', '新增印鉴', 'getMaxSealNumber,addSealInfo,changeUserCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.AssistantGetCheckInfo', 'complexQuery', 1, 'AssGetAccountInfo,AssGetSealsToCheck,AssGetGroupsToCheck,GetInterfaceConfig,GetBillConfig,GetRenwxx,GetYYRZ,GetSysConfigValue,GetSysConfig', '辅助验印接口用-获取验印信息', 'AssGetAccountInfo,AssGetSealsToCheck,AssGetGroupsToCheck,GetInterfaceConfig,GetBillConfig,GetRenwxx,GetYYRZ,GetSysConfigValue,GetSysConfig');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetQiyrqByZhanghAndCaozrq', 'simpleQuery', 1, 'select distinct qiyrq from yinjb where zhangh = :account and (:operatedate >= qiyrq and (:operatedate <  case when tingyrq='''' or tingyrq is null then ''2999-12-01'' else tingyrq end))', '根据账号和操作日期获取印鉴的启用日期(锦州验印查询类交易)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetYinjkh', 'simpleQuery', 1, 'select zhangh, yinjkbh,yinjshzt from yinjb where yinjkbh=:yinjkbh', '获取凭证与印鉴类型的关系配置', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_SUBMIT_YANYLOG_DANZ', 'simpleTrans', 1, 'INSERT INTO CI_YYRZ
  (XITBS,
   JIEDBS,
   RENWBS,
   RENWLX,
   XITLX,
   YINQBGH,
   YINJBZ,
   YANYMS,
   YANYJG,
   HENGXZB,
   SHUXZB,
   YINZJD,
   ZUOBJ,
   SHANGBJ,
   YOUBJ,
   XIABJ,
   CHULRQ,
   CHULSJ,
   CHULGY,
   ZHANGH,
   RENWRQ,
   YINJBH,
   HUM,
   JIGH,
   MONEY,
   PINGZLX,
   PINGZBS,
   GUIYXM,
   YINJLX,
   YANYD)
VALUES
  (:XITBS,
   :JIEDBS,
   :RENWBS,
   :RENWLX,
   :XITLX,
   :YINQBGH,
   :YINJBZ,
   :YANYMS,
   :YANYJG,
   :HENGXZB,
   :SHUXZB,
   :YINZJD,
   :ZUOBJ,
   :SHANGBJ,
   :YOUBJ,
   :XIABJ,
   :CHULRQ,
   :CHULSJ,
   :CHULGY,
   :ZHANGH,
   :RENWRQ,
   :YINJBH,
   :HUM,
   :JIGH,
   :MONEY,
   :PINGZLX,
   :PINGZBS,
   :GUIYXM,
   :YINJLX,
   :YANYD)', '提交验印日志-单章(后台验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IChangeAccountInfo', 'complexTrans', 1, 'getAccountInfo,iUpdateAccountInfo,WriteWorkLogToDb', '柜面发起账户信息修改---长沙', 'getAccountInfo,iUpdateAccountInfo,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IChangeAccountState', 'complexTrans', 1, 'getAccountInfo,updateAccountState,WriteWorkLogToDb', '更改账户状态-长沙', 'getAccountInfo,updateAccountState,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('deleteZhangkzb', 'simpleTrans', 1, 'delete ZHANGHKZB where ZHANGH=:zhangh', '删除-账户扩展表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('iUpdateAccountInfo', 'simpleTrans', 1, 'UPDATE     zhanghb SET     kehh = :kehh,   hum = :hum,  jigh = :jigh, beiz=:beiz, zhanghxz=:zhanghxz, tongctd=:tongctd WHERE     zhangh = :zhangh', '柜面发起账户信息修改(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('insertZhangkzb', 'simpleTrans', 1, 'insert into ZHANGHKZB (ZHANGH, TASKID, TYPE) values (:zhangh,:taskid,:type)', '插入-账户扩展表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('selectZhangkzb', 'simpleQuery', 1, 'select ZHANGH, TASKID, TYPE from ZHANGHKZB where ZHANGH=:zhangh', '查询-账户扩展表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('query-minus', 'simpleQuery', 1, 'select account from accountespecialexpand except select account from b2admin.daccountinfo', '查询两个表差集', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSeals', 'simpleQuery', 1, 'select * from yinjb where zhangh=(select CASE WHEN (zhuzh is null )or(zhuzh = '''' ) THEN zhangh ELSE zhuzh END from zhanghb where zhangh=:zhangh) and yinjzt||yinjshzt!=''删除已审'' order by to_number(yinjbh),to_number(yinjbgh)', '根据帐号获取账户下所有可用的预留印鉴', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JGetSealCheckInfo', 'complexQuery', 1, 'getAccountInfo,getSatisfySealToCheck,getSatisfyZuheToCheck', '获取满足条件的印鉴(V3.0-引擎)', 'getAccountInfo,getSatisfySealToCheck,getSatisfyZuheToCheck');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSatisfySealToCheck', 'simpleQuery', 1, 'select * from yinjb where zhangh = :zhangh and qiyrq<=to_char(sysdate, ''YYYY-MM-DD'') and yinjshzt=''已审'' and (:chuprq  >= qiyrq and  (:chuprq <  case when tingyrq='''' or tingyrq is null then ''2999-12-01'' else tingyrq end))  order by to_number(yinjbh)', '获取满足出票日期的印鉴(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSatisfyZuheToCheck', 'simpleQuery', 1, 'select * from yinjzhb where zhangh = :zhangh  and qiyrq<=to_char(sysdate, ''YYYY-MM-DD'') and zuhshzt =''已审'' and xitlx=:xitlx and :jine > jinexx and :jine <= jinesx and (:chuprq >= qiyrq and (:chuprq <  case when tingyrq='''' or tingyrq is null then ''2999-12-01'' else tingyrq end))  union all select * from yinjzhb where zhangh = :zhangh  and qiyrq<=to_char(sysdate, ''YYYY-MM-DD'') and zuhshzt =''已审'' and xitlx=:xitlx  and (:chuprq >= qiyrq and (:chuprq <  case when tingyrq='''' or tingyrq is null then ''2999-12-01'' else tingyrq end)) and :jine=jinexx and jinexx = jinesx', '获取满足条件的组合(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JSaveSealCheckLog', 'complexTrans', 1, 'WriteZhengpyylogToDb,WriteYulyjyylogToDb,WriteWorkLogToDb', '提交验印日志(V3.0-引擎)', 'WriteZhengpyylogToDb,WriteYulyjyylogToDb,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('setSealTingyrq', 'simpleTrans', 1, 'update yinjb set tingyrq=:tingyrq where zhangh=:zhangh and qiyrq=:qiyrq and :tingyrq != :qiyrq', '设置印鉴停用日期(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('setCombinaTingyrq', 'simpleTrans', 1, 'update yinjzhb set tingyrq=:tingyrq where zhangh=:zhangh and qiyrq=:qiyrq and :tingyrq != :qiyrq', '设置组合停用日期(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ResultMgrAction.addResultElement', 'simpleTrans', 1, 'INSERT INTO r_jiegyspz(baobbs,yaosbs, yaosmc,yaosbt,yaoscd,xianslx,shifxs,xianssx,zhidbs) values(:baobbs,:yaosbs,:yaosmc,:yaosbt,:yaoscd,:xianslx,:shifxs,:xianssx,:zhidbs)', '新增结果要素信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ResultMgrAction.delResultElement', 'simpleTrans', 1, 'delete from r_jiegyspz where baobbs = :baobbs and yaosbs=:yaosbs', '删除指定的结果要素信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ResultMgrAction.getResultElement', 'simpleQuery', 1, 'select baobbs,yaosbs,yaosmc,yaosbt,yaoscd,xianslx,shifxs,xianssx,zhidbs from r_jiegyspz where baobbs=:baobbs and yaosbs = :yaosbs', '获取指定报表的结果要素信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ResultMgrAction.getResultElementList', 'simpleQuery', 1, 'select baobbs,yaosbs,yaosmc,yaosbt,yaoscd,xianslx,shifxs,xianssx,zhidbs from r_jiegyspz where baobbs=:baobbs order by xianssx', '获取指定报表的结果要素信息列表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ResultMgrAction.updResultElement', 'simpleTrans', 1, 'update r_jiegyspz set yaosmc=:yaosmc,yaosbt=:yaosbt,yaoscd=:yaoscd,xianslx=:xianslx,shifxs=:shifxs,xianssx=:xianssx,zhidbs=:zhidbs where baobbs=:baobbs and yaosbs=:yaosbs', '更新指定的结果要素信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('saveRoleByClerk', 'simpleTrans', 1, 'INSERT INTO guiyjsgxb (GUIYID, JUESID, BEIZ) values (:guiyid,:juesid,:beiz)', '保存柜员角色关系', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SelectImageInfoFromDB', 'simpleQuery', 1, 'select * from zhanghyxxxb where zhangh=:zhangh and yxlx=:yxlx and wenjbh=:wenjbh', '从账户影像信息表中获取数据', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('shiwutest', 'combinTrans', 1, 'deletedata1,delete not', '事物测试', 'deletedata1,delete not');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('simplequery-tables', 'simpleQuery', 1, 'select', '多表间进行查询', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JChangeSealAndCombinaInfo', 'complexTrans', 1, 'clearSealInfo,clearCombinaInfo,setSealTingyrq,setCombinaTingyrq,addSealInfo,addCombineInfo,changeUserCheckState,WriteWorkLogToDb', '变更\重建印鉴和组合(V3.0-引擎)', 'clearSealInfo,clearCombinaInfo,setSealTingyrq,setCombinaTingyrq,addSealInfo,addCombineInfo,changeUserCheckState,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('sys_transload', 'systemconfig', 1, 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg', '通知引擎获取更新配置-不可删除', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetPingzYinjlxGX', 'simpleQuery', 1, 'select pingzbs,yinjlx from PINGZYJLXGXB', '获取凭证与印鉴组合的系统类型间的关系配置', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetPingzXitlxGX', 'simpleQuery', 1, 'select pingzbs,xitlx from PINGZXTLXGXB', '获取凭证与印鉴类型的关系配置', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('Test', 'simpleTrans', 1, 'INSERT INTO tiemtesttable(dat8,dat10,yyy) values(char(sysdate,''yyyymmdd''),char(sysdate,''hh24miss''),:yyy)', '时间测试', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('testComplex', 'complexQuery', 1, 'GetCheckSeals_ComplexTest,a11', null, 'GetCheckSeals_ComplexTest,a11');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('updateAccountInfo', 'simpleTrans', 1, 'UPDATE     zhanghb SET     kehh = :kehh,     hum = :hum,     jigh = :jigh,     diz = :diz,     youzbm = :youzbm,     lianxr = :lianxr,     dianh = :dianh,     tongctd = :tongctd,     huobh = :huobh ,     zhanghshzt =:zhanghshzt,     beiz = :beiz,     zhanghxz =:zhanghxz WHERE     zhangh = :zhangh', '更新账户基本信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('updateAccountState', 'simpleTrans', 1, 'update zhanghb set zhanghzt=:zhanghzt where zhangh=:zhangh', '修改用户状态（销户，冻结，解冻，挂失等等等等）', null);



insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_REQUEST_TASKINFO', 'complexQuery', 1, 'SINO_REQUEST_TASKINFO_INFO,SINO_REQUEST_TASKINFO_SEAL,SINO_REQUEST_TASKINFO_COMBINE,getXityygz,SINO_REQUEST_ASSIST_TASKINFO_ACCOUNT,getAccountInfo,getScOrg,getShangJjgh', '获取任务信息(后台验印)', 'SINO_REQUEST_TASKINFO_INFO,SINO_REQUEST_TASKINFO_SEAL,SINO_REQUEST_TASKINFO_COMBINE,getXityygz,SINO_REQUEST_ASSIST_TASKINFO_ACCOUNT,getAccountInfo,getScOrg,getShangJjgh');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_REQUEST_TASKINFO_INFO', 'simpleQuery', 1, 'SELECT JIEDBS AS NODEID,XITBS AS SYSTEMID,XITLX AS SYSTEMTYPE,RENWBS AS TASKID,XFENBL AS PICDPI,TUXSY AS PICADDR,HUOQYXFS AS PICTYPE,CHUPRQ,JINE,PINGZH,PINGZBS AS PINGZLX,YANYJB,ZHANGH,ZHANGH1,ZHANGH2,ZHANGH3FROM CI_RENWXX WHERE RENWBS = :RENWBS', '获取任务信息-任务详情(后台验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_REQUEST_TASKINFO_SEAL', 'simpleQuery', 1, 'SELECT QIYRQ as STARTDATE,YINJBH, YINJLX, YINJTP,YINJZL FROM YINJB WHERE ZHANGH = (SELECT CASE WHEN (ZHUZH IS NULL) OR (ZHUZH = '''') THEN ZHANGH ELSE ZHUZH END FROM ZHANGHB WHERE ZHANGH=:ZHANGH) AND YINJSHZT =''已审'' AND :CHUPRQ >=replace(QIYRQ,''-'','''') and(:CHUPRQ <replace(TINGYRQ,''-'','''') or TINGYRQ='''' or TINGYRQ is null or TINGYRQ ='' '')  ORDER BY to_number(YINJBH)', '获取任务信息-印鉴信息(后台验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_REQUEST_TASKINFO_COMBINE', 'simpleQuery', 1, 'SELECT ZUHGZ as EXPRESSION FROM YINJZHB WHERE ZHANGH =(SELECT CASE WHEN (ZHUZH IS NULL )OR(ZHUZH = '''' ) THEN ZHANGH ELSE ZHUZH END FROM ZHANGHB WHERE ZHANGH=:ZHANGH) AND ZUHSHZT =''已审'' AND :CHUPRQ>=QIYRQ and XITLX=:xitlx and ((:jine > jinexx and :jine <= jinesx) or (jinexx = ''0'' and jinesx=''0'' and :jine=''0'')) and (:CHUPRQ <TINGYRQ or TINGYRQ='''' or TINGYRQ is null or TINGYRQ='' '')', '获取任务信息-组合规则(后台验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getXityygz', 'simpleQuery', 1, 'select xitmc,yanygz,beiz from xityygzb where xitmc=:xitlx', '获取系统类型对应的验印规则(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_REQUEST_ASSIST_TASKINFO_ACCOUNT', 'simpleQuery', 1, 'select * from zhanghb where zhangh =  (SELECT CASE WHEN (ZHUZH IS NULL) OR (ZHUZH = '''') THEN ZHANGH ELSE ZHUZH END FROM ZHANGHB WHERE ZHANGH=:ZHANGH)', '获取账户信息(辅助验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAccountInfo', 'simpleQuery', 1, 'select g.shenghjgh,z.* from zhanghb z left join organarchives g on z.jigh = g.organnum where zhangh=:zhangh', '获取账户基本信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getScOrg', 'simpleQuery', 1, 'select organnum from org_ctrl', '获取需要验印小码的机构列表（引擎－江苏银行）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getShangJjgh', 'simpleQuery', 1, 'select n_parentnum from organarchives where organnum=:jigh', '获取上级机构号（引擎－江苏银行）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addSealInfo', 'simpleTrans', 1, 'INSERT INTO     yinjb     (         zhangh,         yinjbh,         qiyrq,         yinjlx,         yinjzl,         yinjys,         yinjtp,         yinjzt,         yinjshzt,         yinjkbh,         yanyjg,         yanyjb     ,kaihy ,  kaihynum)     VALUES     (         :zhangh,         :yinjbh,         :qiyrq,         :yinjlx,         :yinjzl,         :yinjys,         :yinjtp,         :yinjzt,         :yinjshzt,         :yinjkbh,         :yanyjg,         :yanyjb    ,:kaihy ,  :kaihynum )', '添加一个印鉴信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addSettingInfo', 'simpleTrans', 1, 'INSERT INTO xinzxxxlb (shuxm, gongnym, zhansm, shifzs, zhanssx, morz, shifzhxs, zhansfs,shurkz,zuidcd, yanzzfc,shujy) values (:shuxm, :gongnym, :zhansm, :shifzs, :zhanssx, :morz, :shifzhxs, :zhansfs, :shurkz,:zuidcd, :yanzzfc,:shujy)', '增加校验配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('changesealdelete', 'simpleTrans', 1, 'update yinjb set yinjzt =''更删'',yinjshzt=''未审'',shancrq =:shancrq where zhangh =:zhangh and yinjbh =:yinjbh and yinjbgh = :yinjbgh', '变更删除子交易', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AddYYRZ', 'simpleTrans', 1, 'INSERT INTO ci_yyrz (xitbs, jiedbs, renwbs, renwlx, xitlx, yinjbh, yinqbgh, yinjbz, yanyms, yanyjg, hengxzb, shuxzb, yinzjd, zuobj, shangbj, youbj, xiabj, chulrq, chulsj, chulgy, zhangh, renwrq) values (:xitbs, :jiedbs, :renwbs, :renwlx, :xitlx, :yinjbh, :yinqbgh, :yinjbz, :yanyms, :yanyjg, :hengxzb, :shuxzb, :yinzjd, :zuobj, :shangbj, :youbj, :xiabj, :chulrq, :chulsj, :chulgy, :zhangh, :renwrq)', '（接口用）记录印鉴验印日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetPingzys', 'simpleQuery', 1, 'select yaosbs,yaosqy from pingzysb where pingzbs=:pingzbs', '获取凭证要素配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getExaminedSeal', 'simpleQuery', 1, 'select * from yinjb where qiyrq = (select max(qiyrq) from yinjb where zhangh =:zhangh and yinjshzt =''已审'') and zhangh=:zhangh order by to_number(yinjbh)', '获取账户下最新批次的已审印鉴（接口用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getExaminedGroup', 'simpleQuery', 1, 'select * from yinjzhb where qiyrq = (select max(qiyrq) from yinjzhb where zhangh =:zhangh) and zhangh=:zhangh', '获取账户下最新批次的已审印鉴组合（接口用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JSaveInfoCheckInfo', 'complexTrans', 1, 'GetWSqyrq,getAccountInfo,NcheckAccountInfo,NcheckSeals,NcheckGroups,WriteWorkLogToDb', '保存账户审核信息（江西）', 'GetWSqyrq,getAccountInfo,NcheckAccountInfo,NcheckSeals,NcheckGroups,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('updateYinjkbh', 'simpleTrans', 1, 'update yinjb set yinjkbh=:yinjkbh where zhangh=:zhangh', '更新印鉴卡编号（江西审核）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('confirmDHyinj', 'simpleTrans', 1, 'update yinjb set yinjshzt=:shzt where zhangh=:zhangh and yinjshzt=''待核''', '更改账户所有“待核”印鉴状态为“已审”', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('confirmDHzh', 'simpleTrans', 1, 'update yinjzhb set zuhshzt=:shzt where zhangh=:zhangh and zuhshzt=''待核''', '更改账户所有“待核”组合状态为“已审”', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JUppdateInfoCheckAbled', 'complexTrans', 1, 'getAccountInfo,NcheckAccountInfo,confirmDHyinj,confirmDHzh,updateYinjkbh', '账户审核信息确认（江西审核）', 'getAccountInfo,NcheckAccountInfo,confirmDHyinj,confirmDHzh,updateYinjkbh');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IGetAccountInfoWhole', 'complexQuery', 1, 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg,getAllSeals,getAllGroups', '获取账户全部信息(V3.0-引擎)', 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg,getAllSeals,getAllGroups');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getBakYinj', 'simpleQuery', 1, 'select * from  bak_yinjb  where zhangh=:zhangh', '获得印鉴备份表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AddzhanghbForAlter', 'simpleTrans', 1, 'insert into zhanghb( ZHANGH, KEHH, HUM,JIGH,DIZ, YOUZBM, LIANXR, DIANH, KAIHRQ, TONGCTD, HUOBH, YOUWYJ, YOUWZH, YINJSHZT, ZHANGHSHZT, ZUHSHZT, ZHANGHZT, ZHANGHXZ,YANYJB,
YANYJG,BEIZ,ZHUZH,FUYRQ,QUXFYRQ,JIANKBS,TINGYRQ) (select  ZHANGH, KEHH, HUM,JIGH,DIZ, YOUZBM, LIANXR, DIANH, KAIHRQ, TONGCTD, HUOBH, YOUWYJ, YOUWZH, YINJSHZT, ZHANGHSHZT, ZUHSHZT, ZHANGHZT, ZHANGHXZ,YANYJB,
YANYJG,BEIZ,ZHUZH, FUYRQ,QUXFYRQ,JIANKBS,TINGYRQ from bak_zhanghb where zhangh=:zhangh)', '回退账户表信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AddyinjbForAlter', 'simpleTrans', 1, 'insert into yinjb( ZHANGH, YINJBH, QIYRQ, SHANCRQ, YINJLX, YINJZL, YINJYS, YINJTP, YINJZT, YINJSHZT, YINJKBH, YANYJB, YANYJG, TINGYRQ)
(select  ZHANGH, YINJBH, QIYRQ, SHANCRQ, YINJLX, YINJZL, YINJYS, YINJTP, YINJZT, YINJSHZT, YINJKBH, YANYJB, YANYJG, TINGYRQ from bak_yinjb where zhangh=:zhangh)', '回退印鉴表信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AddyinjzhbForAlter', 'simpleTrans', 1, 'insert into yinjzhb(ZHANGH, JINEXX, JINESX, XITLX, ZUHGZ, QIYRQ, SHANCRQ, ZUHZT, ZUHSHZT, TINGYRQ)
(select ZHANGH, JINEXX, JINESX, XITLX, ZUHGZ, QIYRQ, SHANCRQ, ZUHZT, ZUHSHZT, TINGYRQ from bak_yinjzhb where zhangh=:zhangh)', '回退组合表信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('RollbackSealChanges', 'complexTrans', 1, 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg,getBakYinj,DelAccount,DelAllYinj,DelAllZh,AddzhanghbForAlter,AddyinjbForAlter,AddyinjzhbForAlter,WriteWorkLogToDb', '回退账户信息（江西）', 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg,getBakYinj,DelAccount,DelAllYinj,DelAllZh,AddzhanghbForAlter,AddyinjbForAlter,AddyinjzhbForAlter,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ChangeZhanghDate', 'simpleTrans', 1, 'update bak_zhanghb set changedate=:changedate where zhangh=:zhangh', '更新备份账户表时间为备份时间（江西）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IGetCheckInfo', 'complexQuery', 1, 'getIAccountInfo,getVersionInfo,getISatisfySealToCheck,getISatisfyZuheToCheck', '获取满足条件的印鉴、组合信息以及ocx版本信息(V3.0-引擎-WP)', 'getIAccountInfo,getVersionInfo,getISatisfySealToCheck,getISatisfyZuheToCheck');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getIAccountInfo', 'simpleQuery', 1, 'select g.shenghjgh,z.* from zhanghb z left join organarchives g on z.jigh = g.organnum where zhangh=:accno', '获取账户基本信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getISatisfySealToCheck', 'simpleQuery', 1, 'select * from yinjb where zhangh = :accno and qiyrq<=to_char(sysdate, ''YYYY-MM-DD'') and yinjshzt=''已审'' and (:chuprq  >= qiyrq and  (:chuprq <  case when tingyrq='''' or tingyrq is null then ''2999-12-01'' else tingyrq end))  order by to_number(yinjbh)', '获取满足出票日期的印鉴(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getISatisfyZuheToCheck', 'simpleQuery', 1, 'select * from yinjzhb where zhangh = :accno  and qiyrq<=to_char(sysdate, ''YYYY-MM-DD'') and zuhshzt =''已审'' and :jine > jinexx and :jine <= jinesx and (:chuprq >= qiyrq and (:chuprq <  case when tingyrq='''' or tingyrq is null then ''2999-12-01'' else tingyrq end))', '获取满足条件的组合(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getVersionInfo', 'simpleQuery', 1, 'SELECT cansid, parametervalue FROM BSKONGZCS WHERE cansid=''icheck_version''', '获取数据库OCX版本号(V3.0-引擎-WP)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('WriteDanzlogToDb', 'simpleTrans', 1, 'insert into CI_YYRZ(XITBS,JIEDBS,RENWBS,RENWLX,XITLX,YINJBH,YINQBGH,YINJBZ,YANYMS,YANYJG,HENGXZB,SHUXZB,YINZJD,ZUOBJ,SHANGBJ,YOUBJ,XIABJ,CHULRQ,CHULSJ,CHULGY,ZHANGH,RENWRQ,ZHUZH) VALUES (:XITBS,:JIEDBS,:RENWBS,:RENWLX,:XITLX,:YINJBH,:YINQBGH,:YINJBZ,:YANYMS,:YANYJG,:HENGXZB,:SHUXZB,:YINZJD,:ZUOBJ,:SHANGBJ,:YOUBJ,:XIABJ,:CHULRQ,:CHULSJ,:CHULGY,:ZHANGH,:RENWRQ,:ZHUZH) ', '写整票验印日志到数据库(V3.0-引擎-WP)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('WriteZhengplogToDb', 'simpleTrans', 1, 'insert into CI_RENWXX(XITBS,JIEDBS,RENWBS,XITLX,ZHANGH,PINGZH,JINE,CHUPRQ,PINGZBS,ZHAOZQ,FAZQ,WENJM,TUXSY,XFENBLYFENBL,YANYJB,CHULZT,YANYMS,YANYJG,WEIGYY,CHULRQ,FAQSJ,HUIZSJ,CHULGY,YEWTZ1,ZHANGH1,ZHANGH2,ZHANGH3,ZHANGH4,TONGGZH,RENWRQ,TASKTYPE,PICTYPE) VALUES (:XITBS,:JIEDBS,:RENWBS,:XITLX,:ZHANGH,:PINGZH,:JINE,:CHUPRQ,:PINGZBS,:ZHAOZQ,:FAZQ,:WENJM,:TUXSY,:XFENBL,:YFENBL,:YANYJB,:CHULZT,:YANYMS,:YANYJG,:WEIGYY,:CHULRQ,:FAQSJ,:HUIZSJ,:CHULGY,:YEWTZ1,:ZHANGH1,:ZHANGH2,:ZHANGH3,:ZHANGH4,:TONGGZH,:RENWRQ,:TASKTYPE,:PICTYPE) ', '写整票验印日志到数据库(V3.0-引擎-WP)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IGetAccountInfo', 'complexQuery', 1, 'getAccountInfo,getAllSeals,getAllGroups', '获取账户全部信息（账户信息、印鉴信息、组合信息）(V3.0-引擎-WP)', 'getAccountInfo,getAllSeals,getAllGroups');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('ISaveCheckLog', 'complexTrans', 1, ' WriteZhengpyylogToDb,WriteYulyjyylogToDb,WriteWorkLogToDb', '提交验印日志(V3.0-引擎-WP)', 'WriteZhengpyylogToDb,WriteYulyjyylogToDb,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getYYgz', 'simpleQuery', 1, 'select guizmc,yanygz,beiz from yanygzb where guizbh=:guizbh', '获得验印规则表规则', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getDanzrzBySequen', 'simpleQuery', 1, 'select * from SEALCHECKLOG where pingzbsm=:pingzbsm', '根据流水号获得单章验印日志信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getZhprzBySequen', 'simpleQuery', 1, 'select * from CREDENCECHECKLOG where pingzbsm=:pingzbsm', '根据流水号获得整票验印日志信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JGetInfoCheckInfo', 'complexQuery', 1, 'getAccountInfo,getExaminedSeal,getSatisfySealToVerify,getSatisfyZuheToVerify', '账户审核交易(接口用)', 'getAccountInfo,getExaminedSeal,getSatisfySealToVerify,getSatisfyZuheToVerify');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('WriteZhengpyylogToDb', 'simpleTrans', 1, 'insert into credencechecklog(ip,account,checknum,MONEY,checkdate,checktime,clerknum,clerkname,clerkorgcode,doublesignatureclerknum,doublesignatureclerkname,checkresult,checkmode,yanybs,remark,zuhgz,xitlx,checktype,chuprq,pingzbsm,credencetype,IMAGENAME,accorgno) VALUES (:ip,:zhangh,:pingzh,:jine,:checkdate,:checktime,:guiyh,:guiym,:clerkorgcode,:shuangqgyh,:shuangqgymc,:yanyjg,:yanyfs,:yanybs,:remark,:zuhgz,:xitlx,:checktype,:chuprq,:pingzbsm,:credencetype,:tuxmc,:accorgno) ', '写整票验印日志到数据库(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getMaxtimeYinjbkh', 'simpleQuery', 1, 'select distinct(yinjkbh) from yinjb where zhangh=:zhangh and qiyrq=:qiyrq', '查询最大日期已审印鉴的印鉴表中的印鉴卡号', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addYinjkxx', 'simpleTrans', 1, 'INSERT INTO YINJK (YINJKH, ZHANGH, JIGH, ZHENGMWJM, FANMWJM, QIYRQ, TINGYRQ, SHIFZK, YEWLX) VALUES (:YINJKH, :ZHANGH, :JIGH, :ZHENGMWJM, :FANMWJM, :QIYRQ, :TINGYRQ, :SHIFZK, :YEWLX)', '添加印鉴卡信息（锦州银行:印鉴查阅添加影像）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAccountList', 'simpleQuery', 1, 'select zhangh from (select distinct(zhangh) from yinjb where zhangh in(select zhangh from zhanghb where jigh=:jigh)) where zhangh not in (select distinct(zhangh) from yinjk where jigh=:jigh)', '查看该机构号所有的没有影像的帐号', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IGetAccountListInfo', 'complexQuery', 1, 'getAccountList', '查看该机构号所有的没有影像的帐号/添加影像路径（锦州银行：补影像）', 'getAccountList');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('AddYinjkInfo', 'complexTrans', 1, 'addYinjkxx', '添加印鉴卡信息（锦州银行:印鉴查阅添加影像）', 'addYinjkxx');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JGetAcCheckInfo', 'complexQuery', 1, 'getAccountInfo,getYSqyrq,getMaxtimeYinjkhxx,getExaminedSeal,getExaminedGroup,getMaxtimeYinjbkh', '获取帐号印鉴信息用来审核,添加相应的影像（锦州银行：补影像前验印）', 'getAccountInfo,getYSqyrq,getMaxtimeYinjkhxx,getExaminedSeal,getExaminedGroup,getMaxtimeYinjbkh');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getMaxtimeYinjkhxx', 'simpleQuery', 1, 'select * from yinjk where zhangh=:zhangh and qiyrq=:qiyrq', '查询最大日期已审印鉴的印鉴卡信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JudgeAccountOrgBelongToGuiyOrg', 'simpleQuery', 1, 'select * from (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:guiyjgh) where ORGANNUM = :jigh', '判账户机构是否为柜员下属机构(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IsSubsidiaries', 'simpleQuery', 1, 'select * from (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:organnum) where organnum=:organnum_', '判断organnum_是否是organnum的下属机构', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IsSubdivision', 'simpleQuery', 1, 'select * from (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:clerk_organnum) whereorgannum=:zhangh_organnum', '查看zhangh_organnum
是否是clerk_organnum的下属机构（包括自己）;用于判断账户的机构号是否是柜员的下属机构号', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('QueryService.validateOrg', 'simpleQuery', 1, 'select * from (select organnum from organarchives connect by prior organnum=n_parentnum start with organnum=:organnum) where organnum=:organnum_', '
判断查询账号数量权限', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.ChangeSeal', 'complexTrans', 1, 'getMaxChangeNumber,addSealInfo,updateSealDelDate,changeUserCheckState', '印鉴变更', 'getMaxChangeNumber,addSealInfo,updateSealDelDate,changeUserCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.DeleteCombine', 'complexTrans', 1, 'delCombineAsState,changeCombineCheckState', '删除组合（假删除，但非滞后删除）', 'delCombineAsState,changeCombineCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.DeleteCombineLag', 'complexTrans', 1, 'delCombinelag,changeCombineCheckState', '删除组合（滞后删除，假删除）', 'delCombinelag,changeCombineCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.DeleteCombineReal', 'complexTrans', 1, 'delCombineReal,GetUsableCombines,GetVerifyCombines,changeCombineCheckState', '删除组合(真删除)', 'delCombineReal,GetUsableCombines,GetVerifyCombines,changeCombineCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.DeleteSeal', 'complexTrans', 1, 'delSealAsState,changeUserCheckState', '删除印鉴（假删除，但非滞后删除）', 'delSealAsState,changeUserCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.DeleteSealLag', 'complexTrans', 1, 'delSealag,changeUserCheckState', '删除印鉴（滞后删除，假删除）', 'delSealag,changeUserCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.DeleteSealReal', 'complexTrans', 1, 'delSeal,GetUsableSeals,GetVerifySeals,changeUserCheckState', '删除印鉴（真删除）', 'delSeal,GetUsableSeals,GetVerifySeals,changeUserCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JDoublecheck', 'complexQuery', 1, 'GetClerk,GetClerkQXExist', '用于双签的用户和权限验证', 'GetClerk,GetClerkQXExist');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.GetAccountInfo', 'complexQuery', 1, 'getAccountInfo,getSeals,getGroups,GetClerk', '获取账户所有信息（包括预留印鉴，组合）', 'getAccountInfo,getSeals,getGroups,GetClerk');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.GetInfoForInfoCheck', 'complexQuery', 1, 'getAccountInfo,getSeals,getGroups,GetClerk', '获取账户信息(For账户审核)', 'getAccountInfo,getSeals,getGroups,GetClerk');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.GetInfoForSealCheck', 'complexQuery', 1, 'getAccountInfo,GetSealsToCheck,getGroupsToCheck,GetClerk', '获取账户信息进行验印', 'getAccountInfo,GetSealsToCheck,getGroupsToCheck,GetClerk');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.SaveICheckLog', 'complexTrans', 1, 'DeleteRenWXX,AddRenWXX,DeleteYYRZ,AddYYRZ', '保存验印日志', 'DeleteRenWXX,AddRenWXX,DeleteYYRZ,AddYYRZ');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('com.unitop.bank.complextrans.impl.SetAccountCheckState', 'complexTrans', 1, 'checkSeals,checkGroups,GetUsableSeals,GetUsableCombines,ChangeAccountStateForInfoCheck', '账户审核通过', 'checkSeals,checkGroups,GetUsableSeals,GetUsableCombines,ChangeAccountStateForInfoCheck');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('combin-delete', 'combinTrans', 1, 'deletedata1,deletedata2', '组合删除', 'deletedata1,deletedata2');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('combinQuery', 'combinQuery', 1, 'querydata-all,Querydata,querylinenumber', '组合查询', 'querydata-all,Querydata,querylinenumber');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('combinTrans', 'combinTrans', 1, 'deletedata1,updatedata2,insertdata-str1-str2,insertdata-str1-7', '组合交易', 'deletedata1,updatedata2,insertdata-str1-str2,insertdata-str1-7');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('changesealdeleteCombTran', 'combinTrans', 1, 'changesealdelete,changeUserCheckState', '变更删除组合交易', 'changesealdelete,changeUserCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('changecombinedelete', 'simpleTrans', 1, 'update yinjzhb set zuhzt =''更删'',zuhshzt=''未审'',shancrq =:shancrq where zhangh=:zhangh and jinexx=:jinexx and jinesx=:jinesx and xitlx=:xitlx and zuhgz=:zuhgz and qiyrq=:qiyrq', '变更删除组合的子交易', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('changecombinedeleteCombTran', 'combinTrans', 1, 'changecombinedelete,changeCombineCheckState', '组合变更删除的组合交易', 'changecombinedelete,changeCombineCheckState');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_REQUEST_TASKLIST', 'complexQuery', 1, 'SELECT RENWBS, YOUXJ FROM CI_RENWXX WHERE JIEDBS = :JIEDBS AND CHULZT = ''0''', '获取任务列表(后台验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_SUBMIT_STATUS', 'complexTrans', 1, 'SINO_SUBMIT_STATUS_DELETE,SINO_SUBMIT_STATUS_INSERT', '提交当前借点状态信息(后台验印)', 'SINO_SUBMIT_STATUS_DELETE,SINO_SUBMIT_STATUS_INSERT');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_SUBMIT_STATUS_DELETE', 'simpleTrans', 1, 'DELETE FROM HOUTSBZT WHERE JIEDBS = :JIEDBS', '提交当前借点状态信息-删除(后台验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_SUBMIT_STATUS_INSERT', 'simpleTrans', 1, 'INSERT INTO HOUTSBZT(JIEDBS, SHEBLX, IPDIZ, DUANK, ZHUANGT, RENWZS, RENWYE, CHULZS) VALUES (:JIEDBS, :SHEBLX, :IPDIZ, :DUANK, :ZHUANGT, :RENWZS, :RENWYE, :CHULZS)', '提交当前借点状态信息-插入(后台验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_SUBMIT_YANYLOG', 'complexTrans', 1, 'SINO_SUBMIT_YANYLOG_ZHENGP,SINO_SUBMIT_YANYLOG_DANZ,SINO_REQUEST_TASKINFO_INFO', '提交验印日志(后台验印)', 'SINO_SUBMIT_YANYLOG_ZHENGP,SINO_SUBMIT_YANYLOG_DANZ,SINO_REQUEST_TASKINFO_INFO');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SINO_SUBMIT_YANYLOG_ZHENGP', 'simpleTrans', 1, 'UPDATE CI_RENWXX
   SET YANYJG = :YANYJG, YANYMS = :YANYMS, WEIGYY = :WEIGYY, ZIDKZIP=:ZIDKZIP, ZIDKZDK=:ZIDKZDK, CHULRQ=:CHULRQ, CHULGY=:CHULGY, CHULZT=''1''
 WHERE RENWBS = :RENWBS', '提交验印日志-整票(后台验印)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JGetAccountInfoBase', 'complexQuery', 1, 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg', '获取账户基本信息(V3.0-引擎)', 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JSubmitAccountInfo', 'complexTrans', 1, 'addAccountInfo,UpdateAccountInfo,WriteWorkLogToDb', '提交\修改账户信息(V3.0-引擎)', 'addAccountInfo,UpdateAccountInfo,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAllSeals', 'simpleQuery', 1, 'select * from
(
  select ZHANGH, YINJBH, QIYRQ, YINJLX, YINJZL, YINJYS, YINJTP,YINJZT, YINJSHZT,YINJKBH,YANYJG, TINGYRQ from yinjb where zhangh=:zhangh
  union all
  select ZHANGH,YINJBH,case when QIYRQ<(select FUYRQ from zhanghb where zhangh=:zhangh) then (select FUYRQ from zhanghb where zhangh=:zhangh )else  QIYRQ  END QIYRQ,  YINJLX, YINJZL, YINJYS, YINJTP, ''复用'' YINJZT,YINJSHZT,YINJKBH, YANYJG,TINGYRQ  from yinjb where zhangh = (select zhuzh from zhanghb where zhangh=:zhangh) and (tingyrq > (select FUYRQ from zhanghb where zhangh=:zhangh) or tingyrq='''' OR TINGYRQ IS NULL)
)
order by QIYRQ,to_number(yinjbh)
', '浙商_根据账号获取全部印鉴(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAllGroups', 'simpleQuery', 1, 'select ZHANGH,JINEXX,JINESX,XITLX,ZUHGZ,ZUHZT,ZUHSHZT,TINGYRQ,QIYRQ from yinjzhb where zhangh=:zhangh
union all (
select ZHANGH,JINEXX,JINESX,XITLX,ZUHGZ,''复用'' ZUHZT,ZUHSHZT,TINGYRQ,
case when QIYRQ<(select FUYRQ from zhanghb where zhangh=:zhangh) then (select FUYRQ from zhanghb where zhangh=:zhangh )else  QIYRQ  END
from yinjzhb where zhangh = (select zhuzh from zhanghb where zhangh=:zhangh)
and (tingyrq > (select FUYRQ from zhanghb where zhangh=:zhangh) or tingyrq='''' OR TINGYRQ IS NULL) )', '根据账号获取组全部合(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JGetAccountInfoWhole', 'complexQuery', 1, 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg,getAllSeals,getAllGroups', '获取账户全部信息(V3.0-引擎)', 'getAccountInfo,JudgeAccountOrgBelongToGuiyOrg,getAllSeals,getAllGroups');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DecideZhuzhRight', 'simpleQuery', 1, 'select * from zhanghb where zhangh=:zhuzh', '查看主账号是否符合条件(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JDecideZhuzhRight', 'complexQuery', 1, 'DecideZhuzhRight', '查看主账号是否符合条件(类)(V3.0-引擎)', 'DecideZhuzhRight');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JSubmitSealAndCombinaInfo', 'complexTrans', 1, 'addSealInfo,changeUserCheckState,addCombineInfo,changeCombineCheckState,WriteWorkLogToDb', '提交印鉴、组合信息(V3.0-引擎)', 'addSealInfo,changeUserCheckState,addCombineInfo,changeCombineCheckState,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetZhanghztResource', 'simpleQuery', 1, 'select ZHANGHZT key, ZHANGHZT value from zhanghztb order by xuh', '获取账户状态列表(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JGetAccountCheckInfo', 'complexQuery', 1, 'getAccountInfo,isZhuzh,getSatisfySealToVerify,getSatisfyZuheToVerify', '未审印鉴审核交易(V3.0-引擎)', 'getAccountInfo,isZhuzh,getSatisfySealToVerify,getSatisfyZuheToVerify');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JSaveAccountCheckInfo', 'complexTrans', 1, 'checkAccountInfo,checkSeals,checkGroups,WriteZhengpyylogToDb,WriteYulyjyylogToDb,WriteWorkLogToDb', null, 'checkAccountInfo,checkSeals,checkGroups,WriteZhengpyylogToDb,WriteYulyjyylogToDb,WriteWorkLogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JisFuyrqSatisfy', 'complexQuery', 1, 'isFuyrqSatisfy', '查看复用日期是否符合条件(V3.0-引擎)', 'isFuyrqSatisfy');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('isFuyrqSatisfy', 'simpleQuery', 1, 'select qiyrq from yinjb where zhangh=:zhuzh group by(qiyrq) order by qiyrq', '查看复用日期是否符合条件(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getXityygzList', 'simpleQuery', 1, 'select xitmc,yanygz from xityygzb', '获取系统类型对应的验印规则列表(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('updateYinjk', 'simpleTrans', 1, 'update YINJK set ZHENGMWJM=:ZHENGMWJM,FANMWJM=:FANMWJM where zhangh=:ZHANGH and YINJKH=:YINJKH and QIYRQ=:QIYRQ', '建库yinjk表更新图像文件信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('clearSealInfo', 'simpleTrans', 1, 'delete from yinjb where zhangh=:zhangh and qiyrq=:qiyrq', '清空传入批次日期的印鉴信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('clearCombinaInfo', 'simpleTrans', 1, 'delete from yinjzhb where zhangh=:zhangh and qiyrq=:qiyrq', '清空传入批次日期的组合信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSatisfySealToCheckForzhuzh', 'simpleQuery', 1, 'select * from yinjb where zhangh =:zhuzh and qiyrq<=to_char(sysdate,''YYYY-MM-DD'') and yinjshzt=''已审''and (:chuprq>= qiyrq and (:chuprq< case when tingyrq=''''or tingyrq is null then ''2999-12-01'' else tingyrq end)) and :chuprq>=(select fuyrq from zhanghb where zhangh=:zhangh) and to_char(sysdate,''YYYY-MM-DD'') >=(select fuyrq from zhanghb where zhangh=:zhangh) order by to_number(yinjbh)', '获取满足子账户出票日期的印鉴(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JGetAllAccountInfo', 'complexQuery', 1, 'getAccountInfo,GetPici,getYSqyrq,JudgeAccountOrgBelongToGuiyOrg,getAllSeals,getAllGroups,getExaminedSeal,getExaminedGroup,getYinjkxx', '账户管理交易', 'getAccountInfo,GetPici,getYSqyrq,JudgeAccountOrgBelongToGuiyOrg,getAllSeals,getAllGroups,getExaminedSeal,getExaminedGroup,getYinjkxx');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSatisfyZuheToCheckForzhuzh', 'simpleQuery', 1, 'select * from yinjzhb where zhangh = :zhangh  and qiyrq<=to_char(sysdate, ''YYYY-MM-DD'') and zuhshzt =''已审''and :chuprq>=(select fuyrq from zhanghb where zhangh=:zhangh) and xitlx=:xitlx and :jine > jinexx and :jine <= jinesx and (:chuprq >= qiyrq and (:chuprq <  case when tingyrq='''' or tingyrq is null then ''2999-12-01'' else tingyrq end)) ', '获取满足条件子账户的组合(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('writeFileInfo', 'simpleTrans', 1, 'insert into PIAOJYXWJB (ZHANGH, YXLX, WENJBH, WENJFWDZ, PIAOJYXDZ) values (:zhangh,:yxlx,:wenjbh,:wenjfwdz,:piaojyxdz)', '写入验印图像文件服务器信息(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetSettings', 'simpleQuery', 1, 'addSealInfo,changeUserCheckState,addCombineInfo,WriteWorkLogToDb', '查询所有配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetSysConfig', 'simpleQuery', 1, 'select key,value from ocxkongzcsb order by key', '获取系统参数配置(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetSysConfigValue', 'simpleQuery', 1, 'select value from ocxkongzcsb where key =:key', '获取控制参数表中指定参数的值', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('get-systime', 'simpleQuery', 1, 'select to_char(current timestamp, ''YYYY-MM-DD HH24:MI:SS'') datetimenow from sysibm.sysdummy1', '获取当前时间(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetTheTargetfromOCX', 'simpleQuery', 1, 'select distinct target from ocxkongzcsb', '获取OCXkongzscb中的target字段', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getThreeDateNow', 'combinQuery', 1, 'getdatenow,getdatenow,getdatenow', '连续获取三次时间，用于测试连续交易与组合交易的速度差距', 'getdatenow,getdatenow,getdatenow');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetUsableCombines', 'simpleQuery', 1, 'select zhangh from yinjzhb where zhangh=:zhangh and zuhzt||zuhshzt!=''删除已审''', '获取账户下是否有可用的组合（只排除删除已审的组合），有返回true', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetUsableSeals', 'simpleQuery', 1, 'select zhangh from yinjb where zhangh=:zhangh and yinjzt||yinjshzt!=''删除已审''', '获取账户下是否有可用的印鉴（只排除删除已审的印鉴） 有字段值就有，无就没有', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetVerifyCombines', 'simpleQuery', 1, 'select zhangh from yinjzhb where zhangh=:zhangh and zuhshzt=''未审''', '获取当前账户下的组合是否都已审核', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetVerifySeals', 'simpleQuery', 1, 'select zhangh from yinjb where zhangh=:zhangh and yinjshzt=''未审''', '获取当前账户下的印鉴是否都已审核', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetYYRZ', 'simpleQuery', 1, 'select * from ci_yyrz where xitbs=:xitbs and renwbs=:renwbs', '获取CI_YYRZ中的单章验印信息（辅助验印接口所用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetZhanghxzResource', 'simpleQuery', 1, 'SELECT ZHANGHXZ KEY,ZHANGHXZ VALUE FROM ZHANGHXZB ORDER BY ZHANGHXZBH', '获取账户性质的数据源(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('hf_addaccount', 'simpleTrans', 1, 'INSERT INTO accountinfo (account, netpointflag, accountname, englishname, linkman, phone, address, postalcode, opendate, incomerange, yearcheckdate, registercapital, mainoperation, billperiod, creditgrade, startdate, accountstate, allexchange, checkperiod, accountcharacter, enterprisecharacter, industrycharacter, remark, timestampnum) values (:account, ''15057'', ''德阳市西物汽车销售服务有限公司'', ''218590503'', ''21837485905038091001'', ''00023'', ''德阳市八角工业园区'', ''618000'', ''2007-05-24'', ''10'', '''', 0.00, ''已审'', ''210000022726'', 0, ''2007-05-27'', ''有效'', ''非'', ''210000022726'', ''有'', ''是'', ''001'', ''  任燕飞  0838-2601026'', 0)', '新建账户，用于批量建库工具', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('hf_addseal', 'simpleTrans', 1, 'INSERT INTO sealinkinfo (account, netpointflag, sealinknum, sealinkchangenum, startdate, sealinktype, sealinkstate, sealinkmaterial, sealinkflag, sealinkcolor, sealinkimage, timestampnum, auditflag, inputdate, inputclerknum, inputclerkname, auditclerknum, auditclerkname, auditdate,str7) values (:account, ''15057'',:sealinknum, ''0'', ''2007-05-24'', ''财务章'', '''', ''彩色'', ''章'', ''红色'',:sealinkimage, 0, ''增章已审'', ''2007-08-03'', '''', ''曹伙明'', '''', ''罗芳'', ''2007-08-07'',  ''支付'')', '新建印鉴，用于批量建库工具', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('hf_getaccount', 'simpleQuery', 1, 'select * from accountinfo where account = :account', '根据帐号获取账户信息，用于批量建库', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('hf_getmaxsealnum', 'simpleQuery', 1, 'select max(to_number(sealinknum)) as max_number_yinjbh from sealinkinfo where account = :account', '获取帐号下预留印鉴的最大编号，批量建库的时候用到', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('hf_testnum', 'simpleQuery', 1, 'select * from hf_testint', '测试引擎对数值的支持', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetZhuzh', 'simpleTrans', 1, 'select zhuzh from zhanghb where zhangh=:zhangh', '获取主帐号【主从账户环境下】', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('insertdata-sometimes', 'combinTrans', 1, 'insertdata-str1-str2,insertdata-str3-str4', '组合插入多条数据', 'insertdata-str1-str2,insertdata-str3-str4');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('insertdata-str1-7', 'simpleTrans', 1, 'INSERT INTO accountespecialexpand (account,str5,str6,str7)values(:account,:str5,:str6,:str7)', '插入数据-str1-7', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('insertdata-str1-str2', 'simpleTrans', 1, 'INSERT INTO accountespecialexpand (account,str1,str2)values(:account,:str1,:str2)', '插入数据-str1-str2', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('insertdata-str3-str4', 'simpleTrans', 1, 'INSERT INTO accountespecialexpand (account,str3,str4)values(:account,:str3,:str4)', '插入数据-str3-str4', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('InsertOcxkongzcsb', 'simpleTrans', 1, 'INSERT INTO ocxkongzcsb(key,value,target,defaultvalue,remark) values (:key,:value,:target,:defaultvalue,:remark)', '新增记录到OCX控制参数表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IsExitsRWXX', 'simpleQuery', 1, 'select renwbs  from ci_renwxx where xitbs = :xitbs  and renwbs = :renwbs', '查看任务信息是否存在', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('IsExitsYYRZ', 'simpleQuery', 1, 'select renwbs  from ci_yyrz where xitbs = :xitbs and renwbs = :renwbs  and yinjbh = :yinjbh and yinqbgh = :yinqbgh  and zhangh = :zhangh', '查看印鉴验印日志是否存在', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('Querydata', 'simpleQuery', 1, 'select * from accountespecialexpand where account=:account', '查询数据-全部', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('Test1', 'simpleQuery', 1, 'sdfdsff', 'dsfsdf', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('log_inssealchecklog', 'simpleTrans', 1, 'INSERT INTO sealchecklog (ip,account,checknum,sealinktype,sealinknum,checkdate,checktime, clerknum,clerkname,checkresult,checkmode) values (:ip,:account,:checknum,:sealinktype,:sealinknum,:checkdate,:checktime, :clerknum,:clerkname,:checkresult,:checkmode)', '写入验印识别日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('Querydata2', 'simpleQuery', 1, 'select str1,str2 from accountespecialexpand where account=:account', '查询数据-部分', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('Querydata3', 'simpleQuery', 1, 'select str3,str4 from accountespecialexpand where account=:account', '查询数据-部分1', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('querydata-all', 'simpleQuery', 1, 'select * from accountespecialexpand', '查询数据-全表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('querylinenumber', 'simpleQuery', 1, 'select count(*) xixi from accountespecialexpand', '查询总行数', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetRenwxx', 'simpleQuery', 1, 'select * from ci_renwxx where xitbs=:xitbs and renwbs=:renwbs and chulzt=''1''', '从任务信息表中获取任务（辅助验印接口用）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getOcxVersionInfo', 'simpleQuery', 1, 'SELECT cansid, parametervalue FROM BSKONGZCS WHERE TYPE=''OCX版本参数''', '获取数据库OCX版本号(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSameNumberSealsCount', 'simpleQuery', 1, 'select count(*) as count_sameseal from yinjb where zhangh=:zhangh and yinjbh=:yinjbh', '获取同一个印鉴编号的印鉴数目，即判断是否有更改', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetSealsToCheck', 'simpleQuery', 1, 'select * from yinjb where zhangh =(select CASE WHEN (zhuzh is null )or(zhuzh = '''' ) THEN zhangh ELSE zhuzh END from zhanghb where zhangh=:zhangh) and yinjzt||yinjshzt !=''删除已审'' and yinjzt||yinjshzt!=''新增未审'' and yinjzt||yinjshzt!=''更增未审'' and qiyrq <= current date order by to_number(yinjbh),to_number(yinjbgh)', '获取账户下供验印的所有预留印鉴', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSealsToCombine', 'simpleQuery', 1, 'select * from yinjb where zhangh=:zhangh and xitlx=:xitlx and yinjzl=''章'' and yinjzt!=''删除'' and yinjshzt=''已审'' order by to_number(yinjbh)', '获取当前用户的所有可用于生成组合的预留印鉴列表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getSettingInfo', 'simpleQuery', 1, 'select * from shuxkzgxb where gongnym = :gongnym and shuxm = :shuxm', '查询表单中的属性配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DeleteYYRZ', 'simpleTrans', 1, 'delete from ci_yyrz where xitbs=:xitbs and renwbs=:renwbs', '（接口用）删除印鉴验印日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('DeleteRenWXX', 'simpleTrans', 1, 'delete from ci_renwxx where xitbs=:xitbs and renwbs=:renwbs', '（接口用）删除整票验印日志（任务信息）', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('updateSealInfo', 'simpleTrans', 1, 'update yinjb set yinjkbh=:yinjkbh,xitlx=:xitlx,yinjlx=:yinjlx,yinjzl=:yinjzl,yinjys=:yinjys,qiyrq=:qiyrq where zhangh=:zhangh and yinjbh=:yinjbh and yinjbgh=:yinjbgh', '编辑印鉴基本信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getKzcs', 'simpleQuery', 1, 'select parametervalue from BSKONGZCS where cansid=:cansid', '获取系统控制参数', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('WriteHandleLog', 'simpleTrans', 1, 'INSERT INTO accountmanagelog(account, managedate, managetime, managetype, managecontent, clerknum, clerkname, ip) values (:zhangh,current date,replace(current time,''.'','':''), :managetype, :managecontent, :clerknum, :clerkname, :ip)', '写柜员操作日志到数据库(V3.0-引擎)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('updateSettingInfo', 'simpleTrans', 1, 'update shuxkzgxb set zhansm=:zhansm, shifzs=:shifzs, zhanssx=:zhanssx, morz=:morz, shifzhxs=:shifzhxs, zhansfs=:zhansfs, shurkz=:shurkz,zuidcd=:zuidcd, yanzzfc=:yanzzfc where gongnym=:gongnym and shuxm=:shuxm', '更新配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('UppdateRenWXX', 'simpleTrans', 1, 'update ci_renwxx set renwrq = :renwrq,tonggzh=:tonggzh,chulgy=:chulgy,huizsj=:huizsj,faqsj=:faqsj,chulrq=:chulrq,weigyy=:weigyy,yanyjg=:yanyjg,yanyms=:yanyms,chulzt=:chulzt,yanyjb=:yanyjb where xitbs=:xitbs and renwbs=:renwbs', '(接口用)更新任务信息,提交任务', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('uppdateseal', 'simpleTrans', 1, 'update yinjb set yinjlx = :yinjlx ,yinjys = :yinjys where zhangh = :zhangh,yinjbh = :yinjbh,yinjbgh = :yinjbgh', '更新印鉴信息(只更新基本的一些信息,不改变审核状态)', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('UppdateYYRZ', 'simpleTrans', 1, 'update ci_yyrz set renwrq=:renwrq,chulgy=:chulgy,chulsj=:chulsj,chulrq=:chulrq,yinzjd=:yinzjd,shuxzb=:shuxzb,hengxzb=:hengxzb,yanyjg=:yanyjg,yanyms=:yanyms,yinjbz=:yinjbz where xitbs=:xitbs and zhangh=:zhangh and renwbs=:renwbs and yinjbh=:yinjbh and yinqbgh=:yinqbgh', '（接口用）更新印鉴验印日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('WriteSealCheckLog', 'combinTrans', 1, 'WriteZhengpyylogToDb,WriteYulyjyylogToDb', '在为某用户新增或更改某印鉴时(V3.0-引擎)', 'WriteZhengpyylogToDb,WriteYulyjyylogToDb');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('WriteSystemManageLogToDb', 'simpleTrans', 1, 'INSERT INTO systemmanagelog（id,admincode,content,operdate) values （:id,:admincode,:content,:operdate)', '写系统管理员操作日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('WriteWorkLogToDb', 'simpleTrans', 1, 'INSERT INTO accountmanagelog (account,managedate,managetime,managetype,clerknum,clerkname,ip,upflag,str1,str2,str3,managecontent,qiyrq) values (:account,:managedate,:managetime,:managetype,:clerknum,:clerkname,:ip,:upflag,:str1,:str2,:str3,:managecontent,:qiyrq)', '写账户管理操作日志（需要写日志的相关操作为：开户销户审核、增变更印鉴、资料修改、账户冻结等，但不包括验印信息、如整票通过等）(V3.0-引擎)', null);





insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('querySon', 'simpleQuery', 1, 'select b.instanceid , b.zhangh , b.imagekey , b.limit , b.ccode , b.chopindicator , b.recordsequence , b.signaturename ,b.errorid , b.errortxt , b.image yinjtp  from TASKZIB  a left join TASKJGZIB  b on a.instanceid = b.instanceid where  a.masterinstanceid =  :masterinstanceid  order by b.recordsequence ', '查询子任务结果表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addDad', 'simpleTrans', 1, 'insert into taskzhub(instanceid , managetype , zhangh , limit , ccode , clerkname , clerknum , clerkorgnum ) values(:instanceid , :managetype , :zhangh , :limit , :ccode , :clerkname , :clerknum , :clerkorgnum)', '主任务信息记录到主任务表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('queryDad', 'simpleQuery', 1, 'select instanceid , zhangh , CROSSINDICATOR , instruction , noteline , occurrencecount , numberSignature , notoSignature , errorid , errortxt , customername from TASKZJGB where instanceid=:instanceid ', '查询主任务结果表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('queryDad_vice', 'simpleQuery', 1, 'select  masterinstanceid , zhangh , limit , ccode , chopindicator , recordsequence , signaturename , imagekey from TASKJGFB where masterinstanceid = :masterinstanceid', '查询主任务结果表副表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addSon', 'simpleTrans', 1, 'insert into TASKZIB(instanceid , masterinstanceid , zhangh , imagekey , limit , ccode , indicator , recordsequence , signaturename ) values(:instanceid  , :masterinstanceid , :zhangh , :imagekey , :limit , :ccode , :indicator , :recordsequence , :signaturename )', '子任务信息记录到子任务表', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('MQConfigure', 'simpleQuery', 1, 'select ip , port , mqlchannel , queuemanager , requestqueue , replyqueue , characterset , username , userpassword from MQconfigure', '查询MQ连接需要的配置信息', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addBillCheckLog', 'simpleTrans', 1, 'insert into  billchecklog   values(:taskid , :pich , :account , :customername , :zhangh , :groupmember , :branchname , :ccode , :limit , :checktype , :billresultmodel , :billresult , :remark , :clerknum , :clerkname , :clerkorgnum , :checkdate , :checktime , :pingzlx)', '添加整票验印日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addSealCheckLog', 'simpleTrans', 1, 'insert into  sealchecklog   values(:taskid , :chopsequence , :imagekey , :chopindicator , :chopname , :result , :resultmodel)', '添加单张验印日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SaveCheckedResults', 'complexQuery', 1, 'addBillCheckLog,addSealCheckLog', '添加验印日志', 'addBillCheckLog,addSealCheckLog');

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addjournal', 'simpleTrans', 1, 'insert  into  yinjcxrz(groupmenber , branchname , account , customername, enquirydate, enquirytime, clerknum, clerkname , clerkorgnum , remark) values (:groupmenber , :branchname , :account , :customername, :enquirydate, :enquirytime, :clerknum  , :clerkname , :clerkorgnum , :remark)', '添加印鉴查询日志', null);

insert into YQ_JIAOYNR (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('MQGetSealList', 'complexQuery', 1, 'addDad,queryDad,queryDad_vice,addSon,querySon,MQConfigure,addjournal', 'MQ通讯', 'addDad,queryDad,queryDad_vice,addSon,querySon,MQConfigure,addjournal');


insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz,jiaoyzh) 
values( 'CheckClerk' , 'complexQuery' , '1' ,'selectClerk,selectClerkjues,addClerk,updateClerk,addjues,deletejues' ,  'AD域登录' ,'selectClerk,selectClerkjues,addClerk,updateClerk,addjues,deletejues');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'selectClerk' , 'simpleQuery' , '1' , 'select clerknum , clerkpwd , n_organnum from clerktable where clerknum = :clerknum' , '查询clerk');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'selectClerkjues' , 'simpleQuery' , '1' , 'select * from guiyjsgxb where guiyid = :guiyid and juesid = :juesid' , '查询clerk 角色');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'addClerk' , 'simpleTrans' , '1' , 'insert into clerktable(CLERKNUM , clerkname , clerkpwd , n_organnum , shenghjgh ,wdflag ) values(:clerknum ,:clerkname , :clerkpwd ,:n_organnum , :shenghjgh ,:wdflag )' , '添加clerk');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'updateClerk' , 'simpleTrans' , '1' , 'update clerktable set clerkpwd  = :clerkpwd , postnum  = :postnum , postname  = :postname , n_updatedate  = :n_updatedate , n_organnum  = :n_organnum , n_error  = :n_error , n_logdate  = :n_logdate , n_ip  = :n_ip , n_creator  = :n_creator , shenghjgh  = :shenghjgh , wdflag  = :wdflag  where clerkname = :clerkname' , '更新clerk');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'addjues' , 'simpleTrans' , '1' , 'insert into guiyjsgxb values (:guiyid , :juesid , :beiz )' , '添加clerk角色');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'deletejues' , 'simpleTrans' , '1' , 'delete guiyjsgxb where guiyid = :guiyid and juesid = :juesid ' , '删除clerk角色');




insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accountname', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accountstamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accorgno', 'String', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accountstate', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accuser', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('address', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('admincode', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('allexchange', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcgydm', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcgymc', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkclerknum', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcsj', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangjgn', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangjjgh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checknum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ceshi', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shebdm', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chinaname', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shenghjgh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifbt', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifdy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifyt', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifky', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifsc', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifxs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifzhxs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifzs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shij', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shoukrmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shoukrzh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shuangqgyh', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shuangqgymc', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinqbgh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinzjd', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cj_time', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_youbj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yzsf', 'float', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zhangh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zhaozq', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zhiphm', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zidclcz', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zidyylsh', 'string', 28);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zuobj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('getdate', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('gongnid', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('gongnmc', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('gongnym', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('goofficenum', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('gudfbl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerknamebymanage', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerknum', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiyh', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerknumbymanage', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerkpwd', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiymc', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiz', 'string', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guizmc', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hangyxz', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('haspickupmoney', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('height', 'integer', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hengxzb', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('heqzt', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('historybackupcondition', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidaystr', 'string', 366);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayStr', 'string', 366);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayyear', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayyear1', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayyear2', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayyeardata', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('huizqx', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('huizsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hum', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('huobh', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('id', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('idd', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imagemaxheight', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imagemaxwidth', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('img1', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('img2', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('img3', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imptype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('incomerange', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('industrycharacter', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('deletedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inimageleft', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inimagetop', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inputclerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('depict', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inputclerknum', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inputdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int1', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int10', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int2', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int3', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int4', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int5', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int6', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int7', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int8', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int9', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('io_cost', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isautosealagain', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isdownload', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isedit', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ishaspassword', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('account2', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accountcharacter', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fenytj', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fieldname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fieldtype', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fileinfo', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('filename', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('access_predicates', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accname', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accno', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('account', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('filter_predicates', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fimgname', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('funcoption', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('functiondescribe', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('functionid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('functionname', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fuygy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fuz', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_caozsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_chulsxh', 'string', 37);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_chulzt', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_chuprq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_fazq', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_fenbl', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('topset', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tuxsy', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_fuygy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_gudfbl', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_hengxzb', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_id', 'string', 33);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_jiaohrq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_jine', 'float', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_lianjxtbh', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_lianjxtnxh', 'string', 28);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_shangbj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_shuxzb', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_waiwxtgy', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_wenjm', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangjqx', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('secretstring', 'string', 64);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sftype', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaosqy', 'string', 19);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shancrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangbj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('auditdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('auditflag', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bankid', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('baobbs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('baobbt', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('baobmc', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bathid', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('beiscs', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('beisrqd', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('beiz', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hf3', 'integer', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkmode', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkperiod', 'string', 14);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('lianxr', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('licensecode', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjw', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjh', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qiyrqnew', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulzs', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('duank', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ipdiz', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwye', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwzs', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sheblx', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhuangt', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('juesjb', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiyjgh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fuyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quxfyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiankbs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tingyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiym', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanybs', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('henxzb', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjkh', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('taskid', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tasktype', 'integer', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pictype', 'integer', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('huoqyxfs', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youxj', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiyxm', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjkbhz', 'string', 250);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyd', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bianglx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shenhrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhengmwjm', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fanmwjm', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerkorgcode', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yewlx', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjks', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifzk', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzbsm', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('changedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shzt', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanyjg', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinjbh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('linkman', 'string', 125);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('logindate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('logintime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('lvalue', 'string', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('mainoperation', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('managecontent', 'string', 1000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinjbz', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinjkbb', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('managedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('managetime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('managetype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('mandep', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('max_cast_sealinknum', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('max_number_yinjbh', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('maxcode', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('meaning', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('memoinfo', 'string', 512);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('mnsource', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('money', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moneydown', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moneydown1', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moneyup', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moneyup1', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('morz', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tuxmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shiffy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_basepostnum', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_creator', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_error', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_ip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_logdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_organnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_parentnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_paymentnum', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_updatedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('name', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('names', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('netpointflag', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('newcolumn', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('neworgannum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('newpostpopedom', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('newprocedurename', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('newtablename', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('noclerknum', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number1', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number2', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number3', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str47', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str48', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str49', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str5', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str50', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str6', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str7', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str8', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str9', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('suoyz', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('syncip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('syncport', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sysdate_string', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tableid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tablename', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tablenum', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tabletype', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('target', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('taskbegintime', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('taskflag', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tctd', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tel', 'string', 36);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('temp_space', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwbs', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwlx', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tg', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tichhh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('time', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('time_type', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('time_value', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('timestamp', 'string', 7);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('account1', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('postnum', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('lianjxtbh', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('lianjxtnxh', 'string', 28);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('postpopedom', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('printcount', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('procedureid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('projection', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('property', 'string', 64);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('publishcount', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('putoutdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('groupmenber', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('branchname', 'string', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('customername', 'string', 350);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enquirydate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enquirytime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('putouttime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pzhid', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qblock_name', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qiyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qiysj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quyid', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quymc', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qysj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('r_retflag', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('r_retmsg', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('registercapital', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('remark', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('remarks', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yfenbl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xfenbl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('faqsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fazq', 'string', 19);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quanxms', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quanxmc', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quanxid', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('juesms', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('juesmc', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('juesid', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiyid', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('extendcreditflag', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('type', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('unitname', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('up_date', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('up_okcount', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('up_time', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('updatedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('updatedbokflag', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('updateflag', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('updatetimes', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('upflag', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('upflage', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('auditclerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('auditclerknum', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('upokflag', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('uptime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('uvalue', 'string', 510);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('value', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('valverectdistance', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('version', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('versiondata', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('versionnum', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shujhqfs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shujy', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shunxh', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shurkz', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shuxm', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifqy', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanybj', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hf1', 'integer', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhuzh', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifkk', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hf2', 'integer', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imagename', 'String', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkpwd', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkresult', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkstate', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checktime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('liandfs', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sql_id', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sql_value', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('startdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('state', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('statement_id', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('statue', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str1', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str10', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str11', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str12', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str13', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str14', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str15', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str16', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str17', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str18', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('riqfw_', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str19', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str2', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str20', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str21', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str22', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str23', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str24', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str25', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str26', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str27', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str28', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str29', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str3', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str30', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str31', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str32', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str33', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str34', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str35', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str36', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str37', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str38', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str39', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str4', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str40', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str41', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str42', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str43', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str44', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str45', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str46', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jinexxnew', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jinesxnew', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuhgznew', 'string', 400);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitlxnew', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('code', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('codeend', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('codename', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('codestart', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('columnid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('combine_count', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('condition', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('content', 'string', 2000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cost', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('count', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('count_sameseal', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cpu_cost', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('crc', 'integer', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('credence_bktype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('credencestamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('credencetype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('creditgrade', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('currentbackupcondition', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('currentresource', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('currenttaborder', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dat10', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dat8', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dayfa', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dayzy', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('defaultresource', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('defaulttaborder', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('defaultvalue', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('delet', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('postalcode', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('postname', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('depth', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('description', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('desorg', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dianh', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('discaption', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('displaylength', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('displayname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('displayorder', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('distribution', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('diz', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('docimage', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('docname', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('docstamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('doctype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('doublesignatureclerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('doublesignatureclerknum', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dz_field', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enableaudit', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fenbl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enablecheck', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enablemanage', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tisxx', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enableperiod', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enablesearch', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('encodetype', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enddate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('englishname', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enterprisecharacter', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('error', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('exefilename', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('expression', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('verify_combines ', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('verify_seals', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('usable_combines', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('usable_seals', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('rvalverect', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('s_enableupload', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('scantime', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealgrade', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkchangenum', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkcolor', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkcombinestamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkflag', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkimage', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkmaterial', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinknum', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('riqfw', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkstamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkstate', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinktype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealnum', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealrect', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealrectbottomdistance', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealrectdistance', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('search_columns', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('secretdata', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('secretkey', 'string', 64);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youxq', 'integer', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shuxzb', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('formid', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qrcode', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sql', 'string', 1000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifsy', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('waiwxtgy', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wc_time', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wdflag', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('weigyy', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjbh', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjfwcs', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjfwdk', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjfwdz', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjfwip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjm', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjmlph', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wg', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('width', 'integer', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wincontrol', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wmode', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wtrq', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wux', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wx', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xhrs', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xhsj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xiabj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xianslx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xianssx', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitbs', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitlx', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitslrq', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xz_time', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xzsf', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yans', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanslx', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanybgyy', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanydj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyfs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyjb', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyjg', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyms', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanysj', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanywgyy', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanzzfc', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaosbs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaosbt', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaoscd', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaoshw', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaoslx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaosmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yearcheckdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yewtz1', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjbgh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjbh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjbz', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjian', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerk_organnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh_organnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjkbh', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjlb', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjlx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjshzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjtp', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjys', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjzl', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinqbgh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinqlx', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinzjd', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yjdm', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yjkh', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yjtype', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yongt', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youbj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youwyj', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youwzh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youzbm', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yxlx', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yy_004', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yy_008', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yyy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yzsf', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh1', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh2', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh3', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh4', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanghqz', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanghshzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanghzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhansfs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhansm', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanssx', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhaozq', 'string', 19);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhdm', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhengfbz', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhidbs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhifmm', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhuanhz', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidcd', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidclcz', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidkzcs', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidkzdk', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihy', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidkzip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidlx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidm', 'string', 25);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidyylsh', 'string', 28);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zipcode', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ziybs', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zongs', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zs', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuhgz', 'string', 400);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuhshzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuhzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuidcd', 'string', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuobj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zxsj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kapbh', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kehh', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('key', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('khsj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('leftset', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tonggzh', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('leix', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwrq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwzt', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tongdgz', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tonggl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('reportdate', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('residualmoney', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('resourceid', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('responsibilityperson', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('result', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('rightset', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('rimgname', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('riq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bgyjdm', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_xiabj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_xzsf', 'float', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('biaos', 'string', 38);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanydj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanyfs', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('billid', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bespeakmoney', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('billperiod', 'string', 14);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bingxq', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanslx', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanybgyy', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bottomset', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bufbz', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bytes', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('c_enabledownload', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('c_enableupload', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('caijzd', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansfl', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansid', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('canslx', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansm', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansmc', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('canssm', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansz', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('caozsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cardinality', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkclerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuangjgy', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuangjjg', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulgy', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulrq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bglx', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulsxh', 'string', 37);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulzt', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuprkhhhh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuprmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuprq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuprzh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cisfilename', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cisfn', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifzd', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjjd', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjkbb', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number4', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number5', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number6', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number7', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_alias', 'string', 65);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_instance', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_name', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_node', 'string', 128);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_owner', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_type', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('objectid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldaccount', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldclerknum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldcolumn', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldexpression', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldmoneydown', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldmoneyup', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldpostpopedom', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldprocedurename', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldtablename', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('opendate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operate', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operatedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operatetime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operatetype', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operation', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operdate', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operorg', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('optimizer', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guizbh', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('options', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('org_num', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organname', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organnum_', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organnum1', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organnum2', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('orgname', 'string', 2000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('other', 'integer', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('other_tag', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('package', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parameter_type', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parameter_value', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('datetimenow', 'string', 25);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhiphm', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhlx', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanghxz', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanshi', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parametername', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parameternum', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parameterrefername', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parametersort', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parametertype', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parametervalue', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parent_id', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('partition_id', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('partition_start', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('partition_stop', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('password', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('peryu', 'string', 24);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('phone', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('piaojcheckresult', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moyz', 'string', 400);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('piaojhm', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('piaojyxdz', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzbs', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('expression1', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzh', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzlx', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzzl', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('plan_id', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pofish', 'string', 24);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('position', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('reng', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwbh', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isview', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isvisible', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandgydm', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandgymc', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandsj', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaohrq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoybz', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoyid', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoylx', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoynr', 'string', 1000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoyxh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoyzh', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoyzt', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiedbs', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jigdm', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jigh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jigmc', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jine', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jinesx', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jinexx', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihhh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihsj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('timestampnum', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tisfkrq', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tongctd', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cannotnull', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansbs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ysuof', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanzxx', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xsuof', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiedmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shenhy', 'String', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihynum', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shenhynum', 'String', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checktype', 'String', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('errorid', 'string', 7);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('errortxt', 'string', 78);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('image', 'blob', 130000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('occurrencecount', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('numberSignature', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('notoSignature', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pich', 'string', 23);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('groupmember', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('billresultmodel', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('billresult', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chopsequence', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chopname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('resultmodel', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pinglx', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('crossindicator', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('port', 'integer', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('mqlchannel', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('queuemanager', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('requestqeue', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('replyqueue', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('characterset', 'integer', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('username', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('userpassword', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('instanceid', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('masterinstanceid', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanggh', 'string', 18);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('indicator', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('instruction', 'string', 1305);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('noteline', 'string', 1200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('limit', 'string', 9);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ccode', 'string', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('recordsequence', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('signaturename', 'string', 175);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imagekey', 'string', 9);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chopindicator', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cccode', 'string', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerkorgnum', 'string', 8);






insert into YQ_KONGZCS (CANSBS, CANSMC, CANSLX, CANSFL, CANSZ, CANSSM)
values ('isBase64', null, null, null, '0', '保存印鉴时是否需要解码,1：不需要解码；0：解码，获取时再加密');



--mq参数
insert  into MQCONFIGURE values('133.10.221.122',8209,'ULCVS01CN.SVRCHL.TM','ULCVS01CN','T.CVS.CN_CVS.CN_HUB.CVS_RQST','T.CVS.CN_HUB.CN_CVS.CVS_RESP',819,null,null);

insert into  ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HFYY' , '汇丰银行' , null , 1 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBCB' , '湖北随州曾都汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBCD' , '重庆大足汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBFU' , '福建永安汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBBJ' , '北京密云汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBGD' , '广东恩平汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBDP' , '大连普兰店汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBCF' , '重庆丰都汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBHT' , '湖北天门汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBCQ' , '重庆荣昌汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBHU' , '湖南平江汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBSD' , '山东荣成汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBMC' , '湖北麻城汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HSBC' , '汇丰银行（中国）' , 'HFYY' , 2 , 'HFYY' ,  '是' );



--生成全局流水号
insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH) values ('GetQuanJlsh', 'simpleQuery', 1, 'select ''QG013''||to_char(sysdate,''yyyymmdd'')||lpad(to_char(YY_GUIMLS_SEQ.nextval),10,''0'') guimqjls  from dual', '生成全局流水号', null);


INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01001', '系统管理员', '3', null, null, null);
INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01002', '管理员', '2', null, null, null);
INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01004', '查询员', '1', '印章查阅', null, null);
--INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01005', '审核员', '1', '印鉴审核员', null, null);
INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01006', '验印员', '1', '验印经办员', null, null);


commit;