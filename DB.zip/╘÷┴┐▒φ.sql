

--日志表
--drop table yinjcxrz cascade constraints;
create table yinjcxrz (
  groupmenber varchar2(4),
  branchname  varchar2(3),
  account     varchar2(12),
  customername  varchar2(350),
  
  enquirydate   varchar2(10),
  enquirytime   varchar2(8),
  clerknum      varchar2(20),
  clerkname     varchar2(20),
  clerkorgnum   varchar2(4),
  remark     varchar2(200)
);

--drop table yonghwhb cascade constraints;
create table yonghwhb (
       id  varchar(36) primary key,
       jigouhao varchar2(40) ,
       jigouname  varchar2(200) ,
       userid  varchar2(20) ,
       username varchar2(20),
       maintenance varchar2(20),
       chaxrq varchar(10) ,
       chaxtime varchar2(10),
       beiz varchar2(200),
       userjues varchar2(200),
       clerkcode varchar2(20),
       clerkname varchar2(20)
       
);

--drop table BillCheckLog cascade constraints;
create table BillCheckLog 
(
   taskid             varchar2(20)         not null,
   pich               varchar2(23),
   account            varchar2(18),
   customername        varchar2(350),
   zhangh             varchar2(12),
   groupmember        varchar2(4)          not null,
   branchname         varchar2(3),
   ccode              varchar2(3),
   limit              varchar2(20),
   checktype          char(1),
   billresultmodel    varchar2(6),
   billresult         varchar2(12),
   remark             varchar2(200),
   clerknum           varchar2(6)          not null,
   clerkname          varchar2(26),
   clerkorgnum        varchar2(4)          not null,
   checkdate          varchar(10)          not null,
   checktime          varchar(8)           not null,
   pingzlx			  varchar2(60),
   constraint PK_BILLCHECKLOG primary key (taskid)
);
create index idx_BillCheckLog  on BillCheckLog(groupmember,checkdate); 


--drop table SealCheckLog cascade constraints;
create table SealCheckLog 
(
   taskid             varchar2(20)         not null,
   chopsequence       varchar2(5),
   imagekey           varchar2(9),
   chopindicator      varchar2(6),
   chopname           varchar2(175),
   result             varchar2(12),
   resultmodel        varchar2(6),
   constraint PK_SEALCHECKLOG primary key (taskid , chopsequence)
);






--主任务表
--drop table TASKZHUB cascade constraints;
create table TASKZHUB (
  
  INSTANCEID  VARCHAR2(20) ,
  MANAGETYPE  VARCHAR2(10) ,
  ZHANGH      VARCHAR2 (18) ,
  limit       VARCHAR2 (9),
  CCODE      VARCHAR2 (3) ,
  CLERKNAME   VARCHAR2 (20),
  CLERKNUM    VARCHAR2 (20),
  CLERKORGNUM VARCHAR2 (5),
  constraint PK_TASKZHUB primary key(INSTANCEID); 
);

--子任务表
--drop table TASKZIB cascade constraints;
create table TASKZIB (

  INSTANCEID      VARCHAR2(20),
  MASTERINSTANCEID  VARCHAR2(20),
  ZHANGH        VARCHAR2(18),
  IMAGEKEY      VARCHAR2(9),
  limit       VARCHAR2(9),
  CCODE        VARCHAR2(3),
  INDICATOR     VARCHAR2(1),
  RECORDSEQUENCE    VARCHAR2(5),
  SIGNATURENAME   VARCHAR2(175),
  PK_TASKZIB primary key(MASTERINSTANCEID,INSTANCEID);  
);


--MQ参数配置表
--drop table MQCONFIGURE cascade constraints;
create table MQCONFIGURE (
  
  IP          VARCHAR2(20),
  PORT       NUMBER,
  MQLCHANNEL      VARCHAR2(50),
  QUEUEMANAGER    VARCHAR2(50),
  REQUESTQEUE     VARCHAR2(50),
  REPLYQUEUE      VARCHAR2(50),
  CHARACTERSET    NUMBER,
  USERNAME        VARCHAR2(50),
  USERPASSWORD      VARCHAR2(50)
);

---------------TASKZJGB

--drop table TASKZJGB cascade constraints;
create table TASKZJGB
(      
  instanceid  VARCHAR2(20),
  zhangh      VARCHAR2(18),
  CROSSINDICATOR   VARCHAR2(1),
  instruction VARCHAR2(1305),
  noteline    VARCHAR2(1200),
  occurrencecount        VARCHAR2(5),
  numberSignature   VARCHAR2(5),
  notoSignature    VARCHAR2(1),
  error        varchar2(10),
  errorid      varchar2(7),
  errortxt     varchar2(78),
  customername varchar2(350),
  constraint PK_TASKZJGB primary key(instanceid); 
);

---------------TASKJGFB
--drop table TASKJGFB cascade constraints;
create table TASKJGFB
(
  masterinstanceid VARCHAR2(20),
  zhangh           VARCHAR2(18),
  limit           VARCHAR2(9),
  ccode            VARCHAR2(3),
  chopindicator        VARCHAR2(1),
  recordsequence   VARCHAR2(5),
  signaturename    VARCHAR2(175),
  imagekey         VARCHAR2(9),
  constraint PK_TASKJGFB primary key(masterinstanceid,recordsequence); 
);

-----------------------
--drop table TASKJGZIB cascade constraints;
create table TASKJGZIB
(
  instanceid     VARCHAR2(20),
  errorid        VARCHAR2(7),
  errortxt        VARCHAR2(78),
  zhangh         VARCHAR2(18),
  imagekey       VARCHAR2(9),
  limit          VARCHAR2(9),
  ccode          VARCHAR2(3),
  chopindicator  VARCHAR2(1),
  recordsequence VARCHAR2(5),
  signaturename  VARCHAR2(175),
  image          BLOB,
  constraint PK_TASKJGZIB primary key(instanceid,recordsequence); 
);

