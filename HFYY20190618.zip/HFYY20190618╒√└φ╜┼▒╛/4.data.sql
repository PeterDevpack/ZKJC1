
set define off
insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('icheck_version', null, null, '3.0', null, null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('getVersion_Addr', null, 'string', 'http://172.168.1.196', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('xit_sequence', null, 'string', '31312', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('maxmeibzs', null, 'int', '1000', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('versionnum', null, 'string', 'V3.0', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('oper_tctd', null, 'string', '13:00', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('org_ranking', null, 'int', '2', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('admin', null, 'string', 'admin', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('file_address_ip', null, 'string', '172.167.1.133', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('version', null, 'string', 'zhengshi', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('productperiod', null, 'string', '2011-12-22', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('empower', null, 'string', 'w', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('clerkquantity', null, 'string', '500', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('onlinenum', null, 'string', '1000', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('biz_date', null, 'string', '2014-08-13', '批量服务参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('report_line', null, 'string', '4', 'Ureport引擎', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('db_type', null, 'string', 'oracle', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('rootcode', null, 'string', '000000', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('rootname', null, 'string', '总行', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('supermanager', null, 'string', '0', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('adminPassword', null, 'string', '111111', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('systemmodle', null, 'string', 'test', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('changpassworddays', null, 'string', '30', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('updatepasswordtimes', null, 'string', '5', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('errorpasswordtimes', null, 'string', '6', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('outtime', null, 'string', '1800', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('forcedtosign', null, 'string', '0', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('tesyw_shuangrhq', null, 'string', '0', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('pingzyxll', null, 'string', '1', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('yingjkll', null, 'string', '1', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('startPz', null, 'string', 'J', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('maxpings', null, 'string', '100', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('yanyinlogType', null, 'string', '开户|账户复核|变更|修改资料|账户销户|销户恢复|账户挂失|账户解挂|账户物理删除', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('admincode', null, 'string', '000000', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('baobys', null, 'string', '25', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('ocx_version', null, 'string', '3.1.0.3', 'OCX版本参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('kzcs_version', null, 'string', '1.5', 'OCX版本参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('sxkz_version', null, 'string', '1.4', 'OCX版本参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('org_guanlms', null, 'string', '2', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('file_address_port', null, 'int', '7001', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('file_address_outtime', null, 'int', '10000', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('clerk_guanlms', null, 'string', '1', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('maxbens', null, 'int', '50', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('dic_version', null, 'string', '3.3', 'OCX版本参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('kag_kongzcs', null, 'string', '1', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('clerk_firstlogincpw', null, 'string', '1', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('datasync', null, 'string', 't', '系统参数', null);

insert into bskongzcs (CANSID, CANSM, CANSLX, PARAMETERVALUE, TYPE, CANSSM)
values ('local_image', null, 'string', '1', '系统参数', null);



INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'CANSSM', '参数描述', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('12', 'REMARK', '备注栏位', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('12', 'INDUSTRYCHARACTER', '货币号', 'string', '文本框', null, null, null, '1', '1', '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('13', 'cansid', '控制参数ID', 'string', '文本框', null, null, 'required', '1', '1', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'YUANSNAME', '元素name', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('13', 'canslx', '控制参数类型', 'string', '文本框', null, 'int', null, '1', '1', '1', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('13', 'parametervalue', '控制参数值', 'string', '文本框', null, '1', null, '1', '1', '1', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('001', 'postnum', '主键', 'string', '文本框', null, null, null, '1', '1', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('001', 'postname', '权限名称', 'string', '文本框', null, null, null, '1', '0', '1', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'BAOBBS', '报表标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'BAOBMC', '报表名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'BAOBBT', '报表标题', 'string', '文本框', null, null, null, '1', null, '0', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHIFKY', '是否可用', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHIFFY', '是否分页', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'FENYTJ', '分页条件', 'int', '文本框', null, null, null, '1', null, '1', '0', '5', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHIFDY', '是否打印', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHIFSC', '是否删除', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'SHUJHQFS', '数据获取方式', 'string', '文本域', null, null, null, '1', null, '0', '0', '8', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BAOBPZ', 'ZHIDYL', '自定义类', 'string', '文本域', null, null, null, '1', null, '0', '0', '9', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('15', 'QUANXID', '权限ID', 'string', '文本框', null, null, null, ' ', ' ', ' ', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('15', 'QUANXMC', '权限名称', 'string', '文本框', null, null, null, ' ', ' ', ' ', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('15', 'QUANXLX', '权限类型', 'string', '文本框', null, null, null, ' ', ' ', ' ', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('15', 'QUANXZT', '权限状态', 'string', '文本框', null, null, null, ' ', ' ', ' ', '0', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('13', 'CANSID', '控制参数ID', 'string', '文本框', null, null, 'required', '1', ' ', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'BAOBBS', '报表标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSMC', '要素名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSBS', '要素标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'MSGID', '提示信息ID', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('22', 'account', '账号', 'string', '文本框', null, null, null, '1', ' ', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSBT', '要素标题', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSLX', '要素类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'SHIFBT', '是否必填', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'STYLECLASS', 'class', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'MOYZ', '默认值', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'XIANSSX', '显示顺序', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSGS', '要素格式', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'BEIZ', '备注', 'string', '文本域', null, null, null, '1', null, '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'VALIDATERULE', '校验规则', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('12345', 'account', '账号', 'string', '文本框', null, null, null, '1', ' ', '1', '1', null, null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'YUANSID', '元素id', 'string', '文本框', null, null, null, '1', ' ', '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'YUANSSTYLE', '元素style', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '6', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('yewgz', 'MAXLENGTH', '最大输入数', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '5', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_BIAODYSPZ', 'YAOSCD', '要素长度', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'BAOBBS', '报表标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '0', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSBS', '要素标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSMC', '要素名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'VALUE', '参数值', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSBT', '要素标题', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSCD', '要素长度', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'XIANSLX', '显示类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'SHIFXS', '是否显示', 'string', '文本框', null, null, null, '1', null, '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'XIANSSX', '显示顺序', 'string', '文本框', null, null, null, '1', null, '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'ZHIDBS', '字典标识', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'TARGET', '参数类型', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'DEFAULTVALUE', '默认值', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'REMARK', '备注', 'string', '文本域', null, null, null, '1', ' ', '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('07', 'KEY', '参数编号', 'string', '文本框', null, null, null, '1', ' ', '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('zhidb', 'ZDID', '字典ID', 'string', '文本框', null, null, null, '1', ' ', '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'YAOSGS', '要素格式', 'string', '文本框', null, null, null, '1', null, '1', '0', '0', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('zhidb', 'ZIDMC', '字典名称', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('zhidb', 'ZIDCD', '字典长度', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '4', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('zhidb', 'ZIDLX', '字典类型', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'CANSID', '参数ID', 'string', '文本框', null, null, null, '1', ' ', '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'CANSM', '参数名称', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'CANSLX', '参数类型', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'PARAMETERVALUE', '参数值', 'string', '文本域', null, null, null, '1', ' ', '1', '0', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('bskongzcs', 'TYPE', '参数模块', 'string', '文本框', null, null, null, '1', ' ', '1', '0', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_JIEGYSPZ', 'BEIZ', '备注', 'string', '文本域', null, null, null, '1', null, '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_ZHIDPZ', 'ZHIDBS', '字段标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_ZHIDPZ', 'SUOYZ', '索引值', 'string', '文本框', null, null, null, '1', null, '1', '1', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('R_ZHIDPZ', 'ZHUANHZ', '转换值', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'DPIID', '编号', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'DIQH', '地区号', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'WANGDH', '网点号', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'YEWLX', '业务类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'SECBZ', '色彩标识', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'DPI', 'DPI', 'string', '文本框', null, null, null, '1', null, '1', '0', '6', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('peizdpi', 'TIAOYCS', '调优参数', 'string', '文本框', null, null, null, '1', null, '1', '0', '7', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'JIEDBS', '节点标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSBS', '参数标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSMC', '参数名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSLX', '参数类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSFL', '参数分类', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSZ', '参数值', 'string', '文本框', null, null, null, '1', null, '1', '0', '6', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_jiedcs', 'CANSSM', '参数说明', 'string', '文本框', null, null, null, '1', null, '1', '0', '7', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitjd', 'JIEDBS', '节点标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitjd', 'JIEDMC', '节点名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_yewxt', 'XITBS', '系统标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_yewxt', 'XITMC', '系统名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_yewxt', 'YANZXX', '验证信息', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'XITBS', '系统标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'PINGZBS', '凭证标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'PINGZMC', '凭证名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'ZHAOZQ', '找章区', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'FAZQ', '阀值区', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'YANYJB', '验印级别', 'int', '文本框', null, null, null, '1', null, '1', '0', '6', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'XFENBL', 'X分辨率', 'int', '文本框', null, null, null, '1', null, '1', '0', '7', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'YFENBL', 'Y分辨率', 'int', '文本框', null, null, null, '1', null, '1', '0', '8', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'XSUOF', 'X缩放', 'float', '文本框', null, null, null, '1', null, '1', '0', '9', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_pingzcs', 'YSUOF', 'Y缩放', 'float', '文本框', null, null, null, '1', null, '1', '0', '10', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'XITBS', '系统标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSBS', '参数标识', 'string', '文本框', null, null, null, '1', null, '1', '1', '2', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSMC', '参数名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSLX', '参数类型', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSFL', '参数分类', 'string', '文本框', null, null, null, '1', null, '1', '0', '5', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSZ', '参数值', 'string', '文本框', null, null, null, '1', null, '1', '0', '6', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('ci_xitcs', 'CANSSM', '参数说明', 'string', '文本框', null, null, null, '1', null, '1', '0', '7', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('XITYYGZB', 'xitbh', '系统编号', 'string', '文本框', null, null, null, '1', null, '1', '1', '1', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('XITYYGZB', 'xitmc', '系统名称', 'string', '文本框', null, null, null, '1', null, '1', '0', '2', null);
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('XITYYGZB', 'yanygz', '验印规则', 'string', '文本框', null, null, null, '1', null, '1', '0', '3', '|');
INSERT INTO DANBWHCB (GONGNID, ZIDMC, ZHANSMC, ZIDLX, SHURLX, QUZFW, MORZ, JIAOYGZ, SHIFBC, SHIFBJ, SHIFZX, SHIFZJ, XIANSSX, BEIZ) VALUES ('XITYYGZB', 'beiz', '备注', 'string', '文本框', null, null, null, '1', null, '1', '0', '4', '|');





INSERT INTO DANBWHGXB (ID, ZHUBBH, ZIBBH, ZHUBZD, ZIBZD, SHIFLJZD, ZHIBWHMC) VALUES ('2c2785693d5d27fb013d5d3dc4a60001', 'R_BAOBPZ', 'R_BIAODYSPZ', 'BAOBBS', 'BAOBBS', '1', '表单要素维护');
INSERT INTO DANBWHGXB (ID, ZHUBBH, ZIBBH, ZHUBZD, ZIBZD, SHIFLJZD, ZHIBWHMC) VALUES ('2c2785693d67b426013d67bdb3bc0001', 'R_BAOBPZ', 'R_JIEGYSPZ', 'BAOBBS', 'BAOBBS', '1', '结果要素维护');
INSERT INTO DANBWHGXB (ID, ZHUBBH, ZIBBH, ZHUBZD, ZIBZD, SHIFLJZD, ZHIBWHMC) VALUES ('2c2785693d81e24e013d81f87f900002', 'R_JIEGYSPZ', 'R_ZHIDPZ', 'ZHIDBS', 'ZHIDBS', '0', '字典维护');



INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('R_BAOBPZ', 'Ureport维护', 'R_BAOBPZ', 'doDanbwh.do?method=list&gongnid=R_BAOBPZ', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('R_BIAODYSPZ', 'Ureport表单维护', 'R_BIAODYSPZ', 'doDanbwh.do?method=list&gongnid=R_BIAODYSPZ', '1', '1', '1', '0', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('R_JIEGYSPZ', 'Ureport结果维护', 'R_JIEGYSPZ', 'doDanbwh.do?method=list&gongnid=R_JIEGYSPZ', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('R_ZHIDPZ', 'Ureport字典维护  ', 'R_ZHIDPZ', 'doDanbwh.do?method=list&gongnid=R_ZHIDPZ', '1', '1', '1', '0', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('peizdpi', '配置DPI', 'peizdpi', 'doDanbwh.do?method=list&gongnid=peizdpi', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('yewgz', '业务规则定制', 'yewgz', 'doDanbwh.do?method=list&gongnid=yewgz', '1', '1', '1', null, null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_jiedcs', '节点参数维护', 'ci_jiedcs', 'doDanbwh.do?method=list&gongnid=ci_jiedcs', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_xitjd', '节点信息维护', 'ci_xitjd', 'doDanbwh.do?method=list&gongnid=ci_xitjd', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('07', 'ocx参数控制', 'ocxkongzcsb', 'doDanbwh.do?method=list&gongnid=07', '1', '1', '1', null, null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_yewxt', '系统信息维护', 'ci_yewxt', 'doDanbwh.do?method=list&gongnid=ci_yewxt', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('bskongzcs', '系统控制参数', 'bskongzcs', 'doDanbwh.do?method=list&gongnid=bskongzcs', '1', '1', '1', null, null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_pingzcs', '系统凭证信息维护', 'ci_pingzcs', 'doDanbwh.do?method=list&gongnid=ci_pingzcs', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('ci_xitcs', '系统参数信息维护', 'ci_xitcs', 'doDanbwh.do?method=list&gongnid=ci_xitcs', '1', '1', '1', '1', null);
INSERT INTO DANBWHZB (GONGNID, GONGNMC, WEIHBM, GONGNURL, SHIFBC, SHIFBJ, SHIFSC, SHIFZB, ZHIDYL) VALUES ('XITYYGZB', '系统验印规则维护', 'XITYYGZB', 'doDanbwh.do?method=list&gongnid=XITYYGZB', '1', '1', '1', '1', null);





insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('001', '人民币', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('012', '英镑', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('013', '港币', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('014', '美元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('015', '瑞士法郎', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('018', '新加坡元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('027', '日元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('028', '加元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('029', '澳元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('038', '欧元', null);
insert into HUOBB (HUOBBH, HUOBMC, BEIZ) values ('088', '韩元', null);





set define off
insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isshowautotip', '否', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealUploadMode', '1', '系统', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsSetSmallCount', '是', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('infochekedstate', '已审', '审核', '已审', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isautobsealcheck', '1', '批量验印', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifkzzhxx', '是', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isautoinfocheck', '1', '审核', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifkzyjxx', '是', '印鉴', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifkzzuhxx', '是', '组合', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shiysmorpy', 'shaom', '系统', 'shaom', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealcolor', '2', '验印', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyydgsz', '√', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyywgsz', '×', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyywysz', '×', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyydgzt', 'Verdana', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyywgdx', '40', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyydgdx', '30', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyywyzt', 'Verdana', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyywgzt', 'Verdana', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyywgys', 'Gray', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyydgys', 'Green', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyywydx', '40', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjyywyys', 'Gray', '验印印鉴', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjzdzzsz', '已增加', '自动找章', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjzdzzys', 'Blue', '自动找章', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjzdzzdx', '15', '自动找章', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjzdzzzt', 'Verdana', '自动找章', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('jiankzsfs', '1|2|3|4|5', '印鉴展示', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shenhzsfs', '1|2|3|4|5|6', '印鉴展示', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yanyzsfs', '1|2|3|6', '印鉴展示', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('pilyyzsfs', '1|2|3|4|6', '印鉴展示', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('zidzzzsfs', '1|7', '印鉴展示', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('attributetime', '2012-08-15 19:04:41', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjbhzt', 'Verdana', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjbhdx', '10', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjlxys', 'Black', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('piaoyingstart', '是', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isrebuildgroupsvisible', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('saomiaosave', '否', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjsjzt', 'Verdana', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifzdzz', '是', '建库', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjsjdx', '10', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjsjys', 'Green', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjlxdx', '10', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjlxzt', 'Verdana', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjbgdx', '10', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjbgzt', 'Verdana', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjbgys', 'Red', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('dpifordb', '300', '建库', '300', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('YY_008', '200', '验印', '300', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealcheckgrade', '75', '验印', '50', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealcheckresultmodel', '0', '验印', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealbackcolor', '0', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifkzyyxx', '是', '验印', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sysconfigtime', '2013-03-14 17:22:17', '系统', '默认值', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('zhanghwssfky', '是', '验印', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('zuhwssfky', '是', '验印', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjwssfky', '是', '验印', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjbhys', 'Blue', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifjejc', '否', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifqyfileup', '否', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifqymorehint', '是', '系统', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifqyprint', '否', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('bingxq', '10', '系统', '10', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjbgjjrsy', '0', '印鉴', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjfyandx', '20', '印鉴列表', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('yinjzskjkk', '135', '印鉴列表', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('FileSeverIp', '192.168.1.73', '系统', '192.168.1.148', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('FileSeverPort', '7004', '系统', '7004', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifbillinfofirst', '否', '系统', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('gfrfile', 'Scheme\Scheme.gfr', '系统', 'Scheme\Scheme.gfr', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('dbms_tonggl', '90', 'dbms', '90', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('dbms_shibl', '95', 'dbms', '95', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isuseprint', '否', '验印', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('issealsmall', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealsmallcount', '13', '账户', '13', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('PiaoYingDoubleExposure', '是', '系统', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifqyLagDelete', '3', '滞后删除', '3', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isautosealcheck', '1', '验印', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('dbms_type', '0', 'dbms', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('zuhbgjjrsy', '1', '组合', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('pingzyxq', '10', '验印', '10', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('shifpzyxqjjrsy', '是', '验印', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993Deletedoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993Freezedoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993Reportdoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993Sealinfodoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99990Infocheckdoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('CameraType', '2', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ScanType', '5', '系统', '2', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealresulttype', '23', '系统', '23', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('resultforecolor', 'Black', '系统', 'Blue', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('resultbackcolor', 'White', '系统', 'White', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('maskforecolor', 'Blue', '系统', 'Yellow', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('maskbackcolor', 'Black', '系统', 'Black', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealforecolornormal', 'Red', '系统', 'Red', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealbackcolornormal', 'White', '系统', 'White', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealforecolorpass', 'Lime', '系统', 'Red', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealbackcolorpass', 'White', '系统', 'Lime', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealforecolornotpass', 'Black', '系统', 'Red', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealbackcolornotpass', 'White', '系统', 'Black', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('dabms', '0', '验印', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('maxgrade', '100', '验印', '100', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('mingrade', '1', '验印', '100', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealBorderSelColor', 'Black', '系统', 'Black', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealBorderDefColor', 'Blue', '系统', 'Blue', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('pingzlxdefault', '0', '验印', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isAccountInfoModify', '1', '账户', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993AccountInfodoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isYinJInfoModify', '1', '账户', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isGroupSealModify', '1', '账户', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993GroupSealdoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('deljjrsy', '3', '滞后删除', '3', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsdelDateModify', '是', '滞后删除', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isusebanktrans', '1', '验印', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBDFlag', '1', '验印', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBCFrameFlag', '1', '验印', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBCStarFlag', '1', '验印', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBCBigCharFlag', '1', '验印', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ICBCSmallCharFlag', '1', '验印', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ocrserverip', '172.167.7.122', '系统', '192.168.1.149', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ocrserverport', '5868', '系统', '5868', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('kaihzhshzt', '未审', '账户', '未审', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('xiugzlzhshzt', '已审', '账户', '已审', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('groupbing', '&', '组合', '&', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('grouphuo', '|', '组合', '|', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('jiankyjshzt', '未审', '账户', '未审', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('infochecktype', '10|20|21', '验印', '20', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealchecktype', '10|20|21', '验印', '20', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993InfoModifyDoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('DoubleCheckMode', '0', '系统', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993InfoChangeDoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993InfoRebuildDoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('jkshifqyfileup', '否', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('jkFileSeverIp', '10.11.162.102:7005', '系统', '192.168.217.128:7005', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ischangesealsvisible', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isOneGongzhang', '是', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('InfoCheckFileSeverIp', '172.167.1.133:7001', '系统', '192.168.1.148', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealCheckFileSeverIp', '172.167.1.133:7001', '系统', '192.168.1.148', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('InfoCheckshifqyfileup', '否', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealCheckshifqyfileup', '否', '系统', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealCheckDPI', '200', '系统', '200', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('InfoCheckDPI', '200', '系统', '200', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('infocheckshifqyreadbill', '否', '审核', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('sealcheckshifqyreadbill', '否', '验印', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ischangegroupsvisible', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isrebuildsealsvisible', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('typeforsanse', '0', '验印', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('usecontogether', '是', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('ocrdllpath', 'DLL\OCRDLL', '账户', 'DLL\OCRDLL', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('identifyType_zhgl', '4', '账户', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('identifyType_zhsh', '4', '审核', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('identifyType_zhyy', '4', '验印', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isOpenFileButton_J', '否', '开户', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isScanButton_J', '否', '开户', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isOpenFileButton_P', '否', '开户', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isScanButton_P', '否', '开户', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('99993InfoModifyAlwaysDoublecheck', '否', '账户', '是', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsSideSealOpen', '否', '账户', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('accountpartial', '1', '账户', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isInfoCheckManualable', '1', '系统', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsUseFileServer', '0', '验印接口', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('FileServerIP', '10.11.162.102', '验印接口', '10.11.162.102', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('FileServerPort', '7005', '验印接口', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealCreateShowName', '建库', 'I账户管理', '保存', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('maxSmallLen', '25', 'I账户管理', '20', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isReUseYinjkbh', '是', 'I账户管理', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('CodeScore', '80', '系统', '100', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsShowNotpassReason', '是', '系统', '否', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('IsAssiCheckDoubleCheck', '0', '验印接口', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('btnNameOnNotpass', '退回', '审核接口', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('DoubleCheckMoney', '0', '验印接口', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isSaveAotuNotpass', '0', '验印接口', '1', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('SealLengthVissible', '0', 'I账户管理', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('AutoSearchMode', '1', 'I账户管理', '0', null);

insert into ocxkongzcsb (KEY, VALUE, TARGET, DEFAULTVALUE, REMARK)
values ('isGetYinjkxx', '1', 'I账户管理', '0', null);



/*
insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('87', '授权双签', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('40', '账户查询', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('41', '日志查询', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('42', '统计分析', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('43', '系统管理', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('44', '特殊业务', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('50', '账户管理', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('51', '账户审核', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('52', '印签验印', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('53', '账户简单查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('54', '客户简单查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('55', '账户高级查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('56', '未审核清单查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('57', '验印结果当日查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('58', '验印日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('59', '账户日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('60', '管理员日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('61', '机构管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('62', '基本岗位管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('63', '详细岗位管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('64', '柜员管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('65', '通存通兑管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('66', '节假日管理', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('67', '销户恢复', null, null, '44');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('68', '账户物理删除', null, null, '44');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('70', '账户数量统计', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('74', '账户验印通过率统计', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('76', '凭证参数设置', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('77', '清楚柜员IP限制', null, null, '43');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('78', '省行机构通过率排名', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('79', '二级分行通过率排名', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('80', '机构通过率排名', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('81', '账号通过率排名', null, null, '42');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('82', '账户信息定制查询', null, null, '40');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('83', '验印日志定制查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('84', '机构凭证日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('85', '批量验印', null, null, '0');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('86', '凭证验印日志查询', null, null, '41');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('PLYY_001', '单章通过', null, null, '85');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('PLYY_002', '单章不通过', null, null, '85');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('QTYY_001', '单章通过', null, null, '52');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('QTYY_002', '单章不通过', null, null, '52');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_001', '开户', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_005', '修改资料', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_006', '新增印章', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_007', '新增签字', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_008', '本地影像', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_009', '采集影像', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_010', '删除印鉴', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_011', '新增组合', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_012', '删除组合', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHSH_001', '审核通过', null, null, '51');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHSH_002', '审核不通过', null, null, '51');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHSH_003', '印鉴通过', null, null, '51');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHSH_004', '印鉴不通过', null, null, '51');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_014', '重建', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_015', '变更', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_016', '二维码识别', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_017', 'OCR识别', null, null, '50');

insert into QUANXB (QUANXID, QUANXMC, QUANXMS, BEIZ, SHANGJQX)
values ('ZHGL_019', '自动找章', null, null, '50');

*/




insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('0009', '账户同步查询', '账户同步查询', '是', null, 25, null, null, null, null, 'accountinfo', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('002', '账户高级查询', '账户高级查询', '是', null, 25, null, null, null, null, 'zhanghb', 'com.sinodata.user.ZhanghugjcxImpl');

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('003', '账户通过率排名', '账户通过率排名', '是', null, 25, null, null, null, null, '(SELECT  ROWNUM,A.* FROM (select * from zhanghtgl) A order by A.Tonggl desc) ', 'com.sinodata.user.TongglForZhanghImpl');

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('004', '机构通过率排名', '机构通过率排名', '是', null, 25, null, null, null, null, '(SELECT  ROWNUM,A.* FROM (select * from jigtgl) A order by A.Tonggl desc) ', 'com.sinodata.user.TongglForjigImpl');

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('005', '账户审核查询', '账户审核查询', '是', '是', 25, '是', null, '是', null, 'zhanghb', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('006', '实物风险跟踪', '风险跟踪记录', '是', null, 25, null, null, null, null, '(select RENWBS, ZHANGH, JIGH, HUM, case RENWLX when ''0'' then ''放卡'' else ''取卡''end as RENWLX, RENWRQ, RENWSJ, YINJKS,case YEWLX when ''0'' then ''开户'' when ''1'' then ''变更'' when ''2'' then ''查阅'' else ''归还''end as YEWLX, RENWZT, GUIY, CAOZRQ, CAOZSJ, ZUOB from kagrw)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('009', '客户号查询', '客户号查询', '是', null, 25, null, null, null, null, 'zhanghb', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('13000', '重空凭证 - 大库余额明细查询', '查询结果列表', '是', null, 25, null, null, null, null, '(select k.jigh,p.pingzmc as pingzlx,k.zongs,k.yilzs,k.shengyzs,k.zuofzs from pingzkcsyb k,pingzpzb p where k.pingzlx=p.pingzbs)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('13001', '重空凭证 - 机构余额明细查询', '查询结果列表', '是', null, 25, null, null, null, null, '(select j.jigh,p.pingzmc as pingzlx,j.yilzs,j.shengyzs,j.zuofzs from pingzjgsyb j,pingzpzb p where j.pingzlx=p.pingzbs)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('13008', '重空凭证 - 柜员余额明细查询', '查询结果列表', '是', null, 25, null, null, null, null, '(select c.lingyjg,c.guiyh,c.pingzlx ,c.a as yilzs,c.b as zuofzs,case when c.a-c.b>0 then to_number(c.a-c.b) else 0 end as shengyzs from (select g.lingyjg,g.guiyh,p.pingzmc as pingzlx,sum(case g.pingzzt when ''已领'' then 1 else 0 end)as a ,sum(case g.pingzzt when ''作废'' then 1 else 0 end)as b from pingzgcb g,pingzpzb p where g.pingzlx=p.pingzbs group by p.pingzmc,g.guiyh,g.lingyjg)c)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('clerktable', '查询柜员信息', '查询柜员信息', '是', null, 25, null, null, null, null, 'clerktable', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('huizong_cx', '汇总查询', '汇总查询', '是', null, 25, null, null, null, null, '(select zhangh,guiyh clerknum,jigh organnum,pingzlx,riq,hum,qispzh,zhongzpzh,bens,zhangs,shij,pich from pingzcshz)', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('pingz_01', '凭证日志追踪', '凭证日志追踪', '是', null, 25, null, null, null, null, 'pingzcsmx', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('u_danz', '接口单章日志查询', '接口单章日志列表', '是', null, 25, null, null, null, null, 'ci_yyrz', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('u_jiek', '接口整票日志查询', '接口整票日志列表', '是', null, 25, null, null, null, null, 'ci_renwxx', null);

insert into R_BAOBPZ (BAOBBS, BAOBMC, BAOBBT, SHIFKY, SHIFFY, FENYTJ, SHIFDY, DAYFA, SHIFSC, SHUCFA, SHUJHQFS, ZHIDYL)
values ('yinjkdjb', '管理印鉴卡日志查询', '管理印鉴卡日志查询', '是', null, 25, null, null, null, null, '(select * from YINJKDJB order by zhangh,caozrq desc,caozsj desc)', 'com.sinodata.user.YinjkrzcxImpl');





insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'PINGZLX', 'PINGZLX', '凭证类型', '动态多选框', '是', null, '4', null, null, 'string', null, 'select  pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'JIGH1', 'JIGH', '是否包含下级', '子集输入', '是', null, '2', null, null, 'string', null, 'SELECT

organnum  FROM TABLE(ORGFUNCTION(?)) AS A');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'guiyh', 'GUIYH', '柜员号', '文本输入', '否', null, '3', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_danz', 'yanyjg', 'YANYJG', '验印结果', '静态多选框', '是', null, '4', null, null, 'string', null, '通过=通过|未过=未过|未验=未验|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('002', 'JIGH', 'JIGH', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('002', 'YOUWYJ', 'YOUWYJ', '印签标志', '静态多选框', '否', null, '4', null, null, 'string', null, '有=有|无=无');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('002', 'ZHANGHZT', 'ZHANGHSHZT', '账户审核状态', '静态多选框', '否', null, '5', null, null, 'string', null, '已审=已审|未审=未审');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('002', 'begindate', 'KAIHRQ', '开户日期', '日期范围', '否', null, '7', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('003', 'JIGH', 'JIGH', '机构号', '回显输入', '是', null, '2', null, null, 'string', null, 'select organname from organarchives where organnum =?');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('003', 'LEIX', 'LEIX', '统计类型', '静态多选框', '是', null, '3', null, null, 'string', null, '单章=章|整票=票|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('003', 'RIQFW', 'RIQFW', '统计时间', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('004', 'JIGH1', 'JIGH', '是否查看明细', '子集输入', '是', null, '3', null, null, 'string', null, 'SELECT organnum  FROM TABLE(ORGFUNCTION(?)) AS A');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('004', 'LEIX', 'LEIX', '统计类型', '静态多选框', '是', null, '4', null, null, 'string', null, '单章=章|整票=票|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('004', 'RIQFW', 'RIQFW', '统计时间', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('004', 'JIGH', 'JIGH', '机构号', '回显输入', '是', null, '2', null, null, 'string', null, 'select organname from organarchives where organnum =?');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'JIGH', 'JIGH', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'YINJSHZT', 'YINJSHZT', '印鉴审核状态', '静态多选框', '是', null, '3', null, null, 'string', null, '已审=已审|未审=未审|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'ZHANGHZT', 'ZHANGHSHZT', '账户审核状态', '静态多选框', '是', null, '4', null, null, 'string', null, '已审=已审|未审=未审|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('005', 'ZUHSHZT', 'ZUHSHZT', '组合审核状态', '静态多选框', '是', null, '5', null, null, 'string', null, '已审=已审|未审=未审|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('009', 'KEHH', 'KEHH', '客户号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('111', 'jigh', 'JIGH', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('111', 'zhanghzt', 'ZHANGHZT', '账户状态', '静态多选框', '是', null, '2', null, null, 'string', null, '有效=有效|销户=销户|冻结=冻结|挂失=挂失|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('JH_001', '001_0', 'N_ORGANNUM', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_jiek', 'renwbs', 'renwbs', '任务标识', '文本输入', '否', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_jiek', 'renwrq', 'RENWRQ', '任务日期', '日期范围', '是', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_jiek', 'yanyjg', 'YANYJG', '验印结果', '静态多选框', '是', null, '4', null, null, 'string', null, '通过=通过|未过=未过|未验=未验|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_jiek', 'yanyms', 'YANYMS', '验印模式', '静态多选框', '是', null, '3', null, null, 'string', null, '自动=自动|辅助=辅助|人工=人工|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'zhangh', 'ZHANGH', '账号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'jigh', 'JIGH', '机构号', '文本输入', '否', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_danz', 'renwbs', 'RENWBS', '任务标识', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_danz', 'xitbs', 'XITBS', '系统标识', '文本输入', '是', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'RIQ', 'RIQ', '出售日期', '日期范围', '是', null, '5', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'organnum', 'ORGANNUM', '机构号', '文本输入', '否', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'PINGZLX', 'PINGZLX', '凭证类型', '动态多选框', '是', null, '4', null, null, 'string', null, 'select  pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'RIQ', 'RIQ', '出售日期', '日期范围', '是', null, '6', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'zhangh', 'ZHANGH', '账号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('pingz_01', 'ZHUANGT', 'ZHUANGT', '凭证状态', '静态多选框', '是', null, '5', null, null, 'string', null, '已打印=已打印|未打印=未打印|已作废=已作废|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('u_danz', 'yanyms', 'YANYMS', '验印模式', '静态多选框', '是', null, '3', null, null, 'string', null, '自动=自动|辅助=辅助|人工=人工|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('huizong_cx', 'clerknum', 'CLERKNUM', '柜员号', '文本输入', '否', null, '3', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('clerktable', 'orgcode', 'n_organnum', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('clerktable', 'clerknum', 'clerknum', '柜员号', '文本输入', '否', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('0009', 'jigh', 'jigh', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('0009', 'daorsj', 'daorsj', '导入时间', '日期范围', '是', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('0009', 'chengbz', 'chengbz', '成功标志', '静态多选框', '是', null, '3', null, null, 'string', null, '成功=成功|失败=成功|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('0009', 'daorlx', 'daorlx', '导入类型', '静态多选框', '是', null, '4', null, null, 'string', null, '开户=开户|销户=销户|');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13001', 'jigh', 'jigh', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13001', 'pingzlx', 'pingzlx', '凭证类型', '动态多选框', '是', null, '2', null, null, 'string', null, 'select pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13000', 'pingzlx', 'pingzlx', '凭证类型', '动态多选框', '是', null, '2', null, null, 'string', null, 'select pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13008', 'pingzlx', 'pingzlx', '凭证类型', '动态多选框', '是', null, '3', null, null, 'string', null, 'select pingzmc key,pingzmc name from pingzpzb');

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('006', 'zhangh', 'ZHANGH', '账号', '文本输入', '是', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13008', 'lingyjg', 'lingyjg', '机构号', '文本输入', '否', null, '1', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13008', 'guiyh', 'guiyh', '柜员号', '文本输入', '是', null, '2', null, null, 'string', null, null);

insert into R_BIAODYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSLX, SHIFBT, MOYZ, XIANSSX, ZHIDBS, YAOSHW, YAOSGS, YAOSCD, BEIZ)
values ('13000', 'jigh', 'jigh', '机构号', '文本输入', '是', null, '1', null, null, 'string', null, null);








insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('009', 'JIGH', 'jigh', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('111', 'zhangh', 'zhangh', '账号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'WDFLAG', 'WDFLAG', 'WDFLAG', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_UPDATEDATE', 'N_UPDATEDATE', 'N_UPDATEDATE', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('111', 'jigh', 'jigh', '机构号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('111', 'zhanghzt', 'zhanghzt', '账户状态', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('111', 'kehh', 'kehh', '客户号', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'CLERKPWD', 'CLERKPWD', 'CLERKPWD', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('009', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'wdflag', 'wdflag', '网点标识', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('009', 'KEHH', 'kehh', '客户号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('009', 'YOUWYJ', 'youwyj', '有无印鉴', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('005', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('005', 'YINJSHZT', 'yinjshzt', '印鉴审核状态', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'ZONGS', 'zongs', '验印总笔数', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('005', 'ZUHSHZT', 'zuhshzt', '组合审核状态', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('005', 'ZHANGHSHZT', 'zhanghshzt', '账户资料审核状态', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'JIGH', 'jigh', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'LEIX', 'leix', '统计类型', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'ZID', 'zid', '自动验印总笔数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'FUZ', 'fuz', '辅助验印总笔数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'RENG', 'reng', '人工验印总笔数', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'TONGGL', 'tonggl', '通过率(%)', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'ROWNUM', 'rownum', '排名', null, '普通显示', '是', '-1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('003', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '0', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'ROWNUM', 'rownum', '排名', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'JIGH', 'jigh', '机构号', null, '报表链接', '是', '2', null, 'string', 'reportService.do?method=exeReport&baobbs=004&JIGH=');

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'LEIX', 'leix', '统计类型', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'ZONGS', 'zongs', '验印总笔数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'ZID', 'zid', '自动验印总笔数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'FUZ', 'fuz', '辅助验印总笔数', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('004', 'TONGGL', 'tonggl', '通过率(%)', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_ORGANNUM', 'N_ORGANNUM', 'N_ORGANNUM', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'RENWRQ', 'RENWRQ', 'RENWRQ', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH2', 'ZHANGH2', 'ZHANGH2', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'CHULGY', 'CHULGY', 'CHULGY', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'PINGZH', 'PINGZH', 'PINGZH', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'CHULRQ', 'CHULRQ', 'CHULRQ', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH', 'ZHANGH', 'ZHANGH', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'XITLX', 'XITLX', 'XITLX', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH3', 'ZHANGH3', 'ZHANGH3', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'WEIGYY', 'WEIGYY', 'WEIGYY', null, '普通显示', '是', '9', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'HUIZSJ', 'HUIZSJ', 'HUIZSJ', null, '普通显示', '是', '10', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'FAZQ', 'FAZQ', 'FAZQ', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'JINE', 'JINE', 'JINE', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YANYMS', 'YANYMS', 'YANYMS', null, '普通显示', '是', '13', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YFENBL', 'YFENBL', 'YFENBL', null, '普通显示', '是', '14', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'TUXSY', 'TUXSY', 'TUXSY', null, '普通显示', '是', '15', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHAOZQ', 'ZHAOZQ', 'ZHAOZQ', null, '普通显示', '是', '16', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'WENJM', 'WENJM', 'WENJM', null, '普通显示', '是', '17', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'FAQSJ', 'FAQSJ', 'FAQSJ', null, '普通显示', '是', '18', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YANYJG', 'YANYJG', 'YANYJG', null, '普通显示', '是', '19', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'XITBS', 'XITBS', 'XITBS', null, '普通显示', '是', '20', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'CHULZT', 'CHULZT', 'CHULZT', null, '普通显示', '是', '21', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YEWTZ1', 'YEWTZ1', 'YEWTZ1', null, '普通显示', '是', '22', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'CHUPRQ', 'CHUPRQ', 'CHUPRQ', null, '普通显示', '是', '23', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH4', 'ZHANGH4', 'ZHANGH4', null, '普通显示', '是', '24', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'XFENBL', 'XFENBL', 'XFENBL', null, '普通显示', '是', '25', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'YANYJB', 'YANYJB', 'YANYJB', null, '普通显示', '是', '26', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'PINGZBS', 'PINGZBS', 'PINGZBS', null, '普通显示', '是', '27', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'RENWBS', 'RENWBS', 'RENWBS', null, '普通显示', '是', '28', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'TONGGZH', 'TONGGZH', 'TONGGZH', null, '普通显示', '是', '29', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'ZHANGH1', 'ZHANGH1', 'ZHANGH1', null, '普通显示', '是', '30', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_jiek', 'JIEDBS', 'JIEDBS', 'JIEDBS', null, '普通显示', '是', '31', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'n_organnum', 'n_organnum', '机构号', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'shenghjgh', 'shenghjgh', '省行机构号', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'n_ip', 'n_ip', '锁定IP', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'n_creator', 'n_creator', '创建机构', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'clerkname', 'clerkname', '柜员名称', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'n_logdate', 'n_logdate', '登录日期', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('0009', 'zhangh', 'zhangh', '帐号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'CLERKNUM', 'clerknum', '柜员号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'HUM', 'hum', '户名', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'ORGANNUM', 'organnum', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'RIQ', 'riq', '日期', null, '普通显示', '是', '10', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'ZHONGZPZH', 'zhongzpzh', '终止凭证号', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'ZHANGS', 'zhangs', '张数', null, '普通显示', '是', '9', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'SHIJ', 'shij', '时间', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'QISPZH', 'qispzh', '起始凭证号', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'PINGZLX', 'pingzlx', '凭证类型', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('huizong_cx', 'PICH', 'pich', '查看明细', null, '链接显示', '是', '90', null, 'string', 'pingz.do?method=getPingzListByPich&pich=');

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'GUIYH', 'guiyh', '柜员号', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'HUM', 'hum', '户名', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'JIGH', 'jigh', '机构号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'PINGZH', 'pingzh', '追踪日志', null, '链接显示', '是', '33', null, 'string', 'pingz.do?method=getPingzMxRizListByPich&pingzh=');

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'PINGZLX', 'pingzlx', '凭证类型', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'RIQ', 'riq', '日期', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'SHIJ', 'shij', '时间', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('pingz_01', 'ZHANGH', 'zhangh', '账号', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'CLERKNAME', 'clerkname', '柜员名称', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'SHENGHJGH', 'SHENGHJGH', 'SHENGHJGH', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'HENGXZB', 'HENGXZB', 'HENGXZB', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'RENWRQ', 'RENWRQ', 'RENWRQ', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YINJBZ', 'YINJBZ', 'YINJBZ', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YINJBH', 'YINJBH', 'YINJBH', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YANYJG', 'YANYJG', 'YANYJG', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'CHULGY', 'CHULGY', 'CHULGY', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'SHANGBJ', 'SHANGBJ', 'SHANGBJ', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'XITBS', 'XITBS', 'XITBS', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'CHULRQ', 'CHULRQ', 'CHULRQ', null, '普通显示', '是', '9', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'CHULSJ', 'CHULSJ', 'CHULSJ', null, '普通显示', '是', '10', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'ZHANGH', 'ZHANGH', 'ZHANGH', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'XITLX', 'XITLX', 'XITLX', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YINQBGH', 'YINQBGH', 'YINQBGH', null, '普通显示', '是', '13', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YINZJD', 'YINZJD', 'YINZJD', null, '普通显示', '是', '14', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YANYMS', 'YANYMS', 'YANYMS', null, '普通显示', '是', '15', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'RENWLX', 'RENWLX', 'RENWLX', null, '普通显示', '是', '16', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'RENWBS', 'RENWBS', 'RENWBS', null, '普通显示', '是', '17', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'SHUXZB', 'SHUXZB', 'SHUXZB', null, '普通显示', '是', '18', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'YOUBJ', 'YOUBJ', 'YOUBJ', null, '普通显示', '是', '19', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'ZUOBJ', 'ZUOBJ', 'ZUOBJ', null, '普通显示', '是', '20', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'XIABJ', 'XIABJ', 'XIABJ', null, '普通显示', '是', '21', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('u_danz', 'JIEDBS', 'JIEDBS', 'JIEDBS', null, '普通显示', '是', '22', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('clerktable', 'CLERKNUM', 'clerknum', '柜员号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('0009', 'jigh', 'jigh', '机构号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('0009', 'hum', 'hum', '户名', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('0009', 'cgbz', 'cgbz', '成功标志', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'jigh', 'jigh', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'pingzlx', 'pingzlx', '凭证类型', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'zongs', 'zongs', '总数', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'yilzs', 'yilzs', '已领张数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'shengyzs', 'shengyzs', '剩余张数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13000', 'zuofzs', 'zuofzs', '作废张数', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'jigh', 'jigh', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'pingzlx', 'pingzlx', '凭证类型', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'yilzs', 'yilzs', '已领张数', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'shengyzs', 'shengyzs', '剩余张数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13001', 'zuofzs', 'zuofzs', '作废张数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'renwlx', 'renwlx', '任务类型', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'zhangh', 'zhangh', '账号', null, '普通显示', '是', '0', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'hum', 'hum', '户名', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'caozrq', 'caozrq', '操作日期', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'caozsj', 'caozsj', '操作时间', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'yewlx', 'yewlx', '业务类型', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('006', 'guiy', 'guiy', '操作柜员', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'lingyjg', 'lingyjg', '机构号', null, '普通显示', '是', '1', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'guiyh', 'guiyh', '柜员号', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'pingzlx', 'pingzlx', '凭证类型', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'shengyzs', 'shengyzs', '剩余张数', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'yilzs', 'yilzs', '已领张数', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('13008', 'zuofzs', 'zuofzs', '作废张数', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'CLERKNUM', 'CLERKNUM', 'CLERKNUM', null, '普通显示', '是', '6', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'POSTNUM', 'POSTNUM', 'POSTNUM', null, '普通显示', '是', '7', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_IP', 'N_IP', 'N_IP', null, '普通显示', '是', '8', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'POSTNAME', 'POSTNAME', 'POSTNAME', null, '普通显示', '是', '9', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_CREATOR', 'N_CREATOR', 'N_CREATOR', null, '普通显示', '是', '10', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'CLERKNAME', 'CLERKNAME', 'CLERKNAME', null, '普通显示', '是', '11', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_LOGDATE', 'N_LOGDATE', 'N_LOGDATE', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('1', 'N_ERROR', 'N_ERROR', 'N_ERROR', null, '普通显示', '是', '13', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'KAIHRQ', 'kaihrq', '开户日期', null, '普通显示', '是', '5', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'KEHH', 'kehh', '客户号', null, '普通显示', '是', '4', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'HUM', 'hum', '户名', null, '普通显示', '是', '2', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'YOUWYJ', 'youwyj', '有无印鉴', null, '普通显示', '是', '9', '001', 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'YOUWZH', 'youwzh', '有无组合', null, '普通显示', '是', '10', '002', 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'ZHANGHSHZT', 'zhanghshzt', '账户审核状态', null, '普通显示', '是', '12', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'JIGH', 'jigh', '机构号', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'diz', 'diz', '地址', null, '普通显示', '是', '3', null, 'string', null);

insert into R_JIEGYSPZ (BAOBBS, YAOSBS, YAOSMC, YAOSBT, YAOSCD, XIANSLX, SHIFXS, XIANSSX, ZHIDBS, YAOSGS, BEIZ)
values ('002', 'zhangh', 'zhangh', '账户', null, '普通显示', '是', '1', null, 'string', null);







insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('diz', '1', '60', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('hum', '1', '60', '@inside[EmptyValidator]|', null, '户名不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('beiz', '1', '100', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('jigh', '3', '9', '@inside[CompareLength]|<=,9', null, '机构号不为6位');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('jine', '8', '13', '@inside[EmptyValidator]|', null, '金额不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('kehh', '3', '15', '@inside[CompareLength]|<=,15', null, '客户号不为10位');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('dianh', '6', '13', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('huobh', '2', '5', null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetHuobhResource', '|获取货币失败|号');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('qiyrq', '4', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('xitlx', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetXitlxResource', '|获取系统类型失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zuhgz', '1', '100', '@inside[EmptyValidator]|', null, '组合规则不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('bingxq', '1', '2', null, '$10,30', '|获取并行期失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('jinesx', '10', '13', '@inside[EmptyValidator]|', null, '金额上限不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('jinexx', '10', '13', '@inside[EmptyValidator]|', null, '金额下限不能为空');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('kaihrq', '4', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('lianxr', '1', '20', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('pingzh', '3', '10', '@inside[LengthValidator]|10', null, '凭证号不为10位');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('pofish', '-1', '-1', null, '$peryu,peryu1,peryu2,peryu3', null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('yinjlx', '-1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetYinjlxResource', '|获取印鉴类型失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('yinjys', '-1', null, null, '$红色,蓝色,其它', '|获取印鉴颜色失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('youzbm', '2', '6', '@inside[LengthValidator]|6', null, '邮政编码不为6位');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zhangh', '2', '30', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('pingzlx', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetPingzlxResource]|', '|获取凭证类型失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('shancrq', '5', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('tongctd', '1', '4', null, '$是,否', '|获取通存通兑失败|');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('yinjkbh', '3', '10', '@inside[CompareLength]|<=,10', null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('yinjbgh', '1', '2', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zhanghxz', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetZhanghxzResource', null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('chuprq', '4', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zhuzh', '2', '25', '@inside[CompareLength]|>=,12@inside[CompareLength]|<=,25', null, '主账号长度不正确，12~25');

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('daxx', '1', null, null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zuhzt', null, null, null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zuhshzt', null, null, null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('zhanghzt', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][GetDataResource]|GetZhanghztResource', null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('tingyrq', '4', null, null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('fuyrq', '4', '10', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('guiyh', '3', '7', null, null, null);

insert into SHUXKZB (SHUXM, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX)
values ('guiymm', '9', '6', null, null, null);





insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhanghxz', '账户详情', '账户类别', '是', '1', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('lianxr', '账户详情', '联系人', '否', '14', null, '否', '1', null, null, '@inside[CompareLength]|<=,20', null, '最大只能输入10个汉字或20个字母', '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('huobh', '账户详情', '货币号', '否', '6', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('dianh', '账户详情', '电话', '否', '15', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('beiz', '账户详情', '备注', '是', '16', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '账户详情', '账号', '是', '2', null, '是', '1', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('kehh', '账户详情', '客户号', '是', '4', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('hum', '账户详情', '户名', '是', '3', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jigh', '账户详情', '机构号', '是', '5', '#Inside[GetInitDefault]|S[guiyjgh]', '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('diz', '账户详情', '地址', '否', '13', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('youzbm', '账户详情', '邮政编码', '否', '15', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('kaihrq', '账户详情', '开户日期', '是', '10', '#Inside[GetDefaultTime]|', '否', '1', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '账户详情', '启用日期', '否', '11', '#Inside[GetDefaultTime]|', '否', '1', null, null, '@inside[CompareValidator]|>=,2,C[kaihrq]@inside[CompareValidator]|%,3,C[kaihrq]', null, '启用日期不能小于开户日期并且时间间隔不能超过3个月', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tongctd', '账户详情', '通存通兑', '是', '9', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('bingxq', '账户详情', '并行期', '否', '9', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('fuyrq', '账户详情', '复用日期', '否', '12', null, '否', '1', null, null, '@inside[CompareValidator]|>=,2,C[kaihrq]@inside[CheckFuyrq]|C[zhuzh]', null, '复用日期不能早于开户日期', '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhuzh', '账户详情', '主账号', '否', '2', null, '是', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][CheckZhuzh]|C[zhangh]', null, '主账号校验失败', '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhanghzt', '账户详情', '账户状态', '是', '8', null, '否', '1', null, null, null, null, null, '2', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '账户详情', '停用日期', '否', '11', null, '否', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjbh', '印鉴信息', '印鉴编号', '是', '2', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjkbh', '印鉴信息', '印鉴卡编号', '是', '1', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '印鉴信息', '停用日期', '是', '4', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhanghxz', '账户', '账户类别', '是', '1', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('lianxr', '账户', '联系人', '否', '14', null, '否', '1', null, null, '@inside[CompareLength]|<=,20', null, '最大只能输入10个汉字或20个字母', '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('huobh', '账户', '货币号', '否', '6', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('dianh', '账户', '电话', '否', '15', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('beiz', '账户', '备注', '是', '16', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjlx', '印鉴', '印鉴种类', '是', '3', null, '是', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjys', '印鉴', '印鉴颜色', '是', '4', null, '是', '2', null, null, null, '$红色,蓝色,黑色', null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '印鉴', '启用日期', '是', '5', '#Inside[GetDefaultTime]|', '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('shancrq', '印鉴', '删除日期', '否', '6', null, '是', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjkbh', '印鉴', '印鉴卡号', '是', '1', null, '是', '1', null, null, null, null, null, '1', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jinexx', '组合', '金额下限', '是', '3', '0', '否', '1', null, '16', '@inside[CompareValidator]|<=,0,c[jinesx]', null, '金额下限必须小于金额上限||获取金额下限失败', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jinesx', '组合', '金额上限', '是', '4', '9999999999', '否', '1', null, '16', '@inside[CompareValidator]|>=,0,c[jinexx]', null, '金额上限必须大于金额下限||获取金额下限失败', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zuhgz', '组合', '组合规则', '是', '5', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '组合', '启用日期', '是', '2', '#Inside[GetDefaultTime]|', '否', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('pingzh', '票据', '凭证号', '是', '3', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '账户', '账号', '是', '2', null, '是', '1', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('kehh', '账户', '客户号', '是', '4', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('hum', '账户', '户名', '是', '3', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jigh', '账户', '机构号', '是', '5', '#Inside[GetInitDefault]|S[guiyjgh]', '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('diz', '账户', '地址', '否', '13', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('youzbm', '账户', '邮政编码', '否', '15', null, '否', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('kaihrq', '账户', '开户日期', '是', '10', '#Inside[GetDefaultTime]|', '否', '1', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '账户', '启用日期', '否', '11', '#Inside[GetDefaultTime]|', '否', '1', null, null, '@inside[CompareValidator]|>=,2,C[kaihrq]@inside[CompareValidator]|%,3,C[kaihrq]', null, '启用日期不能小于开户日期并且时间间隔不能超过3个月', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tongctd', '账户', '通存通兑', '是', '9', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('bingxq', '账户', '并行期', '否', '9', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jine', '票据', '金额', '是', '4', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('pingzlx', '验印', '凭证类型', '是', '1', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '审核', '账号', '是', '1', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '验印', '账号', '是', '1', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('xitlx', '印鉴', '系统类型', '是', '2', null, '是', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('xitlx', '组合', '系统类型', '是', '1', null, '否', '2', null, null, null, null, null, '1', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('chuprq', '票据', '出票日期', '是', '5', null, '否', '1', null, null, '@inside[CompareNowDate]', null, '出票日期不允许为空！', '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjbh', '印鉴详情', '印鉴编号', '是', '3', null, '是', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '印鉴详情', '停用日期', '是', '6', null, '是', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '组合列表', '停用日期', '是', '7', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjkbh', '印鉴详情', '印鉴卡号', '是', '1', null, '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjlx', '印鉴详情', '印鉴种类', '是', '4', null, '是', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('yinjys', '印鉴详情', '印鉴颜色', '是', '5', null, '是', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '印鉴详情', '启用日期', '是', '2', '#Inside[GetDefaultTime]|', '是', '1', null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '票据', '账号', '是', '1', null, '否', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('fuyrq', '账户', '复用日期', '否', '12', null, '否', '1', null, null, '@inside[CompareValidator]|>=,2,C[kaihrq]@inside[CheckFuyrq]|C[zhuzh]', null, '复用日期不能早于开户日期', '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhuzh', '账户', '主账号', '否', '2', null, '是', '1', null, null, '$DLL[CommonMethods][Sinodata.CommonMethods][MethodLibrary][CheckZhuzh]|C[zhangh]', null, '主账号校验失败', '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('daxx', '票据', '大小写', '否', '6', null, '否', '2', null, null, null, '$不相符,相符', null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhangh', '组合列表', '账号', '否', '1', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jinexx', '组合列表', '金额下限', '是', '2', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('jinesx', '组合列表', '金额上限', '是', '3', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('xitlx', '组合列表', '系统类型', '是', '4', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zuhgz', '组合列表', '组合规则', '是', '5', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '组合列表', '启用日期', '是', '6', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('xitlx', '票据', '系统类型', '是', '2', null, '否', '2', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zuhshzt', '组合列表', '审核状态', '是', '9', null, '否', null, null, null, null, null, null, '0', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('zhanghzt', '账户', '账户状态', '是', '8', null, '否', '2', null, null, null, null, null, '2', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('tingyrq', '账户', '停用日期', '否', '11', null, '否', '1', null, null, null, null, null, '2', null, '是');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('guiyh', '双签', '柜员号', '是', '1', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('guiymm', '双签', '密  码', '是', '2', null, '是', '1', null, null, null, null, null, '0', null, '否');

insert into SHUXKZGXB (SHUXM, GONGNYM, ZHANSM, SHIFZS, ZHANSSX, MORZ, SHIFZHXS, ZHANSFS, SHURKZ, ZUIDCD, YANZZFC, SHUJY, TISXX, SHIFZD, LIANDFS, SHIFKK)
values ('qiyrq', '印鉴信息', '启用日期', '是', '3', null, '是', '1', null, null, null, null, null, '0', null, '是');



insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YY_meibzs', '各凭证每本张数不能超过1000！', '凭证参数设置', '新增凭证', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-ip_err2', '本机器已经有柜员【${clerknum}】登陆验印系统，不允许再次登陆！', '登陆', null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_account_isPost', '没有权限查询账号[${account}]', 'UREPORT报表', 'UREPORT报表', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_account_isNull', '[${account}]账号不存在', 'UREPORT报表', 'UREPORT报表', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-clerknum', '柜员号格式不正确！', null, null, '柜员错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_account_jygz', '柜员编号格式不正确，最少输入12位！', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_clerknum_isPost', '没有权限查询柜员[${clerknum}]', 'UREPORT报表', 'UREPORT报表', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('ureport_clerknum_isNull', '[${clerknum}]柜员不存在', 'UREPORT报表', 'UREPORT报表', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-import-ok', '导入数据成功！', null, null, '导入错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-import-error', '导入数据失败！', null, null, '导入错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-export-ok', '导出数据成功！', null, null, '导出成功提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-export-error', '导出数据失败，${exception}！', null, null, '导出错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-orgCode', '机构代码格式不正确,必须为5或6位数字！', null, null, '机构号错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-paymentCode', '人行支付系统行号格式不正确！', '机构管理', '添加机构', '人行支付系统行号提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-password', '柜员密码格式不正确！', null, null, '柜员密码提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-pwdError', '账号或密码错误，${leavetimes}次后用户将被锁定!', '登录', '登录', '密码错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-account', '账号格式不正确！', null, null, '账号错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-englishname', '客户号格式不正确！', '客户号查询', null, '客户号错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-checknum', '凭证号必须为10位字母或数字！', null, null, '凭证号提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYF-sealchecklog', '需要同时输入【账号+票据号】', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYF-voucherchecklog', '请输入：【账号】或【柜员号】（可以加上凭证号进行过滤）！', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-pwdErrorCat', '密码错误！', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYA-ip_err1', '柜员【${clerknum}】已在IP为:${clerkip}的机器上登录!', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY_PINGZH', '凭证号格式不正确！', '凭证销售', '凭证出售', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-juesid', '角色ID应为字母或数字', '角色管理', '添加角色', '角色id错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('PJCS_success', '录入成功！', null, null, '票据出售成功提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('PJCS_alreadyhave', '请重新录入！凭证号已存在！', null, null, '票据出售错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('PJCS_error', '录入过程发生错误！', null, null, '票据出售错误提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('pingzcssz_youxq', '有效期最多4位数字', '系统管理', '凭证参数设置', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('pingzxs_pzcs', '凭证号必须10位数字!', '凭证销售', '凭证出售', null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YYY-kagid', '卡柜编号格式不正确', null, null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YY_BENS', '本数必须是数字，且不能为0！', '凭证入库、领用、退回', null, null);

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('zhongk_ly', '凭证领用成功！', '重控凭证', '凭证领用', '领用成功提示');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('zhongk_th', '凭证退回成功！', '重控凭证', '凭证退回', '退回成功提示信息');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('zhongk_zf', '凭证作废成功！', '重控凭证', '凭证作废', '作废成功提示信息');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('zhongk_rk', '凭证入库成功！', '重控凭证', '凭证入库', '入库成功提示信息');

insert into TISXX (MSGID, MSGCONTENT, FUNCTIONAREA, FUNCTIONPOINT, REMARK)
values ('YY_pingzbs', '凭证标识为2位！', null, null, null);







insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('meibzs', '每本张数', '4', null, null, null, '/[0-9]{0,4}/', 'YY_meibzs', '限定各种凭证每本张数不超过1000');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('pingzhqz', '凭证前缀', '10', null, null, null, null, null, null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('account', '帐号', '30', 'width:175px;', null, null, '/^[a-zA-Z0-9]{1,30}$/', 'YYY-account', '账户简单查询，账户定制查询，日志查询，特殊业务');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('englishname', '客户号', '15', null, null, null, '/\w{15}/', 'YYY-englishname', '账户定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('clerknum_7', '柜员号', '8', null, null, null, '/(^\w{3,8})/', 'YYY-clerknum', '柜员管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('netpointflag', '机构号', '6', 'width:65px;', null, null, '/(^[0-9]{2,8}$)/', 'YYY-orgCode', '按机构清IP，账户定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('paymentCode', '人行支付系统行号', '12', null, null, null, '/[0-9]{12}/', 'YYY-paymentCode', '机构管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('password', '柜员密码', '6', null, null, null, '/\w{6}/', 'YYY-password', '柜员密码');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('gongnid', '功能id', null, null, null, null, '/[^\u4e00-\u9fa5]+/', null, '功能菜单定制');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zignid', '子功能ID', null, null, null, null, '/[^\u4e00-\u9fa5]+/', null, '功能菜单定制');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('BAOBBS', '报表标识', null, null, null, null, '/[^\u4e00-\u9fa5]+/', null, null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('password1', '柜员密码', '6', null, null, null, '/\w{6}/', 'YYY-password', '确认柜员密码');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('orgCode', '机构号', '6', 'width:65px;', null, null, '/(^{4}$)/', 'YYY-orgCode', '机构管理，机构凭证日志查询，账户信息定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('clerknum', '柜员号', '8', null, null, null, '/(^\w{3,8})/', 'YYY-clerknum', '管理员日志查询，验印日志定制查询，整票日志查询，单张日志查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('JIGH', '机构号', '6', 'width:65px;', null, null, '/(^[0-9]{2,8}$)/', 'YYY-orgCode', '账户审核查询，账户高级查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('checknum', '凭证号', '10', null, null, null, '/\w{10}/', 'YYY-checknum', '验印日志定制查询，整票日志查询，单张日志查询，验印结果当日查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('KEHH', '客户号', '15', null, null, null, '/[0-9]{15}/', 'YYY-englishname', '客户简单查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('begindate', '开始日期', '10', 'width:70px;', null, null, null, 'YYY-begindate', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('enddate', '结束日期', null, 'width:70px;', null, null, null, null, null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('jigh', '机构号', '6', 'width:155px;', null, null, '/(^[0-9]{2,8}$)/', 'YYY-orgCode', '账户审核查询，账户高级查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('password2', '原密码', '6', null, null, null, '/\w{6}/', 'YYY-password', '修改密码');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zhangh', '账号', '30', 'width:175px;', null, null, '/^[a-zA-Z0-9]{1,30}$/', 'YYY-account', '账户简单查询，账户定制查询，日志查询，特殊业务');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('guiyh', '柜员号', '8', null, null, null, '/(^\w{3,8})/', 'YYY-clerknum', '管理员日志查询，验印日志定制查询，整票日志查询，单张日志查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('organnum', '机构号', '6', 'width:65px;', null, null, '/(^[0-9]{2,8}$)/', 'YYY-orgCode', '机构管理，机构凭证日志查询，账户信息定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('qispzh', '起始凭证号', '10', null, null, null, '/[0-9]{10}/', 'pingzxs_pzcs', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zhongzpzh', '终止凭证号', '10', null, null, null, '/[0-9]{10}/', 'pingzxs_pzcs', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('juesid', '角色ID', '12', null, null, null, '/^(\w){1,12}$/', 'YYY-juesid', '角色管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('juesmc', '角色名称', '25', null, null, null, null, null, '角色管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('clerkname', '柜员名称', '20', null, null, null, null, null, null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('organname', '机构名称', '20', null, null, null, null, null, '机构管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('RIQFW', '月份格式', '6', 'width:62px;', null, null, null, 'RIQFW', '账户通过率、机构通过率');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('pingzbs', '凭证标识', '2', null, null, null, ' /^(\w){2,2}$/', 'YY_pingzbs', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('lingyjg', '领用机构号', '6', 'width:65px;', null, null, '/(^[0-9]{6}$)|(^[0-9]{5}$)/', 'YYY-orgCode', '重控凭证管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('rengwms', '任务描述', '100', null, null, null, null, null, '账户定制查询、验印日志定制查询');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('youxq', '有效期', '4', null, null, null, '/[0-9]{1,4}/', 'pingzcssz_youxq', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('qispzh_', '起始凭证号', '10', null, null, null, '/[0-9]{10}/', 'pingzxs_pzcs', '凭证入库、凭证退回、凭证作废');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('bens', '本数', '2', 'width:40px;', null, null, ' /[0-9]/', 'YY_BENS', '凭证入库');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('kagid', '卡柜编号', '20', null, null, null, '/^[0-9]{1,20}$/', 'YYY-kagid', '卡柜维护');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('rukjg', '入库机构', '6', 'width:65px;', null, null, ' /(^[0-9]{6}$)|(^[0-9]{5}$)/', 'YYY-orgCode', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('jiglyfzr', '机构领用负责人', '7', null, null, null, '/(^\w{7})|(^\w{6})/', 'YYY-clerknum', null);

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zh', '帐号', '32', 'width:175px;', null, null, '/^[a-zA-Z0-9]{1,32}$/', null, '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('hm', '户名', '120', 'width:175px;', null, null, null, null, '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('khh', '客户号', '15', 'width:175px;', null, null, '/[0-9]{15}/', 'YYY-englishname', '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('zhjgh', '账户机构号', '6', 'width:175px;', null, null, '/[0-9]{6}/', 'YYY-orgCode', '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('khrq', '开户日期', '10', 'width:175px;', null, null, '/[0-9]{10}/', 'YYY-begindate', '账户管理、印鉴审核');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('jgmc', '机构名称', '20', 'width:175px;', null, null, null, null, '机构管理');

insert into YEWGZ (YUANSID, YUANSNAME, MAXLENGTH, YUANSSTYLE, STYLECLASS, ISREADONLY, VALIDATERULE, MSGID, REMARK)
values ('bghkhrq', '变更后开户日期', '10', 'width:175px;', null, null, '/[0-9]{10}/', null, '印鉴审核');







insert into YINHDJ (ID, NAME, PID)
values ('1', '一级', null);

insert into YINHDJ (ID, NAME, PID)
values ('2', '二级', '1');







insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SystemMgrService_getSystetemNowDate', 'simpleQuery', 1, 'select to_char(sysdate,''yyyy-mm-dd hh24:mi:ss'') GETDATE from dual', '获取数据库时间(V3.0-引擎)', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getAttribute', 'simpleQuery', 1, ' select a.shuxm,a.gongnym,a.zhansm,a.zhanssx,a.morz,a.shifzd,a.shifzhxs,a.zhansfs,a.liandfs,a.shifkk,CASE WHEN (a.shurkz is null )or(a.shurkz = '''' ) THEN b.shurkz ELSE a.shurkz END shurkz,CASE WHEN (a.zuidcd is null )or(a.zuidcd = '''' ) THEN b.zuidcd ELSE a.zuidcd END zuidcd,CASE WHEN (a.yanzzfc is null )or(a.yanzzfc = '''' ) THEN b.yanzzfc ELSE a.yanzzfc END   yanzzfc,CASE WHEN (a.shujy is null )or(a.shujy = '''' ) THEN b.shujy ELSE a.shujy END shujy,CASE WHEN (a.tisxx is null )or(a.tisxx = '''' ) THEN b.tisxx ELSE a.tisxx END tisxx ,a.shifzs from shuxkzgxb a left join shuxkzb b on a.shuxm=b.shuxm order by a.gongnym,to_number(a.zhanssx)', '获取属性扩展相关数据（采用两表连接，排序显示）(V3.0-引擎)', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('JInitializeOcx', 'complexQuery', 1, 'getOcxVersionInfo,getAttribute,GetSysConfig,SystemMgrService_getSystetemNowDate', 'OCX初始化交易(V3.0-引擎)', 'getOcxVersionInfo,getAttribute,GetSysConfig,SystemMgrService_getSystetemNowDate');

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetQuanJlsh', 'simpleQuery', 1, 'select ''QG013''||to_char(sysdate,''yyyymmdd'')||lpad(to_char(YY_GUIMLS_SEQ.nextval),10,''0'') guimqjls  from dual', '生成全局流水号', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('GetSysConfig', 'simpleQuery', 1, 'select key,value from ocxkongzcsb order by key', '获取系统参数配置(V3.0-引擎)', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('getOcxVersionInfo', 'simpleQuery', 1, 'SELECT cansid, parametervalue FROM BSKONGZCS WHERE TYPE=''OCX版本参数''', '获取数据库OCX版本号(V3.0-引擎)', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('querySon', 'simpleQuery', 1, 'select b.instanceid , b.zhangh , b.imagekey , b.limit , b.ccode , b.chopindicator , b.recordsequence , b.signaturename ,b.errorid , b.errortxt , b.image yinjtp  from TASKZIB  a left join TASKJGZIB  b on a.instanceid = b.instanceid where  a.masterinstanceid =  :masterinstanceid and b.instanceid is not null  order by b.recordsequence ', '查询子任务结果表', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('CheckClerk', 'complexQuery', 1, 'selectClerk,selectClerkjues,addClerk,updateClerk,addjues,deletejues', 'AD域登录', 'selectClerk,selectClerkjues,addClerk,updateClerk,addjues,deletejues');

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addDad', 'simpleTrans', 1, 'insert into taskzhub(instanceid , managetype , zhangh , limit , ccode , clerkname , clerknum , clerkorgnum ) values(:instanceid , :managetype , :zhangh , :limit , :ccode , :clerkname , :clerknum , :clerkorgnum)', '主任务信息记录到主任务表', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('queryDad', 'simpleQuery', 1, 'select instanceid , zhangh , CROSSINDICATOR , instruction , noteline , occurrencecount , numberSignature , notoSignature , errorid , errortxt , customername from TASKZJGB where instanceid=:instanceid ', '查询主任务结果表', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('queryDad_vice', 'simpleQuery', 1, 'select  masterinstanceid , zhangh , limit , ccode , chopindicator , recordsequence , signaturename , imagekey from TASKJGFB where masterinstanceid = :masterinstanceid', '查询主任务结果表副表', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addSon', 'simpleTrans', 1, 'insert into TASKZIB(instanceid , masterinstanceid , zhangh , imagekey , limit , ccode , indicator , recordsequence , signaturename ) values(:instanceid  , :masterinstanceid , :zhangh , :imagekey , :limit , :ccode , :indicator , :recordsequence , :signaturename )', '子任务信息记录到子任务表', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('MQConfigure', 'simpleQuery', 1, 'select ip , port , mqlchannel , queuemanager , requestqueue , replyqueue , characterset , username , userpassword from MQconfigure', '查询MQ连接需要的配置信息', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addBillCheckLog', 'simpleTrans', 1, 'insert into  billchecklog   values(:taskid , :pich , :account , :customername , :zhangh , :groupmember , :branchname , :ccode , :limit , :checktype , :billresultmodel , :billresult , :remark , :clerknum , :clerkname , :clerkorgnum , :checkdate , :checktime , :pingzlx)', '添加整票验印日志', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addSealCheckLog', 'simpleTrans', 1, 'insert into  sealchecklog   values(:taskid , :chopsequence , :imagekey , :chopindicator , :chopname , :result , :resultmodel)', '添加单张验印日志', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('SaveCheckedResults', 'complexQuery', 1, 'addBillCheckLog,addSealCheckLog', '添加验印日志', 'addBillCheckLog,addSealCheckLog');

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('addjournal', 'simpleTrans', 1, 'insert  into  yinjcxrz(groupmenber , branchname , account , customername, enquirydate, enquirytime, clerknum, clerkname , clerkorgnum , remark) values (:groupmenber , :branchname , :account , :customername, :enquirydate, :enquirytime, :clerknum  , :clerkname , :clerkorgnum , :remark)', '添加印鉴查询日志', null);

insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH)
values ('MQGetSealList', 'complexQuery', 1, 'addDad,queryDad,queryDad_vice,addSon,querySon,MQConfigure,addjournal', 'MQ通讯', 'addDad,queryDad,queryDad_vice,addSon,querySon,MQConfigure,addjournal');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'selectClerk' , 'simpleQuery' , '1' , 'select clerknum , clerkpwd , n_organnum from clerktable where clerknum = :clerknum' , '查询clerk');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'selectClerkjues' , 'simpleQuery' , '1' , 'select * from guiyjsgxb where guiyid = :guiyid and juesid = :juesid' , '查询clerk 角色');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'addClerk' , 'simpleTrans' , '1' , 'insert into clerktable(CLERKNUM , clerkname , clerkpwd , n_organnum , shenghjgh ,wdflag ) values(:clerknum ,:clerkname , :clerkpwd ,:n_organnum , :shenghjgh ,:wdflag )' , '添加clerk');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'updateClerk' , 'simpleTrans' , '1' , 'update clerktable set clerkpwd  = :clerkpwd , postnum  = :postnum , postname  = :postname , n_updatedate  = :n_updatedate , n_organnum  = :n_organnum , n_error  = :n_error , n_logdate  = :n_logdate , n_ip  = :n_ip , n_creator  = :n_creator , shenghjgh  = :shenghjgh , wdflag  = :wdflag  where clerkname = :clerkname' , '更新clerk');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'addjues' , 'simpleTrans' , '1' , 'insert into guiyjsgxb values (:guiyid , :juesid , :beiz )' , '添加clerk角色');

insert into yq_jiaoynr(jiaoyid , jiaoylx , jiaoyzt , jiaoynr , jiaoybz) 
values( 'deletejues' , 'simpleTrans' , '1' , 'delete guiyjsgxb where guiyid = :guiyid and juesid = :juesid ' , '删除clerk角色');



insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accountname', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accountstamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accorgno', 'String', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accountstate', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accuser', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('address', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('admincode', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('allexchange', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcgydm', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcgymc', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkclerknum', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangcsj', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangjgn', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangjjgh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checknum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ceshi', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shebdm', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chinaname', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shenghjgh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifbt', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifdy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifyt', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifky', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifsc', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifxs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifzhxs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifzs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shij', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shoukrmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shoukrzh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shuangqgyh', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shuangqgymc', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinqbgh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinzjd', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cj_time', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_youbj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yzsf', 'float', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zhangh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zhaozq', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zhiphm', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zidclcz', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zidyylsh', 'string', 28);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_zuobj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('getdate', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('gongnid', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('gongnmc', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('gongnym', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('goofficenum', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('gudfbl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerknamebymanage', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerknum', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiyh', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerknumbymanage', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerkpwd', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiymc', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiz', 'string', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guizmc', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hangyxz', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('haspickupmoney', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('height', 'integer', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hengxzb', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('heqzt', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('historybackupcondition', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidaystr', 'string', 366);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayStr', 'string', 366);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayyear', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayyear1', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayyear2', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('holidayyeardata', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('huizqx', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('huizsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hum', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('huobh', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('id', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('idd', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imagemaxheight', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imagemaxwidth', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('img1', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('img2', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('img3', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imptype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('incomerange', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('industrycharacter', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('deletedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inimageleft', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inimagetop', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inputclerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('depict', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inputclerknum', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('inputdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int1', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int10', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int2', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int3', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int4', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int5', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int6', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int7', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int8', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('int9', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('io_cost', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isautosealagain', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isdownload', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isedit', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ishaspassword', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('account2', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accountcharacter', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fenytj', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fieldname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fieldtype', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fileinfo', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('filename', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('access_predicates', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accname', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('accno', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('account', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('filter_predicates', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fimgname', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('funcoption', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('functiondescribe', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('functionid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('functionname', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fuygy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fuz', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_caozsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_chulsxh', 'string', 37);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_chulzt', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_chuprq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_fazq', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_fenbl', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('topset', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tuxsy', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_fuygy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_gudfbl', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_hengxzb', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_id', 'string', 33);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_jiaohrq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_jine', 'float', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_lianjxtbh', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_lianjxtnxh', 'string', 28);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_shangbj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_shuxzb', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_waiwxtgy', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_wenjm', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangjqx', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('secretstring', 'string', 64);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sftype', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaosqy', 'string', 19);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shancrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shangbj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('auditdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('auditflag', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bankid', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('baobbs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('baobbt', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('baobmc', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bathid', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('beiscs', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('beisrqd', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('beiz', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hf3', 'integer', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkmode', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkperiod', 'string', 14);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('lianxr', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('licensecode', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjw', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjh', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qiyrqnew', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulzs', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('duank', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ipdiz', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwye', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwzs', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sheblx', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhuangt', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('juesjb', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiyjgh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fuyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quxfyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiankbs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tingyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiym', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanybs', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('henxzb', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjkh', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('taskid', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tasktype', 'integer', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pictype', 'integer', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('huoqyxfs', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youxj', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiyxm', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjkbhz', 'string', 250);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyd', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bianglx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shenhrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhengmwjm', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fanmwjm', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerkorgcode', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yewlx', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjks', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifzk', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzbsm', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('changedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shzt', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanyjg', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinjbh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('linkman', 'string', 125);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('logindate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('logintime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('lvalue', 'string', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('mainoperation', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('managecontent', 'string', 1000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinjbz', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yinjkbb', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('managedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('managetime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('managetype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('mandep', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('max_cast_sealinknum', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('max_number_yinjbh', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('maxcode', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('meaning', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('memoinfo', 'string', 512);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('mnsource', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('money', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moneydown', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moneydown1', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moneyup', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moneyup1', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('morz', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tuxmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shiffy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_basepostnum', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_creator', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_error', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_ip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_logdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_organnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_parentnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_paymentnum', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('n_updatedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('name', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('names', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('netpointflag', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('newcolumn', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('neworgannum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('newpostpopedom', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('newprocedurename', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('newtablename', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('noclerknum', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number1', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number2', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number3', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str47', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str48', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str49', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str5', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str50', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str6', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str7', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str8', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str9', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('suoyz', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('syncip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('syncport', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sysdate_string', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tableid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tablename', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tablenum', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tabletype', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('target', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('taskbegintime', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('taskflag', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tctd', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tel', 'string', 36);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('temp_space', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwbs', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwlx', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tg', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tichhh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('time', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('time_type', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('time_value', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('timestamp', 'string', 7);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('account1', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('postnum', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('lianjxtbh', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('lianjxtnxh', 'string', 28);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('postpopedom', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('printcount', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('procedureid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('projection', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('property', 'string', 64);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('publishcount', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('putoutdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('groupmenber', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('branchname', 'string', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('customername', 'string', 350);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enquirydate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enquirytime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('putouttime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pzhid', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qblock_name', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qiyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qiysj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quyid', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quymc', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qysj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('r_retflag', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('r_retmsg', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('registercapital', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('remark', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('remarks', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yfenbl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xfenbl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('faqsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fazq', 'string', 19);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quanxms', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quanxmc', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('quanxid', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('juesms', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('juesmc', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('juesid', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guiyid', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('extendcreditflag', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('type', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('unitname', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('up_date', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('up_okcount', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('up_time', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('updatedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('updatedbokflag', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('updateflag', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('updatetimes', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('upflag', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('upflage', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('auditclerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('auditclerknum', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('upokflag', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('uptime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('uvalue', 'string', 510);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('value', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('valverectdistance', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('version', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('versiondata', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('versionnum', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shujhqfs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shujy', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shunxh', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shurkz', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shuxm', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifqy', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanybj', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hf1', 'integer', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhuzh', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifkk', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('hf2', 'integer', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imagename', 'String', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkpwd', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkresult', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkstate', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checktime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('liandfs', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sql_id', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sql_value', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('startdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('state', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('statement_id', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('statue', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str1', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str10', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str11', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str12', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str13', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str14', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str15', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str16', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str17', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str18', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('riqfw_', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str19', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str2', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str20', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str21', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str22', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str23', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str24', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str25', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str26', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str27', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str28', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str29', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str3', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str30', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str31', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str32', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str33', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str34', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str35', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str36', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str37', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str38', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str39', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str4', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str40', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str41', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str42', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str43', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str44', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str45', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('str46', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jinexxnew', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jinesxnew', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuhgznew', 'string', 400);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitlxnew', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('code', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('codeend', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('codename', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('codestart', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('columnid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('combine_count', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('condition', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('content', 'string', 2000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cost', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('count', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('count_sameseal', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cpu_cost', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('crc', 'integer', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('credence_bktype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('credencestamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('credencetype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('creditgrade', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('currentbackupcondition', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('currentresource', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('currenttaborder', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dat10', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dat8', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dayfa', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dayzy', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('defaultresource', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('defaulttaborder', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('defaultvalue', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('delet', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('postalcode', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('postname', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('depth', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('description', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('desorg', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dianh', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('discaption', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('displaylength', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('displayname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('displayorder', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('distribution', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('diz', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('docimage', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('docname', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('docstamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('doctype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('doublesignatureclerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('doublesignatureclerknum', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('dz_field', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enableaudit', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fenbl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enablecheck', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enablemanage', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tisxx', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enableperiod', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enablesearch', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('encodetype', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enddate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('englishname', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('enterprisecharacter', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('error', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('exefilename', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('expression', 'string', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('verify_combines ', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('verify_seals', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('usable_combines', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('usable_seals', 'integer', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('rvalverect', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('s_enableupload', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('scantime', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealgrade', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkchangenum', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkcolor', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkcombinestamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkflag', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkimage', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkmaterial', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinknum', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('riqfw', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkstamp', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinkstate', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealinktype', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealnum', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealrect', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealrectbottomdistance', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sealrectdistance', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('search_columns', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('secretdata', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('secretkey', 'string', 64);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youxq', 'integer', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shuxzb', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('formid', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('qrcode', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('sql', 'string', 1000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifsy', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('waiwxtgy', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wc_time', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wdflag', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('weigyy', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjbh', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjfwcs', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjfwdk', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjfwdz', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjfwip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjm', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wenjmlph', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wg', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('width', 'integer', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wincontrol', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wmode', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wtrq', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wux', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('wx', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xhrs', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xhsj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xiabj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xianslx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xianssx', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitbs', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitlx', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitslrq', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xz_time', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xzsf', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yans', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanslx', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanybgyy', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanydj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyfs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyjb', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyjg', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyms', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanyrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanysj', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanywgyy', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanzzfc', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaosbs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaosbt', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaoscd', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaoshw', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaoslx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yaosmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yearcheckdate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yewtz1', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjbgh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjbh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjbz', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjian', 'blob', 16);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerk_organnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh_organnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjkbh', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjlb', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjlx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjshzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjtp', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjys', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjzl', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinqbgh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinqlx', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinzjd', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yjdm', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yjkh', 'string', 80);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yjtype', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yongt', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youbj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youwyj', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youwzh', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('youzbm', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yxlx', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yy_004', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yy_008', 'integer', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yyy', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yzsf', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh1', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh2', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh3', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhangh4', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanghqz', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanghshzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanghzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhansfs', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhansm', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanssx', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhaozq', 'string', 19);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhdm', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhengfbz', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhidbs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhifmm', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhuanhz', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidcd', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidclcz', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidkzcs', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidkzdk', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihy', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidkzip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidlx', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidm', 'string', 25);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zidyylsh', 'string', 28);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zipcode', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ziybs', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zongs', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zs', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuhgz', 'string', 400);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuhshzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuhzt', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuidcd', 'string', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zuobj', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zxsj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kapbh', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kehh', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('key', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('khsj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('leftset', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tonggzh', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('leix', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwrq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwzt', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tongdgz', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tonggl', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('reportdate', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('residualmoney', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('resourceid', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('responsibilityperson', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('result', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('rightset', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('rimgname', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('riq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bgyjdm', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_xiabj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_xzsf', 'float', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('biaos', 'string', 38);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanydj', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanyfs', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('billid', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bespeakmoney', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('billperiod', 'string', 14);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bingxq', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanslx', 'integer', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('fy_yanybgyy', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bottomset', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bufbz', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bytes', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('c_enabledownload', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('c_enableupload', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('caijzd', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansfl', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansid', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('canslx', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansm', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansmc', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('canssm', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansz', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('caozsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cardinality', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checkclerkname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuangjgy', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuangjjg', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulgy', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulrq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('bglx', 'integer', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulsj', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulsxh', 'string', 37);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chulzt', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuprkhhhh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuprmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuprq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chuprzh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cisfilename', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cisfn', 'string', 200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shifzd', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjjd', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yinjkbb', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number4', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number5', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number6', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('number7', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_alias', 'string', 65);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_instance', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_name', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_node', 'string', 128);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_owner', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('object_type', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('objectid', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldaccount', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldclerknum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldcolumn', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldexpression', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldmoneydown', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldmoneyup', 'float', 13);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldpostpopedom', 'string', 300);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldprocedurename', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('oldtablename', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('opendate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operate', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operatedate', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operatetime', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operatetype', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operation', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operdate', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('operorg', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('optimizer', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('guizbh', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('options', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('org_num', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organname', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organnum', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organnum_', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organnum1', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('organnum2', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('orgname', 'string', 2000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('other', 'integer', 0);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('other_tag', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('package', 'blob', 4000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parameter_type', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parameter_value', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('datetimenow', 'string', 25);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhiphm', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhlx', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanghxz', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanshi', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parametername', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parameternum', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parameterrefername', 'string', 30);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parametersort', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parametertype', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parametervalue', 'string', 40);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('parent_id', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('partition_id', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('partition_start', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('partition_stop', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('password', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('peryu', 'string', 24);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('phone', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('piaojcheckresult', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('moyz', 'string', 400);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('piaojhm', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('piaojyxdz', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzbs', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('expression1', 'string', 500);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzh', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzlx', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzzl', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('plan_id', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pofish', 'string', 24);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('position', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('reng', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('renwbh', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isview', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('isvisible', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandgydm', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandgymc', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandip', 'string', 15);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiandsj', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaohrq', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoybz', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoyid', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoylx', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoynr', 'string', 1000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoyxh', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoyzh', 'string', 255);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiaoyzt', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiedbs', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jigdm', 'string', 8);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jigh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jigmc', 'string', 120);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jine', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jinesx', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jinexx', 'string', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihhh', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihrq', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihsj', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('timestampnum', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tisfkrq', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('tongctd', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cannotnull', 'string', 2);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cansbs', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ysuof', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('yanzxx', 'string', 32);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xsuof', 'integer', 22);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('xitmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pingzmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('jiedmc', 'string', 100);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shenhy', 'String', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('kaihynum', 'string', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('shenhynum', 'String', 10);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('checktype', 'String', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('errorid', 'string', 7);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('errortxt', 'string', 78);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('image', 'blob', 130000);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('occurrencecount', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('numberSignature', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('notoSignature', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pich', 'string', 23);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('groupmember', 'string', 4);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('billresultmodel', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('billresult', 'string', 12);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chopsequence', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chopname', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('resultmodel', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('pinglx', 'string', 60);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('crossindicator', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('port', 'integer', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('mqlchannel', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('queuemanager', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('requestqeue', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('replyqueue', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('characterset', 'integer', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('username', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('userpassword', 'string', 50);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('instanceid', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('masterinstanceid', 'string', 20);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('zhanggh', 'string', 18);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('indicator', 'string', 1);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('instruction', 'string', 1305);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('noteline', 'string', 1200);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('limit', 'string', 14);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('ccode', 'string', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('recordsequence', 'string', 5);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('signaturename', 'string', 175);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('imagekey', 'string', 9);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('chopindicator', 'string', 6);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('cccode', 'string', 3);

insert into YQ_JIAOYZD (ZIDM, ZIDLX, ZIDCD)
values ('clerkorgnum', 'string', 8);






insert into YQ_KONGZCS (CANSBS, CANSMC, CANSLX, CANSFL, CANSZ, CANSSM)
values ('isBase64', null, null, null, '0', '保存印鉴时是否需要解码,1：不需要解码；0：解码，获取时再加密');



--mq参数
insert  into MQCONFIGURE values('133.10.221.122',8209,'ULCVS01CN.SVRCHL.01','ULCVS01CN','T.CVS.CN_CVS.CN_HUB.CVS_RQST','T.CVS.CN_HUB.CN_CVS.CVS_RESP',819,null,null);

insert into  ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HFYY' , '汇丰银行' , null , 1 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBCB' , '湖北随州曾都汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBCD' , '重庆大足汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBFU' , '福建永安汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBBJ' , '北京密云汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBGD' , '广东恩平汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBDP' , '大连普兰店汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBCF' , '重庆丰都汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBHT' , '湖北天门汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBCQ' , '重庆荣昌汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBHU' , '湖南平江汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBSD' , '山东荣成汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HBMC' , '湖北麻城汇丰村镇银行有限责任公司' , 'HFYY' , 2 , 'HFYY' ,  '是' );
INSERT INTO ORGANARCHIVES(ORGANNUM,ORGANNAME,N_PARENTNUM,WDFLAG,SHENGHJGH,TONGDGZ) VALUES('HSBC' , '汇丰银行（中国）' , 'HFYY' , 2 , 'HFYY' ,  '是' );



--生成全局流水号
--insert into yq_jiaoynr (JIAOYID, JIAOYLX, JIAOYZT, JIAOYNR, JIAOYBZ, JIAOYZH) values ('GetQuanJlsh', 'simpleQuery', 1, 'select ''QG013''||to_char(sysdate,''yyyymmdd'')||lpad(to_char(YY_GUIMLS_SEQ.nextval),10,''0'') guimqjls  from dual', '生成全局流水号', null);


INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01001', '系统管理员', '3', null, null, null);
INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01002', '管理员', '2', null, null, null);
INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01004', '查询员', '1', '印章查阅', null, null);
--INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01005', '审核员', '1', '印鉴审核员', null, null);
INSERT INTO JUESB (JUESID, JUESMC, JUESJB, JUESMS, SHIFXS, BEIZ) VALUES ('01006', '验印员', '1', '验印经办员', null, null);


insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('00029', '用户维护报告', 'orgCheckLog_huif.do?method=forward', 9, '50000', '69', '0', null, '0', '0', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('60005', '汇总报告', 'forwordbatchsealchecklog_huif.do', 9, '60000', null, '1', null, '0', '0', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('00028', '印章查询报表', 'sealqueryReport_huif.do?method=view', 9, '50000', null, '1', null, '0', '0', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('60004', '通过率', 'accountPassRate_huif.do?method=view', 9, '60000', '121', '1', null, '0', '0', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('60006', '交易明细报告', 'forwordvoucherchecklog_huif.do', 9, '60000', null, '1', null, '0', '0', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('50000', '印鉴查阅', null, 5, '1', null, '1', null, '0', null, null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('60000', '印鉴核验', null, 6, '1', null, '1', null, '0', null, null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('70000', '系统管理', null, 7, '1', null, '1', null, '0', null, null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('30000', '机构管理', 'main/org_manager.jsp', 9, '70000', '77', '1', null, '0', '0', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('30000', '添加', null, 9, '30000', '87', '1', null, '1', '1', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('30000', '删除', null, 9, '30000', '88', '1', null, '2', '1', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('30000', '导入', null, 9, '30000', '122', '1', null, '6', '1', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('30000', '导出', null, 9, '30000', '123', '1', null, '7', '1', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('30000', '修改', null, 9, '30000', '89', '1', null, '3', '1', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('37000', '角色管理', 'roleManager.do?method=list', 2, '70000', '125', '1', null, '0', '0', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('31000', '柜员管理', 'main/clerk_manager.jsp', 2, '70000', '80', '1', null, '0', '0', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('31000', '添加', null, 9, '31000', '98', '1', null, '1', '1', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('31000', '修改', null, 9, '31000', '99', '1', null, '2', '1', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('31000', '删除', null, 9, '31000', '100', '1', null, '3', '1', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('31000', '导出', null, 9, '31000', '121', '1', null, '5', '1', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('11110', '印章查阅与核验', null, 1, '1', '0', '0', null, '0', null, null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('11111', '印章核验', 'accountinfo.do?method=accInfoCheck', 9, '11110', '0', '1', null, '0', null, null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('11114', '印章查阅', 'accountinfo.do?method=yinjxxck', 14, '11110', '0', '1', null, '0', null, null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('38000', '密码重置', 'clerkManage.do?method=forwardReset', 9, '70000', '60', '1', null, '0', '0', null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('32123', '授权权限', 'shuangqts.jsp', 9, '99770', '0', '1', null, '0', null, null);

insert into chanpgncd (GONGNID, GONGNMC, GONGNURL, GONGNSX, SHANGJGN, QUANXWZ, ZHUANGT, BEIZ, ZIGNID, GONGNLX, CLASSID)
values ('1', '电子验印系统', null, 9, 'null', null, null, null, '0', '0', null);








insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '50000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '00028', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '00029', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '60000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '60006', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '60004', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '60005', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '70000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '31000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '31000|1', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '31000|2', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '31000|3', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '31000|5', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '37000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '30000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '30000|1', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '30000|2', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '30000|6', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '30000|7', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '30000|3', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01001', '38000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01004', '50000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01004', '00028', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01006', '50000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01006', '00028', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '50000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '00028', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '00029', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '60000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '60006', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '60004', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '60005', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '70000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '31000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '31000|1', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '31000|2', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '31000|3', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '31000|5', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01002', '38000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01006', '60000', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01006', '60006', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01006', '60004', null);

insert into JUESQXGXB (JUESID, QUANXID, BEIZ)
values ('01006', '60005', null);












commit;